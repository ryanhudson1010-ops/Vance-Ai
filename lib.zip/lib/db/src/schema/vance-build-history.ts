import { jsonb, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

export const vanceBuildHistory = pgTable("vance_build_history", {
  id: serial("id").primaryKey(),
  ts: timestamp("ts", { withTimezone: true }).notNull().defaultNow(),
  instruction: text("instruction").notNull(),
  filesChanged: jsonb("files_changed").notNull().default([]),
  summary: text("summary").notNull().default(""),
  snapshots: jsonb("snapshots").notNull().default([]),
  // Screenshots captured during this build (screenshot_app / run_e2e_test).
  // Each entry: { path: string (relative to repo .vance-screenshots/), label: string, ts: number }
  // Used so chat-mode Vance can find and reference screenshots from his own
  // recent build work when the user asks about them.
  screenshots: jsonb("screenshots").notNull().default([]),
});

export type VanceBuildHistoryRow = typeof vanceBuildHistory.$inferSelect;
export type InsertVanceBuildHistory = typeof vanceBuildHistory.$inferInsert;
