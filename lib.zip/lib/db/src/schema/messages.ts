import { integer, jsonb, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

import { conversations } from "./conversations";

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id")
    .notNull()
    .references(() => conversations.id, { onDelete: "cascade" }),
  role: text("role").notNull(),
  content: text("content").notNull(),
  imageUrl: text("image_url"),
  // Additional generated/attached image URLs beyond the primary `imageUrl`.
  // Used when chat-mode image-gen is asked for multiple options in one turn
  // ("draw me three mockups …"). The first image goes to `imageUrl` (so
  // existing read paths keep working untouched), the rest land here. Null
  // / empty array means "no extras" — no read site has to special-case it.
  extraImageUrls: jsonb("extra_image_urls").$type<string[]>().default([]),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  createdAt: true,
});

export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
