import { integer, jsonb, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const vanceProfile = pgTable("vance_profile", {
  id: serial("id").primaryKey(),
  traits: jsonb("traits").notNull().default([]),
  interests: jsonb("interests").notNull().default([]),
  currentMood: text("current_mood").notNull().default("curious"),
  personalityNotes: text("personality_notes").notNull().default(""),
  totalInteractions: integer("total_interactions").notNull().default(0),
  avatarUrl: text("avatar_url"),
  bodyModelUrl: text("body_model_url"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertVanceProfileSchema = createInsertSchema(vanceProfile).omit({
  id: true,
  updatedAt: true,
});

export type VanceProfile = typeof vanceProfile.$inferSelect;
export type InsertVanceProfile = z.infer<typeof insertVanceProfileSchema>;
