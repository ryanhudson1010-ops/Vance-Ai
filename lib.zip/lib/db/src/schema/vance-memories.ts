import { pgTable, serial, text, timestamp, boolean, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

import { messages } from "./messages";

export const vanceMemories = pgTable("vance_memories", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  category: text("category").notNull().default("general"),
  source: text("source").notNull().default("conversation"),
  // Pinned memories are ALWAYS re-attached to Vance's system prompt regardless
  // of how old they are or how many newer memories exist. Used for things the
  // user has explicitly told him to remember forever, plus auto-pinned for
  // user_fact / preference category memories extracted from chat.
  pinned: boolean("pinned").notNull().default(false),
  // Optional FK to the user message this memory was extracted from. Set when
  // extractAndLearn fires from a chat turn; null for voice extracts and for
  // anything created before this column existed. ON DELETE CASCADE means
  // deleting a chat bubble also wipes the memories spawned from it — wired
  // for the per-bubble X delete button. Pinned memories cascade too: the
  // user's stated intent in deleting the source message overrides pinning.
  sourceMessageId: integer("source_message_id").references(() => messages.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const insertVanceMemorySchema = createInsertSchema(vanceMemories).omit({
  id: true,
  createdAt: true,
});

export type VanceMemory = typeof vanceMemories.$inferSelect;
export type InsertVanceMemory = z.infer<typeof insertVanceMemorySchema>;
