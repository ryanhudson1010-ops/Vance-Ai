import { useEffect, useState } from "react";
import { Switch, Route, Router as WouterRouter, Link, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { MessageCircle, Brain, User, ImageIcon, ChartCandlestick } from "lucide-react";
import NotFound from "@/pages/not-found";
import Chat from "@/pages/Chat";
import Memories from "@/pages/Memories";
import Profile from "@/pages/Profile";
import TextToImage from "@/pages/TextToImage";
import Xrp from "@/pages/Xrp";
import Lock from "@/pages/Lock";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: 1, staleTime: 30000 },
  },
});

function NavItem({ href, icon, label }: { href: string; icon: React.ReactNode; label: string }) {
  const [location] = useLocation();
  const isActive = location === href;
  return (
    <Link
      href={href}
      data-testid={`nav-${label.toLowerCase()}`}
      className={`group relative flex min-w-[4.4rem] flex-col items-center gap-1 rounded-2xl px-3 py-2 text-[11px] font-medium tracking-wide transition-all duration-200 ${
        isActive
          ? "bg-primary/14 text-primary shadow-[0_12px_30px_rgba(245,179,74,0.16)] ring-1 ring-primary/25"
          : "text-muted-foreground hover:bg-white/[0.04] hover:text-foreground"
      }`}
    >
      <span
        aria-hidden
        className={`absolute inset-x-3 top-1 h-px rounded-full transition-opacity ${isActive ? "bg-primary/60 opacity-100" : "bg-white/20 opacity-0 group-hover:opacity-100"}`}
      />
      <span className={`transition-transform duration-200 ${isActive ? "scale-105" : "group-hover:scale-105"}`}>{icon}</span>
      <span>{label}</span>
    </Link>
  );
}

function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative flex h-screen min-h-0 flex-col overflow-hidden bg-background">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-x-0 top-0 h-40 bg-[radial-gradient(circle_at_top,rgba(245,179,74,0.14),transparent_60%)]" />
        <div className="absolute -left-24 top-20 h-72 w-72 rounded-full bg-violet-500/10 blur-3xl" />
        <div className="absolute -right-20 bottom-16 h-72 w-72 rounded-full bg-cyan-500/10 blur-3xl" />
      </div>
      <div
        className="relative min-h-0 flex-1 overflow-y-auto overscroll-y-contain"
        style={{ paddingTop: "calc(env(safe-area-inset-top) + 6px)" }}
      >
        {children}
      </div>
      <div className="safe-bottom px-3 pb-3 pt-2">
        <nav className="mx-auto flex max-w-3xl items-center justify-center gap-1 rounded-[1.75rem] border border-white/8 bg-sidebar/78 px-2 py-2 shadow-[0_-10px_40px_rgba(0,0,0,0.28)] backdrop-blur-2xl supports-[backdrop-filter]:bg-sidebar/60">
          <NavItem href="/" icon={<MessageCircle size={20} />} label="Chat" />
          <NavItem href="/memories" icon={<Brain size={20} />} label="Memories" />
          <NavItem href="/xrp" icon={<ChartCandlestick size={20} />} label="Crypto" />
          <NavItem href="/create" icon={<ImageIcon size={20} />} label="Create" />
          <NavItem href="/profile" icon={<User size={20} />} label="Profile" />
        </nav>
      </div>
    </div>
  );
}

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Chat} />
        <Route path="/memories" component={Memories} />
        <Route path="/xrp" component={Xrp} />
        <Route path="/create" component={TextToImage} />
        <Route path="/profile" component={Profile} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

// Passcode lock disabled — AuthGate is a no-op pass-through. To re-enable,
// restore the previous status check + <Lock /> render path.
function AuthGate({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
// Keep the import alive without rendering it so the file isn't dead-code-shaken
// inconsistently and re-enabling stays trivial.
void Lock;

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthGate>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
        </AuthGate>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
