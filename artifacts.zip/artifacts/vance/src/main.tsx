import { Component, type ErrorInfo, type ReactNode } from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { installErrorReporter } from "./lib/errorReporter";

// ── React error boundary ───────────────────────────────────────────────────
// Without this, ANY render-time throw inside the tree (a malformed message,
// a bad date, a third-party widget that hates an iOS UA quirk) white-screens
// the entire PWA — Vance just disappears.  This boundary catches the throw,
// logs it via the existing error reporter, and shows a recovery card with a
// Reload button so the user can get back into the app without force-quitting
// the PWA from the home screen.
interface BoundaryState { hasError: boolean; error: Error | null; }
class RootErrorBoundary extends Component<{ children: ReactNode }, BoundaryState> {
  state: BoundaryState = { hasError: false, error: null };
  static getDerivedStateFromError(error: Error): BoundaryState {
    return { hasError: true, error };
  }
  componentDidCatch(error: Error, info: ErrorInfo): void {
    // Surface to the existing error ring so chat-mode Vance can see it.
    try {
      window.dispatchEvent(new ErrorEvent("error", {
        error,
        message: error.message,
        filename: info.componentStack ?? "",
      }));
    } catch { /* noop */ }
  }
  reset = (): void => {
    // Hard reload — safer than just clearing state because the broken
    // component tree may have left HMR/hooks in an inconsistent place.
    window.location.reload();
  };
  render(): ReactNode {
    if (!this.state.hasError) return this.props.children;
    const msg = this.state.error?.message ?? "Unknown error";
    return (
      <div style={{
        minHeight: "100vh", display: "flex", flexDirection: "column",
        alignItems: "center", justifyContent: "center", padding: "2rem",
        background: "linear-gradient(180deg, #0a0a14 0%, #15152a 100%)",
        color: "#e6e6f0", fontFamily: "system-ui, -apple-system, sans-serif",
        textAlign: "center", gap: "1.25rem",
      }}>
        <div style={{ fontSize: "1.4rem", fontWeight: 600 }}>Vance hit a snag</div>
        <div style={{ maxWidth: "28rem", opacity: 0.7, fontSize: "0.95rem", lineHeight: 1.5 }}>
          The interface threw an error and recovered safely. Tap reload to come back — your chats and memories are intact.
        </div>
        <pre style={{
          maxWidth: "32rem", overflow: "auto", padding: "0.75rem 1rem",
          background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)",
          borderRadius: "0.5rem", fontSize: "0.75rem", opacity: 0.8,
          textAlign: "left", whiteSpace: "pre-wrap", wordBreak: "break-word",
        }}>{msg}</pre>
        <button onClick={this.reset} style={{
          padding: "0.65rem 1.5rem", borderRadius: "9999px", border: "none",
          background: "#14b8a6", color: "#0a0a14", fontWeight: 600,
          fontSize: "0.95rem", cursor: "pointer",
        }}>Reload Vance</button>
      </div>
    );
  }
}

installErrorReporter();
createRoot(document.getElementById("root")!).render(
  <RootErrorBoundary>
    <App />
  </RootErrorBoundary>
);
