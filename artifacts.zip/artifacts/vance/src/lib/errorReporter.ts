// Background error reporter.
//
// Hooks browser-level error sources (uncaught exceptions and unhandled
// promise rejections) and forwards each captured error to the API server's
// in-memory ring at POST /api/vance/errors.  Also keeps a local copy the
// chat UI can read synchronously to show an "errors pending" badge.
//
// We deliberately do NOT wrap console.error — it's far too noisy (React
// streaming/render warnings, third-party libs) and creates feedback loops
// that lock up the browser.  Real bugs surface as uncaught exceptions or
// unhandled rejections; that's what we capture.

export interface CapturedError {
  id: string;
  ts: number;
  source: "window.onerror" | "unhandledrejection";
  message: string;
  stack?: string;
  url?: string;
  line?: number;
  col?: number;
}

const RING_SIZE = 50;
const ring: CapturedError[] = [];
const listeners = new Set<() => void>();
let unread = 0;
let installed = false;

function nextId(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

function notify(): void {
  for (const fn of listeners) {
    try { fn(); } catch { /* noop */ }
  }
}

function dedupeKey(e: CapturedError): string {
  return `${e.source}|${e.message}|${e.line ?? ""}|${e.col ?? ""}`;
}
const seenKeys = new Map<string, number>();
const DEDUPE_WINDOW_MS = 5000;

// Hard rate limit: no more than this many records per rolling second.  If we
// exceed it we silently drop further captures — we'd rather lose a couple of
// errors than freeze the browser in a feedback loop.
const RATE_LIMIT_PER_SEC = 5;
const recentTimestamps: number[] = [];

function record(e: CapturedError): void {
  const now = Date.now();

  // Time-windowed dedupe across the last few seconds (not just consecutive)
  const lastSeen = seenKeys.get(dedupeKey(e));
  if (lastSeen !== undefined && now - lastSeen < DEDUPE_WINDOW_MS) return;
  seenKeys.set(dedupeKey(e), now);
  if (seenKeys.size > 200) {
    // Trim old keys
    for (const [k, t] of seenKeys) {
      if (now - t > DEDUPE_WINDOW_MS) seenKeys.delete(k);
    }
  }

  // Rate limit
  while (recentTimestamps.length > 0 && now - recentTimestamps[0]! > 1000) {
    recentTimestamps.shift();
  }
  if (recentTimestamps.length >= RATE_LIMIT_PER_SEC) return;
  recentTimestamps.push(now);

  ring.push(e);
  if (ring.length > RING_SIZE) ring.shift();
  unread++;
  notify();

  // Fire-and-forget POST to backend ring.  Use keepalive so it survives an
  // immediate page unload when the error itself crashes the SPA.
  try {
    void fetch("/api/vance/errors", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(e),
      keepalive: true,
    }).catch(() => { /* swallow */ });
  } catch { /* noop */ }
}

function truncate(s: string, max = 4000): string {
  return s.length > max ? s.slice(0, max) + "…[truncated]" : s;
}

export function installErrorReporter(): void {
  if (installed) return;
  installed = true;
  if (typeof window === "undefined") return;

  window.addEventListener("error", (ev) => {
    const err = ev.error as Error | undefined;
    record({
      id: nextId(),
      ts: Date.now(),
      source: "window.onerror",
      message: truncate(err?.message ?? ev.message ?? "Unknown error"),
      stack: err?.stack ? truncate(err.stack) : undefined,
      url: ev.filename || undefined,
      line: ev.lineno || undefined,
      col: ev.colno || undefined,
    });
  });

  window.addEventListener("unhandledrejection", (ev) => {
    const r = ev.reason as unknown;
    let message = "Unhandled promise rejection";
    let stack: string | undefined;
    if (r instanceof Error) {
      message = r.message || message;
      stack = r.stack;
    } else if (typeof r === "string") {
      message = r;
    } else if (r && typeof r === "object") {
      try { message = JSON.stringify(r); } catch { /* noop */ }
    }
    record({
      id: nextId(),
      ts: Date.now(),
      source: "unhandledrejection",
      message: truncate(message),
      stack: stack ? truncate(stack) : undefined,
    });
  });
}

export function getRecentErrors(): CapturedError[] {
  return ring.slice();
}

export function getUnreadErrorCount(): number {
  return unread;
}

export function markErrorsRead(): void {
  if (unread === 0) return;
  unread = 0;
  notify();
}

export function clearLocalErrors(): void {
  ring.length = 0;
  unread = 0;
  notify();
}

export function subscribeErrors(fn: () => void): () => void {
  listeners.add(fn);
  return () => { listeners.delete(fn); };
}

export function formatErrorsForPrompt(errors: CapturedError[]): string {
  if (errors.length === 0) return "(no errors captured)";
  return errors
    .map((e, i) => {
      const when = new Date(e.ts).toISOString();
      const loc = e.url ? ` at ${e.url}:${e.line ?? "?"}:${e.col ?? "?"}` : "";
      const stack = e.stack ? `\n  stack:\n${e.stack.split("\n").map((l) => "    " + l).join("\n")}` : "";
      return `#${i + 1} [${when}] (${e.source})${loc}\n  message: ${e.message}${stack}`;
    })
    .join("\n\n");
}
