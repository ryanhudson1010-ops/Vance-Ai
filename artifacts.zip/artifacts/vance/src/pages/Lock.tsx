import { useState } from "react";

export default function Lock({ onUnlock }: { onUnlock: () => void }) {
  const [passcode, setPasscode] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!passcode || loading) return;
    setLoading(true);
    setError(null);
    try {
      const resp = await fetch(`${import.meta.env.BASE_URL}api/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ passcode }),
      });
      if (!resp.ok) {
        const data = (await resp.json().catch(() => ({}))) as { error?: string };
        setError(data.error || "Wrong passcode");
        setPasscode("");
        setLoading(false);
        return;
      }
      onUnlock();
    } catch {
      setError("Network error — please try again.");
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-background px-6">
      <img
        src={`${import.meta.env.BASE_URL}vance-avatar-default.png`}
        alt="Vance"
        className="w-28 h-28 rounded-full mb-6 ring-2 ring-primary/30 shadow-2xl"
      />
      <h1 className="text-3xl font-serif text-foreground mb-1">Vance</h1>
      <p className="text-sm text-muted-foreground mb-8">Enter your passcode to continue</p>

      <form onSubmit={submit} className="w-full max-w-xs flex flex-col gap-3">
        <input
          type="password"
          inputMode="numeric"
          autoFocus
          autoComplete="current-password"
          value={passcode}
          onChange={(e) => {
            setPasscode(e.target.value);
            setError(null);
          }}
          placeholder="• • • •"
          className="text-center text-2xl tracking-[0.5em] py-4 rounded-2xl bg-card border border-card-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
        />
        {error && (
          <div className="text-center text-sm text-destructive">{error}</div>
        )}
        <button
          type="submit"
          disabled={!passcode || loading}
          className="bg-primary text-primary-foreground py-3 rounded-2xl font-medium disabled:opacity-50 transition-opacity"
        >
          {loading ? "Unlocking…" : "Unlock"}
        </button>
      </form>
    </div>
  );
}
