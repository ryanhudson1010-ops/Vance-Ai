import { useEffect, useRef, useState } from "react";
import {
  ImageIcon, Sparkles, Download, RotateCcw, ExternalLink, Wand2,
} from "lucide-react";

// ─── Pollinations.ai · free, no signup, no queue, no key ───────────────────
// Direct image URLs: https://image.pollinations.ai/prompt/{encoded}?...
// Returns a PNG immediately. Browser renders via <img>.

const STYLES = [
  "Photorealistic", "Cinematic", "Oil painting",
  "Watercolor", "Anime", "Dark fantasy", "Sketch", "Cyberpunk",
];

type ModelOpt = { id: string; label: string; blurb: string };
const MODELS: ModelOpt[] = [
  { id: "flux",          label: "FLUX",          blurb: "Default · best all-rounder" },
  { id: "flux-realism",  label: "FLUX Realism",  blurb: "Photo-style"               },
  { id: "flux-anime",    label: "FLUX Anime",    blurb: "Anime / illustration"      },
  { id: "flux-3d",       label: "FLUX 3D",       blurb: "3D render look"            },
  { id: "turbo",         label: "Turbo",         blurb: "Fastest, lower quality"    },
];

const ASPECTS = [
  { id: "square",    label: "Square",    icon: "▢", w: 1024, h: 1024 },
  { id: "portrait",  label: "Portrait",  icon: "▯", w: 768,  h: 1280 },
  { id: "landscape", label: "Landscape", icon: "▭", w: 1280, h: 768  },
] as const;

const COUNTS = [1, 2, 3] as const;

type Aspect = typeof ASPECTS[number]["id"];
type Count  = typeof COUNTS[number];

type Generated = {
  url:     string;
  seed:    number;
  prompt:  string;
  width:   number;
  height:  number;
  model:   string;
  loaded:  boolean;
  failed:  boolean;
  started: number;
};

const PER_IMAGE_TIMEOUT_MS = 95_000;
// Pollinations rate-limits to roughly 1 concurrent generation per IP, so we
// run tiles strictly sequentially. STAGGER_MS is the small breather we add
// between tiles after the previous one finishes (gives the upstream queue
// time to release the slot).
const INTER_TILE_PAUSE_MS  = 600;

const PERCHANCE_URL = "https://perchance.org/ai-text-to-image-generator";
const PERCHANCE_VIDEO_URL = "https://perchance.org/pretty-ai-video-generator";
const WAN_VIDEO_URL = "https://create.wan.video/";
const NSFW_WAN_URL = "https://www.nsfwwan.video/en";

function buildUrl(opts: { prompt: string; model: string; width: number; height: number; seed: number }): string {
  const params = new URLSearchParams({
    width:   String(opts.width),
    height:  String(opts.height),
    model:   opts.model,
    seed:    String(opts.seed),
    nologo:  "true",
    private: "true",
    nofeed:  "true",
    safe:    "false",
    _t:      String(Date.now()),
  });
  return `https://image.pollinations.ai/prompt/${encodeURIComponent(opts.prompt)}?${params}`;
}

function randomSeed(): number {
  return Math.floor(Math.random() * 2_147_483_647);
}

export default function TextToImage() {
  const [prompt,    setPrompt]    = useState("");
  const [negPrompt, setNegPrompt] = useState("");
  const [style,     setStyle]     = useState("");
  const [modelId,   setModelId]   = useState<string>(MODELS[0].id);
  const [aspect,    setAspect]    = useState<Aspect>("square");
  const [count,     setCount]     = useState<Count>(1);
  const [seed,      setSeed]      = useState("");

  const [images,    setImages]    = useState<Generated[]>([]);
  const [error,     setError]     = useState<string | null>(null);
  const [loading,   setLoading]   = useState(false);

  const abortersRef = useRef<Map<number, AbortController>>(new Map());
  const objectUrlsRef = useRef<Set<string>>(new Set());

  const cancelRef = useRef(false);
  useEffect(() => () => {
    cancelRef.current = true;
    abortersRef.current.forEach(c => { try { c.abort(); } catch { /* ignore */ } });
    abortersRef.current.clear();
    objectUrlsRef.current.forEach(u => URL.revokeObjectURL(u));
    objectUrlsRef.current.clear();
  }, []);

  function buildTile(args: { fullPrompt: string; model: string; width: number; height: number; seed: number }): Generated {
    return {
      url: "", seed: args.seed, prompt: args.fullPrompt, model: args.model,
      width: args.width, height: args.height,
      loaded: false, failed: false, started: Date.now(),
    };
  }

  async function fetchTile(idx: number, tile: Generated, errorLabel: (msg: string) => void) {
    const controller = new AbortController();
    abortersRef.current.set(idx, controller);
    const timeoutId = setTimeout(() => controller.abort("timeout"), PER_IMAGE_TIMEOUT_MS);

    const sourceUrl = buildUrl({
      prompt: tile.prompt, model: tile.model,
      width: tile.width, height: tile.height, seed: tile.seed,
    });
    // Route through our server proxy: bypasses CORS + iOS PWA fetch quirks
    // that silently drop direct cross-origin image fetches to pollinations.
    const proxyUrl = `/api/vance/proxy-image?url=${encodeURIComponent(sourceUrl)}`;

    try {
      const r = await fetch(proxyUrl, { signal: controller.signal });
      if (!r.ok) {
        const reason =
          r.status === 429 ? "Rate-limited by Pollinations (too many requests). Wait ~30s and try again."
          : r.status === 502 || r.status === 503 || r.status === 504 ? `Pollinations is busy (${r.status}). Try again in a moment.`
          : `HTTP ${r.status} from Pollinations.`;
        errorLabel(reason);
        setImages(curr => curr.map((g, i) => i === idx ? { ...g, failed: true } : g));
        return;
      }
      const blob = await r.blob();
      const objUrl = URL.createObjectURL(blob);
      objectUrlsRef.current.add(objUrl);
      setImages(curr => curr.map((g, i) => i === idx ? { ...g, url: objUrl, loaded: true } : g));
    } catch (e: unknown) {
      if (controller.signal.aborted && controller.signal.reason === "timeout") {
        errorLabel("Timed out — Pollinations is overloaded right now. Try again in a moment or pick a different model.");
      } else if (controller.signal.aborted) {
        return;
      } else {
        const msg = e instanceof Error ? e.message : "network error";
        errorLabel(`Network error: ${msg}`);
      }
      setImages(curr => curr.map((g, i) => i === idx ? { ...g, failed: true } : g));
    } finally {
      clearTimeout(timeoutId);
      abortersRef.current.delete(idx);
    }
  }

  function handleGenerate() {
    if (!prompt.trim() || loading) return;

    abortersRef.current.forEach(c => { try { c.abort(); } catch { /* ignore */ } });
    abortersRef.current.clear();
    objectUrlsRef.current.forEach(u => URL.revokeObjectURL(u));
    objectUrlsRef.current.clear();

    const fullPrompt = [
      prompt.trim(),
      style || null,
      negPrompt.trim() ? `avoid: ${negPrompt.trim()}` : null,
    ].filter(Boolean).join(", ");

    const a = ASPECTS.find(x => x.id === aspect)!;
    const baseSeed = seed.trim() ? Number(seed.trim()) : randomSeed();

    const tiles: Generated[] = Array.from({ length: count }).map((_, i) => {
      const s = Number.isFinite(baseSeed) ? baseSeed + i : randomSeed();
      return buildTile({ fullPrompt, model: modelId, width: a.w, height: a.h, seed: s });
    });

    setError(null);
    setImages(tiles);
    setLoading(true);

    let lastErrorReason = "";
    const setLastErr = (m: string) => { lastErrorReason = m; };

    // Sequential: wait for each tile to finish before starting the next.
    // Pollinations rejects parallel requests from the same IP with 429.
    (async () => {
      for (let i = 0; i < tiles.length; i++) {
        if (cancelRef.current) return;
        await fetchTile(i, tiles[i], setLastErr);
        if (cancelRef.current) return;
        if (i < tiles.length - 1) {
          await new Promise((r) => setTimeout(r, INTER_TILE_PAUSE_MS));
        }
      }
      setImages(curr => {
        if (curr.length > 0 && curr.every(g => g.failed)) {
          setError(lastErrorReason || "All images failed to load. Try again or pick a different model.");
        }
        return curr;
      });
    })();
  }

  function retryTile(idx: number) {
    setImages(curr => curr.map((g, i) => {
      if (i !== idx) return g;
      const newSeed = randomSeed();
      const fresh: Generated = { ...g, seed: newSeed, url: "", loaded: false, failed: false, started: Date.now() };
      setTimeout(() => fetchTile(idx, fresh, (m) => setError(m)), 0);
      return fresh;
    }));
    setLoading(true);
  }

  useEffect(() => {
    if (!loading || images.length === 0) return;
    if (images.every(g => g.loaded || g.failed)) setLoading(false);
  }, [images, loading]);

  async function handleDownload(url: string) {
    try {
      const r = await fetch(url);
      const blob = await r.blob();
      const objUrl = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = objUrl;
      a.download = `image-${Date.now()}.png`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(objUrl), 1000);
    } catch {
      window.open(url, "_blank");
    }
  }

  function handleReset() {
    setImages([]);
    setPrompt("");
    setStyle("");
    setNegPrompt("");
    setError(null);
    setSeed("");
  }

  function handleStop() {
    abortersRef.current.forEach(c => { try { c.abort(); } catch { /* ignore */ } });
    abortersRef.current.clear();
    objectUrlsRef.current.forEach(u => URL.revokeObjectURL(u));
    objectUrlsRef.current.clear();
    setImages([]);
    setLoading(false);
    setError(null);
  }

  function handleReuseSeed(s: number) { setSeed(String(s)); }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) handleGenerate();
  }

  const model = MODELS.find(m => m.id === modelId) ?? MODELS[0];

  // Reusable label class — small caps, premium tracking.
  const labelClass = "text-[10px] font-semibold text-white/55 uppercase tracking-[0.2em]";

  return (
    <div className="relative min-h-full">
      {/* Aurora accent blobs */}
      <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -left-24 -top-20 h-72 w-72 rounded-full bg-fuchsia-500/12 blur-3xl" />
        <div className="absolute right-[-6rem] top-32 h-72 w-72 rounded-full bg-violet-500/12 blur-3xl" />
        <div className="absolute left-1/3 bottom-[-4rem] h-72 w-72 rounded-full bg-cyan-500/10 blur-3xl" />
      </div>

      <div className="relative mx-auto max-w-3xl px-4 py-8 pb-10 sm:py-10 flex flex-col gap-5">
        {/* Header card */}
        <div className="rounded-3xl border border-white/8 bg-white/[0.04] backdrop-blur-2xl px-5 py-5 md:px-7 md:py-6 shadow-[0_18px_60px_rgba(0,0,0,0.32)]">
          <div className="flex items-start gap-4">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-fuchsia-500/30 to-violet-500/20 border border-white/15 flex items-center justify-center shrink-0">
              <ImageIcon size={20} className="text-white/90" />
            </div>
            <div className="flex-1 min-w-0">
              <h1 className="font-serif text-2xl md:text-3xl text-foreground leading-tight">Text to Image</h1>
              <p className="text-muted-foreground text-[13px] md:text-sm mt-1">Pollinations · {model.label} · free, no signup, no queue.</p>
            </div>
            <div className="hidden sm:flex items-center gap-1.5">
              <a
                href={PERCHANCE_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-white/[0.05] border border-white/10 text-xs text-white/75 hover:bg-white/10 hover:text-white transition-all"
                title="Open Perchance image generator in a new tab"
              >
                <ExternalLink size={12} />
                Perchance
              </a>
              <a
                href={PERCHANCE_VIDEO_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-white/[0.05] border border-white/10 text-xs text-white/75 hover:bg-white/10 hover:text-white transition-all"
                title="Open Perchance Pretty AI Video generator in a new tab"
              >
                <ExternalLink size={12} />
                Pretty AI Video
              </a>
              <a
                href={WAN_VIDEO_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-gradient-to-br from-violet-500/20 to-fuchsia-500/15 border border-violet-400/30 text-xs text-white/85 hover:from-violet-500/30 hover:to-fuchsia-500/20 hover:text-white transition-all"
                title="Open Wan 2.2 video generator in a new tab"
              >
                <ExternalLink size={12} />
                Wan 2.2
              </a>
              <a
                href={NSFW_WAN_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-gradient-to-br from-rose-500/20 to-pink-500/15 border border-rose-400/30 text-xs text-white/85 hover:from-rose-500/30 hover:to-pink-500/20 hover:text-white transition-all"
                title="Open NSFW Wan video generator in a new tab"
              >
                <ExternalLink size={12} />
                NSFW Wan
              </a>
            </div>
          </div>
        </div>

        {/* PROMPT — hero card. Big, prominent. */}
        <div
          className="relative overflow-hidden rounded-3xl border border-violet-400/25 bg-gradient-to-br from-violet-500/[0.10] via-white/[0.035] to-fuchsia-500/[0.08] backdrop-blur-2xl p-5 md:p-6 shadow-[0_22px_60px_rgba(0,0,0,0.32),0_0_30px_rgba(167,139,250,0.10)] focus-within:border-violet-400/50 focus-within:shadow-[0_22px_60px_rgba(0,0,0,0.32),0_0_40px_rgba(167,139,250,0.20)] transition-all"
        >
          <label className={`${labelClass} flex items-center gap-2 mb-3`}>
            <Sparkles size={11} className="text-violet-300" />
            Describe your image
          </label>
          <div className="relative">
            <textarea
              value={prompt}
              onChange={e => setPrompt(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="A neon-lit Tokyo street at dusk, cinematic, ultra-detailed…"
              rows={4}
              className="w-full resize-none bg-transparent text-[15px] md:text-base text-white placeholder:text-white/35 focus:outline-none leading-relaxed"
            />
            <span className="absolute bottom-0 right-0 text-[10px] text-white/30">⌘↵ to generate</span>
          </div>
        </div>

        {/* SETTINGS GRID */}
        <div className="grid gap-3 md:grid-cols-2">
          {/* Model dropdown */}
          <div className="rounded-2xl border border-white/8 bg-white/[0.035] backdrop-blur-xl p-4">
            <label className={`${labelClass} block mb-2`}>Model</label>
            <select
              value={modelId}
              onChange={e => setModelId(e.target.value)}
              className="w-full rounded-xl bg-black/30 border border-white/10 px-3 py-2.5 text-sm text-white focus:outline-none focus:border-violet-400/50 focus:ring-1 focus:ring-violet-400/30 transition-all"
            >
              {MODELS.map(m => (
                <option key={m.id} value={m.id}>{m.label} — {m.blurb}</option>
              ))}
            </select>
          </div>

          {/* Negative prompt */}
          <div className="rounded-2xl border border-white/8 bg-white/[0.035] backdrop-blur-xl p-4">
            <label className={`${labelClass} block mb-2`}>Avoid</label>
            <input
              type="text"
              value={negPrompt}
              onChange={e => setNegPrompt(e.target.value)}
              placeholder="blurry, watermark, low quality…"
              className="w-full rounded-xl bg-black/30 border border-white/10 px-3 py-2.5 text-sm placeholder:text-white/35 focus:outline-none focus:border-violet-400/50 transition-all"
            />
          </div>
        </div>

        {/* Style */}
        <div className="rounded-2xl border border-white/8 bg-white/[0.035] backdrop-blur-xl p-4">
          <label className={`${labelClass} block mb-3`}>Style</label>
          <div className="flex flex-wrap gap-2">
            {STYLES.map(s => (
              <button
                key={s}
                onClick={() => setStyle(style === s ? "" : s)}
                className={`px-3 py-1.5 rounded-full text-[11.5px] font-medium border transition-all ${
                  style === s
                    ? "bg-violet-500/20 border-violet-400/55 text-violet-200 shadow-[0_0_14px_rgba(167,139,250,0.25)]"
                    : "bg-white/[0.04] border-white/10 text-white/60 hover:border-white/25 hover:text-white hover:-translate-y-[1px]"
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Aspect + Count */}
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="rounded-2xl border border-white/8 bg-white/[0.035] backdrop-blur-xl p-4">
            <label className={`${labelClass} block mb-3`}>Aspect Ratio</label>
            <div className="flex gap-2">
              {ASPECTS.map(a => (
                <button
                  key={a.id}
                  onClick={() => setAspect(a.id)}
                  className={`flex-1 px-2 py-2.5 rounded-xl text-[12px] font-medium border transition-all flex items-center justify-center gap-1.5 ${
                    aspect === a.id
                      ? "bg-cyan-500/15 border-cyan-400/55 text-cyan-200 shadow-[0_0_14px_rgba(34,211,238,0.20)]"
                      : "bg-white/[0.04] border-white/10 text-white/60 hover:border-white/25 hover:text-white"
                  }`}
                >
                  <span className="text-base leading-none">{a.icon}</span>
                  {a.label}
                </button>
              ))}
            </div>
          </div>

          <div className="rounded-2xl border border-white/8 bg-white/[0.035] backdrop-blur-xl p-4">
            <label className={`${labelClass} block mb-3`}>How Many</label>
            <div className="flex gap-2">
              {COUNTS.map(c => (
                <button
                  key={c}
                  onClick={() => setCount(c)}
                  className={`flex-1 px-3 py-2.5 rounded-xl text-[12px] font-medium border transition-all ${
                    count === c
                      ? "bg-fuchsia-500/15 border-fuchsia-400/55 text-fuchsia-200 shadow-[0_0_14px_rgba(232,121,249,0.20)]"
                      : "bg-white/[0.04] border-white/10 text-white/60 hover:border-white/25 hover:text-white"
                  }`}
                >
                  {c} {c === 1 ? "image" : "images"}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Seed */}
        <div className="rounded-2xl border border-white/8 bg-white/[0.035] backdrop-blur-xl p-4">
          <label className={`${labelClass} block mb-2`}>Seed</label>
          <div className="flex items-center gap-2">
            <input
              type="text"
              inputMode="numeric"
              value={seed}
              onChange={e => setSeed(e.target.value)}
              placeholder="Optional — same seed reproduces the same look"
              className="flex-1 rounded-xl bg-black/30 border border-white/10 px-3 py-2 text-xs placeholder:text-white/35 focus:outline-none focus:border-violet-400/50 transition-all font-mono"
            />
            {seed && (
              <button
                onClick={() => setSeed("")}
                className="px-3 py-2 rounded-xl text-xs bg-white/[0.04] border border-white/10 text-white/65 hover:text-white hover:bg-white/10 transition-colors"
              >
                Clear
              </button>
            )}
          </div>
        </div>

        {/* Generate button — premium gradient */}
        <div className="flex gap-2">
          <button
            onClick={handleGenerate}
            disabled={!prompt.trim() || loading}
            className="group relative flex-1 flex items-center justify-center gap-2 py-3.5 rounded-2xl text-sm font-semibold text-white border border-violet-400/40 bg-gradient-to-r from-violet-600 via-fuchsia-600 to-violet-600 bg-[length:200%_100%] bg-left shadow-[0_18px_45px_rgba(139,92,246,0.35),inset_0_1px_0_rgba(255,255,255,0.18)] transition-all hover:bg-right disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-left active:translate-y-[1px]"
          >
            {loading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Generating…
              </>
            ) : (
              <>
                <Sparkles size={16} className="transition-transform group-hover:rotate-12" />
                Generate {count > 1 ? `${count} images` : "Image"}
              </>
            )}
          </button>
          {loading && (
            <button
              onClick={handleStop}
              className="px-5 rounded-2xl bg-red-500/15 border border-red-400/40 text-red-200 text-sm font-medium hover:bg-red-500/25 transition-colors"
            >
              Stop
            </button>
          )}
        </div>

        {loading && (
          <p className="text-center text-[11px] text-white/45">
            Spacing requests 8s apart to stay under Pollinations' free limit. {count} image{count > 1 ? "s" : ""} ≈ {count * 8}s.
          </p>
        )}

        {error && (
          <div className="flex flex-col gap-2 rounded-2xl bg-red-500/10 border border-red-400/30 px-4 py-3 backdrop-blur-xl">
            <p className="text-sm text-red-200">{error}</p>
            <button onClick={handleGenerate} className="self-start text-xs underline text-red-200/80 hover:text-red-100">
              Try again
            </button>
          </div>
        )}

        {/* Results */}
        {images.length > 0 && (
          <div className="flex flex-col gap-3">
            <div className={`grid gap-3 ${images.length === 1 ? "grid-cols-1" : "grid-cols-2"}`}>
              {images.map((g, i) => (
                <div key={`${g.seed}-${i}`} className="flex flex-col gap-2">
                  <div className="relative rounded-2xl overflow-hidden border border-white/10 bg-black/30 aspect-square shadow-[0_18px_45px_rgba(0,0,0,0.35)]">
                    {!g.loaded && !g.failed && (
                      <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 text-white/55">
                        <div className="w-6 h-6 border-2 border-violet-400/30 border-t-violet-400 rounded-full animate-spin" />
                        <span className="text-[10px] uppercase tracking-wider">loading…</span>
                      </div>
                    )}
                    {g.failed && (
                      <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 text-xs px-3 text-center">
                        <span className="text-red-300">Took too long or failed</span>
                        <button
                          onClick={() => retryTile(i)}
                          className="px-3 py-1.5 rounded-lg bg-violet-500/20 border border-violet-400/55 text-violet-200 text-[10px] font-medium hover:bg-violet-500/30"
                        >
                          Retry this one
                        </button>
                      </div>
                    )}
                    {g.url && (
                      <img loading="eager"
                        src={g.url}
                        alt={`Generated ${i + 1}`}
                        className={`w-full h-full object-cover block transition-opacity ${g.loaded ? "opacity-100" : "opacity-0"}`}
                      />
                    )}
                  </div>
                  <div className="flex items-center justify-between gap-1 text-[10px] text-white/50">
                    <button
                      onClick={() => handleReuseSeed(g.seed)}
                      className="font-mono truncate hover:text-violet-300 transition-colors text-left"
                      title="Click to reuse this seed"
                    >
                      🌱 {g.seed}
                    </button>
                    <div className="flex gap-1 shrink-0">
                      <button
                        onClick={() => handleDownload(g.url)}
                        disabled={!g.loaded}
                        className="p-1.5 rounded-lg hover:bg-white/10 disabled:opacity-30 transition-colors"
                        title="Download"
                      >
                        <Download size={12} />
                      </button>
                      <button
                        onClick={() => window.open(g.url, "_blank")}
                        className="p-1.5 rounded-lg hover:bg-white/10 transition-colors"
                        title="Open in new tab"
                      >
                        <ExternalLink size={12} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <button
                onClick={handleGenerate}
                className="flex items-center gap-2 flex-1 justify-center py-2.5 rounded-2xl bg-violet-500/15 border border-violet-400/40 text-sm font-medium text-violet-200 hover:bg-violet-500/25 transition-all"
              >
                <Sparkles size={15} />
                Regenerate
              </button>
              <button
                onClick={handleReset}
                className="flex items-center gap-2 flex-1 justify-center py-2.5 rounded-2xl bg-white/[0.04] border border-white/10 text-sm font-medium text-white/80 hover:bg-white/10 hover:text-white transition-all"
              >
                <RotateCcw size={15} />
                New
              </button>
            </div>
          </div>
        )}

        {images.length === 0 && !loading && !error && (
          <div className="flex flex-col items-center justify-center gap-3 py-10 text-center rounded-3xl border border-dashed border-white/10 bg-white/[0.02]">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-violet-500/25 to-fuchsia-500/15 border border-white/15 flex items-center justify-center">
              <Wand2 size={28} className="text-violet-300" />
            </div>
            <p className="text-sm text-white/55 max-w-xs">
              Free, no signup, no queue · Pick a model and describe what you want to see.
            </p>
          </div>
        )}

        {/* External generators — Perchance + Wan */}
        <div className="mt-2 pt-4 border-t border-white/8 flex flex-col gap-3">
          <p className="text-[11px] text-white/45 text-center">
            Need something stricter filters caught, or want video? Try one of these:
          </p>
          <div className="flex flex-col gap-2">
            <a
              href={PERCHANCE_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 py-3 rounded-xl bg-white/[0.04] border border-white/10 text-sm font-medium text-white/80 hover:bg-white/[0.08] hover:text-white hover:border-white/20 transition-all"
            >
              <ExternalLink size={14} />
              Open Perchance Image Generator
            </a>
            <a
              href={PERCHANCE_VIDEO_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 py-3 rounded-xl bg-white/[0.04] border border-white/10 text-sm font-medium text-white/80 hover:bg-white/[0.08] hover:text-white hover:border-white/20 transition-all"
            >
              <ExternalLink size={14} />
              Open Perchance Pretty AI Video
            </a>
            <a
              href={WAN_VIDEO_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-br from-violet-500/20 to-fuchsia-500/15 border border-violet-400/30 text-sm font-medium text-white/90 hover:from-violet-500/30 hover:to-fuchsia-500/20 hover:text-white hover:border-violet-400/50 transition-all shadow-[0_0_20px_rgba(167,139,250,0.10)]"
            >
              <ExternalLink size={14} />
              Open Wan 2.2 Video Generator
            </a>
            <a
              href={NSFW_WAN_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-br from-rose-500/20 to-pink-500/15 border border-rose-400/30 text-sm font-medium text-white/90 hover:from-rose-500/30 hover:to-pink-500/20 hover:text-white hover:border-rose-400/50 transition-all shadow-[0_0_20px_rgba(244,114,182,0.10)]"
            >
              <ExternalLink size={14} />
              Open NSFW Wan Video Generator
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
