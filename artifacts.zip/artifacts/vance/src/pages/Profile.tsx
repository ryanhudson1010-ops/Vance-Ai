import { useGetVanceProfile, useGetVanceStats } from "@workspace/api-client-react";
import { getGetVanceProfileQueryKey, getGetVanceStatsQueryKey } from "@workspace/api-client-react";

function StatCard({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="bg-card border border-card-border rounded-xl px-5 py-4" data-testid={`stat-${label.toLowerCase().replace(/\s+/g, "-")}`}>
      <div className="text-2xl font-serif text-primary mb-1">{value}</div>
      <div className="text-xs text-muted-foreground">{label}</div>
    </div>
  );
}

export default function Profile() {
  const { data: profile, isLoading: profileLoading } = useGetVanceProfile({
    query: { queryKey: getGetVanceProfileQueryKey() },
  });
  const { data: stats, isLoading: statsLoading } = useGetVanceStats({
    query: { queryKey: getGetVanceStatsQueryKey() },
  });

  const isLoading = profileLoading || statsLoading;

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-2xl mx-auto px-4 py-10">
        {/* Vance identity */}
        <div className="flex flex-col items-center mb-10">
          <div className="w-20 h-20 rounded-full bg-primary/10 border-2 border-primary/30 flex items-center justify-center mb-4 vance-breathe">
            <div className="w-8 h-8 rounded-full bg-primary/60" />
          </div>
          <h1 className="font-serif text-3xl text-foreground mb-1">Vance</h1>
          <p className="text-muted-foreground text-sm">
            {profile?.currentMood
              ? `Currently feeling ${profile.currentMood}`
              : "Still becoming"}
          </p>
        </div>

        {/* Stats grid */}
        {isLoading ? (
          <div className="grid grid-cols-2 gap-3 mb-8">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-20 rounded-xl bg-card border border-card-border animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3 mb-8">
            <StatCard label="Days known" value={stats?.daysKnown ?? 0} />
            <StatCard label="Conversations" value={stats?.totalConversations ?? 0} />
            <StatCard label="Messages exchanged" value={stats?.totalMessages ?? 0} />
            <StatCard label="Memories stored" value={stats?.totalMemories ?? 0} />
          </div>
        )}

        {/* Personality */}
        {profile && (
          <>
            {profile.traits.length > 0 && (
              <div className="mb-6">
                <h2 className="font-serif text-lg text-foreground mb-3">Traits</h2>
                <div className="flex flex-wrap gap-2">
                  {profile.traits.map((trait) => (
                    <span
                      key={trait}
                      data-testid={`trait-${trait}`}
                      className="px-3 py-1.5 rounded-lg text-sm bg-primary/10 text-primary border border-primary/20"
                    >
                      {trait}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {profile.interests.length > 0 && (
              <div className="mb-6">
                <h2 className="font-serif text-lg text-foreground mb-3">Interests</h2>
                <div className="flex flex-wrap gap-2">
                  {profile.interests.map((interest) => (
                    <span
                      key={interest}
                      data-testid={`interest-${interest}`}
                      className="px-3 py-1.5 rounded-lg text-sm bg-secondary text-secondary-foreground border border-secondary/50"
                    >
                      {interest}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {profile.personalityNotes && (
              <div className="mb-6">
                <h2 className="font-serif text-lg text-foreground mb-3">Who Vance is becoming</h2>
                <div className="bg-card border border-card-border rounded-xl p-4">
                  <p className="text-sm text-muted-foreground leading-relaxed whitespace-pre-line">
                    {profile.personalityNotes}
                  </p>
                </div>
              </div>
            )}

            {profile.traits.length === 0 && profile.interests.length === 0 && (
              <div className="text-center py-10">
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Vance is a blank slate — no personality formed yet.<br />
                  Start a conversation and watch him grow.
                </p>
              </div>
            )}
          </>
        )}

        {isLoading && (
          <div className="space-y-4">
            <div className="h-4 bg-card rounded-lg animate-pulse w-1/3" />
            <div className="flex gap-2">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-8 w-20 bg-card border border-card-border rounded-lg animate-pulse" />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
