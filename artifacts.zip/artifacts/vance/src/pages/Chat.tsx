import { useState, useEffect, useRef, useCallback, useMemo, type ReactNode } from "react";
import { flushSync } from "react-dom";
import {
  Mic, MicOff, Send, Plus, Trash2, Search, ChevronRight, ChevronDown,
  Code, FileText, Pencil, CheckCheck, BookOpen, Globe, Brain, Database, ExternalLink, Link, Sparkles, Volume2, VolumeX, UserCircle,
  Zap, Eye, ListChecks, Terminal, Square, Wand2, X, Check, ImagePlus, Loader2, SlidersHorizontal,
  Menu, Settings, ArrowUp,
  ZoomIn, ZoomOut, RotateCw, RotateCcw, Maximize2,
} from "lucide-react";
import { Code2, MessageSquare } from "lucide-react";
import { CurrentTaskPanel, categorizeText, loadBuilds, type BuildEntry } from "@/components/CurrentTaskPanel";

const CATEGORY_COLORS = {
  website: "#4A90E2",
  build:   "#FF9500",
  chat:    "#9B59B6",
} as const;

function dayBucket(d: Date | string): "Today" | "Yesterday" | "This week" | "Earlier" {
  const dt = typeof d === "string" ? new Date(d) : d;
  const now = new Date();
  const startOfToday     = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const startOfYesterday = startOfToday - 86_400_000;
  const startOfWeek      = startOfToday - 6 * 86_400_000;
  const t = dt.getTime();
  if (t >= startOfToday)     return "Today";
  if (t >= startOfYesterday) return "Yesterday";
  if (t >= startOfWeek)      return "This week";
  return "Earlier";
}
import { type Persona, type Emote, emoteDuration } from "../components/VanceAvatar3D";
import {
  getRecentErrors,
  getUnreadErrorCount,
  markErrorsRead,
  subscribeErrors,
  formatErrorsForPrompt,
} from "../lib/errorReporter";
import VanceFaceAvatar from "../components/VanceFaceAvatar";
import AvatarSettingsModal from "../components/AvatarSettingsModal";
import {
  useListOpenaiConversations,
  useCreateOpenaiConversation,
  useGetOpenaiConversation,
  useDeleteOpenaiConversation,
  useDeleteOpenaiMessage,
  getListOpenaiConversationsQueryKey,
  getGetOpenaiConversationQueryKey,
  getListOpenaiMessagesQueryKey,
  useVanceWebSearch,
} from "@workspace/api-client-react";
import { useVoiceRecorder, useVoiceStream } from "@workspace/integrations-openai-ai-react";
import { useQueryClient } from "@tanstack/react-query";

interface Source {
  title: string;
  url: string;
  snippet: string;
}

interface Message {
  id?: number;
  clientId: string;
  role: "user" | "assistant";
  content: string;
  imageUrl?: string | null;
  // Additional image URLs beyond the primary `imageUrl`. Currently populated
  // only by chat-mode multi-image gen ("draw me three mockups"); rendered
  // as a stacked column of thumbnails directly under the main image.
  extraImageUrls?: string[] | null;
  streaming?: boolean;
  buildEvents?: BuildEvent[];
  buildStream?: string;
  buildPhase?: string;
  isBuildResult?: boolean;
  researchEvents?: ResearchEvent[];
  isResearchResult?: boolean;
  sources?: Source[];
  sourcesQuery?: string;
  browsingQuery?: string;
  webSearched?: boolean;
  proposal?: BuildProposal;
  intake?: IntakeState;
  files?: VanceDownloadableFile[];
  createdAt?: string;
}

function formatTimeEastern(iso?: string): string {
  if (!iso) return "";
  try {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return "";
    const parts = new Intl.DateTimeFormat("en-US", {
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
      timeZone: "America/New_York",
      timeZoneName: "short",
    }).formatToParts(d);
    return parts.map((p) => p.value).join("");
  } catch {
    return "";
  }
}

interface BuildProposal {
  instruction: string;
  status: "pending" | "editing" | "accepted" | "cancelled";
  // "app" → Accept routes to Build Mode (edits the Vance app itself).
  // "website" → Accept sends a normal chat message so Vance can call
  // update_zip / create_zip / create_text_file in the same turn (used for
  // standalone deliverables like the gun-shop site zip). Default is "app"
  // for back-compat with existing rows.
  kind?: "app" | "website";
}

// ─── Website intake form (in-chat) ────────────────────────────────────────
// Vance can emit a ```website-intake``` fence when the user asks for a new
// website build WITHOUT supplying details. Frontend strips the fence and
// renders an interactive form with structured fields. Submit auto-formats
// the answers as the user's NEXT message; Skip just dismisses the card so
// they can type freely. The fence body is optional JSON prefill — Vance
// can pre-populate fields he already knows (businessName from prior chat,
// phone from intake the user already volunteered, etc.).
interface IntakeState {
  prefill: Record<string, string>;
  status: "open" | "submitted" | "skipped";
}

// ─── Persistence: proposal status + build result snapshots ────────────────────
// Without these, navigating away from /chat (or the app being unmounted by
// PWA backgrounding) destroys the in-memory React state. On re-entry every
// assistant message that contains a propose-edit block re-derives its
// proposal as "pending" — so the user sees the approval card pop back even
// though the build already ran. Same problem with build result panels: the
// rich BuildProgress UI is purely client state, so the summary report
// (file list + before/after screenshots) just disappears. We persist both
// to localStorage and rehydrate in mapServerMessages.

const RESOLVED_PROPOSALS_KEY = "vance-resolved-proposals-v1";
const RESOLVED_INTAKES_KEY = "vance-resolved-intakes-v1";
const BUILD_RESULTS_KEY = "vance-build-results-v1";
const MOBILE_BUBBLE_LAYOUT_KEY = "vance-mobile-chat-bubble-layout-v4";

interface SavedBuildResult {
  filesChanged?: string[];
  screenshots?: Array<{ url: string; label: string; ts: number }>;
  errorMessage?: string;
}

interface MobileBubbleLayoutSettings {
  messagesAreaHeightPct: number;
  // Horizontal nudge for the avatar stage, expressed as percent of the
  // avatar wrapper's own width.  0 = unchanged (centered), negative = left,
  // positive = right.  Persisted alongside messagesAreaHeightPct so users
  // can hand-center the avatar after a persona swap or aspect-ratio change.
  avatarOffsetXPct: number;
}

const DEFAULT_MOBILE_BUBBLE_LAYOUT: MobileBubbleLayoutSettings = {
  messagesAreaHeightPct: 30,
  avatarOffsetXPct: 0,
};

const MOBILE_MESSAGES_AREA_PCT_MIN = 22;
const MOBILE_MESSAGES_AREA_PCT_MAX = 78;
const AVATAR_OFFSET_X_PCT_MIN = -40;
const AVATAR_OFFSET_X_PCT_MAX = 40;

function clampMobileBubbleLayout(raw: Partial<MobileBubbleLayoutSettings> | null | undefined): MobileBubbleLayoutSettings {
  const messagesAreaHeightPct = typeof raw?.messagesAreaHeightPct === "number"
    ? Math.min(MOBILE_MESSAGES_AREA_PCT_MAX, Math.max(MOBILE_MESSAGES_AREA_PCT_MIN, raw.messagesAreaHeightPct))
    : DEFAULT_MOBILE_BUBBLE_LAYOUT.messagesAreaHeightPct;
  const avatarOffsetXPct = typeof raw?.avatarOffsetXPct === "number"
    ? Math.min(AVATAR_OFFSET_X_PCT_MAX, Math.max(AVATAR_OFFSET_X_PCT_MIN, raw.avatarOffsetXPct))
    : DEFAULT_MOBILE_BUBBLE_LAYOUT.avatarOffsetXPct;
  return { messagesAreaHeightPct, avatarOffsetXPct };
}

function loadMobileBubbleLayout(): MobileBubbleLayoutSettings {
  try {
    return clampMobileBubbleLayout(JSON.parse(localStorage.getItem(MOBILE_BUBBLE_LAYOUT_KEY) ?? "null") as Partial<MobileBubbleLayoutSettings> | null);
  } catch {
    return DEFAULT_MOBILE_BUBBLE_LAYOUT;
  }
}

// Build snapshots are keyed by a normalized signature of the assistant
// message content because the message id isn't known at the moment the
// build's "done" event fires (the local message has no server id yet).
// First 80 chars of normalized content is stable enough — Vance's final
// build summaries are unique sentences.
function buildResultKey(convId: number, content: string): string {
  const sig = content.replace(/\s+/g, " ").trim().slice(0, 80);
  return `${convId}::${sig}`;
}

function loadResolvedProposals(): Record<string, "accepted" | "cancelled"> {
  try { return JSON.parse(localStorage.getItem(RESOLVED_PROPOSALS_KEY) ?? "{}"); } catch { return {}; }
}
// Build a stable content-signature key for a proposal. Used as a fallback
// when the assistant message hasn't been assigned a server id yet (which
// happens when the user clicks Accept on a freshly-streamed proposal
// before the message-persist round-trip lands). Without this, the click
// silently fails to persist and the card pops back to "pending" after a
// reload, letting the user accept the same proposal twice.
function proposalSigKey(convId: number, instruction: string): string {
  const sig = instruction.replace(/\s+/g, " ").trim().slice(0, 120);
  return `${convId}:proposal-sig:${sig}`;
}
function saveProposalStatus(
  convId: number | null | undefined,
  msgId: number | undefined,
  instruction: string,
  status: "accepted" | "cancelled",
): void {
  if (!convId) return;
  const all = loadResolvedProposals();
  // Always write under whichever stable keys we have. id-key is preferred
  // for direct lookup; sig-key is the fallback used when the server hasn't
  // assigned an id yet at click time.
  if (typeof msgId === "number") all[`${convId}:${msgId}`] = status;
  if (instruction) all[proposalSigKey(convId, instruction)] = status;
  try { localStorage.setItem(RESOLVED_PROPOSALS_KEY, JSON.stringify(all)); } catch {}
}
function loadResolvedIntakes(): Record<string, "submitted" | "skipped"> {
  try { return JSON.parse(localStorage.getItem(RESOLVED_INTAKES_KEY) ?? "{}"); } catch { return {}; }
}
function saveIntakeStatus(convId: number | null | undefined, msgId: number | undefined, status: "submitted" | "skipped"): void {
  if (!convId || typeof msgId !== "number") return;
  const all = loadResolvedIntakes();
  all[`${convId}:${msgId}`] = status;
  try { localStorage.setItem(RESOLVED_INTAKES_KEY, JSON.stringify(all)); } catch {}
}
function loadBuildResults(): Record<string, SavedBuildResult> {
  try { return JSON.parse(localStorage.getItem(BUILD_RESULTS_KEY) ?? "{}"); } catch { return {}; }
}

// Autolinkify message text — handles BOTH markdown link syntax `[label](url)`
// AND bare http(s):// URLs. Renders as anchor tags that open in the system
// browser (target="_blank" + noopener), which on installed PWAs (iOS/Android)
// hands off to the user's default browser instead of opening in the webview.
//
// Order matters: we strip markdown links FIRST so the bare-URL pass doesn't
// double-link the URL inside `[...](...)` (which would produce the duplicate
// rendering bug — both label and href showing as separate links).
const LINK_REGEX = /(\[([^\]]+)\]\((https?:\/\/[^\s)]+)\))|(https?:\/\/[^\s<>"')\]]+)/g;

// Highlight class for the karaoke-style active word during TTS playback.
// Subtle teal pill — visible enough to track, soft enough not to feel
// jarring as it shifts ~3-5 times per second across the message.
const TTS_HIGHLIGHT_CLASS = "rounded-[4px] bg-teal-400/25 text-white px-0.5 -mx-0.5 transition-colors duration-75";

// Render a non-link text slice with optional karaoke highlight applied.
// `sliceStart` is the absolute char offset of `s` within the original
// message text — used to test whether the highlight range falls inside
// this slice. Returns AT MOST 3 spans (before/active/after), so the DOM
// stays small even on long messages: most non-link slices render as a
// single span when no highlight is active or the highlight falls
// outside the slice.
function renderSliceWithHighlight(s: string, sliceStart: number, highlight: { start: number; end: number } | null | undefined, key: string): ReactNode {
  if (!highlight || highlight.end <= sliceStart || highlight.start >= sliceStart + s.length) {
    return <span key={key}>{s}</span>;
  }
  const hStart = Math.max(0, highlight.start - sliceStart);
  const hEnd = Math.min(s.length, highlight.end - sliceStart);
  return (
    <span key={key}>
      {hStart > 0 && s.slice(0, hStart)}
      <span className={TTS_HIGHLIGHT_CLASS} data-tts-active="1">{s.slice(hStart, hEnd)}</span>
      {hEnd < s.length && s.slice(hEnd)}
    </span>
  );
}

function renderWithLinks(text: string, highlight?: { start: number; end: number } | null): ReactNode {
  if (!text) return text;
  const out: ReactNode[] = [];
  let lastIndex = 0;
  let key = 0;
  for (const match of text.matchAll(LINK_REGEX)) {
    const idx = match.index ?? 0;
    if (idx > lastIndex) {
      out.push(renderSliceWithHighlight(text.slice(lastIndex, idx), lastIndex, highlight, `t${key++}`));
    }
    let url: string;
    let label: string;
    if (match[1]) {
      // Markdown form: [label](url)
      label = match[2];
      url = match[3];
    } else {
      // Bare URL — strip trailing punctuation that often sticks to URLs in prose.
      url = match[4];
      let trailing = "";
      while (url.length > 0 && /[.,;:!?)\]]$/.test(url)) {
        trailing = url.slice(-1) + trailing;
        url = url.slice(0, -1);
      }
      label = url;
      if (trailing) {
        out.push(
          <a
            key={`l${key++}`}
            href={url}
            target="_blank"
            rel="noopener noreferrer"
            className="text-teal-300 underline decoration-teal-400/40 underline-offset-2 hover:text-teal-200 hover:decoration-teal-300 break-all"
          >
            {label}
          </a>
        );
        out.push(<span key={`p${key++}`}>{trailing}</span>);
        lastIndex = idx + match[0].length;
        continue;
      }
    }
    out.push(
      <a
        key={`l${key++}`}
        href={url}
        target="_blank"
        rel="noopener noreferrer"
        className="text-teal-300 underline decoration-teal-400/40 underline-offset-2 hover:text-teal-200 hover:decoration-teal-300 break-all"
      >
        {label}
      </a>
    );
    lastIndex = idx + match[0].length;
  }
  if (lastIndex < text.length) {
    out.push(renderSliceWithHighlight(text.slice(lastIndex), lastIndex, highlight, `t${key++}`));
  }
  return out;
}

function detectEmote(text: string): Emote | null {
  const s = text.toLowerCase();
  if (/\b(yes|yeah|yep|absolutely|definitely|certainly|correct|exactly|indeed)\b/.test(s)) return "nod_yes";
  if (/\b(no|nope|nah|never|incorrect|wrong|can't|cannot|won't|wouldn't|don't)\b/.test(s)) return "shake_no";
  if (/\b(thanks|thank you|got it|understood|will do|right away|okay|ok)\b/.test(s)) return "ack";
  if (/\b(happy|glad|great|lovely|brilliant|fantastic|wonderful|delighted)\b/.test(s)) return "happy";
  if (/\b(angry|furious|annoyed|frustrated|ridiculous|outrageous)\b/.test(s)) return "angry";
  if (/\b(whatever|obviously|clearly|naturally|of course)\b/.test(s)) return "cocky";
  if (/\b(sigh|unfortunately|alas|regrettably)\b/.test(s)) return "sigh";
  if (/\b(look away|another matter|elsewhere|different direction)\b/.test(s)) return "look_away";
  if (/\b(let's think|consider|perhaps|maybe|hmm|thoughtful)\b/.test(s)) return "thoughtful_shake";
  return null;
}

function saveBuildResultSnapshot(convId: number | null | undefined, content: string, data: SavedBuildResult): void {
  if (!convId || !content?.trim()) return;
  const all = loadBuildResults();
  all[buildResultKey(convId, content)] = data;
  // Keep storage bounded — drop oldest if we ever exceed ~200 entries.
  const keys = Object.keys(all);
  if (keys.length > 200) {
    for (const k of keys.slice(0, keys.length - 200)) delete all[k];
  }
  try { localStorage.setItem(BUILD_RESULTS_KEY, JSON.stringify(all)); } catch {}
}

// Remove a single sidebar build entry from localStorage. The sidebar's
// BuildEntry exposes (convId, title) where `title` is the sig portion of the
// key (`${convId}::${sig}`). loadBuilds() splits on "::" and trims, so we
// match the same way to find the right key — there can be multiple builds
// per convId, so we can't just delete by convId alone.
function removeBuildResultBySig(convId: number, sig: string): void {
  try {
    const all = JSON.parse(localStorage.getItem(BUILD_RESULTS_KEY) ?? "{}") as Record<string, unknown>;
    let changed = false;
    for (const k of Object.keys(all)) {
      const [cidStr, rawSig = ""] = k.split("::");
      if (Number(cidStr) === convId && (rawSig.trim() || "Build") === sig) {
        delete all[k];
        changed = true;
      }
    }
    if (changed) localStorage.setItem(BUILD_RESULTS_KEY, JSON.stringify(all));
  } catch { /* storage may be unavailable; silent */ }
}

// Strip ```vance-file ... ``` blocks out of an assistant message, returning
// the clean text plus a list of downloadable files. Mirrors extractProposal
// — one block per file Vance produced this turn (create_text_file or
// create_zip). The block format is plain key=value lines:
//   ```vance-file
//   name=foo.txt
//   url=/api/openai/files/abc/foo.txt
//   size=1234
//   desc=optional one-liner
//   ```
export interface VanceDownloadableFile {
  name: string;
  url: string;
  sizeBytes: number;
  description: string | null;
}

function extractFiles(text: string): { cleaned: string; files: VanceDownloadableFile[] } {
  const re = /`{3,}vance-file[^\n]*\n([\s\S]*?)`{3,}/gi;
  const files: VanceDownloadableFile[] = [];
  for (const match of text.matchAll(re)) {
    const body = match[1] ?? "";
    const lines = body.split("\n");
    const kv: Record<string, string> = {};
    for (const line of lines) {
      const eq = line.indexOf("=");
      if (eq <= 0) continue;
      const key = line.slice(0, eq).trim().toLowerCase();
      const val = line.slice(eq + 1).trim();
      if (key) kv[key] = val;
    }
    const name = kv.name;
    const url = kv.url;
    if (!name || !url) continue;
    // Only accept URLs that point at our own download route — anything else
    // would let a poisoned message render an arbitrary download link.
    if (!/^\/api\/openai\/files\/[a-z0-9-]{8,64}\/[a-z0-9._-]{1,80}$/i.test(url)) continue;
    files.push({
      name,
      url,
      sizeBytes: Number(kv.size) || 0,
      description: kv.desc || null,
    });
  }
  if (files.length === 0) return { cleaned: text, files: [] };
  const cleaned = text.replace(re, "").replace(/\n{3,}/g, "\n\n").trim();
  return { cleaned, files };
}

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(2)} MB`;
}

// Strip a ```propose-edit``` OR ```propose-website-edit``` block out of an
// assistant message, returning the clean text the user should see plus the
// extracted instruction (if any) and which kind of proposal it is.
//   - propose-edit         → kind="app"     → Accept routes to Build Mode.
//   - propose-website-edit → kind="website" → Accept sends as a chat message
//     so Vance can call update_zip/create_zip directly.
// We surface the LAST block as the active proposal — matches the chat
// convention of "the most recent statement is the operative one." If both
// kinds appear in one message, the LAST fence wins regardless of kind.
// Heuristic: if the model emitted `propose-edit` (kind=app → routes to
// Build Mode = edits the Vance codebase) but the instruction text is
// plainly about updating a website / zip / deliverable that was shipped
// earlier, reclassify as kind="website" so Accept routes back to chat
// and Vance calls update_zip instead of mutating his own source code.
// Caught a real bug: model proposed a fix to the Foothills storefront
// website using the wrong fence; user accepted; Build Mode booted up
// and started editing the Vance app. This safety net catches that.
function looksLikeWebsiteInstruction(s: string): boolean {
  const t = s.toLowerCase();
  return (
    /\b(update_zip|create_zip|the zip|new zip|re-?ship|reship|redeploy|the website|the site|your site|user'?s site|the homepage|landing page|index\.html|style\.css|the storefront|hero photo|hero image|hero section|the hero|about section|contact page|contact section|services page|services section|footer|navbar|the photos? (?:on|in|at) the|swap (?:the )?photo|fix the (?:photo|image)|replace the (?:photo|image)|the deliverable|the bundle|the download)\b/.test(t)
  );
}
function extractProposal(
  text: string,
  chatMode?: "website" | "build" | "chat",
): { cleaned: string; instruction: string | null; kind: "app" | "website" } {
  // Match website variant FIRST in the alternation so the regex doesn't
  // greedily consume "propose-edit" and miss the "-website" suffix.
  const re = /`{3,}(propose-website-edit|propose-edit)[^\n]*\n?([\s\S]*?)`{3,}/gi;
  const matches = [...text.matchAll(re)];
  if (matches.length === 0) return { cleaned: text, instruction: null, kind: "app" };
  const last = matches[matches.length - 1]!;
  const tag = (last[1] ?? "").toLowerCase();
  let kind: "app" | "website" = tag === "propose-website-edit" ? "website" : "app";
  const instruction = (last[2] ?? "").trim();
  // Safety reclassification — only upgrades app→website (never the
  // reverse). If the model explicitly chose propose-website-edit we
  // trust it, but if it chose propose-edit and the instruction is
  // plainly website-y, we force website to avoid corrupting the Vance
  // codebase with a website fix.
  if (kind === "app" && instruction && looksLikeWebsiteInstruction(instruction)) {
    kind = "website";
  }
  // Hard guard — in Website Build mode, NEVER allow a kind=app proposal
  // to slip through and route to Build Mode (which mutates the Vance
  // app source). The model occasionally proposes edits to its own UI
  // ("let me tweak the layout") forgetting it's in website mode; force
  // every proposal in this mode to the website pipeline so Accept goes
  // back to chat as a follow-up message instead of touching Vance code.
  if (chatMode === "website" && kind === "app") {
    kind = "website";
  }
  const cleaned = text.replace(re, "").replace(/\n{3,}/g, "\n\n").trim();
  return { cleaned, instruction: instruction || null, kind };
}

// Strip a ```website-intake``` block out of an assistant message, returning
// the clean text plus the parsed JSON prefill (empty object if the body is
// missing or invalid JSON). Vance emits this fence when the user asks for
// a new website build without supplying details — the frontend renders an
// inline form whose Submit becomes the user's next message.
function extractIntake(text: string): { cleaned: string; prefill: Record<string, string> | null } {
  const re = /`{3,}website-intake[^\n]*\n?([\s\S]*?)`{3,}/i;
  const m = text.match(re);
  if (!m) return { cleaned: text, prefill: null };
  const body = (m[1] ?? "").trim();
  let prefill: Record<string, string> = {};
  if (body && body.startsWith("{")) {
    try {
      const parsed = JSON.parse(body);
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
        for (const [k, v] of Object.entries(parsed as Record<string, unknown>)) {
          if (typeof v === "string") prefill[k] = v;
          else if (Array.isArray(v)) prefill[k] = v.map((x) => String(x)).join("\n");
        }
      }
    } catch { /* ignore invalid JSON, render empty form */ }
  }
  const cleaned = text.replace(re, "").replace(/\n{3,}/g, "\n\n").trim();
  return { cleaned, prefill };
}

// Field list driving the intake form. Order matches the rendered form AND
// the formatted message Submit produces. Keep in sync with the backend
// prompt — Vance is told to prefill into these exact keys.
const INTAKE_FIELDS: Array<{ key: string; label: string; placeholder: string; multiline?: boolean; required?: boolean }> = [
  { key: "businessName", label: "businessName", placeholder: "[Business Name]", required: true },
  { key: "businessType", label: "businessType", placeholder: "[e.g. Cleaning Service, Firearms Shop, ATV Dealer]", required: true },
  { key: "tagline", label: "tagline", placeholder: "[Main headline, e.g. Professional Cleaning in Hamptonville, NC]" },
  { key: "location", label: "location", placeholder: "[City, State or area served]" },
  { key: "phone", label: "phone", placeholder: "[Phone number]" },
  { key: "email", label: "email", placeholder: "[Email address]" },
  { key: "vibe", label: "vibe", placeholder: "[e.g. fresh and trustworthy, tactical and rugged, adventurous]" },
  { key: "services", label: "Services (one per line)", placeholder: "[Service 1 Name]\n[Service 2 Name]\n[Service 3 Name]", multiline: true },
  { key: "additionalInfo", label: "Additional Info (optional)", placeholder: "Available schedules or special offers\nAbout text\nAnything else important", multiline: true },
];

function formatIntakeAnswers(values: Record<string, string>): string {
  const lines: string[] = ["Business Details:"];
  const detailKeys = ["businessName", "businessType", "tagline", "location", "phone", "email", "vibe"];
  for (const k of detailKeys) {
    const v = (values[k] ?? "").trim();
    if (!v) continue;
    lines.push(`- ${k}: "${v}"`);
  }
  const services = (values.services ?? "").trim();
  if (services) {
    lines.push("");
    lines.push("Services:");
    for (const raw of services.split(/\n+/).map((l) => l.trim().replace(/^[-•*]\s*/, "")).filter(Boolean)) {
      lines.push(`- ${raw}`);
    }
  }
  const additional = (values.additionalInfo ?? "").trim();
  if (additional) {
    lines.push("");
    lines.push("Additional Info (optional):");
    for (const raw of additional.split(/\n+/).map((l) => l.trim().replace(/^[-•*]\s*/, "")).filter(Boolean)) {
      lines.push(`- ${raw}`);
    }
  }
  lines.push("");
  lines.push("Requirements:");
  lines.push("- Multi-page with sticky top navigation (Home, About, Services, Contact)");
  lines.push("- Full Tailwind CSS");
  lines.push("- Modern, professional design matching the vibe");
  lines.push("- Big \"Call Now\" button with the phone number on every page");
  lines.push("- Working contact form");
  lines.push("- No repetition");
  lines.push("");
  lines.push("First show the structured JSON proposal, then generate and ship the complete new zip after I approve.");
  return lines.join("\n").trim();
}

interface IntakeCardProps {
  intake: IntakeState;
  disabled: boolean;
  onSubmit: (text: string) => void;
  onSkip: () => void;
}

function IntakeCard({ intake, disabled, onSubmit, onSkip }: IntakeCardProps) {
  const [values, setValues] = useState<Record<string, string>>(() => ({ ...intake.prefill }));
  const [pasteMode, setPasteMode] = useState(false);
  const [pasteText, setPasteText] = useState("");

  if (intake.status === "submitted") {
    return (
      <div data-testid="intake-submitted" className="flex items-center gap-1.5 px-1 text-xs text-primary/80">
        <Check size={12} /> Sent
      </div>
    );
  }
  if (intake.status === "skipped") {
    return (
      <div data-testid="intake-skipped" className="px-1 text-xs text-white/40">Form skipped — type your details below.</div>
    );
  }

  const canSubmit = pasteMode
    ? pasteText.trim().length > 0
    : (values.businessName ?? "").trim().length > 0 && (values.businessType ?? "").trim().length > 0;

  return (
    <div data-testid="intake-card" className="rounded-2xl border border-white/10 bg-white/[0.04] p-4 md:p-5 space-y-3 backdrop-blur-sm">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-[13px] font-semibold text-white/90">Website intake</div>
          <div className="text-[11.5px] text-white/50 mt-0.5">Fill what you can — the rest I'll figure out. Required: business name + type.</div>
        </div>
        <button
          type="button"
          onClick={() => setPasteMode((p) => !p)}
          className="shrink-0 text-[11px] font-medium text-white/60 hover:text-white/90 px-2 py-1 rounded-md hover:bg-white/5"
          data-testid="button-intake-paste-toggle"
        >
          {pasteMode ? "Form view" : "Paste my own"}
        </button>
      </div>

      {pasteMode ? (
        <textarea
          value={pasteText}
          onChange={(e) => setPasteText(e.target.value)}
          placeholder="Paste your full build brief here — anything goes."
          rows={8}
          className="w-full rounded-lg bg-black/30 border border-white/10 px-3 py-2 text-[13px] text-white/90 placeholder:text-white/30 focus:outline-none focus:border-teal-400/40 resize-y"
          data-testid="textarea-intake-paste"
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
          {INTAKE_FIELDS.map((f) => (
            <div key={f.key} className={f.multiline ? "md:col-span-2" : ""}>
              <label className="block text-[10.5px] font-medium uppercase tracking-wider text-white/45 mb-1">
                {f.label}{f.required ? <span className="text-rose-400/80 ml-0.5">*</span> : null}
              </label>
              {f.multiline ? (
                <textarea
                  value={values[f.key] ?? ""}
                  onChange={(e) => setValues((v) => ({ ...v, [f.key]: e.target.value }))}
                  placeholder={f.placeholder}
                  rows={3}
                  className="w-full rounded-lg bg-black/30 border border-white/10 px-3 py-2 text-[13px] text-white/90 placeholder:text-white/30 focus:outline-none focus:border-teal-400/40 resize-y"
                  data-testid={`textarea-intake-${f.key}`}
                />
              ) : (
                <input
                  type="text"
                  value={values[f.key] ?? ""}
                  onChange={(e) => setValues((v) => ({ ...v, [f.key]: e.target.value }))}
                  placeholder={f.placeholder}
                  className="w-full rounded-lg bg-black/30 border border-white/10 px-3 py-2 text-[13px] text-white/90 placeholder:text-white/30 focus:outline-none focus:border-teal-400/40"
                  data-testid={`input-intake-${f.key}`}
                />
              )}
            </div>
          ))}
        </div>
      )}

      <div className="flex flex-wrap items-center gap-2 pt-1">
        <button
          type="button"
          disabled={disabled || !canSubmit}
          onClick={() => {
            const text = pasteMode ? pasteText.trim() : formatIntakeAnswers(values);
            if (text) onSubmit(text);
          }}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-teal-500 text-white text-[12.5px] font-semibold shadow-sm hover:bg-teal-400 disabled:opacity-40 disabled:cursor-not-allowed transition"
          data-testid="button-intake-submit"
        >
          <Check size={13} /> Send to Vance
        </button>
        <button
          type="button"
          disabled={disabled}
          onClick={onSkip}
          className="px-3 py-2 rounded-full text-[12.5px] font-medium text-white/60 hover:text-white/90 hover:bg-white/5 transition disabled:opacity-40"
          data-testid="button-intake-skip"
        >
          Skip
        </button>
      </div>
    </div>
  );
}

interface ProposalCardProps {
  proposal: BuildProposal;
  disabled: boolean;
  onAccept: (instruction: string) => void;
  onEdit: () => void;
  onSaveEdit: (instruction: string) => void;
  onCancel: () => void;
  // Website-only: re-ship the same spec with a different design pack
  // (palette + fonts + vibe). Shown as a "Retry build (new design)" button
  // in the accepted state. Each click bumps the variation index server-side.
  onRetry?: () => void;
}

// Parse a propose-website-edit fence body as the structured WebsiteSpec JSON
// the backend's deterministic template renderer expects. Returns null on any
// failure (non-JSON, missing fields) so the card falls back to showing the
// raw instruction text. Mirrors parseWebsiteSpec on the server, but we only
// extract the fields needed for the friendly summary card.
function parseStructuredWebsiteProposal(raw: string): {
  businessName: string;
  businessType: string;
  tagline: string;
  location: string;
  vibe: string;
  palette: { primary?: string; secondary?: string; background?: string; accent?: string; text?: string };
  fonts: { heading?: string; body?: string };
  socialCount: number;
  hasFormspree: boolean;
  multiPage: boolean;
  servicesCount: number;
  hasAbout: boolean;
  hasArea: boolean;
  hasTestimonials: boolean;
  imageSlots: Array<{ label: string; url: string | null }>;
} | null {
  const trimmed = raw.trim();
  if (!trimmed.startsWith("{")) return null;
  const firstBrace = trimmed.indexOf("{");
  const lastBrace = trimmed.lastIndexOf("}");
  if (firstBrace === -1 || lastBrace <= firstBrace) return null;
  let parsed: unknown;
  try {
    parsed = JSON.parse(trimmed.slice(firstBrace, lastBrace + 1));
  } catch {
    return null;
  }
  if (!parsed || typeof parsed !== "object") return null;
  const o = parsed as Record<string, unknown>;
  const businessName = typeof o["businessName"] === "string" ? o["businessName"].trim() : "";
  if (!businessName) return null;
  const businessType = typeof o["businessType"] === "string" ? o["businessType"].trim() : "";
  const tagline = typeof o["tagline"] === "string" ? o["tagline"].trim() : "";
  const vibe = typeof o["vibe"] === "string" ? o["vibe"].trim() : "";
  // Prefer the new single-line `location` field; fall back to legacy city/state.
  let location = typeof o["location"] === "string" ? o["location"].trim() : "";
  if (!location) {
    const city = typeof o["city"] === "string" ? o["city"].trim() : "";
    const state = typeof o["state"] === "string" ? o["state"].trim() : "";
    location = [city, state].filter(Boolean).join(", ");
  }
  const HEX6 = /^#[0-9a-fA-F]{6}$/;
  const paletteRaw = o["palette"];
  const palette: { primary?: string; secondary?: string; background?: string; accent?: string; text?: string } = {};
  if (paletteRaw && typeof paletteRaw === "object" && !Array.isArray(paletteRaw)) {
    const p = paletteRaw as Record<string, unknown>;
    for (const k of ["primary", "secondary", "background", "accent", "text"] as const) {
      const v = p[k];
      if (typeof v === "string" && HEX6.test(v.trim())) palette[k] = v.trim();
    }
  }
  // Layout: explicit `layout` enum wins over the legacy `multiPage` boolean.
  // Server defaults multiPage to true now; mirror that — only false if explicitly set.
  const layoutRaw = typeof o["layout"] === "string" ? o["layout"] : "";
  const multiPage = layoutRaw === "single-page" ? false : layoutRaw === "multi-page" ? true : o["multiPage"] !== false;
  const services = Array.isArray(o["services"]) ? o["services"] : [];
  const about = Boolean((o["about"] && typeof o["about"] === "object") || (typeof o["aboutText"] === "string" && o["aboutText"].trim()));
  const area = Array.isArray(o["serviceArea"]) && (o["serviceArea"] as unknown[]).length > 0;
  const testimonials = Array.isArray(o["testimonials"]) && (o["testimonials"] as unknown[]).length > 0;
  // Fonts: pick out heading + body if either is a non-empty string.
  const fontsRaw = o["fonts"];
  const fonts: { heading?: string; body?: string } = {};
  if (fontsRaw && typeof fontsRaw === "object" && !Array.isArray(fontsRaw)) {
    const f = fontsRaw as Record<string, unknown>;
    if (typeof f["heading"] === "string" && f["heading"].trim()) fonts.heading = f["heading"].trim();
    if (typeof f["body"] === "string" && f["body"].trim()) fonts.body = f["body"].trim();
  }
  // Social link count: how many of the 6 channels were filled in (non-null URL).
  const slRaw = o["socialLinks"];
  let socialCount = 0;
  if (slRaw && typeof slRaw === "object" && !Array.isArray(slRaw)) {
    const sl = slRaw as Record<string, unknown>;
    for (const k of ["facebook", "instagram", "twitter", "linkedin", "youtube", "tiktok"]) {
      const v = sl[k];
      if (typeof v === "string" && /^https?:\/\//.test(v.trim())) socialCount += 1;
    }
  }
  const hasFormspree = typeof o["formspreeUrl"] === "string" && /^https?:\/\//.test(o["formspreeUrl"].trim());
  // Image slots — surface every paste-here image field so the user can see
  // at a glance which slots are filled (✓ URL) and which need a real photo.
  // Order matters for display: hero is the marquee image, then per-service,
  // then the supporting page-level slots.
  const imageSlots: Array<{ label: string; url: string | null }> = [];
  const imagesRaw = o["images"];
  const pickUrl = (v: unknown): string | null => (typeof v === "string" && /^https?:\/\//.test(v.trim()) ? v.trim() : null);
  if (imagesRaw && typeof imagesRaw === "object" && !Array.isArray(imagesRaw)) {
    const im = imagesRaw as Record<string, unknown>;
    imageSlots.push({ label: "Hero (top banner)", url: pickUrl(im["hero"]) });
    imageSlots.push({ label: "About section", url: pickUrl(im["about"]) });
    imageSlots.push({ label: "Services page header", url: pickUrl(im["servicesHero"]) });
    imageSlots.push({ label: "Contact page", url: pickUrl(im["contact"]) });
  } else {
    // Spec didn't include `images` at all — still show the four expected slots
    // so the user knows they can fill them in. Backend will Picsum-placeholder.
    imageSlots.push({ label: "Hero (top banner)", url: null });
    imageSlots.push({ label: "About section", url: null });
    imageSlots.push({ label: "Services page header", url: null });
    imageSlots.push({ label: "Contact page", url: null });
  }
  for (let i = 0; i < services.length; i++) {
    const svc = services[i];
    if (!svc || typeof svc !== "object") continue;
    const s = svc as Record<string, unknown>;
    const name = typeof s["name"] === "string" ? s["name"].trim() : typeof s["title"] === "string" ? s["title"].trim() : `Service ${i + 1}`;
    imageSlots.push({ label: `Service: ${name}`, url: pickUrl(s["image"]) });
  }
  return {
    businessName,
    businessType,
    tagline,
    location,
    vibe,
    palette,
    fonts,
    socialCount,
    hasFormspree,
    multiPage,
    servicesCount: services.length,
    hasAbout: about,
    hasArea: area,
    hasTestimonials: testimonials,
    imageSlots,
  };
}

function ProposalCard({ proposal, disabled, onAccept, onEdit, onSaveEdit, onCancel, onRetry }: ProposalCardProps) {
  // Seed the draft once and only resync if we re-enter edit mode after a save
  // — re-syncing on every prop change would wipe the user's in-flight edit
  // whenever the parent re-renders for an unrelated reason.
  const [draft, setDraft] = useState(proposal.instruction);
  const wasEditingRef = useRef(false);
  useEffect(() => {
    if (proposal.status === "editing" && !wasEditingRef.current) setDraft(proposal.instruction);
    wasEditingRef.current = proposal.status === "editing";
  }, [proposal.status, proposal.instruction]);

  if (proposal.status === "accepted") {
    return (
      <div data-testid="proposal-accepted" className="flex flex-wrap items-center gap-2 px-1">
        <div className="text-xs text-primary/80 flex items-center gap-1.5">
          <Check size={12} /> Accepted — building below
        </div>
        {onRetry && proposal.kind === "website" ? (
          <button
            data-testid="proposal-retry"
            aria-label="Retry build with a different design"
            onClick={onRetry}
            disabled={disabled}
            title="Re-ship the same content with a fresh palette, fonts, and vibe"
            className="px-3 py-1 rounded-full text-[11px] font-medium bg-white/10 hover:bg-white/20 border border-white/15 text-white/90 disabled:opacity-40 transition-colors flex items-center gap-1.5"
          >
            <Wand2 size={11} /> Retry (new design)
          </button>
        ) : null}
      </div>
    );
  }
  if (proposal.status === "cancelled") {
    return (
      <div data-testid="proposal-cancelled" className="text-xs text-muted-foreground flex items-center gap-1.5 px-1">
        <X size={12} /> Cancelled
      </div>
    );
  }

  const editing = proposal.status === "editing";
  return (
    <div data-testid="proposal-card" className="rounded-2xl bg-gradient-to-br from-violet-500/10 to-teal-500/5 border border-white/10 shadow-lg backdrop-blur-sm overflow-hidden">
      <div className="flex items-center gap-2 px-4 py-2 border-b border-white/10">
        <Wand2 size={13} className={proposal.kind === "website" ? "text-teal-300" : "text-violet-300"} />
        <span className="text-xs font-medium text-white/80">
          {proposal.kind === "website" ? "Vance proposes a website update" : "Vance proposes a change"}
        </span>
      </div>
      <div className="px-4 py-3">
        {editing ? (
          <textarea
            data-testid="proposal-textarea"
            aria-label="Edit the proposed change before sending it to the build agent"
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            rows={3}
            className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-white/30 resize-y leading-relaxed"
            autoFocus
          />
        ) : (() => {
          const structured = proposal.kind === "website" ? parseStructuredWebsiteProposal(proposal.instruction) : null;
          if (!structured) {
            return <p className="text-sm text-white/85 leading-relaxed whitespace-pre-wrap break-words">{proposal.instruction}</p>;
          }
          const locSuffix = structured.location;
          const sections: string[] = [];
          if (structured.servicesCount > 0) sections.push(`${structured.servicesCount} service${structured.servicesCount === 1 ? "" : "s"}`);
          if (structured.hasAbout) sections.push("about");
          if (structured.hasArea) sections.push("service area");
          if (structured.hasTestimonials) sections.push("reviews");
          sections.push("contact form");
          const swatches: Array<{ key: string; hex: string }> = [];
          for (const k of ["primary", "secondary", "accent", "background"] as const) {
            const v = structured.palette[k];
            if (v) swatches.push({ key: k, hex: v });
          }
          const meta = [structured.businessType, locSuffix].filter(Boolean).join(" · ");
          return (
            <div className="text-sm text-white/85 leading-relaxed">
              <p className="font-semibold text-white">Build site for <span className="text-teal-300">{structured.businessName}</span>{meta ? <span className="text-white/60 font-normal"> · {meta}</span> : null}</p>
              {structured.tagline ? <p className="text-white/70 italic mt-1">&ldquo;{structured.tagline}&rdquo;</p> : null}
              {structured.vibe ? <p className="text-white/50 text-xs mt-1">Vibe: {structured.vibe}</p> : null}
              <p className="text-white/60 text-xs mt-2">{structured.multiPage ? "Multi-page" : "Single page"} · {sections.join(" · ")}</p>
              {(structured.fonts.heading || structured.fonts.body) ? (
                <p className="text-white/50 text-xs mt-1">Fonts: {[structured.fonts.heading, structured.fonts.body].filter(Boolean).join(" / ")}</p>
              ) : null}
              {(structured.socialCount > 0 || structured.hasFormspree) ? (
                <p className="text-white/50 text-xs mt-1">
                  {structured.socialCount > 0 ? `${structured.socialCount} social link${structured.socialCount === 1 ? "" : "s"}` : null}
                  {structured.socialCount > 0 && structured.hasFormspree ? " · " : null}
                  {structured.hasFormspree ? "Formspree wired" : null}
                </p>
              ) : null}
              {swatches.length > 0 ? (
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-white/50 text-xs">Colours:</span>
                  {swatches.map((s) => (
                    <span
                      key={s.key}
                      title={`${s.key}: ${s.hex}`}
                      className="inline-block w-4 h-4 rounded-full border border-white/20 shadow-sm"
                      style={{ background: s.hex }}
                    />
                  ))}
                </div>
              ) : (
                <p className="text-white/40 text-xs mt-1">Default neutral palette (navy · gray · white)</p>
              )}
              {structured.imageSlots.length > 0 ? (() => {
                const filled = structured.imageSlots.filter((s) => s.url).length;
                const total = structured.imageSlots.length;
                return (
                  <details className="mt-3 group">
                    <summary className="text-white/60 text-xs cursor-pointer hover:text-white/80 select-none">
                      📷 Image slots: {filled}/{total} filled{filled < total ? ` — ${total - filled} placeholder${total - filled === 1 ? "" : "s"} will ship until you paste URLs` : ""}
                      <span className="text-white/40 ml-1 group-open:hidden">(tap to expand)</span>
                    </summary>
                    <ul className="mt-2 space-y-1.5 pl-1">
                      {structured.imageSlots.map((slot, i) => (
                        <li key={i} className="text-xs flex items-start gap-2 leading-relaxed">
                          <span className={slot.url ? "text-teal-300" : "text-white/30"}>{slot.url ? "✓" : "○"}</span>
                          <span className="text-white/70 font-medium min-w-0 flex-1">
                            {slot.label}
                            {slot.url ? (
                              <span className="text-white/40 font-normal block truncate">{slot.url}</span>
                            ) : (
                              <span className="text-white/40 font-normal italic"> — placeholder (paste a URL in Edit to replace)</span>
                            )}
                          </span>
                        </li>
                      ))}
                    </ul>
                    <p className="text-white/40 text-[11px] mt-2 italic">
                      Tip: tap Edit above to paste real image URLs into the JSON. Free sources: unsplash.com (search the vertical — e.g. "shooting range", "ATV", "restaurant interior") then copy the image's direct .jpg link.
                    </p>
                  </details>
                );
              })() : null}
            </div>
          );
        })()}
      </div>
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-end gap-1.5 sm:gap-2 px-3 pb-3">
        {editing ? (
          <>
            <button
              data-testid="proposal-edit-cancel"
              aria-label="Discard edits and return to the original proposal"
              onClick={() => { setDraft(proposal.instruction); onSaveEdit(proposal.instruction); }}
              disabled={disabled}
              className="px-4 py-2 rounded-full text-xs font-medium text-white/70 hover:text-white hover:bg-white/5 disabled:opacity-40 transition-colors"
            >
              Back
            </button>
            <button
              data-testid="proposal-save"
              aria-label="Save edited proposal"
              onClick={() => onSaveEdit(draft.trim() || proposal.instruction)}
              disabled={disabled || !draft.trim()}
              className="px-4 py-2 rounded-full text-xs font-medium bg-white text-black hover:bg-white/90 shadow-[0_0_15px_rgba(255,255,255,0.3)] disabled:opacity-40 transition-all flex items-center justify-center gap-1.5"
            >
              <Check size={14} /> Save
            </button>
          </>
        ) : (
          <>
            <button
              data-testid="proposal-cancel"
              aria-label="Cancel proposal"
              onClick={onCancel}
              disabled={disabled}
              className="px-4 py-2 rounded-full text-xs font-medium text-white/70 hover:text-white hover:bg-white/5 disabled:opacity-40 transition-colors"
            >
              Cancel
            </button>
            <button
              data-testid="proposal-edit"
              aria-label="Edit the proposal before accepting"
              onClick={onEdit}
              disabled={disabled}
              className="px-4 py-2 rounded-full text-xs font-medium bg-white/10 hover:bg-white/20 border border-white/10 text-white disabled:opacity-40 transition-colors flex items-center justify-center gap-1.5"
            >
              <Pencil size={12} /> Edit
            </button>
            <button
              data-testid="proposal-accept"
              aria-label="Accept proposal and run the build"
              onClick={() => onAccept(proposal.instruction)}
              disabled={disabled}
              className="px-4 py-2 rounded-full text-xs font-medium bg-white text-black hover:bg-white/90 shadow-[0_0_15px_rgba(255,255,255,0.3)] disabled:opacity-40 transition-all flex items-center justify-center gap-1.5"
            >
              <Check size={14} /> Accept
            </button>
          </>
        )}
      </div>
    </div>
  );
}

function phaseIcon(phaseRaw: string | undefined) {
  const p = (phaseRaw ?? "").toLowerCase();
  if (p.includes("think")) return Brain;
  if (p.includes("analy") || p.includes("read") || p.includes("review")) return Eye;
  if (p.includes("plan")) return ListChecks;
  if (p.includes("cod") || p.includes("writ") || p.includes("edit") || p.includes("build")) return Code;
  if (p.includes("verif") || p.includes("check") || p.includes("test") || p.includes("typecheck")) return CheckCheck;
  if (p.includes("revert") || p.includes("rollback")) return Wand2;
  if (p.includes("shell") || p.includes("command") || p.includes("run")) return Terminal;
  return Sparkles;
}

interface BuildProgressProps {
  events: BuildEvent[];
  currentPhase?: string;
  streamText?: string;
  isStreaming: boolean;
}

function BuildProgress({ events, currentPhase, streamText, isStreaming }: BuildProgressProps) {
  // Group: a phase header followed by all the events that happened "under" it,
  // until the next phase event. The stream from the live phase becomes a
  // synthetic snapshot for the in-flight group.
  type Group = { phase: string; events: BuildEvent[]; live?: boolean };
  const groups: Group[] = [];
  let current: Group | null = null;
  for (const ev of events) {
    if (ev.type === "phase") {
      current = { phase: ev.label ?? ev.phase ?? "Working", events: [] };
      groups.push(current);
    } else if (ev.type === "done" || ev.type === "error") {
      // Render terminal events as their own group so they don't get hidden
      groups.push({ phase: ev.type === "done" ? "Done" : "Error", events: [ev] });
      current = null;
    } else {
      if (!current) {
        current = { phase: currentPhase ?? "Working", events: [] };
        groups.push(current);
      }
      current.events.push(ev);
    }
  }
  if (isStreaming && streamText && streamText.trim()) {
    if (!current) {
      current = { phase: currentPhase ?? "Thinking", events: [], live: true };
      groups.push(current);
    } else {
      current.live = true;
    }
  } else if (isStreaming && groups.length === 0) {
    groups.push({ phase: currentPhase ?? "Thinking", events: [], live: true });
  }

  if (groups.length === 0) return null;

  return (
    <div data-testid="build-progress" className="rounded-2xl border border-white/10 bg-white/[0.03] overflow-hidden backdrop-blur-sm">
      <div className="flex items-center gap-2 px-4 py-2 border-b border-white/10">
        <Code size={13} className="text-violet-300" />
        <span className="text-xs font-medium text-white/85">Build progress</span>
        {isStreaming && (
          <span className="ml-auto flex gap-1 items-center">
            <span className="w-1 h-1 rounded-full bg-teal-300 animate-bounce" style={{ animationDelay: "0ms" }} />
            <span className="w-1 h-1 rounded-full bg-teal-300 animate-bounce" style={{ animationDelay: "150ms" }} />
            <span className="w-1 h-1 rounded-full bg-teal-300 animate-bounce" style={{ animationDelay: "300ms" }} />
          </span>
        )}
      </div>
      <div className="px-3 py-3 space-y-3 max-h-80 overflow-y-auto">
        {groups.map((g, gi) => {
          const Icon = phaseIcon(g.phase);
          const live = g.live && isStreaming;
          return (
            <div key={gi} data-testid={`build-phase-${gi}`} className="space-y-1.5">
              <div className="flex items-center gap-2">
                <div className={`w-5 h-5 rounded-full flex items-center justify-center border ${live ? "bg-primary/25 border-primary/60" : g.phase === "Error" ? "bg-destructive/20 border-destructive/40" : "bg-primary/15 border-primary/30"}`}>
                  <Icon size={11} className={g.phase === "Error" ? "text-destructive" : "text-primary"} />
                </div>
                <span className={`text-xs font-medium ${g.phase === "Error" ? "text-destructive" : "text-foreground/80"}`}>{g.phase}</span>
                {live && <span className="text-[10px] text-primary/70 uppercase tracking-wider">live</span>}
              </div>
              <div className="ml-7 space-y-1">
                {g.events.map((ev, ei) => {
                  const key = `${gi}-${ei}`;
                  if (ev.type === "plan" && ev.steps?.length) {
                    return (
                      <ol key={key} className="text-xs text-foreground/75 list-decimal ml-4 space-y-0.5">
                        {ev.steps.map((s, si) => <li key={si} className="leading-snug">{s}</li>)}
                      </ol>
                    );
                  }
                  if (ev.type === "reading" && ev.path) {
                    return (
                      <div key={key} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                        <Eye size={10} className="flex-shrink-0" />
                        <span className="truncate font-mono text-[11px]">{ev.path}</span>
                      </div>
                    );
                  }
                  if (ev.type === "writing" && ev.path) {
                    return (
                      <div key={key} className="flex items-center gap-1.5 text-xs text-primary/80">
                        <Pencil size={10} className="flex-shrink-0" />
                        <span className="truncate font-mono text-[11px]">{ev.path}</span>
                      </div>
                    );
                  }
                  if (ev.type === "snapshot" && ev.text) {
                    return (
                      <details key={key} className="text-xs text-muted-foreground">
                        <summary className="cursor-pointer hover:text-foreground/80 select-none">Notes ({ev.text.length} chars)</summary>
                        <pre className="mt-1 whitespace-pre-wrap break-words text-[11px] text-foreground/60 max-h-40 overflow-y-auto bg-background/40 rounded px-2 py-1 border border-card-border">{ev.text}</pre>
                      </details>
                    );
                  }
                  if (ev.type === "error") {
                    const shots = ev.screenshots ?? [];
                    return (
                      <div key={key} className="space-y-1.5">
                        <div className="text-xs text-destructive whitespace-pre-wrap break-words font-mono leading-snug bg-destructive/10 border border-destructive/30 rounded px-2 py-1.5">{ev.message ?? "Build error"}</div>
                        {shots.length > 0 && (
                          <div className="flex gap-1.5 flex-wrap pt-0.5">
                            {shots.map((s, si) => (
                              <button
                                key={si}
                                type="button"
                                onClick={() => window.dispatchEvent(new CustomEvent("vance-open-lightbox", { detail: { url: s.url, label: s.label } }))}
                                className="block group text-left bg-transparent border-0 p-0 cursor-zoom-in"
                                title={s.label}
                                aria-label={`Open screenshot: ${s.label}`}
                              >
                                <img src={s.url} alt={s.label} className="h-20 w-auto rounded border border-card-border opacity-90 group-hover:opacity-100 transition-opacity" loading="lazy" />
                                <div className="text-[10px] text-muted-foreground mt-0.5 truncate max-w-[140px]">{s.label.split(" (")[0]}</div>
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  }
                  if (ev.type === "done") {
                    const files = ev.filesChanged ?? [];
                    const shots = ev.screenshots ?? [];
                    // Empty done node — happens when we synthesize a screenshots-
                    // only render after an error event. Skip the "No files
                    // changed" line so we only show the visual diff.
                    const isShotsOnly = files.length === 0 && shots.length > 0 && (ev as { __shotsOnly?: boolean }).__shotsOnly;
                    return (
                      <div key={key} className="space-y-1.5">
                        {!isShotsOnly && (
                          <div className="text-xs text-teal-300 flex items-center gap-1.5"><CheckCheck size={11} /> {files.length === 0 ? "No files changed" : `Updated ${files.length} file${files.length === 1 ? "" : "s"}`}</div>
                        )}
                        {files.length > 0 && (
                          <ul className="text-[11px] text-muted-foreground space-y-0.5 font-mono">
                            {files.slice(0, 8).map((f, fi) => <li key={fi} className="truncate">{f}</li>)}
                            {files.length > 8 && <li className="text-foreground/50">+ {files.length - 8} more</li>}
                          </ul>
                        )}
                        {shots.length > 0 && (
                          <div className="flex gap-1.5 flex-wrap pt-0.5">
                            {shots.map((s, si) => (
                              <button
                                key={si}
                                type="button"
                                onClick={() => window.dispatchEvent(new CustomEvent("vance-open-lightbox", { detail: { url: s.url, label: s.label } }))}
                                className="block group text-left bg-transparent border-0 p-0 cursor-zoom-in"
                                title={s.label}
                                aria-label={`Open screenshot: ${s.label}`}
                              >
                                <img src={s.url} alt={s.label} className="h-20 w-auto rounded border border-card-border opacity-90 group-hover:opacity-100 transition-opacity" loading="lazy" />
                                <div className="text-[10px] text-muted-foreground mt-0.5 truncate max-w-[140px]">{s.label.split(" (")[0]}</div>
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  }
                  return null;
                })}
                {live && streamText && streamText.trim() && (
                  <div className="text-xs text-foreground/70 whitespace-pre-wrap break-words bg-background/40 rounded px-2 py-1 border border-card-border max-h-40 overflow-y-auto">
                    {streamText}
                    <span className="inline-block w-0.5 h-3 bg-primary ml-0.5 animate-pulse" />
                  </div>
                )}
                {live && !streamText?.trim() && g.events.length === 0 && (
                  <span className="flex gap-1 items-center h-3">
                    <span className="w-1 h-1 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: "0ms" }} />
                    <span className="w-1 h-1 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: "150ms" }} />
                    <span className="w-1 h-1 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: "300ms" }} />
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

interface BuildEvent {
  type: "phase" | "snapshot" | "stream" | "plan" | "thinking" | "reading" | "writing" | "done" | "error" | "message";
  phase?: string;
  label?: string;
  text?: string;
  content?: string;
  message?: string;
  path?: string;
  steps?: string[];
  reasoning?: string;
  filesChanged?: string[];
  screenshots?: Array<{ url: string; label: string; ts: number }>;
}

interface ResearchEvent {
  type: "planning" | "queries" | "searching" | "fetching" | "synthesizing" | "storing" | "done" | "error" | "message";
  queries?: string[];
  query?: string;
  index?: number;
  total?: number;
  url?: string;
  title?: string;
  count?: number;
  memoriesStored?: number;
  sourcesChecked?: number;
  message?: string;
}

type VoicePreset = "female" | "male" | "robotic" | "whisper" | "sage" | "velvet" | "lucifer";

const PRESET_TO_VOICE: Record<VoicePreset, "alloy" | "echo" | "fable" | "onyx" | "nova" | "shimmer"> = {
  lucifer: "onyx",
  velvet: "fable",
  male: "echo",
  sage: "onyx",
  female: "nova",
  whisper: "shimmer",
  robotic: "alloy",
};

const voiceLabels: Record<VoicePreset, string> = {
  female: "Female",
  male: "Male",
  robotic: "Advanced Robotic",
  whisper: "Whisper",
  sage: "Sage",
  velvet: "Velvet British",
  lucifer: "Vance",
};

const CHAT_IMAGE_MAX_BYTES = 5 * 1024 * 1024;
const CHAT_FILE_MAX_BYTES = 10 * 1024 * 1024;
const CHAT_FILE_ACCEPT = "image/*,.pdf,.txt,.md,.csv,.json,.xml,.yaml,.yml,.html,.css,.js,.jsx,.ts,.tsx,.py,.go,.rs,.java,.rb,.sh,.toml,.log,application/pdf,text/*";

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === "string") resolve(reader.result);
      else reject(new Error("Could not read the selected image."));
    };
    reader.onerror = () => reject(new Error("Could not read the selected image."));
    reader.readAsDataURL(file);
  });
}

async function uploadChatImage(dataUrl: string): Promise<string> {
  const response = await fetch("/api/openai/uploads/chat-image", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ dataUrl }),
  });

  if (!response.ok) {
    let message = "Image upload failed. Please try again.";
    try {
      const payload = await response.json() as { error?: string };
      if (payload.error) message = payload.error;
    } catch {}
    throw new Error(message);
  }

  const payload = await response.json() as { url?: string };
  if (!payload.url) throw new Error("Image upload failed. Please try again.");
  return payload.url;
}

// Hoisted to module scope so that nested closures (persistWebsiteSession,
// the build-stash helpers, mount-resume effects) cannot accidentally hit a
// TDZ ReferenceError if they execute before the in-component `const` line is
// reached. Previously these were declared inside the Chat component body
// AFTER the useCallbacks that referenced them, and the `try/catch {}` around
// each sessionStorage.setItem silently swallowed the resulting TDZ throw —
// which presented as "the persist call ran but nothing landed in storage".
const ACTIVE_BUILD_KEY = "vance-active-build";
const ACTIVE_WEBSITE_SESSION_KEY = "vance-active-website-session";

export default function Chat() {
  const queryClient = useQueryClient();
  const [conversationId, setConversationId] = useState<number | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [attachedImage, setAttachedImage] = useState<{ dataUrl: string; name: string } | null>(null);
  const [attachedFile, setAttachedFile] = useState<{ fileName: string; text: string; charCount: number; truncated: boolean; originalChars: number } | null>(null);
  const [imageError, setImageError] = useState<string | null>(null);
  const [isVoiceMode, setIsVoiceMode] = useState(false);
  // isBuildMode mirrored to sessionStorage so it survives iOS PWA
  // background/restore reloads (memory pressure can recreate the SPA from
  // scratch on resume). Same lifecycle as buildUnlocked — clears when the
  // user fully closes the app, persists across minimise/return.
  const BUILD_MODE_KEY = "vance-build-mode-v1";
  const [isBuildMode, setIsBuildMode] = useState<boolean>(() => {
    try { return sessionStorage.getItem(BUILD_MODE_KEY) === "1"; } catch { return false; }
  });
  useEffect(() => {
    try {
      if (isBuildMode) sessionStorage.setItem(BUILD_MODE_KEY, "1");
      else sessionStorage.removeItem(BUILD_MODE_KEY);
    } catch { /* private mode — in-memory only */ }
  }, [isBuildMode]);
  // Password gate for orange (Regular Build) mode. Unlocked state lives in
  // sessionStorage so it persists across page reloads and PWA minimise but
  // CLEARS when the user fully closes the app — exactly the user's spec.
  // Website Build (blue) and Conversation (purple) are never gated.
  const BUILD_UNLOCK_KEY = "vance-build-unlocked-v1";
  const BUILD_PASSWORD_KEY = "vance-build-password-v1";
  const DEFAULT_BUILD_PASSWORD = "Ryan123";
  // Password is stored in localStorage so a user-chosen password survives
  // app close. Default is Ryan123 until changed via natural-language command
  // ("change build password to X" / "reset build password" / "new password
  // is X"). When the unlock-key is sessionStorage but password is local, the
  // user gets the right ergonomics: they keep their password forever, but
  // still re-enter it after fully closing the app.
  const [buildPassword, setBuildPassword] = useState<string>(() => {
    try { return localStorage.getItem(BUILD_PASSWORD_KEY) || DEFAULT_BUILD_PASSWORD; } catch { return DEFAULT_BUILD_PASSWORD; }
  });
  const updateBuildPassword = (next: string) => {
    setBuildPassword(next);
    try { localStorage.setItem(BUILD_PASSWORD_KEY, next); } catch { /* private mode — in-memory only */ }
  };
  const [buildUnlocked, setBuildUnlocked] = useState<boolean>(() => {
    try { return sessionStorage.getItem(BUILD_UNLOCK_KEY) === "1"; } catch { return false; }
  });
  const unlockBuild = () => {
    setBuildUnlocked(true);
    try { sessionStorage.setItem(BUILD_UNLOCK_KEY, "1"); } catch { /* private mode — gate stays in-memory only */ }
  };
  const [buildPasswordInput, setBuildPasswordInput] = useState("");
  const [buildPasswordError, setBuildPasswordError] = useState<string | null>(null);
  const [errorCount, setErrorCount] = useState(() => getUnreadErrorCount());
  useEffect(() => subscribeErrors(() => setErrorCount(getUnreadErrorCount())), []);
  const [voiceTranscript, setVoiceTranscript] = useState("");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sidebarBuilds, setSidebarBuilds] = useState<BuildEntry[]>([]);
  useEffect(() => { if (sidebarOpen) setSidebarBuilds(loadBuilds()); }, [sidebarOpen]);
  const [sidebarCollapsed, setSidebarCollapsed] = useState<Record<string, boolean>>(() => {
    try { return JSON.parse(localStorage.getItem("vance-sidebar-collapsed-v1") ?? "{}") as Record<string, boolean>; }
    catch { return {}; }
  });
  const toggleSidebarSection = (key: string) => setSidebarCollapsed(prev => {
    const next = { ...prev, [key]: !prev[key] };
    try { localStorage.setItem("vance-sidebar-collapsed-v1", JSON.stringify(next)); } catch {}
    return next;
  });
  const [sidebarFilter, setSidebarFilter] = useState<"all" | "website" | "build" | "chat">(
    () => (localStorage.getItem("vance-sidebar-filter-v1") as "all" | "website" | "build" | "chat" | null) ?? "all"
  );
  const setSidebarFilterPersist = (f: "all" | "website" | "build" | "chat") => {
    setSidebarFilter(f);
    try { localStorage.setItem("vance-sidebar-filter-v1", f); } catch {}
  };

  // Per-conversation chat-mode override. Lets the user lock a chat into a
  // specific persona ("switch to website mode") regardless of what the title
  // would auto-detect. Persisted in localStorage so it survives reloads.
  const MODE_OVERRIDE_KEY = "vance-chat-mode-override-v1";
  const [chatModeOverrides, setChatModeOverrides] = useState<Record<string, "website" | "build" | "chat">>(() => {
    try { return JSON.parse(localStorage.getItem(MODE_OVERRIDE_KEY) ?? "{}") as Record<string, "website" | "build" | "chat">; }
    catch { return {}; }
  });
  const setChatModeForConv = (convId: number | null, mode: "website" | "build" | "chat") => {
    if (convId == null) return;
    setChatModeOverrides(prev => {
      const next = { ...prev, [String(convId)]: mode };
      try { localStorage.setItem(MODE_OVERRIDE_KEY, JSON.stringify(next)); } catch {}
      return next;
    });
  };
  // Subtle accent tints used by the composer + header bar to reflect the
  // active mode. Hex tints (kept low-saturation so the chat stays readable);
  // a/b suffixes are alpha pairs used for border/background gradients.
  const MODE_TINT = {
    website: { hex: "#4A90E2", border: "rgba(74,144,226,0.40)", bgA: "rgba(74,144,226,0.16)", bgB: "rgba(74,144,226,0.06)", glow: "rgba(74,144,226,0.28)" },
    build:   { hex: "#FF9500", border: "rgba(255,149,0,0.42)",  bgA: "rgba(255,149,0,0.16)",  bgB: "rgba(255,149,0,0.06)",  glow: "rgba(255,149,0,0.28)"  },
    chat:    { hex: "#9B59B6", border: "rgba(155,89,182,0.40)", bgA: "rgba(155,89,182,0.16)", bgB: "rgba(155,89,182,0.06)", glow: "rgba(155,89,182,0.26)" },
  } as const;
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [researchTopic, setResearchTopic] = useState("");
  const [isResearching, setIsResearching] = useState(false);
  const [persona, setPersona] = useState<Persona | null>(null);
  const [isPersonaLoading, setIsPersonaLoading] = useState(false);
  const [showAvatar, setShowAvatar] = useState(true);
  const [ttsEnabled, setTtsEnabled] = useState(true);
  const [isPlayingTTS, setIsPlayingTTS] = useState(false);
  const [voicePreset, setVoicePreset] = useState<VoicePreset>(() => {
    const s = localStorage.getItem("vance-voice-preset");
    return s === "female" || s === "male" || s === "robotic" || s === "whisper" || s === "sage" || s === "velvet" || s === "lucifer" ? s : "velvet";
  });
  const [showVoiceMenu, setShowVoiceMenu] = useState(false);
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);

  // Long-press-to-copy on chat bubbles. Hold a bubble ~550ms to copy its
  // text to the clipboard. We use pointer events with a small movement
  // threshold so scrolling never accidentally triggers a copy. iOS PWAs
  // would otherwise show the OS callout on long-press, so we suppress the
  // native context menu on bubbles. Selecting text the normal way (drag
  // to highlight then tap "Copy") still works because we don't touch
  // user-select; the long-press is just a faster shortcut for "copy whole
  // message". The copiedMsgId state drives a transient "Copied" pill.
  const longPressTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const longPressStartRef = useRef<{ x: number; y: number } | null>(null);
  const [copiedMsgId, setCopiedMsgId] = useState<string | null>(null);
  const cancelLongPress = () => {
    if (longPressTimerRef.current) { clearTimeout(longPressTimerRef.current); longPressTimerRef.current = null; }
    longPressStartRef.current = null;
  };
  const longPressCopyHandlers = (text: string, msgId: string) => ({
    onPointerDown: (e: React.PointerEvent) => {
      // Ignore right-click / middle-click — only primary press triggers.
      if (e.button !== undefined && e.button !== 0) return;
      longPressStartRef.current = { x: e.clientX, y: e.clientY };
      longPressTimerRef.current = setTimeout(async () => {
        longPressTimerRef.current = null;
        try {
          await navigator.clipboard.writeText(text);
          setCopiedMsgId(msgId);
          try { (navigator as Navigator & { vibrate?: (p: number) => void }).vibrate?.(15); } catch { /* haptic optional */ }
          setTimeout(() => setCopiedMsgId(prev => (prev === msgId ? null : prev)), 1200);
        } catch { /* clipboard may be unavailable in insecure contexts; silent */ }
      }, 550);
    },
    onPointerMove: (e: React.PointerEvent) => {
      if (!longPressStartRef.current) return;
      const dx = e.clientX - longPressStartRef.current.x;
      const dy = e.clientY - longPressStartRef.current.y;
      if (dx * dx + dy * dy > 100) cancelLongPress(); // ~10px slop
    },
    onPointerUp: cancelLongPress,
    onPointerCancel: cancelLongPress,
    onPointerLeave: cancelLongPress,
    onContextMenu: (e: React.MouseEvent) => { e.preventDefault(); },
  });

  // Long-press-to-delete on sidebar rows (conversations + builds). Same
  // pointer-event pattern as the bubble copy: ~600ms hold, 10px slop, suppress
  // OS callout. On fire we vibrate + open a confirm dialog (so an accidental
  // hold doesn't silently nuke a build); confirming runs the supplied delete
  // callback. Tap-to-open still works because the timer is cancelled on
  // pointerup before reaching threshold. The factory takes a label that's
  // shown in the confirm prompt so the user sees WHICH row they're nuking.
  const longPressDeleteHandlers = (label: string, onDelete: () => void) => ({
    onPointerDown: (e: React.PointerEvent) => {
      if (e.button !== undefined && e.button !== 0) return;
      longPressStartRef.current = { x: e.clientX, y: e.clientY };
      longPressTimerRef.current = setTimeout(() => {
        longPressTimerRef.current = null;
        try { (navigator as Navigator & { vibrate?: (p: number) => void }).vibrate?.(25); } catch { /* haptic optional */ }
        const truncated = label.length > 60 ? `${label.slice(0, 60)}…` : label;
        if (window.confirm(`Delete "${truncated}"? This cannot be undone.`)) {
          onDelete();
        }
      }, 600);
    },
    onPointerMove: (e: React.PointerEvent) => {
      if (!longPressStartRef.current) return;
      const dx = e.clientX - longPressStartRef.current.x;
      const dy = e.clientY - longPressStartRef.current.y;
      if (dx * dx + dy * dy > 100) cancelLongPress();
    },
    onPointerUp: cancelLongPress,
    onPointerCancel: cancelLongPress,
    onPointerLeave: cancelLongPress,
    onContextMenu: (e: React.MouseEvent) => { e.preventDefault(); },
  });
  const [bodyModelUrl, setBodyModelUrl] = useState<string | null>(null);
  const [profileLoaded, setProfileLoaded] = useState(false);
  // 3D camera controls — hoisted out of VanceAvatar3D so the overlay buttons
  // can sit OUTSIDE the avatar's draggable wrapper and stay anchored to the
  // stage frame even when the user nudges the avatar. Values persist across
  // sessions in localStorage so the user's preferred framing is restored on
  // startup.
  const [avatarZoom, setAvatarZoom] = useState<number>(() => {
    try {
      const raw = localStorage.getItem("vance-avatar-zoom");
      const n = raw ? Number(raw) : NaN;
      return Number.isFinite(n) && n >= 0.5 && n <= 2.5 ? n : 1;
    } catch { return 1; }
  });
  const [avatarRotY, setAvatarRotY] = useState<number>(() => {
    try {
      const raw = localStorage.getItem("vance-avatar-roty");
      const n = raw ? Number(raw) : NaN;
      return Number.isFinite(n) ? n : 0;
    } catch { return 0; }
  });
  useEffect(() => { try { localStorage.setItem("vance-avatar-zoom", String(avatarZoom)); } catch { /* quota */ } }, [avatarZoom]);
  useEffect(() => { try { localStorage.setItem("vance-avatar-roty", String(avatarRotY)); } catch { /* quota */ } }, [avatarRotY]);
  const avatarZoomIn  = useCallback(() => setAvatarZoom((z) => Math.min(2.5, +(z + 0.25).toFixed(2))), []);
  const avatarZoomOut = useCallback(() => setAvatarZoom((z) => Math.max(0.5, +(z - 0.25).toFixed(2))), []);
  const avatarRotateL = useCallback(() => setAvatarRotY((r) => r - Math.PI / 8), []);
  const avatarRotateR = useCallback(() => setAvatarRotY((r) => r + Math.PI / 8), []);
  const avatarReset   = useCallback(() => { setAvatarZoom(1); setAvatarRotY(0); }, []);
  const [showAvatarModal, setShowAvatarModal] = useState(false);
  const [webSearchEnabled, setWebSearchEnabled] = useState(() =>
    localStorage.getItem("vance-web-search") === "true"
  );
  const [mobileBubbleLayout, setMobileBubbleLayout] = useState<MobileBubbleLayoutSettings>(() => loadMobileBubbleLayout());
  const [showMobileBubbleControls, setShowMobileBubbleControls] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesScrollRef = useRef<HTMLDivElement>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  // Web Audio analyser pipeline — taps the TTS audio element to extract
  // live amplitude (RMS) so the 3D avatar's jaw/mouth can react in sync.
  // Once createMediaElementSource(audioRef) is called the audio's output is
  // intercepted by the AudioContext, so analyser.connect(ctx.destination)
  // is REQUIRED to keep TTS audible. The ref-based amplitude avoids per-
  // frame React re-renders.
  const audioCtxRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const audioSourceRef = useRef<MediaElementAudioSourceNode | null>(null);
  const audioAmpRef = useRef<number>(0);
  const ampRafRef = useRef<number | null>(null);
  const ensureAudioAnalyser = useCallback(() => {
    if (!audioRef.current || audioSourceRef.current) return;
    try {
      const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!Ctx) return;
      const ctx = audioCtxRef.current ?? new Ctx();
      audioCtxRef.current = ctx;
      if (ctx.state === "suspended") void ctx.resume().catch(() => {});
      const src = ctx.createMediaElementSource(audioRef.current);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 512;
      analyser.smoothingTimeConstant = 0.4;
      src.connect(analyser);
      analyser.connect(ctx.destination);
      audioSourceRef.current = src;
      analyserRef.current = analyser;
      const buf = new Uint8Array(analyser.frequencyBinCount);
      const tick = () => {
        const a = analyserRef.current;
        if (a) {
          a.getByteTimeDomainData(buf);
          let sum = 0;
          for (let i = 0; i < buf.length; i++) {
            const v = (buf[i]! - 128) / 128;
            sum += v * v;
          }
          const rms = Math.sqrt(sum / buf.length);
          // Speech RMS typically ranges 0.05–0.25 — scale up so loud
          // syllables saturate near 1.0, then ease toward target for
          // smooth motion (raw values would jitter).
          const target = Math.min(1, rms * 5);
          audioAmpRef.current += (target - audioAmpRef.current) * 0.5;
        }
        ampRafRef.current = requestAnimationFrame(tick);
      };
      ampRafRef.current = requestAnimationFrame(tick);
    } catch { /* already attached or unavailable — silent fallback */ }
  }, []);
  useEffect(() => () => {
    if (ampRafRef.current != null) cancelAnimationFrame(ampRafRef.current);
    if (audioCtxRef.current) try { void audioCtxRef.current.close(); } catch { /* noop */ }
  }, []);
  const attachmentInputRef = useRef<HTMLInputElement | null>(null);
  const messageCounterRef = useRef(0);
  // Mirror of `conversationId` for use inside `useCallback([])` closures
  // (applyBuildEvent in particular) — capturing the state directly would
  // stale-close on the value at first render and persist build snapshots
  // under the wrong key after the user switches conversations.
  const conversationIdRef = useRef<number | null>(null);
  // Lightbox state — taps on the screenshot thumbnails open a full-screen
  // overlay inside the app instead of a `target="_blank"` link, which on
  // installed PWAs would kick the user out of standalone mode into the
  // system browser.
  const [lightbox, setLightbox] = useState<{ url: string; label: string } | null>(null);
  const latestTtsTokenRef = useRef(0);
  // Streaming-TTS queue. The chat reply streams in token-by-token; rather
  // than waiting for the entire reply (and then for OpenAI to render the
  // whole MP3) before any audio plays, we extract complete sentences from
  // the accumulating text, fire the TTS fetch for each one in parallel,
  // and play the resulting clips back-to-back. The first sentence starts
  // speaking within ~1s of the model emitting it, instead of after the
  // whole reply is done. Refs (not state) because the streaming loop
  // mutates these every delta and we don't want React re-renders on the
  // hot path.
  // Buffer is keyed by emission sequence number, NOT a FIFO array, because
  // chunk fetches run in parallel and complete out of order. The drain
  // logic plays whichever seq matches `ttsNextPlaySeqRef` and waits if
  // that one hasn't arrived yet — guaranteeing in-order playback even
  // when sentence 2's TTS round-trips faster than sentence 1's.
  const ttsBufferRef = useRef<Map<number, { blob: Blob; text: string; turnId: number; msgClientId: string | null; rawStart: number; rawEnd: number; rawText: string }>>(new Map());
  const ttsDrainingRef = useRef(false);
  const ttsTurnIdRef = useRef(0);            // increments per assistant turn (and on stop)
  const ttsSpokenIdxRef = useRef(0);         // chars of current turn's fullContent already chunked
  const ttsCutHitRef = useRef(false);        // hit the Sources/URL boundary — stop emitting
  const ttsEmoteStartedRef = useRef(false);  // detectEmote runs once per turn, on the first chunk
  const ttsNextSeqRef = useRef(0);           // seq assigned to the next chunk we emit
  const ttsNextPlaySeqRef = useRef(0);       // seq the drain loop is currently waiting to play
  const ttsAbortControllersRef = useRef<AbortController[]>([]);
  // Karaoke-style word-highlight state. The currently-speaking message's
  // assistant clientId + the absolute char range (in that message's
  // content) of the word being spoken right now. Updated by a rAF loop
  // started in drainTTSQueue on each chunk's onplay; cleared on chunk
  // end or stopTTS.
  const [ttsHighlight, setTtsHighlight] = useState<{ msgClientId: string; start: number; end: number } | null>(null);
  // Active message id is captured at sendTextMessage start (in beginTTSTurn)
  // so chunk-emission code can tag each chunk with the right message.
  const ttsActiveMsgIdRef = useRef<string | null>(null);
  // Per-chunk word-timing schedule: precomputed when a chunk starts
  // playing so the rAF tick is just a fast lookup. `tStart` is the
  // fraction (0..1) of the audio duration at which the word begins.
  const ttsWordSchedRef = useRef<{ absStart: number; absEnd: number; tStart: number }[]>([]);
  const ttsHighlightRafRef = useRef<number | null>(null);
  // AbortController for the in-flight chat / build request, plus a snapshot
  // of the user's text so the Stop button can restore it for editing.
  const inFlightAbortRef = useRef<AbortController | null>(null);
  const lastSubmittedInputRef = useRef<string>("");
  // Tracks the server-side build id of the currently-running build, so the
  // Stop button can ask the server to actually cancel it (just aborting the
  // browser fetch isn't enough — the runner now lives independently of the
  // SSE connection and would keep editing files in the background).
  const activeBuildIdRef = useRef<string | null>(null);
  const stopGeneration = useCallback(() => {
    const buildId = activeBuildIdRef.current;
    if (buildId) {
      void fetch(`/api/vance/build/${buildId}/cancel`, { method: "POST" }).catch(() => { /* best effort */ });
      activeBuildIdRef.current = null;
    }
    inFlightAbortRef.current?.abort();
    inFlightAbortRef.current = null;
    setMessages((prev) => {
      const next = [...prev];
      const last = next[next.length - 1];
      if (last?.role === "assistant" && last.streaming) {
        const partial = last.buildEvents && last.buildEvents.length > 0
          ? { ...last, streaming: false, buildEvents: [...last.buildEvents, { type: "error" as const, message: "Stopped by user" }] }
          : null;
        next.pop();
        if (partial) next.push(partial);
      }
      return next;
    });
    setIsSending(false);
    if (lastSubmittedInputRef.current) {
      setInput(lastSubmittedInputRef.current);
      lastSubmittedInputRef.current = "";
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(MOBILE_BUBBLE_LAYOUT_KEY, JSON.stringify(clampMobileBubbleLayout(mobileBubbleLayout)));
    } catch {}
  }, [mobileBubbleLayout]);

  const nextClientId = useCallback((prefix: string) => {
    messageCounterRef.current += 1;
    return `${prefix}-${Date.now()}-${messageCounterRef.current}`;
  }, []);

  const mapServerMessages = useCallback((
    serverMessages: Array<{ id: number; role: string; content: string; imageUrl?: string | null; extraImageUrls?: string[] | null; createdAt?: string }>,
    convId: number | null,
    convMode: "website" | "build" | "chat" | undefined,
  ) => {
    // Pull persisted state once per refetch instead of per message — these
    // are localStorage reads + JSON.parse, cheap but pointless to repeat.
    const resolvedProposals = loadResolvedProposals();
    const resolvedIntakes = loadResolvedIntakes();
    const buildResults = loadBuildResults();
    return serverMessages.map((m, index) => {
      // Server doesn't persist proposal-card state, so on first load we
      // re-derive it from the message content. The merge step below preserves
      // any client-side status the user has already set (accepted/cancelled).
      const role = m.role as "user" | "assistant";
      if (role === "assistant") {
        // Strip ```vance-file``` blocks first so propose-edit/build-result
        // detection runs on file-free text. Files persist via the fenced
        // block in messages.content; rehydrate them as download cards.
        const fileExtract = extractFiles(m.content);
        // Strip intake fence next so it doesn't get fed into proposal parsing.
        const intakeExtract = extractIntake(fileExtract.cleaned);
        const contentForProposal = intakeExtract.cleaned;
        const persistedFiles = fileExtract.files.length > 0 ? fileExtract.files : undefined;
        const intake: IntakeState | undefined = intakeExtract.prefill !== null
          ? {
              prefill: intakeExtract.prefill,
              status: (convId ? (resolvedIntakes[`${convId}:${m.id}`] ?? "open") : "open"),
            }
          : undefined;
        const { cleaned, instruction, kind } = extractProposal(contentForProposal, convMode);
        if (instruction) {
          // If the user already accepted/cancelled this proposal in a prior
          // session, restore that status from localStorage so the approval
          // card doesn't re-pop after navigating away and back.
          const persistedStatus = convId
            ? (resolvedProposals[`${convId}:${m.id}`] ?? resolvedProposals[proposalSigKey(convId, instruction)])
            : undefined;
          return {
            id: m.id,
            clientId: `server-${m.id}-${index}`,
            role,
            content: cleaned,
            imageUrl: m.imageUrl ?? null,
            extraImageUrls: m.extraImageUrls ?? null,
            proposal: { instruction, kind, status: (persistedStatus ?? "pending") as BuildProposal["status"] },
            intake,
            files: persistedFiles,
            createdAt: m.createdAt,
          };
        }
        // Intake-only assistant message (form fence but no proposal). Render
        // the cleaned text + the interactive intake card.
        if (intake) {
          return {
            id: m.id,
            clientId: `server-${m.id}-${index}`,
            role,
            content: intakeExtract.cleaned,
            imageUrl: m.imageUrl ?? null,
            extraImageUrls: m.extraImageUrls ?? null,
            intake,
            files: persistedFiles,
            createdAt: m.createdAt,
          };
        }
        // Rehydrate completed builds — if this assistant message matches a
        // saved build snapshot (by content signature), reconstruct the
        // BuildProgress panel so the file list + before/after screenshots
        // still show after re-entering the app. STRICT MODE ISOLATION:
        // only rehydrate in orange Regular Build conversations. A purple/
        // blue chat must never surface a build-progress panel even if a
        // historic message text happens to match a saved signature.
        if (convId && convMode === "build") {
          const snap = buildResults[buildResultKey(convId, m.content)];
          if (snap) {
            const events: BuildEvent[] = [];
            if (snap.errorMessage) {
              events.push({ type: "error", message: snap.errorMessage, screenshots: snap.screenshots });
            }
            events.push({
              type: "done",
              filesChanged: snap.filesChanged ?? [],
              screenshots: snap.screenshots ?? [],
            });
            return {
              id: m.id,
              clientId: `server-${m.id}-${index}`,
              role,
              content: m.content,
              imageUrl: m.imageUrl ?? null,
            extraImageUrls: m.extraImageUrls ?? null,
              isBuildResult: true,
              buildEvents: events,
              createdAt: m.createdAt,
            };
          }
        }
      }
      // Plain assistant/user message — still strip vance-file fences if the
      // assistant produced any so the cleaned text + file list both surface.
      if (role === "assistant") {
        const fileExtract = extractFiles(m.content);
        return {
          id: m.id,
          clientId: `server-${m.id}-${index}`,
          role,
          content: fileExtract.cleaned,
          imageUrl: m.imageUrl ?? null,
          extraImageUrls: m.extraImageUrls ?? null,
          files: fileExtract.files.length > 0 ? fileExtract.files : undefined,
          createdAt: m.createdAt,
        };
      }
      return {
        id: m.id,
        clientId: `server-${m.id}-${index}`,
        role,
        content: m.content,
        imageUrl: m.imageUrl ?? null,
        createdAt: m.createdAt,
      };
    });
  }, []);

  // Merge fresh server messages with the existing local list so we DO NOT
  // wipe client-only UI state on refetch. Without this, every conversation
  // refetch (which happens after every chat reply) would:
  //   - reset an "accepted"/"cancelled" proposal back to "pending" → the
  //     approval card pops back over a build that's already running, and
  //     the user can no longer interact with it
  //   - drop any in-flight build-result message (no server id yet) → the
  //     build progress UI vanishes mid-stream and the chat looks frozen
  // We match by server `id`, preserve local proposal status + build fields
  // for known messages, and keep trailing local-only messages.
  const mergeServerMessages = useCallback((
    serverMessages: Array<{ id: number; role: string; content: string; imageUrl?: string | null; extraImageUrls?: string[] | null }>,
    localMessages: Message[],
  ): Message[] => {
    const localById = new Map<number, Message>();
    for (const m of localMessages) {
      if (typeof m.id === "number") localById.set(m.id, m);
    }
    // Local messages that haven't been assigned a server id yet (i.e.
    // a turn that just finished streaming and is about to be reconciled
    // by an invalidate refetch). We match these against unmatched server
    // messages BY ROLE+ORDER so the local clientId is preserved across
    // the merge. Without this, the in-flight assistantClientId tagged
    // on TTS chunks (used by the karaoke highlight) would no longer
    // match the rendered message after merge.
    const pendingByRole: Record<string, Message[]> = { user: [], assistant: [] };
    for (const m of localMessages) {
      if (typeof m.id !== "number" && (m.role === "user" || m.role === "assistant")) {
        pendingByRole[m.role]!.push(m);
      }
    }
    const mapped = mapServerMessages(serverMessages, conversationId ?? null, currentChatMode).map((srv) => {
      const local = typeof srv.id === "number" ? localById.get(srv.id) : undefined;
      if (!local) {
        const pendingList = pendingByRole[srv.role];
        const pending = pendingList?.shift();
        if (pending) {
          return {
            ...srv,
            clientId: pending.clientId,
            proposal: pending.proposal ?? srv.proposal,
            streaming: pending.streaming,
            buildEvents: pending.buildEvents,
            buildStream: pending.buildStream,
            buildPhase: pending.buildPhase,
            isBuildResult: pending.isBuildResult,
            isResearchResult: pending.isResearchResult,
            researchEvents: pending.researchEvents,
            sources: pending.sources,
            sourcesQuery: pending.sourcesQuery,
            webSearched: pending.webSearched,
            browsingQuery: pending.browsingQuery,
          };
        }
        return srv;
      }
      const merged: Message = {
        ...srv,
        clientId: local.clientId,
        // Preserve interactive proposal state (accepted/editing/cancelled).
        // Only fall back to the freshly-derived "pending" if the local copy
        // never had one (e.g. a different message type before).
        proposal: local.proposal ?? srv.proposal,
        // Preserve any build / research / streaming UI state attached to this
        // assistant turn — none of this round-trips through the server.
        streaming: local.streaming,
        buildEvents: local.buildEvents,
        buildStream: local.buildStream,
        buildPhase: local.buildPhase,
        isBuildResult: local.isBuildResult,
        researchEvents: local.researchEvents,
        isResearchResult: local.isResearchResult,
        sources: local.sources,
        sourcesQuery: local.sourcesQuery,
        browsingQuery: local.browsingQuery,
        webSearched: local.webSearched,
      };
      return merged;
    });
    // Keep local-only messages ONLY if they're still in-flight or carry
    // client-only UI state the server doesn't persist. Once a regular chat
    // reply finishes streaming, the server copy supersedes the optimistic
    // pair — keeping both is what causes the visible double-feed.
    //
    // Special case for completed build/research results: their local copy
    // never gets a server `id` stamped onto it (the build SSE stream emits
    // `done` without the persisted message row id), so they'd otherwise live
    // forever in trailing-only and float to the bottom of the chat after
    // every subsequent reply — visually clobbering Vance's newest answer.
    // Drop them here once the server has persisted a row with the same
    // role+content; the rehydrated server copy (with buildEvents restored
    // from localStorage in `mapServerMessages`) takes over in the correct
    // chronological slot.
    const trailingLocalOnly = localMessages.filter((m) => {
      if (typeof m.id === "number") return false;
      if ((m.isBuildResult || m.isResearchResult) && !m.streaming) {
        const persisted = serverMessages.some((srv) => srv.role === m.role && srv.content === m.content);
        if (persisted) return false;
      }
      return Boolean(
        m.streaming ||
        m.isBuildResult ||
        m.isResearchResult ||
        (m.buildEvents && m.buildEvents.length) ||
        (m.researchEvents && m.researchEvents.length),
      );
    });
    return [...mapped, ...trailingLocalOnly];
  }, [mapServerMessages, conversationId]);

  const BECOME_PATTERN = /\b(?:become|transform into|turn into|look like|appear as|channel|embody|morph into|take the form of|dress as|play as|be)\s+(?:a\s+|an\s+|the\s+)?([a-zA-Z][a-zA-Z\s\-']{1,50}?)(?:\s+for\s+me|\s+please|\s+now|\s*[.!?]|\s*$)/i;
  const AVATAR_PATTERN = /\b(?:change\s+(?:your|the)\s+(?:avatar|look|face|photo|picture|image)|update\s+(?:your|the)\s+(?:avatar|look|photo|image)|(?:generate|create|make)\s+(?:a\s+)?(?:new\s+)?avatar|show\s+(?:me\s+)?(?:your\s+)?avatar\s+settings|(?:set|upload)\s+(?:your|a\s+)?(?:avatar|photo|picture|image)|(?:edit|customize)\s+(?:your\s+)?(?:avatar|look|appearance))\b/i;

  const { data: conversations } = useListOpenaiConversations();
  // Single source of truth for "what mode is the current chat in?". Override
  // wins; otherwise we derive from the title using the same regex the colored
  // sidebar uses. Recomputed only when conv id, title, or override changes.
  const currentChatMode = useMemo<"website" | "build" | "chat" | undefined>(() => {
    if (conversationId == null) return undefined;
    const ovr = chatModeOverrides[String(conversationId)];
    if (ovr) return ovr;
    const c = conversations?.find(x => x.id === conversationId);
    return c ? categorizeText(c.title) : "chat";
  }, [conversationId, conversations, chatModeOverrides]);
  const currentTint = currentChatMode ? MODE_TINT[currentChatMode] : null;
  const currentModeLabel = currentChatMode === "website" ? "Website Build" : currentChatMode === "build" ? "Code Build" : "Conversation";
  const currentModeEmoji = currentChatMode === "website" ? "🔵" : currentChatMode === "build" ? "🟠" : "🟣";

  // Per-chat message tail limit. Keeps the view focused on recent context;
  // older messages stay in the conversation (still in the DB, still in the
  // model's history server-side) and can be revealed with one tap. Reset to
  // collapsed whenever the user switches conversations.
  // Strip any leftover mode-tag header line from assistant text. Old saved
  // messages may still contain "🟣 **[Conversation Mode - Purple]**" (or the
  // blue/orange variants) from before we removed the prompt rule. The tag is
  // also defensively stripped while streaming in case the model slips one in.
  // We only strip if the tag is at the very start of the content so we never
  // touch legitimate user text.
  const MODE_TAG_RE = /^\s*[🟣🔵🟠]\s*\*{0,2}\[\s*(?:Conversation|Website Build|Regular Build|Build)\s+Mode[^\]]*\]\*{0,2}\s*\n+/i;
  const stripModeTag = (s: string) => s.replace(MODE_TAG_RE, "");

  const MESSAGES_TAIL_LIMIT = 10;
  const [showAllMessages, setShowAllMessages] = useState(false);
  useEffect(() => { setShowAllMessages(false); }, [conversationId]);

  // Per-mode history navigation. Each conversation already stores its own
  // messages on the server, so "switching mode = jumping to the latest chat
  // in that mode" gives instantly-resumable per-mode history without any new
  // storage layer. `conversations` already arrives newest-first from the API.
  const latestConvIdForMode = useCallback((mode: "website" | "build" | "chat"): number | null => {
    if (!conversations) return null;
    for (const c of conversations) {
      const m = chatModeOverrides[String(c.id)] ?? categorizeText(c.title);
      if (m === mode) return c.id;
    }
    return null;
  }, [conversations, chatModeOverrides]);

  const { data: conversationData } = useGetOpenaiConversation(
    conversationId!,
    { query: { enabled: !!conversationId, queryKey: getGetOpenaiConversationQueryKey(conversationId!) } }
  );
  const createConversation = useCreateOpenaiConversation();
  const deleteConversation = useDeleteOpenaiConversation();
  const deleteMessage = useDeleteOpenaiMessage();

  // Delete a single chat bubble. Triggered by the small X on each bubble.
  // Optimistically pops it from local state so the UI feels instant; if the
  // server delete fails (e.g. message wasn't yet persisted), we re-fetch the
  // conversation so local state snaps back to truth instead of silently
  // diverging. Streaming/in-flight messages (no numeric id yet) are removed
  // local-only — there's nothing on the server to delete yet.
  const handleDeleteMessage = useCallback(async (msg: Message) => {
    if (!window.confirm("Delete this message? This can't be undone.")) return;
    setMessages((prev) => prev.filter((m) => m.clientId !== msg.clientId));
    if (typeof msg.id === "number" && conversationId) {
      try {
        await deleteMessage.mutateAsync({ id: conversationId, messageId: msg.id });
      } catch (err) {
        // Server reject (already gone, conv mismatch, etc.) — re-sync from server
        // so the bubble doesn't reappear-then-vanish on the next refetch.
        await queryClient.invalidateQueries({ queryKey: getGetOpenaiConversationQueryKey(conversationId) });
        await queryClient.invalidateQueries({ queryKey: getListOpenaiMessagesQueryKey(conversationId) });
        // Surface to the user so a real failure isn't silent.
        window.alert("Couldn't delete that message. Pull to refresh and try again.");
        // eslint-disable-next-line no-console
        console.warn("[delete-message]", err);
      }
    }
  }, [conversationId, deleteMessage, queryClient]);
  const webSearch = useVanceWebSearch();

  const workletPath = `${import.meta.env.BASE_URL}audio-playback-worklet.js`;

  const clearAudioHandlers = useCallback((audio: HTMLAudioElement | null) => {
    if (!audio) return;
    audio.onplay = null;
    audio.onplaying = null;
    audio.onpause = null;
    audio.onended = null;
    audio.onerror = null;
  }, []);

  const voiceStream = useVoiceStream({
    workletPath,
    onTranscript: (delta, full) => { void delta; setVoiceTranscript(full); },
    onComplete: async (fullTranscript) => {
      setVoiceTranscript("");
      setIsSending(false);
      if (conversationId) {
        const updated = await queryClient.fetchQuery({
          queryKey: getGetOpenaiConversationQueryKey(conversationId),
          queryFn: async () => {
            const res = await fetch(`/api/openai/conversations/${conversationId}`);
            return res.json() as Promise<{ messages: Array<{ id: number; role: string; content: string }> }>;
          },
          staleTime: 0,
        });
        if (updated?.messages) setMessages((prev) => mergeServerMessages(updated.messages, prev));
      }
      void fullTranscript;
    },
    onError: () => { setIsSending(false); setVoiceTranscript(""); },
  });

  const { state: recordingState, startRecording, stopRecording } = useVoiceRecorder();
  const isRecording = recordingState === "recording";

  const avatarState: "idle" | "thinking" | "speaking" =
    isRecording || !!voiceTranscript || isPlayingTTS ? "speaking" :
    isSending || isResearching ? "thinking" :
    "idle";

  // Emote system: a small picker at top-left of the avatar stage triggers
  // one of the six Mixamo-uploaded clips. Auto-clears after the clip's
  // duration so consecutive triggers don't stack.
  const [emote, setEmote] = useState<Emote | null>(null);
  const [speechEmote, setSpeechEmote] = useState<Emote | null>(null);
  const emoteTokenRef = useRef(0);
  const emoteRafRef = useRef<number | null>(null);
  const emoteTimerRef = useRef<number | null>(null);
  const speechEmoteTokenRef = useRef(0);
  const clearSpeechEmote = useCallback(() => {
    speechEmoteTokenRef.current += 1;
    setSpeechEmote(null);
  }, []);
  const startSpeechEmote = useCallback((next: Emote | null) => {
    const token = ++speechEmoteTokenRef.current;
    setSpeechEmote(null);
    if (!next) return;
    requestAnimationFrame(() => {
      if (speechEmoteTokenRef.current !== token) return;
      setSpeechEmote(next);
    });
  }, []);
  const triggerEmote = useCallback((next: Emote) => {
    const token = ++emoteTokenRef.current;
    if (emoteRafRef.current !== null) cancelAnimationFrame(emoteRafRef.current);
    if (emoteTimerRef.current !== null) window.clearTimeout(emoteTimerRef.current);
    setEmote(null);
    emoteRafRef.current = requestAnimationFrame(() => {
      emoteRafRef.current = null;
      if (emoteTokenRef.current !== token) return;
      setEmote(next);
      emoteTimerRef.current = window.setTimeout(() => {
        emoteTimerRef.current = null;
        if (emoteTokenRef.current !== token) return;
        setEmote(null);
      }, emoteDuration(next) * 1000 + 200);
    });
  }, []);
  useEffect(() => () => {
    if (emoteRafRef.current !== null) cancelAnimationFrame(emoteRafRef.current);
    if (emoteTimerRef.current !== null) window.clearTimeout(emoteTimerRef.current);
    speechEmoteTokenRef.current += 1;
  }, []);
  const activeAvatarEmote = speechEmote ?? emote;

  // Shared TTS-text cleaner used by both live streaming and replay so the
  // two paths produce identical audio for the same source text.
  const cleanChunkForTTS = useCallback((raw: string) => raw
    .replace(/```[\s\S]*?```/g, "code block.")
    .replace(/\[([^\]]+)\]\(https?:\/\/[^)]+\)/g, "$1")
    .replace(/`[^`]+`/g, "")
    .replace(/[*_#~>\-]+/g, " ")
    .replace(/\s{2,}/g, " ")
    .trim(), []);

  const stopTTS = useCallback(() => {
    latestTtsTokenRef.current += 1;
    // Tear down the streaming-TTS queue: invalidate the turn id so any
    // in-flight fetches discard their result, abort the underlying
    // requests so they don't waste OpenAI quota, drop everything queued,
    // and reset the per-turn cursors.
    ttsTurnIdRef.current += 1;
    ttsBufferRef.current.clear();
    ttsDrainingRef.current = false;
    ttsCutHitRef.current = true;        // beginTTSTurn() flips this back when a new turn starts
    ttsSpokenIdxRef.current = 0;
    ttsEmoteStartedRef.current = false;
    ttsNextSeqRef.current = 0;
    ttsNextPlaySeqRef.current = 0;
    for (const c of ttsAbortControllersRef.current) { try { c.abort(); } catch { /* noop */ } }
    ttsAbortControllersRef.current = [];
    if (ttsHighlightRafRef.current != null) { cancelAnimationFrame(ttsHighlightRafRef.current); ttsHighlightRafRef.current = null; }
    ttsWordSchedRef.current = [];
    ttsActiveMsgIdRef.current = null;
    setTtsHighlight(null);
    clearSpeechEmote();
    if (audioRef.current) {
      clearAudioHandlers(audioRef.current);
      audioRef.current.pause();
    }
    setIsPlayingTTS(false);
  }, [clearAudioHandlers, clearSpeechEmote]);

  // Jump to (or create) the most recent conversation in the target mode. This
  // is what powers the mode pill — switching modes should swap to that mode's
  // own active thread, not relabel the current one. If no conversation exists
  // for the target mode yet, we create a fresh one with a mode-flavoured
  // title so it auto-categorises correctly even after a localStorage wipe.
  const switchToMode = useCallback(async (mode: "website" | "build" | "chat") => {
    if (!conversations) return;
    const existing = latestConvIdForMode(mode);
    if (existing != null) {
      if (existing !== conversationId) {
        setConversationId(existing);
        setMessages([]);
        stopTTS();
      }
      return;
    }
    const now = new Date();
    const stamp = now.toLocaleDateString("en-US", { month: "short", day: "numeric" });
    const titlePrefix = mode === "website" ? "Website" : mode === "build" ? "Build" : "Chat";
    const title = `${titlePrefix} — ${stamp}`;
    const conv = await createConversation.mutateAsync({ data: { title } });
    setChatModeOverrides(prev => {
      const next = { ...prev, [String(conv.id)]: mode };
      try { localStorage.setItem(MODE_OVERRIDE_KEY, JSON.stringify(next)); } catch { /* ignore */ }
      return next;
    });
    setConversationId(conv.id);
    setMessages([]);
    stopTTS();
    await queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
  }, [conversations, conversationId, latestConvIdForMode, createConversation, queryClient, stopTTS]);

  // Reset per-turn streaming-TTS state at the start of a fresh assistant
  // reply. stopTTS() above leaves cutHit=true so no stragglers leak; this
  // re-opens the gates for the new turn. msgClientId tags every chunk
  // emitted this turn so the karaoke-style word highlight knows which
  // bubble in the message list to light up.
  const beginTTSTurn = useCallback((msgClientId: string) => {
    ttsSpokenIdxRef.current = 0;
    ttsCutHitRef.current = false;
    ttsEmoteStartedRef.current = false;
    ttsActiveMsgIdRef.current = msgClientId;
  }, []);

  // Pulls the NEXT-IN-SEQUENCE blob and plays it, chaining onended →
  // drainTTSQueue() so clips play back-to-back. If the next-in-sequence
  // chunk hasn't finished its TTS fetch yet, this returns silently and
  // will be re-triggered by fetchAndQueueTTSChunk() the moment that
  // chunk's fetch resolves. Reuses the single audioRef element (which
  // is also the analyser tap for jaw movement, and is the one element
  // iOS lets us autoplay after primeSpeech).
  const drainTTSQueue = useCallback(() => {
    if (ttsDrainingRef.current) return;
    const wantSeq = ttsNextPlaySeqRef.current;
    const next = ttsBufferRef.current.get(wantSeq);
    if (!next) {
      // Either no chunks emitted yet OR the next-needed one hasn't
      // come back from OpenAI yet. Stay idle; the fetch resolver will
      // call us again. We do NOT skip ahead — that would scramble the
      // playback order.
      return;
    }
    if (next.turnId !== ttsTurnIdRef.current) {
      // Stale chunk from a cancelled turn — discard and advance.
      ttsBufferRef.current.delete(wantSeq);
      ttsNextPlaySeqRef.current += 1;
      drainTTSQueue();
      return;
    }
    ttsBufferRef.current.delete(wantSeq);
    let audio = audioRef.current;
    if (!audio) { audio = new Audio(); audioRef.current = audio; }
    ensureAudioAnalyser();
    clearAudioHandlers(audio);
    ttsDrainingRef.current = true;
    const url = URL.createObjectURL(next.blob);
    let finished = false;
    // Precompute word schedule for this chunk so the rAF tick is just a
    // fast lookup. Each whitespace-separated token gets a time slot
    // proportional to its character count — close enough to actual TTS
    // pacing that the highlight tracks the spoken word within ~1 word
    // of accuracy. (OpenAI's TTS doesn't return word timestamps, and
    // running Whisper alignment per chunk would cost another round-trip
    // per chunk; proportional scheduling is the standard karaoke trick.)
    const sched: { absStart: number; absEnd: number; tStart: number }[] = [];
    {
      const wordRe = /\S+/g;
      let m: RegExpExecArray | null;
      const words: { absStart: number; absEnd: number; len: number }[] = [];
      let totalLen = 0;
      while ((m = wordRe.exec(next.rawText)) !== null) {
        const len = m[0].length;
        words.push({ absStart: next.rawStart + m.index, absEnd: next.rawStart + m.index + len, len });
        totalLen += len;
      }
      if (totalLen > 0) {
        let cum = 0;
        for (const w of words) {
          sched.push({ absStart: w.absStart, absEnd: w.absEnd, tStart: cum / totalLen });
          cum += w.len;
        }
      }
    }
    ttsWordSchedRef.current = sched;
    const msgIdForChunk = next.msgClientId;
    if (ttsHighlightRafRef.current != null) { cancelAnimationFrame(ttsHighlightRafRef.current); ttsHighlightRafRef.current = null; }

    const finish = () => {
      if (finished) return;
      finished = true;
      URL.revokeObjectURL(url);
      ttsDrainingRef.current = false;
      ttsNextPlaySeqRef.current += 1;
      if (ttsHighlightRafRef.current != null) { cancelAnimationFrame(ttsHighlightRafRef.current); ttsHighlightRafRef.current = null; }
      // Try the next seq immediately; if not ready, drain returns
      // silently and waits for its fetch to resolve.
      drainTTSQueue();
      if (!ttsBufferRef.current.has(ttsNextPlaySeqRef.current)) {
        setIsPlayingTTS(false);
        // Last chunk of the turn ended — clear the highlight so the
        // bubble settles back to plain text.
        setTtsHighlight(null);
      }
    };
    // rAF tick: maps audio.currentTime → fraction → active word.
    // Binary search isn't worth the complexity; sched is short (~30
    // words per chunk) and modern engines do the linear scan in <0.01ms.
    const tick = () => {
      const a = audioRef.current;
      const s = ttsWordSchedRef.current;
      if (!a || s.length === 0 || finished) {
        ttsHighlightRafRef.current = null;
        return;
      }
      const d = a.duration;
      if (!d || !isFinite(d) || d <= 0) {
        ttsHighlightRafRef.current = requestAnimationFrame(tick);
        return;
      }
      const frac = Math.min(1, Math.max(0, a.currentTime / d));
      // Find the LATEST word whose tStart ≤ frac
      let active = s[0]!;
      for (let i = 0; i < s.length; i++) {
        if (s[i]!.tStart <= frac) active = s[i]!;
        else break;
      }
      if (msgIdForChunk) {
        setTtsHighlight((prev) => {
          if (prev && prev.msgClientId === msgIdForChunk && prev.start === active.absStart && prev.end === active.absEnd) return prev;
          return { msgClientId: msgIdForChunk, start: active.absStart, end: active.absEnd };
        });
      }
      ttsHighlightRafRef.current = requestAnimationFrame(tick);
    };

    audio.src = url;
    audio.onplay = () => {
      flushSync(() => {
        setIsPlayingTTS(true);
        if (!ttsEmoteStartedRef.current) {
          ttsEmoteStartedRef.current = true;
          startSpeechEmote(detectEmote(next.text));
        }
      });
      // Start the highlight tick once playback actually begins (so we
      // don't show a stale highlight from a previous chunk during the
      // brief loadedmetadata→play gap).
      if (ttsHighlightRafRef.current == null && msgIdForChunk) {
        ttsHighlightRafRef.current = requestAnimationFrame(tick);
      }
    };
    audio.onplaying = audio.onplay;
    audio.onended = finish;
    audio.onerror = finish;
    audio.onpause = () => { if (audio!.ended || audio!.currentTime === 0) return; finish(); };
    audio.play().catch(() => finish());
  }, [clearAudioHandlers, ensureAudioAnalyser, startSpeechEmote]);

  // Fires the TTS fetch for one chunk and stores the resulting MP3 at
  // its emission sequence number. Multiple chunks fetch in parallel
  // (OpenAI handles ~10/s easily) and may return in ANY order; storing
  // by seq + a drain loop that waits for the next-needed seq guarantees
  // playback order matches emission order regardless of fetch latency.
  const fetchAndQueueTTSChunk = useCallback(async (text: string, turnId: number, voice: string, seq: number, msgClientId: string | null, rawStart: number, rawEnd: number, rawText: string) => {
    if (turnId !== ttsTurnIdRef.current) return;
    const ctrl = new AbortController();
    ttsAbortControllersRef.current.push(ctrl);
    try {
      const res = await fetch("/api/openai/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: text.slice(0, 4000), voice }),
        signal: ctrl.signal,
      });
      if (!res.ok || turnId !== ttsTurnIdRef.current) return;
      const blob = await res.blob();
      if (turnId !== ttsTurnIdRef.current) return;
      ttsBufferRef.current.set(seq, { blob, text, turnId, msgClientId, rawStart, rawEnd, rawText });
      drainTTSQueue();
    } catch { /* aborted or network */ }
  }, [drainTTSQueue]);

  // Inspects the accumulating fullContent and emits any newly-ready
  // sentence chunks for TTS. Called on every streaming delta with
  // isFinal=false, then once with isFinal=true after the stream closes
  // to flush whatever's left.
  //
  // Stop conditions: anything past a "Sources:" line or a bare URL is
  // skipped — that block is for the eye to click, not the ear. Once the
  // cut marker is seen, ttsCutHitRef latches and no further chunks emit
  // for this turn (even if more text streams in past it).
  const maybeEmitTTSChunks = useCallback((fullText: string, isFinal: boolean) => {
    if (!ttsEnabled) return;
    if (ttsCutHitRef.current) return;
    if (ttsSpokenIdxRef.current >= fullText.length) return;
    const turnId = ttsTurnIdRef.current;
    const voice = PRESET_TO_VOICE[voicePreset];
    const pending = fullText.slice(ttsSpokenIdxRef.current);

    // Find the cut marker (Sources: header OR first bare URL) in the
    // pending region. If found, the chunk is everything BEFORE it and
    // we latch cutHit so no more chunks emit this turn.
    const sourcesM = pending.match(/(?:^|\n)\s*Sources?\s*:/i);
    const urlM = pending.match(/https?:\/\//i);
    const cutCandidates: number[] = [];
    if (sourcesM && typeof sourcesM.index === "number") cutCandidates.push(sourcesM.index);
    if (urlM && typeof urlM.index === "number") cutCandidates.push(urlM.index);

    let endIdx = -1;
    let isLastChunk = false;
    if (cutCandidates.length > 0) {
      endIdx = Math.min(...cutCandidates);
      isLastChunk = true;
    } else if (isFinal) {
      endIdx = pending.length;
      isLastChunk = true;
    } else {
      // Mid-stream: take up to the LAST complete sentence boundary in
      // pending and emit ALL of it as ONE chunk. This is the key to
      // smooth playback — each TTS request becomes one continuous audio
      // clip with no inter-sentence gap, and we make far fewer round
      // trips overall (less risk that the next-needed clip hasn't
      // arrived in time and the speaker goes silent waiting for it).
      // Min chunk size 80 chars: small enough that the FIRST chunk
      // still fires fast (~one short sentence), large enough that
      // typical chunks contain 1–4 sentences instead of one fragment.
      let lastBoundary = -1;
      const re = /[.!?…](?:["')\]]*)(?=\s|$)/g;
      let m: RegExpExecArray | null;
      while ((m = re.exec(pending)) !== null) lastBoundary = m.index + m[0].length;
      if (lastBoundary < 80) {
        // Paragraph break fallback (e.g. list items / quoted blocks).
        const nl = pending.lastIndexOf("\n\n");
        if (nl >= 80) lastBoundary = nl + 2;
      }
      if (lastBoundary < 80) return;  // not enough yet — wait for more deltas
      endIdx = lastBoundary;
    }

    const rawStart = ttsSpokenIdxRef.current;
    const rawChunk = pending.slice(0, endIdx);
    const rawEnd = rawStart + endIdx;
    ttsSpokenIdxRef.current = rawEnd;
    if (isLastChunk) ttsCutHitRef.current = true;

    const cleaned = cleanChunkForTTS(rawChunk);
    if (cleaned.length < 3) return;

    // Assign a sequence number BEFORE the await so the order matches
    // emission order, not fetch-completion order. The drain loop plays
    // strictly in seq order, waiting if a lower seq hasn't arrived yet.
    // rawStart/rawEnd/rawText travel with the chunk so the karaoke
    // highlight can map audio.currentTime → an absolute char range in
    // the message's displayed content.
    const seq = ttsNextSeqRef.current++;
    void fetchAndQueueTTSChunk(cleaned, turnId, voice, seq, ttsActiveMsgIdRef.current, rawStart, rawEnd, rawChunk);
  }, [ttsEnabled, voicePreset, fetchAndQueueTTSChunk, cleanChunkForTTS]);

  const EMOTE_LIST: { id: Emote; label: string; emoji: string }[] = [
    { id: "nod_yes",          label: "Yes",          emoji: "✅" },
    { id: "shake_no",         label: "No",           emoji: "❌" },
    { id: "hard_nod",         label: "Hard Nod",     emoji: "💯" },
    { id: "long_nod",         label: "Long Nod",     emoji: "🙇" },
    { id: "sarcastic_nod",    label: "Sarcastic",    emoji: "😏" },
    { id: "annoyed_shake",    label: "Annoyed",      emoji: "😒" },
    { id: "thoughtful_shake", label: "Thoughtful",   emoji: "🤔" },
    { id: "happy",            label: "Happy",        emoji: "😄" },
    { id: "angry",            label: "Angry",        emoji: "😠" },
    { id: "cocky",            label: "Cocky",        emoji: "😎" },
    { id: "ack",              label: "Got It",       emoji: "👌" },
    { id: "dismiss",          label: "Dismiss",      emoji: "🙅" },
    { id: "look_away",        label: "Look Away",    emoji: "👀" },
    { id: "weight_shift",     label: "Shift",        emoji: "🕴️" },
    { id: "sigh",             label: "Sigh",         emoji: "😮‍💨" },
    { id: "box_idle",         label: "Hold Box",     emoji: "📦" },
    { id: "box_walk",         label: "Walk Box",     emoji: "🚶" },
    { id: "box_turn",         label: "Turn Box",     emoji: "🔄" },
    { id: "kneel_idle",       label: "Kneel",        emoji: "🦵" },
    { id: "dig_seeds",        label: "Seeds",        emoji: "🌱" },
    { id: "pull_plant",       label: "Pull",         emoji: "🌿" },
    { id: "plant_tree",       label: "Tree",         emoji: "🌳" },
    { id: "plant",            label: "Plant",        emoji: "🪴" },
    { id: "holding_idle",     label: "Hold",         emoji: "🤲" },
    { id: "holding_walk",     label: "Walk Hold",    emoji: "🚶‍♂️" },
    { id: "holding_turn_l",   label: "Turn L",       emoji: "↩️" },
    { id: "holding_turn_r",   label: "Turn R",       emoji: "↪️" },
    { id: "watering",         label: "Water",        emoji: "💧" },
    { id: "pick_fruit",       label: "Pick",         emoji: "🍎" },
    { id: "milk_cow",         label: "Milk",         emoji: "🐄" },
    { id: "wheel_idle",       label: "Cart",         emoji: "🛒" },
    { id: "wheel_walk",       label: "Push Cart",    emoji: "🚜" },
    { id: "wheel_turn",       label: "Cart Turn",    emoji: "🔃" },
    { id: "wheel_dump",       label: "Dump",         emoji: "🗑️" },
  ];
  const [showEmotePicker, setShowEmotePicker] = useState(false);
  // Track which emotes actually have a file uploaded so the picker can dim
  // missing ones and tell the user where to upload them. Refreshed every
  // time the picker opens (cheap GET, ~27 rows).
  const [emoteAvailability, setEmoteAvailability] = useState<Record<string, boolean>>({});
  const [emoteHint, setEmoteHint] = useState<string | null>(null);
  const emoteHintTimerRef = useRef<number | null>(null);
  useEffect(() => {
    if (!showEmotePicker) return;
    let cancelled = false;
    void (async () => {
      try {
        const res = await fetch("/api/vance/emotes", { credentials: "include" });
        if (!res.ok) return;
        const data = (await res.json()) as { emotes: { name: string; uploaded: boolean }[] };
        if (cancelled) return;
        const next: Record<string, boolean> = {};
        for (const e of data.emotes) next[e.name] = e.uploaded;
        setEmoteAvailability(next);
      } catch { /* ignore */ }
    })();
    return () => { cancelled = true; };
  }, [showEmotePicker]);
  useEffect(() => () => {
    if (emoteHintTimerRef.current !== null) window.clearTimeout(emoteHintTimerRef.current);
  }, []);
  const showEmoteHint = useCallback((label: string) => {
    setEmoteHint(`${label} not uploaded yet — open Profile → Avatar Settings → Animations`);
    if (emoteHintTimerRef.current !== null) window.clearTimeout(emoteHintTimerRef.current);
    emoteHintTimerRef.current = window.setTimeout(() => setEmoteHint(null), 3500);
  }, []);

  useEffect(() => { localStorage.setItem("vance-voice-preset", voicePreset); }, [voicePreset]);

  // Mirror conversationId into a ref so the build event handlers (which are
  // useCallback([])s and would otherwise stale-close on the initial value)
  // always see the active conversation when persisting build snapshots.
  useEffect(() => { conversationIdRef.current = conversationId; }, [conversationId]);

  // Mirror the messages array into a ref so the visibility-restore listener
  // (which deliberately depends only on queryClient to avoid re-binding on
  // every keystroke) can read the LATEST list when the user re-foregrounds.
  const bgResyncMessagesRef = useRef<Message[]>(messages);
  useEffect(() => { bgResyncMessagesRef.current = messages; }, [messages]);

  // ── Background-survival re-sync ──────────────────────────────────────────
  // iOS suspends fetch() when the PWA is backgrounded. The chat SSE socket
  // dies and our local assistant bubble is left either stuck on "streaming"
  // (the placeholder dots) or marked with a generic ⚠️ error from the catch
  // block. Meanwhile the SERVER is still running — the openai loop, any
  // update_zip / create_zip tool call, and the final db.insert(messages)
  // all complete because the server-side emit() now silently swallows
  // post-disconnect writes (see openai/index.ts). So when the user comes
  // back, the truth (the completed assistant reply + zip card) is sitting
  // in the DB; we just need to refetch and let mergeServerMessages swap
  // our stale stub for the persisted row. The merge already matches local
  // pending stubs to fresh server messages by role+order so the clientId
  // (which the TTS turn keys off) is preserved across the swap.
  useEffect(() => {
    const onVisible = () => {
      if (document.visibilityState !== "visible") return;
      if (!conversationIdRef.current) return;
      // Cheap predicate: do we have ANY local message that's either still
      // showing the streaming placeholder OR was just marked with the
      // generic catch-block error? If so, the server probably finished
      // the turn while we were backgrounded — refetch and let the merge
      // resolve it. If there's nothing in-flight or recently-errored,
      // skip the refetch (no point burning a query).
      const needsResync = bgResyncMessagesRef.current.some((m: Message) =>
        m.role === "assistant" && (m.streaming === true || (typeof m.content === "string" && m.content.startsWith("⚠️")))
      );
      if (!needsResync) return;
      void queryClient.invalidateQueries({ queryKey: getListOpenaiMessagesQueryKey(conversationIdRef.current) });
      void queryClient.invalidateQueries({ queryKey: getGetOpenaiConversationQueryKey(conversationIdRef.current) });
    };
    document.addEventListener("visibilitychange", onVisible);
    window.addEventListener("focus", onVisible);
    window.addEventListener("pageshow", onVisible);
    return () => {
      document.removeEventListener("visibilitychange", onVisible);
      window.removeEventListener("focus", onVisible);
      window.removeEventListener("pageshow", onVisible);
    };
  }, [queryClient]);

  // Listen for screenshot-thumbnail clicks bubbled from the BuildProgress
  // component (which is defined outside Chat). Using a custom event avoids
  // threading a setLightbox prop through BuildProgress + every event row.
  // Esc closes the lightbox; the overlay backdrop also closes on click.
  useEffect(() => {
    const onOpen = (e: Event) => {
      const detail = (e as CustomEvent<{ url: string; label: string }>).detail;
      if (detail?.url) setLightbox({ url: detail.url, label: detail.label ?? "" });
    };
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setLightbox(null); };
    window.addEventListener("vance-open-lightbox", onOpen as EventListener);
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("vance-open-lightbox", onOpen as EventListener);
      window.removeEventListener("keydown", onKey);
    };
  }, []);

  useEffect(() => {
    void fetch("/api/vance/avatar")
      .then((r) => r.json() as Promise<{ url: string | null }>)
      .then((d) => { if (d.url) setAvatarUrl(d.url); })
      .catch(() => {});
    // Profile carries the 3D body model URL (Mixamo-rigged GLB the user picked,
    // e.g. a Ready Player Me avatar). Null = use the default soldier model.
    void fetch("/api/vance/profile")
      .then((r) => r.json() as Promise<{ bodyModelUrl: string | null }>)
      .then((d) => { setBodyModelUrl(d.bodyModelUrl ?? null); })
      .catch(() => {})
      .finally(() => { setProfileLoaded(true); });
  }, []);

  const primeSpeech = useCallback(() => {
    if (!audioRef.current) {
      const a = new Audio();
      a.preload = "auto";
      a.src = "data:audio/mpeg;base64,SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjU4Ljc2LjEwMAAAAAAAAAAAAAAA//tQxAADB8AhSmxhIIEVCSiJrDCQBTcu3UrAIwUdkRgQbFAZC1CQEwTJ9mjRvBA4UOLD8nKVOWfh+UlK3z/177OXrfOdKl7pyn3Xf//FJAhJKQiSdjVQopaQjQwa9NIXtHGSC09iVD2+NzEYSGlRgM8FGBlKLNOh+G1ufc/iUeNFSi9XfO8//+NBzNFvNHvfm1//7sP/+P/9F/2///7+f/2N/+IjkVRAg+mKjDKogDFYg2//tQxAQAB+gtSmxhJAEZBKnEHCgxF/9SLOMYvJWDKlgUAaTRgULSAGKGiHwhUVQggwbAFNgAUAUgIwHBaH5RWhAGNKxoQQuWpCERSIRwAUE5NjwAUACgcwLgIw8AOOFAAGAYAEALAGABAAYAFAA";
      a.load();
      audioRef.current = a;
    }
    void audioRef.current.play().catch(() => {});
    ensureAudioAnalyser();
  }, [ensureAudioAnalyser]);

  // Replay a completed assistant message's TTS — splits the full content
  // into the SAME ~80-char-min sentence-bounded chunks the live streaming
  // path produces, fires them all in parallel, and lets the existing drain
  // loop play them back-to-back with the karaoke highlight. Honours the
  // Sources/URL cut marker exactly like the live path so the spoken
  // playback and highlight cover only the speakable region.
  const replayMessageTTS = useCallback((content: string, msgClientId: string) => {
    if (!ttsEnabled) return;
    const text = content ?? "";
    if (!text.trim()) return;
    primeSpeech();
    stopTTS();
    beginTTSTurn(msgClientId);

    // Apply the same Sources/URL cut as live emission.
    const sourcesM = text.match(/(?:^|\n)\s*Sources?\s*:/i);
    const urlM = text.match(/https?:\/\//i);
    const cuts: number[] = [];
    if (sourcesM && typeof sourcesM.index === "number") cuts.push(sourcesM.index);
    if (urlM && typeof urlM.index === "number") cuts.push(urlM.index);
    const speakableEnd = cuts.length ? Math.min(...cuts) : text.length;
    const speakable = text.slice(0, speakableEnd);
    if (!speakable.trim()) return;

    // Walk sentence boundaries and emit chunks of >=80 chars (matches the
    // live MIN). Last fragment is always emitted so the tail isn't lost.
    const re = /[.!?…](?:["')\]]*)(?=\s|$)/g;
    const boundaries: number[] = [];
    let m: RegExpExecArray | null;
    while ((m = re.exec(speakable)) !== null) boundaries.push(m.index + m[0].length);
    if (boundaries[boundaries.length - 1] !== speakable.length) boundaries.push(speakable.length);

    const turnId = ttsTurnIdRef.current;
    const voice = PRESET_TO_VOICE[voicePreset];
    let cursor = 0;
    for (let i = 0; i < boundaries.length; i++) {
      const b = boundaries[i]!;
      const isLast = i === boundaries.length - 1;
      if (b - cursor < 80 && !isLast) continue;
      const rawStart = cursor;
      const rawEnd = b;
      const rawChunk = speakable.slice(rawStart, rawEnd);
      cursor = rawEnd;
      const cleaned = cleanChunkForTTS(rawChunk);
      if (cleaned.length < 3) continue;
      const seq = ttsNextSeqRef.current++;
      void fetchAndQueueTTSChunk(cleaned, turnId, voice, seq, msgClientId, rawStart, rawEnd, rawChunk);
    }
    // Latch so any stray timer/event can't try to emit more for this turn.
    ttsCutHitRef.current = true;
    ttsSpokenIdxRef.current = speakableEnd;
  }, [ttsEnabled, voicePreset, primeSpeech, stopTTS, beginTTSTurn, fetchAndQueueTTSChunk, cleanChunkForTTS]);

  const playTTS = useCallback(async (text: string, preset?: VoicePreset) => {
    if (!ttsEnabled || !text.trim()) return;
    const token = ++latestTtsTokenRef.current;
    const voice = PRESET_TO_VOICE[preset ?? voicePreset];
    // Cut TTS at the first "Sources" block, the first "Source:" line, or
    // the first bare URL — whichever comes first. Vance is prompted to put
    // all links at the END of his reply under a "Sources:" header for
    // exactly this reason; everything above that line is for the ear, and
    // anything below is for the eye to click through. Without this cut,
    // TTS reads aloud "h-t-t-p-s colon slash slash linkedin dot com slash
    // in slash …", which sounds awful and ruins the human-like delivery.
    let speakable = text;
    // 1. Strip code blocks before scanning, so a fenced-block URL doesn't
    //    move the cut point further down.
    speakable = speakable.replace(/```[\s\S]*?```/g, "code block.");
    // 2. Replace markdown links [label](url) with just their label so the
    //    label still gets spoken when the link sits in body text (e.g. a
    //    rare inline reference Vance forgot to push to the bottom).
    speakable = speakable.replace(/\[([^\]]+)\]\(https?:\/\/[^)]+\)/g, "$1");
    // 3. Find the cut point: a line starting with "Sources:" / "Source:"
    //    (case-insensitive) OR the first bare URL.
    const cutCandidates: number[] = [];
    const sourcesMatch = speakable.match(/(?:^|\n)\s*Sources?\s*:/i);
    if (sourcesMatch && typeof sourcesMatch.index === "number") cutCandidates.push(sourcesMatch.index);
    const urlMatch = speakable.match(/https?:\/\//i);
    if (urlMatch && typeof urlMatch.index === "number") cutCandidates.push(urlMatch.index);
    if (cutCandidates.length > 0) {
      speakable = speakable.slice(0, Math.min(...cutCandidates));
    }
    const clean = speakable
      .replace(/`[^`]+`/g, "")
      .replace(/[*_#~>\-]+/g, " ")
      .replace(/\s{2,}/g, " ")
      .trim();
    if (!clean) return;

    const diag = (msg: string) => {
      void fetch("/api/vance/errors", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ source: "vance-tts-diag", message: msg }),
      }).catch(() => {});
    };
    try {
      diag(`fetch start voice=${voice} len=${clean.length} hasAudioRef=${!!audioRef.current}`);
      const res = await fetch("/api/openai/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: clean.slice(0, 4000), voice }),
      });
      if (!res.ok) { diag(`fetch !ok ${res.status}`); throw new Error(`TTS fetch ${res.status}`); }
      const blob = await res.blob();
      diag(`blob ok size=${blob.size} type=${blob.type}`);
      if (latestTtsTokenRef.current !== token) return;

      let audio = audioRef.current;
      if (!audio) {
        audio = new Audio();
        audioRef.current = audio;
      }
      ensureAudioAnalyser();

      clearAudioHandlers(audio);
      audio.pause();
      clearSpeechEmote();
      setIsPlayingTTS(false);

      const url = URL.createObjectURL(blob);
      let started = false;
      let finished = false;
      const speechCue = detectEmote(clean);
      const finishPlayback = () => {
        if (finished) return;
        finished = true;
        clearAudioHandlers(audio);
        URL.revokeObjectURL(url);
        clearSpeechEmote();
        if (latestTtsTokenRef.current === token) setIsPlayingTTS(false);
      };
      const handlePlaybackStart = () => {
        if (started || latestTtsTokenRef.current !== token) return;
        started = true;
        diag(`playback started → speaking window open emote=${speechCue ?? "none"}`);
        flushSync(() => {
          setIsPlayingTTS(true);
          startSpeechEmote(speechCue);
        });
      };
      const handlePlaybackAbort = () => {
        diag(`playback aborted paused=${audio.paused} ended=${audio.ended}`);
        finishPlayback();
      };

      audio.src = url;
      audio.onplay = handlePlaybackStart;
      audio.onplaying = handlePlaybackStart;
      audio.onended = finishPlayback;
      audio.onerror = finishPlayback;
      audio.onpause = handlePlaybackAbort;

      try { await audio.play(); }
      catch (e) { diag(`audio.play() threw: ${e instanceof Error ? e.message : String(e)}`); finishPlayback(); throw e; }
      if (latestTtsTokenRef.current !== token) {
        audio.pause();
        finishPlayback();
        return;
      }
      if (!started && !audio.paused && !audio.ended && audio.currentTime > 0) {
        handlePlaybackStart();
      }
    } catch (e) {
      diag(`playTTS catch: ${e instanceof Error ? e.message : String(e)}`);
      clearSpeechEmote();
      if (latestTtsTokenRef.current === token) setIsPlayingTTS(false);
    }
  }, [ttsEnabled, voicePreset, clearAudioHandlers, clearSpeechEmote, startSpeechEmote]);

  // Direct scrollTop is more reliable than scrollIntoView (which searches
  // up for the nearest scrollable ancestor and can pick the wrong one when
  // the messages area is nested inside another overflow container).
  const scrollMessagesToBottom = useCallback((smooth: boolean) => {
    const el = messagesScrollRef.current;
    if (!el) return;
    el.scrollTo({ top: el.scrollHeight, behavior: smooth ? "smooth" : "auto" });
  }, []);

  // Suppress the snap-to-bottom while TTS is actively reading a streaming
  // reply — otherwise each new text chunk pulls the view down to the latest
  // word and the karaoke follow-scroll immediately yanks it back up to the
  // currently-spoken word, producing a jittery tug-of-war. The karaoke
  // effect below owns the viewport during playback; once TTS stops (or the
  // turn finishes) the next message change snaps back to the bottom as
  // normal.
  useEffect(() => {
    // `isPlayingTTS` (not `ttsHighlight`) is the right gate: the highlight
    // briefly clears in the gap between consecutive chunks, but playback is
    // continuous across the turn. Gating on the highlight let the snap fire
    // in those micro-gaps and the karaoke effect would yank back up.
    if (isPlayingTTS) return;
    scrollMessagesToBottom(true);
  }, [messages, scrollMessagesToBottom, isPlayingTTS]);

  // Karaoke follow-scroll: keep the actively-spoken word visible by
  // smoothly scrolling the messages container so the highlighted word
  // sits near the vertical centre. We only scroll when the word is
  // outside the comfortable middle band (top 25%–bottom 25%) — this
  // prevents jitter on short messages that already fit on-screen, and
  // for long replies it gently pans the bubble down as Vance reads it.
  useEffect(() => {
    if (!ttsHighlight) return;
    const scroller = messagesScrollRef.current;
    if (!scroller) return;
    const wordEl = scroller.querySelector<HTMLElement>('[data-tts-active="1"]');
    if (!wordEl) return;
    const sRect = scroller.getBoundingClientRect();
    const wRect = wordEl.getBoundingClientRect();
    const topBand = sRect.top + sRect.height * 0.25;
    const bottomBand = sRect.top + sRect.height * 0.75;
    if (wRect.top >= topBand && wRect.bottom <= bottomBand) return; // already in the comfy zone
    const desiredCentreInScroller = sRect.height * 0.5;
    const currentCentreInScroller = wRect.top + wRect.height / 2 - sRect.top;
    const delta = currentCentreInScroller - desiredCentreInScroller;
    scroller.scrollBy({ top: delta, behavior: "smooth" });
  }, [ttsHighlight]);

  // On initial load (or after switching conversations) layout keeps shifting
  // for ~1.5s as build panels, screenshots, code blocks, and proposal cards
  // hydrate, so a single scroll call gets overrun by later shifts. Trigger a
  // multi-frame retry burst once messages FIRST populate for the current
  // conversation. The previous version keyed off `conversationId` and bailed
  // early because messages were still empty when conversationId first set.
  const initialScrolledForRef = useRef<number | null>(null);
  useEffect(() => {
    if (messages.length === 0) return;
    if (conversationId == null) return;
    if (initialScrolledForRef.current === conversationId) return;
    initialScrolledForRef.current = conversationId;
    const jump = () => scrollMessagesToBottom(false);
    jump();
    const timers = [60, 200, 500, 900, 1400, 2000, 2800].map((ms) => window.setTimeout(jump, ms));
    return () => { for (const t of timers) window.clearTimeout(t); };
  }, [messages, conversationId, scrollMessagesToBottom]);

  // Reset the "already scrolled" gate when the user switches conversations
  // so the burst fires again for the new conversation.
  useEffect(() => {
    initialScrolledForRef.current = null;
  }, [conversationId]);

  useEffect(() => {
    if (conversationData?.messages) setMessages((prev) => mergeServerMessages(conversationData.messages, prev));
  }, [conversationData, mergeServerMessages]);

  const handleNewConversation = useCallback(async () => {
    const now = new Date();
    const title = `Chat — ${now.toLocaleDateString("en-US", { month: "short", day: "numeric" })}`;
    const conv = await createConversation.mutateAsync({ data: { title } });
    setConversationId(conv.id);
    setMessages([]);
    stopTTS();
    await queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
    setSidebarOpen(false);
  }, [createConversation, queryClient, stopTTS]);

  // On fresh app load, ALWAYS land in 🟣 Conversation Mode. Pick the most
  // recent purple ("chat") conversation; if none exists, create one and stamp
  // the override so it lands in purple regardless of its title. This runs
  // exactly once per page load (guarded by `didInitialModeBootRef`) so the
  // user can still cycle to other modes mid-session without being yanked
  // back to purple.
  const didInitialModeBootRef = useRef(false);
  useEffect(() => {
    if (didInitialModeBootRef.current) return;
    if (conversationId) { didInitialModeBootRef.current = true; return; }
    if (conversations === undefined) return;
    didInitialModeBootRef.current = true;
    const purple = [...conversations]
      .filter(c => (chatModeOverrides[String(c.id)] ?? categorizeText(c.title)) === "chat")
      .sort((a, b) => new Date(b.createdAt ?? 0).getTime() - new Date(a.createdAt ?? 0).getTime())[0];
    if (purple) {
      setConversationId(purple.id);
    } else {
      void (async () => {
        const now = new Date();
        const title = `Chat — ${now.toLocaleDateString("en-US", { month: "short", day: "numeric" })}`;
        const conv = await createConversation.mutateAsync({ data: { title } });
        setChatModeOverrides(prev => {
          const next = { ...prev, [String(conv.id)]: "chat" as const };
          try { localStorage.setItem("vance-chat-mode-override-v1", JSON.stringify(next)); } catch { /* ignore */ }
          return next;
        });
        setConversationId(conv.id);
        setMessages([]);
        await queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
      })();
    }
  }, [conversations, conversationId, chatModeOverrides, createConversation, queryClient]);

  const handleDeleteConversation = useCallback(async (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    await deleteConversation.mutateAsync({ id });
    await queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
    if (conversationId === id) {
      setConversationId(null);
      setMessages([]);
      stopTTS();
    }
  }, [deleteConversation, queryClient, conversationId, stopTTS]);

  const fetchPersona = useCallback(async (character: string) => {
    setIsPersonaLoading(true);
    setShowAvatar(true);
    try {
      const res = await fetch("/api/vance/persona", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ character: character.trim() }),
      });
      if (res.ok) setPersona(await res.json() as Persona);
    } catch {}
    finally { setIsPersonaLoading(false); }
  }, []);

  const toggleWebSearch = useCallback(() => {
    setWebSearchEnabled((prev) => {
      const next = !prev;
      localStorage.setItem("vance-web-search", String(next));
      return next;
    });
  }, []);

  const clearAttachedImage = useCallback(() => {
    setAttachedImage(null);
    setImageError(null);
    if (attachmentInputRef.current) attachmentInputRef.current.value = "";
  }, []);

  const clearAttachedFile = useCallback(() => {
    setAttachedFile(null);
    setImageError(null);
    if (attachmentInputRef.current) attachmentInputRef.current.value = "";
  }, []);

  const handleAttachmentChange = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // ── Image branch ─────────────────────────────────────────────────────────
    if (file.type.startsWith("image/")) {
      if (file.size > CHAT_IMAGE_MAX_BYTES) {
        clearAttachedImage();
        setImageError(`Image must be ${formatBytes(CHAT_IMAGE_MAX_BYTES)} or smaller.`);
        return;
      }
      try {
        const dataUrl = await readFileAsDataUrl(file);
        setImageError(null);
        setAttachedFile(null);
        setAttachedImage({ dataUrl, name: file.name });
      } catch (error) {
        clearAttachedImage();
        setImageError(error instanceof Error ? error.message : "Could not read the selected image.");
      }
      return;
    }

    // ── File branch (PDF / text / code / CSV / JSON / Markdown) ──────────────
    if (file.size > CHAT_FILE_MAX_BYTES) {
      clearAttachedFile();
      setImageError(`File must be ${formatBytes(CHAT_FILE_MAX_BYTES)} or smaller.`);
      return;
    }
    try {
      const dataUrl = await readFileAsDataUrl(file);
      const r = await fetch("/api/openai/uploads/chat-file", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ dataUrl, fileName: file.name }),
      });
      if (!r.ok) {
        const err = await r.json().catch(() => ({})) as { error?: string };
        throw new Error(err.error ?? "File upload failed.");
      }
      const payload = await r.json() as { fileName: string; text: string; charCount: number; truncated: boolean; originalChars: number };
      setImageError(null);
      setAttachedImage(null);
      setAttachedFile(payload);
    } catch (error) {
      clearAttachedFile();
      setImageError(error instanceof Error ? error.message : "Could not read the selected file.");
    }
  }, [clearAttachedImage, clearAttachedFile]);

  // Component-level SSE drain shared by sendTextMessage AND the website-session
  // mount-resume effect. Parameterised on the bubble ids + a few mutable refs
  // so both call sites can thread their own session/cursor state in. Returns
  // {terminal} so the caller knows whether to stop reconnecting.
  type ChatStreamCtx = {
    userClientId: string;
    assistantClientId: string;
    fullContentRef: { v: string };
    idxRef: { last: number };
    websiteSessionIdRef: { id: string | null };
    persistWebsiteSession: () => void;
    chatModeForProposal: "website" | "build" | "chat" | undefined;
  };
  const drainChatStream = useCallback(async (response: Response, ctx: ChatStreamCtx): Promise<{ terminal: boolean }> => {
    if (!response.body) return { terminal: false };
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    let terminal = false;
    let pendingId: number | null = null;
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      // Keep the partial trailing line until the next read so we never lose
      // data when a chunk ends mid-line.
      buffer = lines.pop() ?? "";
      for (const line of lines) {
        if (line.startsWith("id: ")) {
          const n = parseInt(line.slice(4), 10);
          if (Number.isFinite(n)) pendingId = n;
          continue;
        }
        if (!line.startsWith("data: ")) {
          if (line === "") pendingId = null; // SSE event delimiter
          continue;
        }
        try {
          const data = JSON.parse(line.slice(6)) as {
            content?: string;
            done?: boolean;
            usedWebSearch?: boolean;
            type?: string;
            sources?: Source[];
            query?: string;
            fromWebSearch?: boolean;
            url?: string;
            path?: string;
            error?: string;
            message?: string;
            fileName?: string;
            sizeBytes?: number;
            description?: string;
            sessionId?: string;
            conversationId?: number;
          };
          // Reattach init frame from the website-session mirror — adopt the
          // session id (in case we got here via resume before the response
          // header was read) and skip.
          if (data.type === "init") {
            if (typeof data.sessionId === "string" && !ctx.websiteSessionIdRef.id) {
              ctx.websiteSessionIdRef.id = data.sessionId;
              ctx.persistWebsiteSession();
            }
            pendingId = null;
            continue;
          }
          if (data.type === "screenshot_pending") {
            setMessages((prev) => prev.map((m) =>
              m.clientId === ctx.userClientId ? { ...m, browsingQuery: `Capturing ${data.path ?? "/"}…` } : m
            ));
          }
          if (data.type === "screenshot" && data.url) {
            const shotUrl = data.url;
            setMessages((prev) => prev.map((m) =>
              m.clientId === ctx.userClientId ? { ...m, imageUrl: shotUrl, browsingQuery: undefined } : m
            ));
          }
          if (data.type === "screenshot_error") {
            setMessages((prev) => prev.map((m) =>
              m.clientId === ctx.userClientId ? { ...m, browsingQuery: undefined } : m
            ));
          }
          if (data.type === "map" && data.url) {
            const mapUrl = data.url;
            setMessages((prev) => prev.map((m) =>
              m.clientId === ctx.assistantClientId ? { ...m, imageUrl: mapUrl, browsingQuery: undefined } : m
            ));
          }
          if (data.type === "browsing" && data.query) {
            setMessages((prev) => {
              const updated = [...prev];
              const last = updated[updated.length - 1];
              if (last?.clientId === ctx.assistantClientId && last.streaming) updated[updated.length - 1] = { ...last, browsingQuery: data.query };
              return updated;
            });
          }
          if (data.content) {
            ctx.fullContentRef.v += data.content;
            const snapshot = ctx.fullContentRef.v;
            setMessages((prev) => {
              const updated = [...prev];
              const last = updated[updated.length - 1];
              if (last?.clientId === ctx.assistantClientId && last.streaming) updated[updated.length - 1] = { ...last, content: snapshot, browsingQuery: undefined };
              return updated;
            });
            maybeEmitTTSChunks(snapshot, false);
          }
          if (data.type === "sources" && data.sources?.length) {
            setMessages((prev) => {
              const updated = [...prev];
              const last = updated[updated.length - 1];
              if (last?.clientId === ctx.assistantClientId && last.role === "assistant") {
                updated[updated.length - 1] = {
                  ...last,
                  sources: data.sources,
                  sourcesQuery: data.query,
                  webSearched: data.fromWebSearch === true,
                };
              }
              return updated;
            });
          }
          if (data.type === "file" && typeof data.url === "string" && typeof data.fileName === "string") {
            const newFile: VanceDownloadableFile = {
              name: data.fileName,
              url: data.url,
              sizeBytes: typeof data.sizeBytes === "number" ? data.sizeBytes : 0,
              description: typeof data.description === "string" && data.description.length > 0 ? data.description : null,
            };
            setMessages((prev) => {
              const updated = [...prev];
              const last = updated[updated.length - 1];
              if (last?.clientId === ctx.assistantClientId) {
                const existing = last.files ?? [];
                if (!existing.some((f) => f.url === newFile.url)) {
                  updated[updated.length - 1] = { ...last, files: [...existing, newFile] };
                }
              }
              return updated;
            });
          }
          if (data.type === "error") {
            const msg = data.message ?? data.error ?? "The connection was interrupted.";
            setMessages((prev) => prev.map((m) => (
              m.clientId === ctx.assistantClientId
                ? { ...m, content: `${m.content ?? ""}\n\n⚠️ ${msg}`.trim(), streaming: false, browsingQuery: undefined }
                : m
            )));
            terminal = true;
          }
          if (data.done) {
            setMessages((prev) => {
              const updated = [...prev];
              const last = updated[updated.length - 1];
              if (last?.clientId === ctx.assistantClientId && last.streaming) {
                // Strip intake fence first, then proposal fence — so the
                // proposal parser sees clean text and the intake card can
                // light up on the same turn if Vance emitted both.
                const intakeExtract = extractIntake(last.content ?? "");
                const { cleaned, instruction, kind } = extractProposal(intakeExtract.cleaned, ctx.chatModeForProposal);
                const nextIntake: IntakeState | undefined = intakeExtract.prefill !== null
                  ? { prefill: intakeExtract.prefill, status: "open" }
                  : last.intake;
                updated[updated.length - 1] = {
                  ...last,
                  content: cleaned,
                  streaming: false,
                  browsingQuery: undefined,
                  webSearched: last.webSearched || data.usedWebSearch === true,
                  proposal: instruction ? { instruction, kind, status: "pending" } : last.proposal,
                  intake: nextIntake,
                };
              }
              return updated;
            });
            terminal = true;
          }
        } catch {}
        if (pendingId !== null && pendingId > ctx.idxRef.last) ctx.idxRef.last = pendingId;
        pendingId = null;
      }
    }
    return { terminal };
  }, [maybeEmitTTSChunks]);

  const sendTextMessage = useCallback(async (content: string) => {
    if (!conversationId || (!content.trim() && !attachedImage && !attachedFile) || isSending) return;

    // Natural-language build-password management. Handled entirely client-side
    // — never sent to the model so the password isn't logged in chat history.
    // Patterns (case-insensitive):
    //   • "change build password to X"  /  "set build password to X"
    //   • "new build password is X"  /  "make build password X"
    //   • "reset build password"  /  "reset the build password"
    // The word "build" is OPTIONAL so "change password to X" also works.
    const trimmed = content.trim();
    const resetMatch = /^\s*reset\s+(?:the\s+)?(?:build\s+)?password\s*[.!?]?\s*$/i.test(trimmed);
    const changeMatch = /^\s*(?:change|set|update|make)\s+(?:the\s+)?(?:build\s+)?password\s+(?:to|=|is|:)\s+["'`]?([^\s"'`.!?]{3,64})["'`]?\s*[.!?]?\s*$/i.exec(trimmed)
      || /^\s*new\s+(?:build\s+)?password\s+(?:is|=|:)\s+["'`]?([^\s"'`.!?]{3,64})["'`]?\s*[.!?]?\s*$/i.exec(trimmed);
    if (resetMatch || changeMatch) {
      const newPwd = resetMatch ? DEFAULT_BUILD_PASSWORD : changeMatch![1]!;
      updateBuildPassword(newPwd);
      // Lock again so the new password is required next time orange mode is
      // entered. Skip the lock if the user is currently mid-build (rare).
      try { sessionStorage.removeItem(BUILD_UNLOCK_KEY); } catch {}
      setBuildUnlocked(false);
      // Echo the user's instruction + Vance's confirmation directly into the
      // chat without round-tripping the server (keeps the password out of
      // server logs and out of memory extraction).
      const userClientId = nextClientId("user");
      const assistantClientId = nextClientId("assistant");
      const confirm = resetMatch
        ? `Build password reset to the default: ${DEFAULT_BUILD_PASSWORD}`
        : `Build password updated successfully to ${newPwd}`;
      setMessages((prev) => [
        ...prev,
        { clientId: userClientId, role: "user", content: trimmed, createdAt: new Date().toISOString() },
        { clientId: assistantClientId, role: "assistant", content: confirm, createdAt: new Date().toISOString() },
      ]);
      setInput("");
      return;
    }

    const becomeMatch = BECOME_PATTERN.exec(content);
    if (becomeMatch?.[1]) void fetchPersona(becomeMatch[1].trim());
    if (AVATAR_PATTERN.test(content)) { setShowAvatarModal(true); return; }

    // Manual chat-mode switch: "switch to website mode", "this is a build task",
    // "lock into chat mode", etc. Updates the per-conv override BEFORE the
    // request goes out so the very next reply uses the new persona.
    const modeMatch = /\b(?:switch(?:\s+(?:to|into))?|lock(?:ed)?(?:\s+(?:into|to))?|this\s+is\s+a|treat\s+this\s+as)\s+(website|web|frontend|front-end|build|code|coding|chat|conversation|regular|normal)(?:\s+(?:mode|task|chat))?\b/i.exec(content);
    if (modeMatch?.[1]) {
      const w = modeMatch[1].toLowerCase();
      const m: "website" | "build" | "chat" =
        /^(website|web|frontend|front-end)$/.test(w) ? "website"
        : /^(build|code|coding)$/.test(w)            ? "build"
        :                                              "chat";
      setChatModeForConv(conversationId, m);
    }

    const userClientId = nextClientId("user");
    const assistantClientId = nextClientId("assistant");
    const abort = new AbortController();
    const pendingAttachment = attachedImage;
    const pendingFile = attachedFile;
    // Per-turn: file text is sent as a separate body field, NOT prepended to
    // the message content. The user bubble shows just the typed text + a
    // short marker, and the DB stores the same. Vance receives the full text
    // injected into THIS turn's prompt server-side only.
    const displayMarker = pendingFile
      ? `\n\n[📎 ${pendingFile.fileName} — ${pendingFile.charCount.toLocaleString()} chars${pendingFile.truncated ? ` (truncated from ${pendingFile.originalChars.toLocaleString()})` : ""}]`
      : "";
    const displayContent = content + displayMarker;
    stopTTS();
    beginTTSTurn(assistantClientId);
    lastSubmittedInputRef.current = content;
    setInput("");
    setIsSending(true);
    setImageError(null);
    setMessages((prev) => [...prev, { clientId: userClientId, role: "user", content: displayContent, imageUrl: pendingAttachment?.dataUrl ?? null, createdAt: new Date().toISOString() }]);
    setMessages((prev) => [...prev, { clientId: assistantClientId, role: "assistant", content: "", streaming: true, createdAt: new Date().toISOString() }]);

    try {
      const imageUrl = pendingAttachment ? await uploadChatImage(pendingAttachment.dataUrl) : null;
      if (pendingAttachment) clearAttachedImage();
      if (pendingFile) clearAttachedFile();
      setMessages((prev) => prev.map((message) => (
        message.clientId === userClientId ? { ...message, imageUrl } : message
      )));
      inFlightAbortRef.current = abort;
      // Tracks the highest absolute event id seen on the live SSE. Only
      // populated for website-mode turns (the mirror prefixes `id:` lines);
      // chat/build modes never set it. Used to resume from where we left off
      // if the platform proxy kills the request (5-min cap) or the PWA is
      // backgrounded long enough for the fetch to die.
      const idxRef = { last: -1 };
      const websiteSessionIdRef: { id: string | null } = { id: null };
      const persistWebsiteSession = () => {
        if (!websiteSessionIdRef.id) return;
        try {
          sessionStorage.setItem(ACTIVE_WEBSITE_SESSION_KEY, JSON.stringify({
            sessionId: websiteSessionIdRef.id,
            convId: conversationId,
            userClientId,
            assistantClientId,
            lastIdx: idxRef.last,
            content,
          }));
        } catch {}
      };
      const fullContentRef = { v: "" };
      const ctx: ChatStreamCtx = {
        userClientId,
        assistantClientId,
        fullContentRef,
        idxRef,
        websiteSessionIdRef,
        persistWebsiteSession,
        chatModeForProposal: currentChatMode,
      };
      const drainChatStreamLocal = async (response: Response): Promise<{ terminal: boolean }> => drainChatStream(response, ctx);
      // (the per-event handling now lives in the component-level drainChatStream
      // useCallback above so the mount-resume effect can share it.)
      // (drainChatStream lives at component scope above so the mount-resume
      // effect can call it too; we just funnel through drainChatStreamLocal.)

      const response = await fetch(`/api/openai/conversations/${conversationId}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          content,
          webSearchEnabled,
          ...(imageUrl ? { imageUrl } : {}),
          ...(pendingFile ? { attachedFile: { fileName: pendingFile.fileName, text: pendingFile.text, charCount: pendingFile.charCount, truncated: pendingFile.truncated, originalChars: pendingFile.originalChars } } : {}),
          // Always send the client's resolved mode (override OR title-derived).
          // Without this, conversations with auto-generated titles like "Chat —
          // May 14" get re-categorized server-side as "chat" mode, even when
          // the client UI shows the user a blue WEB / orange BUILD pill. That
          // mismatch was making Vance reply with the wrong mode's prompt.
          ...(currentChatMode ? { chatModeOverride: currentChatMode } : {}),
        }),
        signal: abort.signal,
      });
      // The server may reject with 400 (bad payload, image too big, OpenAI
      // upstream error). If we don't bail here, the streaming placeholder
      // hangs forever showing "..." since no SSE chunks arrive.
      if (!response.ok) {
        let serverMsg = `Request failed (${response.status}). Please try again.`;
        try {
          const payload = await response.json() as { error?: string };
          if (payload?.error) serverMsg = payload.error;
        } catch {}
        setMessages((prev) => prev.map((m) => (
          m.clientId === assistantClientId
            ? { ...m, content: `⚠️ ${serverMsg}`, streaming: false, browsingQuery: undefined }
            : m
        )));
        return;
      }
      if (!response.body) {
        setMessages((prev) => prev.map((m) => (
          m.clientId === assistantClientId
            ? { ...m, content: "⚠️ No response stream from the server.", streaming: false }
            : m
        )));
        return;
      }
      // Capture the website-session id from the response header BEFORE we
      // start parsing the stream — if the proxy kills the request before
      // the init event lands, the header is the only way to know what
      // session to reattach to.
      const headerSessionId = response.headers.get("Vance-Website-Session-Id");
      if (headerSessionId) {
        websiteSessionIdRef.id = headerSessionId;
        persistWebsiteSession();
      }

      let { terminal } = await drainChatStreamLocal(response);
      if (websiteSessionIdRef.id && !terminal) persistWebsiteSession();

      // Website-mode reattach. The chat-route handler keeps running on the
      // server even after the platform proxy aborts the request — the
      // session mirror buffers every event so we can pick up here.
      if (currentChatMode === "website" && websiteSessionIdRef.id) {
        let backoffMs = 500;
        while (!terminal && !abort.signal.aborted) {
          await new Promise<void>((r) => setTimeout(r, backoffMs));
          backoffMs = Math.min(backoffMs * 2, 5000);
          if (abort.signal.aborted) break;
          try {
            const next = await fetch(`/api/openai/website-sessions/${websiteSessionIdRef.id}/stream?after=${idxRef.last + 1}`, { signal: abort.signal });
            if (next.status === 410) {
              // Session evicted (10 min after end) — assume the assistant
              // message is already in the DB and refetch.
              terminal = true;
              break;
            }
            if (!next.ok) continue;
            ({ terminal } = await drainChatStreamLocal(next));
            if (!terminal) persistWebsiteSession();
          } catch (err) {
            if ((err as { name?: string })?.name === "AbortError") break;
            // network blip — apply backoff before the next attempt so we
            // don't hot-loop CPU/network when the device is offline or
            // the server is unreachable. Without this delay the catch
            // path would spin as fast as fetch() rejects.
            await new Promise<void>((r) => setTimeout(r, backoffMs));
            backoffMs = Math.min(backoffMs * 2, 5000);
          }
        }
      }

      // Conditional clear: only remove the stash if it still belongs to OUR
      // turn. If the user stopped this turn and immediately fired a new send,
      // the new send's persistWebsiteSession() may have already overwritten
      // the stash with the new turn's sessionId. Unconditional remove here
      // would erase the new turn's resume info and break mount-resume after
      // a refresh.
      try {
        const raw = sessionStorage.getItem(ACTIVE_WEBSITE_SESSION_KEY);
        if (raw) {
          const parsed = JSON.parse(raw) as { sessionId?: string };
          if (!websiteSessionIdRef.id || parsed.sessionId === websiteSessionIdRef.id) {
            sessionStorage.removeItem(ACTIVE_WEBSITE_SESSION_KEY);
          }
        }
      } catch {}
      await queryClient.invalidateQueries({ queryKey: getGetOpenaiConversationQueryKey(conversationId) });
      await queryClient.invalidateQueries({ queryKey: getListOpenaiMessagesQueryKey(conversationId) });
      if (fullContentRef.v) {
        // Final flush: emit any text past the last sentence boundary
        // (or the entire reply if no sentence chunks were emitted, e.g.
        // a one-word answer with no terminal punctuation).
        maybeEmitTTSChunks(fullContentRef.v, true);
      }
    } catch (err) {
      if ((err as { name?: string })?.name !== "AbortError") {
        const message = err instanceof Error ? err.message : "Something went wrong. Please try again.";
        // Clear the stuck "..." placeholder and surface the error in the
        // assistant bubble so the chat doesn't appear frozen.
        setMessages((prev) => prev.map((m) => (
          m.clientId === assistantClientId && m.streaming
            ? { ...m, content: `⚠️ ${message}`, streaming: false, browsingQuery: undefined }
            : m
        )));
        setImageError(message);
      }
    } finally {
      if (inFlightAbortRef.current === abort) inFlightAbortRef.current = null;
      lastSubmittedInputRef.current = "";
      setIsSending(false);
    }
  }, [conversationId, attachedImage, attachedFile, isSending, webSearchEnabled, queryClient, fetchPersona, nextClientId, stopTTS, beginTTSTurn, maybeEmitTTSChunks, clearAttachedImage, clearAttachedFile, currentChatMode, drainChatStream]);

  // Apply one parsed SSE event to the assistant bubble.  Returns true if
  // the event is a terminal one (done / error) so the caller can stop
  // reconnecting.
  const applyBuildEvent = useCallback((event: BuildEvent & { content?: string }, assistantClientId: string): boolean => {
    if (event.type === "stream") {
      setMessages((prev) => {
        const updated = [...prev];
        const last = updated[updated.length - 1];
        if (last?.clientId === assistantClientId && last.isBuildResult) updated[updated.length - 1] = { ...last, buildStream: (last.buildStream ?? "") + (event.content ?? "") };
        return updated;
      });
      return false;
    }
    if (event.type === "phase") {
      setMessages((prev) => {
        const updated = [...prev];
        const last = updated[updated.length - 1];
        if (!last || last.clientId !== assistantClientId || !last.isBuildResult) return updated;
        const snap = last.buildStream?.trim();
        updated[updated.length - 1] = {
          ...last,
          buildEvents: [
            ...(last.buildEvents ?? []),
            ...(snap ? [{ type: "snapshot" as const, phase: last.buildPhase ?? "", text: snap }] : []),
            { type: "phase", phase: event.phase, label: event.label },
          ],
          buildStream: "",
          buildPhase: event.label ?? event.phase,
        };
        return updated;
      });
      return false;
    }
    if (event.type === "plan" || event.type === "reading" || event.type === "writing") {
      setMessages((prev) => {
        const updated = [...prev];
        const last = updated[updated.length - 1];
        if (last?.clientId === assistantClientId && last.isBuildResult) updated[updated.length - 1] = { ...last, buildEvents: [...(last.buildEvents ?? []), event as BuildEvent] };
        return updated;
      });
      return false;
    }
    if (event.type === "message") {
      setMessages((prev) => {
        const updated = [...prev];
        const last = updated[updated.length - 1];
        if (last?.clientId === assistantClientId && last.isBuildResult) updated[updated.length - 1] = { ...last, content: event.content ?? "", streaming: false, buildStream: "" };
        return updated;
      });
      return false;
    }
    if (event.type === "snapshot") {
      setMessages((prev) => {
        const updated = [...prev];
        const last = updated[updated.length - 1];
        if (last?.clientId === assistantClientId && last.isBuildResult) {
          updated[updated.length - 1] = {
            ...last,
            buildStream: "",
            buildEvents: [...(last.buildEvents ?? []), event as BuildEvent],
          };
        }
        return updated;
      });
      return false;
    }
    if (event.type === "done") {
      setMessages((prev) => {
        const updated = [...prev];
        const last = updated[updated.length - 1];
        if (last?.clientId === assistantClientId && last.isBuildResult) {
          const snap = last.buildStream?.trim();
          updated[updated.length - 1] = {
            ...last,
            streaming: false,
            buildStream: "",
            buildEvents: [
              ...(last.buildEvents ?? []),
              ...(snap ? [{ type: "snapshot" as const, phase: last.buildPhase ?? "", text: snap }] : []),
              { type: "done", filesChanged: event.filesChanged, screenshots: event.screenshots },
            ],
          };
          // Persist a snapshot keyed by the final message content so we can
          // reconstruct the BuildProgress panel after the user navigates away
          // and re-enters /chat (otherwise the summary report just vanishes).
          saveBuildResultSnapshot(conversationIdRef.current, updated[updated.length - 1].content, {
            filesChanged: event.filesChanged,
            screenshots: event.screenshots,
          });
        }
        return updated;
      });
      return true;
    }
    if (event.type === "error") {
      setMessages((prev) => {
        const updated = [...prev];
        const last = updated[updated.length - 1];
        if (last?.clientId === assistantClientId && last.isBuildResult) {
          const snap = last.buildStream?.trim();
          updated[updated.length - 1] = {
            ...last,
            streaming: false,
            buildStream: "",
            buildEvents: [
              ...(last.buildEvents ?? []),
              ...(snap ? [{ type: "snapshot" as const, phase: last.buildPhase ?? "", text: snap }] : []),
              event as BuildEvent,
              ...((event as BuildEvent).screenshots && (event as BuildEvent).screenshots!.length > 0
                ? [{ type: "done" as const, filesChanged: [], screenshots: (event as BuildEvent).screenshots }]
                : []),
            ],
          };
          saveBuildResultSnapshot(conversationIdRef.current, updated[updated.length - 1].content, {
            errorMessage: (event as BuildEvent).message,
            screenshots: (event as BuildEvent).screenshots,
          });
        }
        return updated;
      });
      return true;
    }
    return false;
  }, []);

  // Drain an SSE stream into the assistant bubble.  Tracks the highest
  // event id we received so a follow-up reconnect can resume from there.
  // Returns: terminal=true if we saw done/error; the last event index seen.
  const drainBuildStream = useCallback(async (
    response: Response,
    assistantClientId: string,
    onInit: (buildId: string) => void,
    startIdxRef: { last: number },
  ): Promise<{ terminal: boolean }> => {
    if (!response.body) return { terminal: false };
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    let terminal = false;
    let pendingId: number | null = null;
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";
      for (const line of lines) {
        if (line.startsWith("id: ")) {
          const n = parseInt(line.slice(4), 10);
          if (Number.isFinite(n)) pendingId = n;
          continue;
        }
        if (!line.startsWith("data: ")) {
          if (line === "") pendingId = null; // event delimiter
          continue;
        }
        let event: BuildEvent & { content?: string; buildId?: string };
        try { event = JSON.parse(line.slice(6)); } catch { continue; }
        if ((event as { type?: string }).type === "init" && typeof event.buildId === "string") {
          onInit(event.buildId);
          pendingId = null;
          continue;
        }
        if (pendingId !== null && pendingId > startIdxRef.last) startIdxRef.last = pendingId;
        if (applyBuildEvent(event, assistantClientId)) terminal = true;
        pendingId = null;
      }
    }
    return { terminal };
  }, [applyBuildEvent]);


  // Open a build (POST + initial stream) then reattach via GET on any drop
  // until we see a terminal event or run out of recovery options.
  const runBuildWithReconnect = useCallback(async (
    instruction: string,
    assistantClientId: string,
    abort: AbortController,
    initialFetch: () => Promise<Response>,
    initialBuildId: string | null = null,
    initialAfter: number = -1,
  ): Promise<void> => {
    let buildId: string | null = initialBuildId;
    if (initialBuildId) activeBuildIdRef.current = initialBuildId;
    // idxRef.last tracks the highest absolute event id we've consumed.
    // -1 means "no event seen yet"; reconnect will request after = last+1.
    const idxRef = { last: initialAfter };
    const persist = () => {
      if (!buildId) return;
      try { sessionStorage.setItem(ACTIVE_BUILD_KEY, JSON.stringify({ buildId, instruction, assistantClientId, lastIdx: idxRef.last, convId: conversationId })); } catch {}
    };
    const onInit = (id: string) => { buildId = id; activeBuildIdRef.current = id; persist(); };

    let terminal = false;
    try {
      const first = await initialFetch();
      // Capture the buildId from the response header BEFORE we start parsing
      // SSE events, so a Stop pressed during the first turn can cancel the
      // server runner even if the `init` event hasn't been read yet.
      const headerBuildId = first.headers.get("Vance-Build-Id");
      if (headerBuildId && !buildId) onInit(headerBuildId);
      if (!first.ok && first.status !== 200) {
        const text = await first.text().catch(() => "");
        applyBuildEvent({ type: "error", message: `Build failed to start (${first.status}): ${text.slice(0, 200)}` }, assistantClientId);
        return;
      }
      ({ terminal } = await drainBuildStream(first, assistantClientId, onInit, idxRef));
      persist();

      let backoffMs = 500;
      while (!terminal && !abort.signal.aborted && buildId) {
        applyBuildEvent({ type: "reading", path: "(reconnect)", message: `Connection dropped. Reattaching in ${(backoffMs / 1000).toFixed(1)}s…` }, assistantClientId);
        await new Promise<void>((r) => setTimeout(r, backoffMs));
        backoffMs = Math.min(backoffMs * 2, 5000);
        if (abort.signal.aborted) break;
        try {
          const next = await fetch(`/api/vance/build/${buildId}/stream?after=${idxRef.last + 1}`, { signal: abort.signal });
          if (next.status === 410) {
            applyBuildEvent({ type: "error", message: "Build no longer available — it was either finished and evicted, or the server restarted. Try sending the instruction again." }, assistantClientId);
            terminal = true;
            break;
          }
          if (!next.ok) continue; // try again
          ({ terminal } = await drainBuildStream(next, assistantClientId, onInit, idxRef));
          if (!terminal) persist();
          else break;
        } catch (err) {
          if ((err as { name?: string })?.name === "AbortError") break;
          // network blip — loop and try again
        }
      }
    } finally {
      try { sessionStorage.removeItem(ACTIVE_BUILD_KEY); } catch {}
      if (activeBuildIdRef.current === buildId) activeBuildIdRef.current = null;
    }
  }, [applyBuildEvent, drainBuildStream]);

  const sendBuildInstruction = useCallback(async (instruction: string) => {
    if (!instruction.trim() || isSending) return;
    // Hard gate: orange Regular Build is password-protected. If the user
    // somehow reaches here without unlocking (e.g. accepting a build proposal
    // from an unrelated chat), force them to unlock first. The modal is
    // rendered below and watches `isBuildMode` — flipping it on triggers it.
    if (!buildUnlocked) {
      setIsBuildMode(true);
      return;
    }
    const userClientId = nextClientId("build-user");
    const assistantClientId = nextClientId("build-assistant");
    stopTTS();
    setMessages((prev) => [...prev, { clientId: userClientId, role: "user", content: instruction, createdAt: new Date().toISOString() }]);
    lastSubmittedInputRef.current = instruction;
    setInput("");
    setIsSending(true);
    setMessages((prev) => [...prev, { clientId: assistantClientId, role: "assistant", content: "", streaming: true, isBuildResult: true, buildEvents: [], buildStream: "", buildPhase: "Thinking", createdAt: new Date().toISOString() }]);
    const abort = new AbortController();
    inFlightAbortRef.current = abort;
    try {
      await runBuildWithReconnect(
        instruction,
        assistantClientId,
        abort,
        () => fetch("/api/vance/build", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ instruction }),
          signal: abort.signal,
        }),
      );
    } catch (err) {
      if ((err as { name?: string })?.name !== "AbortError") throw err;
    } finally {
      if (inFlightAbortRef.current === abort) inFlightAbortRef.current = null;
      lastSubmittedInputRef.current = "";
      setIsSending(false);
    }
  }, [isSending, nextClientId, stopTTS, runBuildWithReconnect]);

  // On mount, see whether the server has a build in progress that this tab
  // got disconnected from (HMR, refresh, navigation, etc.).  If so, recreate
  // the assistant bubble and reattach so the work doesn't appear lost.
  const buildResumeAttemptedRef = useRef(false);
  useEffect(() => {
    if (buildResumeAttemptedRef.current) return;
    // GATE 1: don't even attempt to resume an in-flight build until the
    // user has unlocked orange mode in this session. The build runner is
    // password-gated UX-side; reattaching the live SSE stream would leak
    // the in-progress build's instruction + tool calls into whatever
    // conversation the user opens first (purple/blue included).
    if (!buildUnlocked) return;
    // GATE 2: scope by conversation. The "active build" is global on the
    // server, but the bubble belongs to ONE conversation. If the user
    // refreshes while sitting on a different conversation than the one
    // that owns the build, do nothing — the build will be resumed when
    // they navigate back to its tab.
    if (conversationId == null) return;
    buildResumeAttemptedRef.current = true;
    let cancelled = false;
    void (async () => {
      try {
        const r = await fetch("/api/vance/build/active");
        if (!r.ok || cancelled) return;
        const data = await r.json() as { buildId: string | null; instruction?: string };
        if (!data.buildId || cancelled) return;
        // Try to recover the prior client's after-cursor so we don't replay
        // the entire buffer if we can avoid it.  Falls back to 0 (full replay).
        let resumeAfter = 0;
        let priorAssistantClientId: string | null = null;
        let stashedConvId: number | null = null;
        try {
          const stash = sessionStorage.getItem(ACTIVE_BUILD_KEY);
          if (stash) {
            const parsed = JSON.parse(stash) as { buildId?: string; lastIdx?: number; assistantClientId?: string; convId?: number };
            if (parsed.buildId === data.buildId) {
              if (typeof parsed.lastIdx === "number") resumeAfter = parsed.lastIdx + 1;
              if (typeof parsed.assistantClientId === "string") priorAssistantClientId = parsed.assistantClientId;
              if (typeof parsed.convId === "number") stashedConvId = parsed.convId;
            }
          }
        } catch {}
        // GATE 3: if the stash records a different convId than the one
        // currently open, the build belongs to a different chat. Skip —
        // resume only fires when the user navigates back to the owning
        // conversation. Allow legacy stash-less resumes (stashedConvId
        // === null) so a server restart doesn't strand running builds.
        if (stashedConvId !== null && stashedConvId !== conversationId) return;
        const assistantClientId = priorAssistantClientId ?? nextClientId("build-assistant");
        // If we don't already have a bubble for this build (server restart,
        // refresh, etc.), create one so the reattached events have somewhere
        // to land.
        setMessages((prev) => {
          if (prev.some((m) => m.clientId === assistantClientId)) return prev;
          return [
            ...prev,
            { clientId: nextClientId("build-user"), role: "user", content: data.instruction ?? "(resumed build)", createdAt: new Date().toISOString() },
            { clientId: assistantClientId, role: "assistant", content: "", streaming: true, isBuildResult: true, buildEvents: [{ type: "reading", path: "(resume)", message: "Reattaching to in-progress build…" }], buildStream: "", buildPhase: "Resuming", createdAt: new Date().toISOString() },
          ];
        });
        const abort = new AbortController();
        inFlightAbortRef.current = abort;
        setIsSending(true);
        try {
          await runBuildWithReconnect(
            data.instruction ?? "(resumed build)",
            assistantClientId,
            abort,
            () => fetch(`/api/vance/build/${data.buildId}/stream?after=${resumeAfter}`, { signal: abort.signal }),
            data.buildId,
            resumeAfter - 1,
          );
        } finally {
          if (inFlightAbortRef.current === abort) inFlightAbortRef.current = null;
          setIsSending(false);
        }
      } catch {
        // If /active is unreachable (server still booting) we silently skip.
      }
    })();
    return () => { cancelled = true; };
  }, [runBuildWithReconnect, nextClientId]);

  // Reattach to an in-flight website-mode chat turn whose initial fetch we
  // lost (Replit Autoscale 5-min cap, hard refresh, long PWA backgrounding).
  // Symmetric to runBuildWithReconnect but for the chat SSE mirror — drains
  // the reattach stream then loops with backoff if it ends without `done`.
  const resumeWebsiteSession = useCallback(async (
    stash: { sessionId: string; convId: number; userClientId: string; assistantClientId: string; lastIdx: number; content: string },
    abort: AbortController,
  ): Promise<void> => {
    // Recreate the user + assistant bubbles if the page reloaded and they're
    // not in `messages` yet. mapServerMessages adds the user's bubble back from
    // the DB once the turn completes, but during the live reattach window only
    // sessionStorage knows about it.
    setMessages((prev) => {
      if (prev.some((m) => m.clientId === stash.assistantClientId)) return prev;
      return [
        ...prev,
        { clientId: stash.userClientId, role: "user", content: stash.content, createdAt: new Date().toISOString() },
        { clientId: stash.assistantClientId, role: "assistant", content: "", streaming: true, createdAt: new Date().toISOString() },
      ];
    });
    const idxRef = { last: stash.lastIdx };
    const websiteSessionIdRef: { id: string | null } = { id: stash.sessionId };
    const fullContentRef = { v: "" };
    const persist = () => {
      try {
        sessionStorage.setItem(ACTIVE_WEBSITE_SESSION_KEY, JSON.stringify({
          sessionId: stash.sessionId,
          convId: stash.convId,
          userClientId: stash.userClientId,
          assistantClientId: stash.assistantClientId,
          lastIdx: idxRef.last,
          content: stash.content,
        }));
      } catch {}
    };
    const ctx = {
      userClientId: stash.userClientId,
      assistantClientId: stash.assistantClientId,
      fullContentRef,
      idxRef,
      websiteSessionIdRef,
      persistWebsiteSession: persist,
      chatModeForProposal: "website" as const,
    };
    let backoffMs = 500;
    let terminal = false;
    while (!terminal && !abort.signal.aborted) {
      try {
        const r = await fetch(`/api/openai/website-sessions/${stash.sessionId}/stream?after=${idxRef.last + 1}`, { signal: abort.signal });
        if (r.status === 410) {
          // Session evicted (10 min after end) — assume the assistant
          // message already landed in the DB and refetch.
          terminal = true;
          break;
        }
        if (!r.ok) {
          await new Promise((res) => setTimeout(res, backoffMs));
          backoffMs = Math.min(backoffMs * 2, 5000);
          continue;
        }
        ({ terminal } = await drainChatStream(r, ctx));
        if (!terminal) {
          persist();
          await new Promise((res) => setTimeout(res, backoffMs));
          backoffMs = Math.min(backoffMs * 2, 5000);
        }
      } catch (err) {
        if ((err as { name?: string })?.name === "AbortError") break;
        // network blip — apply backoff before the next attempt so we
        // don't hot-loop CPU/network when fetch() rejects in a tight
        // loop (e.g. offline on cellular, DNS flap, server cold start).
        await new Promise((res) => setTimeout(res, backoffMs));
        backoffMs = Math.min(backoffMs * 2, 5000);
      }
    }
    // Conditional clear (mirrors sendTextMessage's logic): only remove the
    // stash if it still belongs to THIS resumed turn — otherwise we'd erase a
    // newer turn's stash that the user kicked off in another tab/component
    // while this resume was draining.
    try {
      const raw = sessionStorage.getItem(ACTIVE_WEBSITE_SESSION_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as { sessionId?: string };
        if (parsed.sessionId === stash.sessionId) {
          sessionStorage.removeItem(ACTIVE_WEBSITE_SESSION_KEY);
        }
      }
    } catch {}
    if (terminal) {
      await queryClient.invalidateQueries({ queryKey: getGetOpenaiConversationQueryKey(stash.convId) });
      await queryClient.invalidateQueries({ queryKey: getListOpenaiMessagesQueryKey(stash.convId) });
    }
  }, [drainChatStream, queryClient]);

  // Mount-resume: on first render with a resolved conversation, check if there
  // was an in-flight website-mode turn for this conversation in sessionStorage.
  // If the server still has an active session matching the stash, re-drain it.
  const websiteResumeAttemptedRef = useRef(false);
  useEffect(() => {
    if (websiteResumeAttemptedRef.current) return;
    if (conversationId == null) return;
    let stash: { sessionId: string; convId: number; userClientId: string; assistantClientId: string; lastIdx: number; content: string } | null = null;
    try {
      const raw = sessionStorage.getItem(ACTIVE_WEBSITE_SESSION_KEY);
      if (raw) stash = JSON.parse(raw);
    } catch {}
    if (!stash || stash.convId !== conversationId) return;
    websiteResumeAttemptedRef.current = true;
    let cancelled = false;
    // Hoist the abort so the effect cleanup can actually stop the in-flight
    // resume drain when the user navigates away mid-resume. Without this the
    // background drain keeps running, potentially racing a fresh send on a
    // different conversation. (Fix for architect finding #3.)
    const resumeAbort = new AbortController();
    const stashLocal = stash;
    void (async () => {
      try {
        const r = await fetch(`/api/openai/conversations/${conversationId}/active-website-session`, { signal: resumeAbort.signal });
        if (!r.ok || cancelled) return;
        const data = await r.json() as { sessionId: string | null };
        if (!data.sessionId || data.sessionId !== stashLocal.sessionId) {
          // Server session ended while we were gone — clear stash so we don't
          // try again on the next mount.
          try { sessionStorage.removeItem(ACTIVE_WEBSITE_SESSION_KEY); } catch {}
          return;
        }
        inFlightAbortRef.current = resumeAbort;
        setIsSending(true);
        try {
          await resumeWebsiteSession(stashLocal, resumeAbort);
        } finally {
          if (inFlightAbortRef.current === resumeAbort) inFlightAbortRef.current = null;
          setIsSending(false);
        }
      } catch {
        // /active-website-session unreachable (server still booting) — silently skip.
      }
    })();
    return () => {
      cancelled = true;
      resumeAbort.abort();
    };
  }, [conversationId, resumeWebsiteSession]);

  const sendResearch = useCallback(async (topic: string) => {
    if (!topic.trim() || isResearching) return;
    const userClientId = nextClientId("research-user");
    const assistantClientId = nextClientId("research-assistant");
    stopTTS();
    setResearchTopic("");
    setIsResearching(true);
    setMessages((prev) => [
      ...prev,
      { clientId: userClientId, role: "user", content: `Research everything about: ${topic}`, createdAt: new Date().toISOString() },
      { clientId: assistantClientId, role: "assistant", content: "", streaming: true, isResearchResult: true, researchEvents: [], createdAt: new Date().toISOString() },
    ]);
    try {
      const response = await fetch("/api/vance/research", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic }),
      });
      if (!response.body) return;
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        for (const line of decoder.decode(value).split("\n")) {
          if (!line.startsWith("data: ")) continue;
          try {
            const event = JSON.parse(line.slice(6)) as ResearchEvent & { content?: string; type: string };
            if (event.type === "message") {
              setMessages((prev) => {
                const updated = [...prev];
                const last = updated[updated.length - 1];
                if (last?.clientId === assistantClientId && last.isResearchResult) updated[updated.length - 1] = { ...last, content: event.content ?? "", streaming: false };
                return updated;
              });
            } else {
              setMessages((prev) => {
                const updated = [...prev];
                const last = updated[updated.length - 1];
                if (last?.clientId === assistantClientId && last.isResearchResult) {
                  updated[updated.length - 1] = {
                    ...last,
                    streaming: event.type !== "done",
                    researchEvents: [...(last.researchEvents ?? []), event as ResearchEvent],
                  };
                }
                return updated;
              });
            }
          } catch {}
        }
      }
    } finally {
      setIsResearching(false);
    }
  }, [isResearching, nextClientId, stopTTS]);

  const handleVoiceToggle = useCallback(async () => {
    if (!conversationId) return;
    if (isRecording) {
      const blob = await stopRecording();
      if (!blob || blob.size === 0) return;
      const userClientId = nextClientId("voice-user");
      const assistantClientId = nextClientId("voice-assistant");
      stopTTS();
      setIsSending(true);
      setMessages((prev) => [...prev, { clientId: userClientId, role: "user", content: "[Voice message]", createdAt: new Date().toISOString() }, { clientId: assistantClientId, role: "assistant", content: "", streaming: true, createdAt: new Date().toISOString() }]);
      await voiceStream.streamVoiceResponse(`/api/openai/conversations/${conversationId}/voice-messages`, blob);
    } else {
      await startRecording();
    }
  }, [conversationId, isRecording, startRecording, stopRecording, voiceStream, nextClientId, stopTTS]);

  const handleSearch = useCallback(async () => {
    if (!searchQuery.trim() || !conversationId) return;
    setIsSearching(true);
    try {
      const result = await webSearch.mutateAsync({ data: { query: searchQuery } });
      await sendTextMessage(`I searched for "${searchQuery}":\n\n${result.summary}`);
      setSearchQuery("");
    } finally {
      setIsSearching(false);
    }
  }, [searchQuery, conversationId, webSearch, sendTextMessage]);

  const VOICE_SWITCH_PATTERN = /\b(?:switch|change|use|set|make(?:\s+(?:your|the|it))?\s+voice|give me)\s+(?:(?:your|the|a|an)\s+)?(?:voice\s+(?:to\s+)?)?(?:a\s+|an\s+)?(female|woman|girl|male|man|guy|robotic?|robot|advanced\s+robotic?|whisper|whispering|soft|gentle|sage|wise|deep|warm|velvet|british|seductive|smooth|low[-\s]?pitched|lucifer|devil|morningstar)/i;
  const BUG_FIX_PATTERN = /\b(fix(\s+(this|that|the|it|a|an|my))?\s*(bug|issue|error|crash|problem|glitch)?|debug|what'?s\s+(broken|wrong|the\s+(error|bug|issue))|(?:there'?s|it'?s|something'?s)\s+(an?\s+)?(error|bug|broken|crashing|crashed|failing)|why\s+(is|isn'?t|does|doesn'?t).*?(work|broken|crash|error)|check\s+(the\s+)?(errors?|logs?|console))\b/i;
  const isBugFixRequest = useCallback((text: string) => {
    const s = text.trim();
    if (!s) return false;
    return BUG_FIX_PATTERN.test(s);
  }, []);

  const handleSubmit = () => {
    if (!input.trim() && !attachedImage && !attachedFile) return;
    primeSpeech();
    if (!isBuildMode && input.trim()) {
      const m = VOICE_SWITCH_PATTERN.exec(input);
      if (m) {
        const w = m[1]!.toLowerCase();
        if (/female|woman|girl/.test(w)) setVoicePreset("female");
        else if (/robot/.test(w)) setVoicePreset("robotic");
        else if (/whisper|soft|gentle/.test(w)) setVoicePreset("whisper");
        else if (/sage|wise/.test(w)) setVoicePreset("sage");
        else if (/lucifer|devil|morningstar/.test(w)) setVoicePreset("lucifer");
        else if (/warm|velvet|british|seductive|smooth|low[-\s]?pitched/.test(w)) setVoicePreset("velvet");
        else setVoicePreset("male");
      }
    }
    // STRICT MODE ISOLATION: the bug-fix auto-route to Build Mode is ONLY
    // allowed from inside an orange Regular Build conversation. From purple
    // (Conversation) or blue (Website Build) the user's message must stay
    // in-mode — the system prompt itself will tell them to switch to a
    // Regular Build chat. Routing here would silently send the message to
    // the build agent AND trip the password gate that swallows the input.
    if (!isBuildMode && currentChatMode === "build" && input.trim() && isBugFixRequest(input)) {
      const errs = getRecentErrors();
      const errorBlock = errs.length > 0
        ? `\n\nThe error reporter caught these recent runtime errors from the live frontend:\n\n${formatErrorsForPrompt(errs.slice(-10))}\n`
        : `\n\n(No runtime errors were captured. You can still call get_recent_errors during ANALYZE in case anything has come in since.)\n`;
      const prefixed = `[Auto-routed from chat: bug-fix request]\n\nUser's request: ${input}${errorBlock}`;
      markErrorsRead();
      void sendBuildInstruction(prefixed);
      return;
    }
    if (isBuildMode) void sendBuildInstruction(input);
    else void sendTextMessage(input);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const isActive = isSending || isRecording || isResearching;

  const isSpeaking = avatarState === "speaking";
  const statusText = isRecording ? "Listening…" : isPlayingTTS ? `Speaking in ${voiceLabels[voicePreset]}` : isResearching ? "Researching…" : isSending ? (isBuildMode ? "Coding…" : "Thinking…") : isBuildMode ? "Build mode" : `Voice: ${voiceLabels[voicePreset]}`;

  return (
    <div className="relative flex h-full w-full overflow-hidden bg-[#0a0a16] text-white font-sans">
      {/* Aurora background — fixed pointer-events-none layer behind everything */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute -top-[20%] -left-[10%] w-[60%] h-[60%] rounded-full bg-violet-600/30 blur-[120px] mix-blend-screen" />
        <div className="absolute top-[20%] -right-[10%] w-[50%] h-[70%] rounded-full bg-teal-500/20 blur-[150px] mix-blend-screen" />
        <div className="absolute -bottom-[20%] left-[20%] w-[40%] h-[50%] rounded-full bg-indigo-500/30 blur-[120px] mix-blend-screen" />
      </div>

      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 md:hidden backdrop-blur-sm"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Left sidebar */}
      <div
        className={`fixed md:relative z-50 h-full flex flex-col transition-all duration-300 ease-in-out border-r border-white/10 bg-[#0a0a16]/90 md:bg-white/[0.02] backdrop-blur-2xl ${
          sidebarOpen ? "w-[300px] translate-x-0 opacity-100" : "-translate-x-full md:translate-x-0 w-0 md:w-[260px] opacity-0 md:opacity-100 overflow-hidden border-none md:border-r"
        } md:translate-x-0`}
      >
        <div className="p-4 flex items-center justify-between md:block">
          <button
            data-testid="button-new-conversation"
            onClick={handleNewConversation}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-sm font-medium transition-all shadow-[inset_0_1px_0_rgba(255,255,255,0.1)] text-white"
          >
            <Plus className="w-4 h-4" />
            New chat
          </button>
          <button className="p-2 md:hidden ml-2" onClick={() => setSidebarOpen(false)} aria-label="Close sidebar">
            <X className="w-5 h-5 text-white/50" />
          </button>
        </div>
        <div
          className="flex-1 overflow-y-auto px-2 pb-4 space-y-1"
          style={{ WebkitOverflowScrolling: "touch", touchAction: "pan-y", overscrollBehavior: "contain" }}
        >
          {/* Filter pills */}
          <div className="flex gap-1 px-1 py-1 mb-1 sticky top-0 bg-[#0a0a16]/85 backdrop-blur z-10 rounded-lg">
            {([
              { k: "all",     label: "All",      color: "#9CA3AF" },
              { k: "website", label: "Websites", color: CATEGORY_COLORS.website },
              { k: "build",   label: "Builds",   color: CATEGORY_COLORS.build },
              { k: "chat",    label: "Chats",    color: CATEGORY_COLORS.chat },
            ] as const).map(opt => {
              const active = sidebarFilter === opt.k;
              return (
                <button
                  key={opt.k}
                  type="button"
                  onClick={() => setSidebarFilterPersist(opt.k)}
                  data-testid={`sidebar-filter-${opt.k}`}
                  className="flex-1 text-[10px] font-bold uppercase tracking-wider py-1.5 px-1 rounded-md transition-all"
                  style={{
                    background: active ? `${opt.color}33` : "transparent",
                    color:      active ? opt.color : "rgba(255,255,255,0.45)",
                    border:     active ? `1px solid ${opt.color}66` : "1px solid transparent",
                  }}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>
          {(conversations?.length ?? 0) === 0 && sidebarBuilds.length === 0 && (
            <p className="text-white/40 text-sm text-center py-8">No tasks yet</p>
          )}
          {(() => {
            const showWebsite = sidebarFilter === "all" || sidebarFilter === "website";
            const showBuild   = sidebarFilter === "all" || sidebarFilter === "build";
            const showChat    = sidebarFilter === "all" || sidebarFilter === "chat";
            const allConvs = conversations ?? [];
            const websiteBuilds = sidebarBuilds.filter(b => b.isWebsite);
            const codeBuilds    = sidebarBuilds.filter(b => !b.isWebsite);

            // Classify each conversation by its persisted mode override first
            // (set every time the user cycles the mode button — the source of
            // truth), falling back to keyword classification of the title.
            // Conversations are then placed under the matching section so
            // a website chat appears under "Website Conversations" (and shows
            // up under the Websites filter) instead of being buried in the
            // generic day-bucketed Chats list — that's the bug the user hit.
            const convsByMode: Record<"website" | "build" | "chat", typeof allConvs> = {
              website: [],
              build:   [],
              chat:    [],
            };
            for (const c of allConvs) {
              const m = chatModeOverrides[String(c.id)] ?? categorizeText(c.title);
              convsByMode[m].push(c);
            }
            // Day-bucket ONLY the chat-mode conversations — website/build
            // conversations are fewer and grouping by mode is more useful
            // than by date for them.
            const grouped: Record<string, typeof allConvs> = { Today: [], Yesterday: [], "This week": [], Earlier: [] };
            for (const c of convsByMode.chat) grouped[dayBucket(c.createdAt)].push(c);

            const renderBuildRow = (b: BuildEntry, color: string, idx: number) => (
              <div
                key={`b-${b.convId}-${idx}`}
                className="group flex items-stretch rounded-xl cursor-pointer"
                style={{
                  background: `linear-gradient(90deg, ${color}26, ${color}08 65%, transparent)`,
                  borderLeft: `3px solid ${color}`,
                  touchAction: "pan-y",
                  opacity: b.failed ? 0.6 : 1,
                }}
                onClick={() => { setConversationId(b.convId); setSidebarOpen(false); stopTTS(); }}
                {...longPressDeleteHandlers(b.title || "Build", () => {
                  const sig = b.title || "Build";
                  removeBuildResultBySig(b.convId, sig);
                  setSidebarBuilds(prev => prev.filter(x => !(x.convId === b.convId && (x.title || "Build") === sig)));
                })}
              >
                <div className="flex-1 min-w-0 py-2 pl-3 pr-2">
                  <div className={`text-sm truncate font-medium ${b.failed ? "line-through text-white/50" : "text-white/90"}`}>
                    {b.title || "Build"}
                  </div>
                  <div className="text-[10px] mt-0.5" style={{ color }}>
                    {b.failed ? "Failed" : `${b.filesChanged.length} file${b.filesChanged.length === 1 ? "" : "s"} changed`}
                  </div>
                </div>
              </div>
            );

            const renderConvRow = (conv: typeof allConvs[number], color: string = CATEGORY_COLORS.chat) => {
              const active = conversationId === conv.id;
              return (
                <div
                  key={conv.id}
                  className="group flex items-stretch justify-between rounded-xl cursor-pointer"
                  style={{
                    background: active
                      ? `linear-gradient(90deg, ${color}38, ${color}12 70%, transparent)`
                      : `linear-gradient(90deg, ${color}1a, ${color}05 60%, transparent)`,
                    borderLeft: `3px solid ${color}`,
                    touchAction: "pan-y",
                  }}
                  {...longPressDeleteHandlers(conv.title || "Untitled chat", () => {
                    void (async () => {
                      try {
                        await deleteConversation.mutateAsync({ id: conv.id });
                        await queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
                        if (conversationId === conv.id) { setConversationId(null); setMessages([]); stopTTS(); }
                      } catch { /* ignore */ }
                    })();
                  })}
                >
                  <span
                    data-testid={`button-conversation-${conv.id}`}
                    className={`text-sm truncate py-2.5 pl-3 pr-2 flex-1 font-medium ${active ? "text-white" : "text-white/85"}`}
                    onClick={() => { setConversationId(conv.id); setSidebarOpen(false); stopTTS(); }}
                  >
                    {conv.title}
                  </span>
                  <button
                    data-testid={`button-delete-conversation-${conv.id}`}
                    onClick={(e) => void handleDeleteConversation(conv.id, e)}
                    className="opacity-0 group-hover:opacity-100 px-2.5 hover:bg-white/10 rounded-r-xl transition-all text-white/40 hover:text-red-400 flex-shrink-0"
                    aria-label="Delete conversation"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            };

            const SectionHeader = ({ icon, title, color, count, sectionKey }: { icon: ReactNode; title: string; color: string; count: number; sectionKey: string }) => {
              const collapsed = !!sidebarCollapsed[sectionKey];
              return (
                <button
                  type="button"
                  onClick={() => toggleSidebarSection(sectionKey)}
                  className="w-full flex items-center gap-2 mt-3 mb-1.5 px-1 py-1 rounded-lg hover:bg-white/5 transition-colors"
                  aria-expanded={!collapsed}
                  data-testid={`sidebar-section-${sectionKey}`}
                >
                  <ChevronDown
                    className="w-3.5 h-3.5 transition-transform"
                    style={{ color, transform: collapsed ? "rotate(-90deg)" : "rotate(0deg)" }}
                  />
                  <span className="flex items-center justify-center w-5 h-5 rounded" style={{ background: `${color}26`, color }}>
                    {icon}
                  </span>
                  <span className="text-[10px] uppercase tracking-[0.08em] font-bold" style={{ color }}>
                    {title}
                  </span>
                  <span className="text-[10px] font-semibold ml-auto px-1.5 py-0.5 rounded-full" style={{ color, background: `${color}1a` }}>
                    {count}
                  </span>
                </button>
              );
            };

            const dayOrder: Array<keyof typeof grouped> = ["Today", "Yesterday", "This week", "Earlier"];

            return (
              <>
                {showWebsite && (websiteBuilds.length > 0 || convsByMode.website.length > 0) && (
                  <div>
                    <SectionHeader sectionKey="website-builds" icon={<Globe className="w-3.5 h-3.5" />} title="Websites" color={CATEGORY_COLORS.website} count={websiteBuilds.length + convsByMode.website.length} />
                    {!sidebarCollapsed["website-builds"] && (
                      <div className="flex flex-col gap-1">
                        {convsByMode.website.map(c => renderConvRow(c, CATEGORY_COLORS.website))}
                        {websiteBuilds.map((b, i) => renderBuildRow(b, CATEGORY_COLORS.website, i))}
                      </div>
                    )}
                  </div>
                )}
                {showBuild && (codeBuilds.length > 0 || convsByMode.build.length > 0) && (
                  <div>
                    <SectionHeader sectionKey="code-builds" icon={<Code2 className="w-3.5 h-3.5" />} title="Code Builds" color={CATEGORY_COLORS.build} count={codeBuilds.length + convsByMode.build.length} />
                    {!sidebarCollapsed["code-builds"] && (
                      <div className="flex flex-col gap-1">
                        {convsByMode.build.map(c => renderConvRow(c, CATEGORY_COLORS.build))}
                        {codeBuilds.map((b, i) => renderBuildRow(b, CATEGORY_COLORS.build, i))}
                      </div>
                    )}
                  </div>
                )}
                {showChat && dayOrder.map(day => grouped[day].length > 0 && (
                  <div key={day}>
                    <SectionHeader sectionKey={`day-${day}`} icon={<MessageSquare className="w-3.5 h-3.5" />} title={day} color={CATEGORY_COLORS.chat} count={grouped[day].length} />
                    {!sidebarCollapsed[`day-${day}`] && (
                      <div className="flex flex-col gap-1">{grouped[day].map(c => renderConvRow(c))}</div>
                    )}
                  </div>
                ))}
                {/* Empty-after-filter hint */}
                {((!showWebsite || (websiteBuilds.length === 0 && convsByMode.website.length === 0)) &&
                  (!showBuild   || (codeBuilds.length === 0 && convsByMode.build.length === 0)) &&
                  (!showChat    || dayOrder.every(d => grouped[d].length === 0))) && (
                  <p className="text-white/35 text-xs text-center py-6 italic">Nothing in this filter yet</p>
                )}
              </>
            );
          })()}
        </div>
      </div>

      {/* Main column */}
      <div className="relative z-10 flex min-w-0 flex-1 flex-col overflow-hidden">
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div className="absolute inset-x-0 top-0 h-[34rem] bg-[radial-gradient(circle_at_top,rgba(99,102,241,0.18),transparent_58%)]" />
          <div className="absolute left-1/2 top-[14%] h-[30rem] w-[30rem] -translate-x-1/2 rounded-full bg-[radial-gradient(circle,rgba(245,179,74,0.16),rgba(245,179,74,0.04)_38%,transparent_72%)] blur-3xl" />
          <div className="absolute -left-24 top-28 h-72 w-72 rounded-full bg-fuchsia-500/10 blur-3xl" />
          <div className="absolute -right-24 bottom-20 h-80 w-80 rounded-full bg-cyan-500/10 blur-3xl" />
          <div className="absolute inset-x-0 bottom-0 h-64 bg-gradient-to-t from-background via-background/80 to-transparent" />
        </div>
        {/* Top bar — safe-area top padding is provided by the AppLayout wrapper */}
        <header className="relative z-20 flex h-[64px] items-center justify-between border-b border-white/8 bg-[linear-gradient(180deg,rgba(255,255,255,0.06),rgba(255,255,255,0.015))] px-3 md:px-5 shadow-[0_10px_30px_rgba(0,0,0,0.16)] backdrop-blur-2xl">
          <div className="flex items-center gap-2 md:gap-3">
            <button
              data-testid="button-toggle-sidebar"
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-2 rounded-full hover:bg-white/10 text-white/70 hover:text-white transition-colors"
              aria-label="Toggle sidebar"
            >
              <Menu className="w-5 h-5" />
            </button>
            <CurrentTaskPanel
              conversations={conversations}
              currentConvId={conversationId}
              isSending={isSending}
              isBuildMode={isBuildMode}
              isResearching={isResearching}
              onSelectConv={(id) => { setConversationId(id); stopTTS(); }}
              chatMode={currentChatMode}
            />
            <div className="flex flex-col">
              <div
                className="font-semibold text-base md:text-lg tracking-tight bg-clip-text text-transparent leading-none"
                style={{
                  // Layered backgrounds clipped to the glyphs:
                  //   - Tiny radial "flake" dots scattered at irregular
                  //     positions for a subtle gold-flake speckle.
                  //   - A warm champagne→gold→champagne base gradient
                  //     underneath everything.
                  backgroundImage: [
                    "radial-gradient(circle at 12% 30%, rgba(255,236,170,0.95) 0px, rgba(255,236,170,0) 1.4px)",
                    "radial-gradient(circle at 28% 70%, rgba(255,228,150,0.9) 0px, rgba(255,228,150,0) 1.2px)",
                    "radial-gradient(circle at 44% 22%, rgba(255,240,180,0.95) 0px, rgba(255,240,180,0) 1.6px)",
                    "radial-gradient(circle at 56% 80%, rgba(255,220,130,0.9) 0px, rgba(255,220,130,0) 1.3px)",
                    "radial-gradient(circle at 70% 35%, rgba(255,232,160,0.95) 0px, rgba(255,232,160,0) 1.5px)",
                    "radial-gradient(circle at 82% 65%, rgba(255,224,140,0.9) 0px, rgba(255,224,140,0) 1.4px)",
                    "radial-gradient(circle at 92% 40%, rgba(255,236,170,0.95) 0px, rgba(255,236,170,0) 1.3px)",
                    "linear-gradient(110deg, #fff5d6 0%, #f4d27a 28%, #c9a24a 52%, #f4d27a 76%, #fff5d6 100%)",
                  ].join(", "),
                  WebkitBackgroundClip: "text",
                  backgroundClip: "text",
                  textShadow: "0 0 18px rgba(212,175,80,0.25)",
                }}
              >
                Vance<span style={{ opacity: 0.75 }}>.AI</span>
              </div>
              <div className="hidden sm:block text-[10px] text-white/40 tracking-wide mt-0.5">{statusText}</div>
            </div>
          </div>

          <div className="flex items-center gap-1.5 md:gap-2">
            {/* md+ controls */}
            <div className="hidden md:flex items-center gap-2">
              <button
                data-testid="button-toggle-tts"
                onClick={() => {
                  // Single "Reading mode" toggle: muting Vance also drops out
                  // of voice-input mode and stops any playback in progress.
                  // Re-enabling just turns the speaker back on (voice mode
                  // stays opt-in so we don't surprise the user with a mic UI).
                  if (ttsEnabled) {
                    if (isPlayingTTS) stopTTS();
                    setIsVoiceMode(false);
                    setTtsEnabled(false);
                  } else {
                    setTtsEnabled(true);
                  }
                }}
                title={ttsEnabled ? "Reading mode (mute voice, hide voice input, no follow-along)" : "Voice on"}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-full border transition-all backdrop-blur-2xl ${
                  ttsEnabled
                    ? "bg-white/10 border-white/20 text-white shadow-[0_0_15px_rgba(255,255,255,0.1)]"
                    : "bg-transparent border-transparent text-white/50 hover:bg-white/5 hover:text-white"
                }`}
              >
                {ttsEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                <span className="text-xs font-medium">{ttsEnabled ? "TTS" : "Read"}</span>
              </button>

              <div className="relative">
                <button
                  data-testid="button-voice-preset-menu"
                  onClick={() => setShowVoiceMenu((v) => !v)}
                  title="Change voice"
                  className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 cursor-pointer transition-colors text-white/80 backdrop-blur-2xl"
                >
                  <span className="text-xs font-medium">{voiceLabels[voicePreset]}</span>
                  <ChevronDown className="w-3 h-3 opacity-50" />
                </button>
                {showVoiceMenu && (
                  <div className="absolute right-0 top-full mt-2 z-50 bg-[#0a0a16]/95 border border-white/10 rounded-xl shadow-xl overflow-hidden min-w-[200px] backdrop-blur-2xl">
                    {(["lucifer", "velvet", "male", "female", "sage", "whisper", "robotic"] as const).map((p) => (
                      <button
                        key={p}
                        onClick={() => { setVoicePreset(p); setShowVoiceMenu(false); }}
                        className={`w-full text-left px-3 py-2 text-sm flex items-center gap-2 transition-colors hover:bg-white/10 ${voicePreset === p ? "text-white font-medium" : "text-white/70"}`}
                      >
                        <span>{p === "female" ? "👩" : p === "male" ? "👨" : p === "robotic" ? "🤖" : p === "whisper" ? "🌙" : p === "sage" ? "🗿" : p === "lucifer" ? "😈" : "🥃"}</span>
                        <span>{voiceLabels[p]}</span>
                        {voicePreset === p && <span className="ml-auto text-teal-300">✓</span>}
                      </button>
                    ))}
                  </div>
                )}
              </div>

            </div>

            {/* Web search toggle — promoted out of md+ wrapper so it ALSO
                shows on mobile. Vance needs this for Website Build research,
                and the user couldn't reach it on iPhone. */}
            {!isBuildMode && (
              <button
                data-testid="button-toggle-web-search"
                onClick={toggleWebSearch}
                title={webSearchEnabled ? "Web search enabled — click to disable" : "Enable web search so Vance can browse the internet"}
                className={`p-2 rounded-full transition-all border ${
                  webSearchEnabled
                    ? "bg-teal-500/20 border-teal-500/30 text-teal-300 shadow-[0_0_15px_rgba(20,184,166,0.2)]"
                    : "bg-transparent border-transparent text-white/50 hover:bg-white/5 hover:text-white"
                }`}
              >
                <Globe className="w-4 h-4" />
              </button>
            )}

            {/* Build mode + voice mode (essential, all sizes) */}
            <button
              data-testid="button-toggle-build-mode"
              onClick={() => { setIsBuildMode(!isBuildMode); setIsVoiceMode(false); markErrorsRead(); }}
              title={isBuildMode ? "Switch to chat" : errorCount > 0 ? `Switch to build mode (${errorCount} runtime error${errorCount === 1 ? "" : "s"} captured)` : "Switch to build mode"}
              className={`relative p-2 rounded-full transition-colors ${isBuildMode ? "bg-violet-500/20 border border-violet-400/40 text-violet-200" : "text-white/50 hover:bg-white/5 hover:text-white"}`}
            >
              <Code className="w-4 h-4" />
              {errorCount > 0 && <span data-testid="badge-error-count" className="absolute -top-1 -right-1 min-w-[16px] h-4 px-1 rounded-full bg-red-500 text-white text-[10px] font-semibold leading-4 text-center pointer-events-none">{errorCount > 9 ? "9+" : errorCount}</span>}
            </button>

            {!isBuildMode && (
              <button
                data-testid="button-toggle-voice-mode"
                onClick={() => setIsVoiceMode(!isVoiceMode)}
                title={isVoiceMode ? "Hide voice mode" : "Voice mode"}
                className={`p-2 rounded-full transition-colors ${isVoiceMode ? "bg-white/10 border border-white/20 text-white" : "text-white/50 hover:bg-white/5 hover:text-white"}`}
              >
                <Mic className="w-4 h-4" />
              </button>
            )}

            {/* Mobile-only "Reading mode" toggle (desktop has the pill on the left) */}
            <button
              data-testid="button-toggle-tts-mobile"
              onClick={() => {
                if (ttsEnabled) {
                  if (isPlayingTTS) stopTTS();
                  setIsVoiceMode(false);
                  setTtsEnabled(false);
                } else {
                  setTtsEnabled(true);
                }
              }}
              title={ttsEnabled ? "Reading mode (mute voice + hide voice input)" : "Voice on"}
              aria-label={ttsEnabled ? "Switch to reading mode" : "Turn voice on"}
              className={`md:hidden p-2 rounded-full transition-colors ${ttsEnabled ? "text-white/50 hover:bg-white/5 hover:text-white" : "bg-white/10 border border-white/20 text-white"}`}
            >
              {ttsEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            <div className="relative md:hidden">
              <button
                data-testid="button-voice-preset-menu-mobile"
                onClick={() => setShowVoiceMenu((v) => !v)}
                title="Change voice"
                className="flex items-center gap-1 px-2 py-1.5 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 transition-colors text-white/80"
              >
                <span className="text-[10px] font-medium">{voiceLabels[voicePreset]}</span>
                <ChevronDown className="w-3 h-3 opacity-50" />
              </button>
              {showVoiceMenu && (
                <div className="absolute right-0 top-full mt-2 z-50 bg-[#0a0a16]/95 border border-white/10 rounded-xl shadow-xl overflow-hidden min-w-[180px] backdrop-blur-2xl">
                  {(["lucifer", "velvet", "male", "female", "sage", "whisper", "robotic"] as const).map((p) => (
                    <button
                      key={p}
                      onClick={() => { setVoicePreset(p); setShowVoiceMenu(false); }}
                      className={`w-full text-left px-3 py-2 text-sm flex items-center gap-2 transition-colors hover:bg-white/10 ${voicePreset === p ? "text-white font-medium" : "text-white/70"}`}
                    >
                      <span>{p === "female" ? "👩" : p === "male" ? "👨" : p === "robotic" ? "🤖" : p === "whisper" ? "🌙" : p === "sage" ? "🗿" : p === "lucifer" ? "😈" : "🥃"}</span>
                      <span>{voiceLabels[p]}</span>
                      {voicePreset === p && <span className="ml-auto text-teal-300">✓</span>}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <button
              data-testid="button-toggle-avatar"
              onClick={() => setShowAvatar(!showAvatar)}
              title={showAvatar ? "Hide avatar" : "Show avatar"}
              className={`hidden sm:inline-flex p-2 rounded-full transition-colors ${showAvatar ? "bg-white/10 border border-white/20 text-white" : "text-white/50 hover:bg-white/5 hover:text-white"}`}
            >
              <Sparkles className="w-4 h-4" />
            </button>

            <button
              data-testid="button-avatar-settings"
              onClick={() => setShowAvatarModal(true)}
              title="Vance's avatar settings"
              className="p-2 rounded-full text-white/50 hover:bg-white/5 hover:text-white transition-colors"
            >
              <Settings className="w-5 h-5 md:w-4 md:h-4" />
            </button>
          </div>
        </header>
        {/* Mode accent bar — instant color switch when chat mode changes.
            Thin gradient line with a soft glow, label sits above it. */}
        {currentTint && (
          <div className="relative z-20 pointer-events-none transition-colors duration-300">
            <div
              className="h-[3px] w-full transition-all duration-300"
              style={{
                background: `linear-gradient(90deg, transparent 0%, ${currentTint.hex} 18%, ${currentTint.hex} 82%, transparent 100%)`,
                boxShadow: `0 0 18px 2px ${currentTint.glow}, 0 1px 0 ${currentTint.glow}`,
              }}
            />
            <button
              type="button"
              onClick={() => {
                const next: "website" | "build" | "chat" =
                  currentChatMode === "website" ? "build"
                  : currentChatMode === "build" ? "chat"
                  :                               "website";
                void switchToMode(next);
              }}
              className="pointer-events-auto w-full flex items-center justify-center gap-1.5 py-1 text-[9px] font-semibold uppercase tracking-[0.18em] transition-all duration-300 hover:brightness-125 active:brightness-90 cursor-pointer"
              style={{
                color: currentTint.hex,
                background: `linear-gradient(180deg, ${currentTint.bgA}, transparent 100%)`,
              }}
              aria-label={`Currently in ${currentModeLabel} Mode — tap to switch`}
              title="Tap to switch mode"
              data-testid="button-cycle-chat-mode-header"
            >
              <span className="inline-block w-1 h-1 rounded-full" style={{ background: currentTint.hex, boxShadow: `0 0 6px ${currentTint.hex}` }} />
              {currentModeLabel} Mode
            </button>
          </div>
        )}

        {isBuildMode && (
          <div className="px-4 py-2 bg-violet-500/5 border-b border-white/5 flex items-center gap-2">
            <Code size={12} className="text-violet-300" />
            <span className="text-xs text-violet-200/80">Tell Vance what to build or change — he'll edit his own code live.</span>
          </div>
        )}

        {!isBuildMode && webSearchEnabled && (
          <div className="px-4 py-1.5 bg-teal-500/5 border-b border-white/5 flex items-center gap-2">
            <Globe size={11} className="text-teal-300/80 flex-shrink-0" />
            <span className="text-xs text-teal-200/80">Web search active — Vance can browse the internet when you ask</span>
            <button onClick={toggleWebSearch} className="ml-auto text-xs text-white/40 hover:text-white/70 transition-colors" title="Disable web search">Disable</button>
          </div>
        )}

        {/* Floating conversation height slider — desktop only */}
        <div className="absolute right-4 top-22 z-30 hidden md:flex items-center gap-3 rounded-full border border-white/10 bg-[linear-gradient(180deg,rgba(255,255,255,0.08),rgba(255,255,255,0.03))] p-2.5 pr-4 shadow-[0_16px_40px_rgba(0,0,0,0.28)] backdrop-blur-2xl">
          <span className="pl-2 text-xs font-medium text-white/55">Conversation height</span>
          <input
            type="range"
            min={MOBILE_MESSAGES_AREA_PCT_MIN}
            max={MOBILE_MESSAGES_AREA_PCT_MAX}
            step={1}
            value={mobileBubbleLayout.messagesAreaHeightPct}
            onChange={(e) => setMobileBubbleLayout((prev) => ({ ...prev, messagesAreaHeightPct: Number(e.target.value) }))}
            onPointerDown={(e) => e.stopPropagation()}
            onTouchStart={(e) => e.stopPropagation()}
            style={{ touchAction: "none" }}
            className="w-24 accent-teal-400"
            aria-label="Adjust the height of the messages area"
          />
          <span className="text-xs font-mono text-white/80">{mobileBubbleLayout.messagesAreaHeightPct}%</span>
        </div>

        <div className="relative flex min-h-0 flex-1 flex-col overflow-hidden">
          {showAvatar && (
            <div className="absolute inset-0 pt-2 sm:pt-0 flex flex-col items-center justify-start pointer-events-none">
              {/* Stage backdrop intentionally removed — avatar floats
                  directly on the page background for a cleaner, frameless
                  look. The status pill below still carries its own subtle
                  card so the persona name + state remain visible. */}

              {/* Avatar wrapper — anchors above messages area on mobile, fills sm+ */}
              <div
                className="absolute left-0 right-0 top-0 sm:inset-0 flex flex-col items-center justify-center pointer-events-auto"
                style={{ bottom: `calc(${mobileBubbleLayout.messagesAreaHeightPct}% + 4px)` }}
              >
                {/* Inner shift wrapper — keep the canvas centred via normal
                    layout (`mx-auto`) and only apply a small container-level
                    nudge on top. On mobile we bias the container a touch to
                    the right so the avatar model's visible body mass reads
                    centred by eye within the dark stage, then layer the saved
                    user offset over that baseline. This leaves the stage and
                    bubble composition beneath it untouched.
                    MUST keep explicit width/height because the 3D canvas uses
                    w-full h-full to inherit its parent's size. */}
                <div
                  className="w-full h-full"
                  data-avatar-ready={profileLoaded ? "true" : "false"}
                  data-avatar-kind={profileLoaded ? (bodyModelUrl ? "3d" : "orb") : "loading"}
                  style={{
                    transform: mobileBubbleLayout.avatarOffsetXPct !== 0
                      ? `translateX(${mobileBubbleLayout.avatarOffsetXPct}%)`
                      : undefined,
                  }}
                >
                  {profileLoaded ? (
                    <VanceFaceAvatar state={avatarState} persona={persona} avatarUrl={avatarUrl} emote={activeAvatarEmote} bodyModelUrl={bodyModelUrl} zoom={avatarZoom} rotY={avatarRotY} audioAmpRef={audioAmpRef} />
                  ) : (
                    <div className="h-full w-full" />
                  )}
                </div>

                {/* Floating 3D camera controls — anchored to the stage frame,
                    NOT to the draggable avatar wrapper, so they stay reachable
                    even when the avatar is nudged left/right by the user. Only
                    rendered when a 3D body model is loaded (no controls for
                    the orb fallback). */}
                {profileLoaded && bodyModelUrl ? (
                  <div className="absolute bottom-3 right-3 flex flex-col gap-1.5 z-20 pointer-events-auto">
                    <button onClick={avatarZoomIn}  aria-label="Zoom in"      title="Zoom in"      className="w-9 h-9 flex items-center justify-center rounded-full bg-card/70 backdrop-blur-md border border-border text-muted-foreground hover:text-foreground hover:bg-card transition-colors shadow-md active:scale-95"><ZoomIn    size={16} /></button>
                    <button onClick={avatarZoomOut} aria-label="Zoom out"     title="Zoom out"     className="w-9 h-9 flex items-center justify-center rounded-full bg-card/70 backdrop-blur-md border border-border text-muted-foreground hover:text-foreground hover:bg-card transition-colors shadow-md active:scale-95"><ZoomOut   size={16} /></button>
                    <button onClick={avatarRotateL} aria-label="Rotate left"  title="Rotate left"  className="w-9 h-9 flex items-center justify-center rounded-full bg-card/70 backdrop-blur-md border border-border text-muted-foreground hover:text-foreground hover:bg-card transition-colors shadow-md active:scale-95"><RotateCcw size={16} /></button>
                    <button onClick={avatarRotateR} aria-label="Rotate right" title="Rotate right" className="w-9 h-9 flex items-center justify-center rounded-full bg-card/70 backdrop-blur-md border border-border text-muted-foreground hover:text-foreground hover:bg-card transition-colors shadow-md active:scale-95"><RotateCw  size={16} /></button>
                    <button onClick={avatarReset}   aria-label="Reset view"   title="Reset view"   className="w-9 h-9 flex items-center justify-center rounded-full bg-card/70 backdrop-blur-md border border-border text-muted-foreground hover:text-foreground hover:bg-card transition-colors shadow-md active:scale-95"><Maximize2 size={15} /></button>
                    {/* Hide-avatar toggle promoted from the desktop-only header
                        button so iPhone users can collapse the avatar with one
                        tap from the same control column they already use for
                        zoom/rotate. Re-show pill at top-center handles toggle-back. */}
                    <button onClick={() => setShowAvatar(false)} aria-label="Hide avatar" title="Hide avatar" data-testid="button-hide-avatar-stage" className="w-9 h-9 flex items-center justify-center rounded-full bg-card/70 backdrop-blur-md border border-border text-muted-foreground hover:text-foreground hover:bg-card transition-colors shadow-md active:scale-95"><Eye size={16} /></button>
                  </div>
                ) : null}
              </div>

              {/* Emote picker (top-left) */}
              <div className="absolute top-2 left-2 z-20 pointer-events-auto">
                <button
                  data-testid="button-emote-picker"
                  onClick={() => setShowEmotePicker((v) => !v)}
                  className="px-2.5 py-1 rounded-full bg-white/5 backdrop-blur-md border border-white/10 text-xs text-white/70 hover:text-white hover:bg-white/10 transition-colors flex items-center gap-1.5"
                  title="Trigger an emote"
                >
                  <span className="text-sm leading-none">🎭</span>
                  <span className="tracking-wide">Emote</span>
                </button>
                {showEmotePicker && (
                  <div className="mt-2 p-2 rounded-xl bg-[#0a0a16]/85 backdrop-blur-md border border-white/10 grid grid-cols-3 gap-1 w-44 max-h-[60vh] overflow-y-auto shadow-xl">
                    {EMOTE_LIST.map((e) => {
                      const ready = emoteAvailability[e.id] === true;
                      return (
                        <button
                          key={e.id}
                          data-testid={`button-emote-${e.id}`}
                          onClick={() => {
                            if (!ready) { showEmoteHint(e.label); return; }
                            triggerEmote(e.id);
                            setShowEmotePicker(false);
                          }}
                          className={`relative flex flex-col items-center gap-0.5 py-1.5 rounded-lg transition-colors ${ready ? "hover:bg-white/10" : "opacity-40 hover:opacity-70 hover:bg-white/5"}`}
                          title={ready ? e.label : `${e.label} — not uploaded`}
                        >
                          <span className="text-lg leading-none">{e.emoji}</span>
                          <span className="text-[10px] text-white/55">{e.label}</span>
                          {ready && <span className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-teal-400/80" />}
                        </button>
                      );
                    })}
                  </div>
                )}
                {emoteHint && (
                  <div className="mt-2 px-2.5 py-1.5 rounded-lg bg-amber-500/15 border border-amber-400/30 text-amber-200/90 text-[11px] max-w-[220px] leading-snug shadow-lg">
                    {emoteHint}
                  </div>
                )}
              </div>

              {/* Character card footer — sits inside the stage frame, just
                  above the messages area. Shows Vance's name + a live status
                  pill (Listening / Speaking / Thinking / Researching / Online).
                  Replaces the previous bare-text persona caption to fill the
                  empty space the user circled with something premium. */}
              {(() => {
                // Derive a single status object so the JSX stays clean.
                let statusLabel = "Online · Ready to chat";
                let statusColor = "#34D399"; // emerald
                let pulse = false;
                let bouncing = false;
                if (isPersonaLoading) {
                  statusLabel = "Becoming…";
                  statusColor = "#A78BFA";
                  bouncing = true;
                } else if (isRecording) {
                  statusLabel = "Listening…";
                  statusColor = "#F87171";
                  pulse = true;
                } else if (isSpeaking) {
                  statusLabel = "Speaking…";
                  statusColor = "#2DD4BF";
                  pulse = true;
                } else if (avatarState === "thinking") {
                  statusLabel = isResearching ? "Researching the web…" : "Thinking…";
                  statusColor = "#2DD4BF";
                  bouncing = true;
                }
                const accent = currentTint?.hex ?? "#F5B34A";
                return (
                  <div
                    className="absolute left-1/2 -translate-x-1/2 flex flex-col items-center pointer-events-none w-full px-4"
                    style={{ bottom: `calc(${mobileBubbleLayout.messagesAreaHeightPct}% + 8px)` }}
                  >
                    <div
                      className="pointer-events-auto relative inline-flex items-center gap-3.5 overflow-hidden rounded-2xl border border-white/12 bg-[linear-gradient(180deg,rgba(28,20,56,0.95)_0%,rgba(14,10,30,0.96)_55%,rgba(8,8,20,0.96)_100%)] pl-6 pr-6 py-3 min-w-[18rem] sm:min-w-[22rem] justify-center backdrop-blur-2xl"
                      style={{ boxShadow: `0 16px 44px rgba(0,0,0,0.5), 0 0 28px rgba(167,139,250,0.22), 0 0 18px ${accent}25, inset 0 1px 0 rgba(255,255,255,0.07)` }}
                    >
                      {/* Violet accent stripe on the left edge */}
                      <span
                        aria-hidden
                        className="absolute left-0 top-0 bottom-0 w-[4px]"
                        style={{ background: "linear-gradient(180deg, rgba(196,181,253,1) 0%, rgba(167,139,250,0.9) 50%, rgba(139,92,246,0.55) 100%)", boxShadow: "0 0 16px rgba(167,139,250,0.7)" }}
                      />
                      {/* Status indicator dot — brighter, with halo */}
                      {bouncing ? (
                        <span className="flex items-center gap-1">
                          <span className="h-2 w-2 rounded-full animate-bounce" style={{ background: statusColor, boxShadow: `0 0 10px ${statusColor}`, animationDelay: "0ms" }} />
                          <span className="h-2 w-2 rounded-full animate-bounce" style={{ background: statusColor, boxShadow: `0 0 10px ${statusColor}`, animationDelay: "150ms" }} />
                          <span className="h-2 w-2 rounded-full animate-bounce" style={{ background: statusColor, boxShadow: `0 0 10px ${statusColor}`, animationDelay: "300ms" }} />
                        </span>
                      ) : (
                        <span className="relative flex h-3 w-3 items-center justify-center">
                          <span className="absolute inset-0 rounded-full opacity-60 animate-ping" style={{ background: statusColor }} />
                          <span className="relative h-3 w-3 rounded-full ring-2 ring-white/15" style={{ background: statusColor, boxShadow: `0 0 12px ${statusColor}, 0 0 22px ${statusColor}90` }} />
                          {/* Glossy highlight */}
                          <span className="absolute top-[2px] left-[3px] h-[4px] w-[4px] rounded-full bg-white/80 blur-[0.3px]" />
                        </span>
                      )}
                      {/* Name — bolder, larger */}
                      <span className="text-[16px] font-bold tracking-tight text-white drop-shadow-[0_1px_6px_rgba(167,139,250,0.45)]">
                        {persona?.name ?? "Vance"}
                      </span>
                      {/* Separator */}
                      <span className="h-4 w-px bg-white/15" />
                      {/* Status text — clean light weight */}
                      <span className="text-[12.5px] font-light tracking-wide text-white/70">
                        {statusLabel}
                      </span>
                    </div>
                    {persona?.description && !isPersonaLoading && (
                      <span className="mt-1 line-clamp-1 max-w-[14rem] px-4 text-center text-[10px] leading-snug text-white/40 sm:max-w-xs sm:px-6 sm:text-[11px]">
                        {persona.description}
                      </span>
                    )}
                  </div>
                );
              })()}

              {/* Mobile bubble layout slider (mobile only) */}
              {!isBuildMode && (
                <div className="absolute top-2.5 right-12 z-20 md:hidden pointer-events-auto">
                  <div className="relative">
                    <button
                      type="button"
                      data-testid="button-mobile-bubble-layout"
                      onClick={() => setShowMobileBubbleControls((prev) => !prev)}
                      className={`flex h-8 w-8 items-center justify-center rounded-full border backdrop-blur-2xl transition-colors ${showMobileBubbleControls ? "border-white/20 bg-white/10 text-white" : "border-white/10 bg-white/5 text-white/60 hover:text-white"}`}
                      aria-expanded={showMobileBubbleControls}
                      aria-label="Show layout controls"
                    >
                      <SlidersHorizontal size={14} />
                    </button>

                    {showMobileBubbleControls && (
                      <div className="absolute right-0 top-[calc(100%+0.55rem)] z-30 w-[min(18.5rem,calc(100vw-1.5rem))] overflow-hidden rounded-2xl border border-white/10 bg-[#0a0a16]/90 p-3 backdrop-blur-2xl shadow-xl">
                        <div className="mb-3 flex items-center justify-between gap-3">
                          <div>
                            <div className="text-[11px] font-semibold tracking-[0.14em] uppercase text-white/80">Layout</div>
                            <div className="mt-1 text-[11px] leading-snug text-white/50">Adjust the conversation area.</div>
                          </div>
                          <button
                            type="button"
                            onClick={() => setMobileBubbleLayout(DEFAULT_MOBILE_BUBBLE_LAYOUT)}
                            className="rounded-full border border-white/15 px-2.5 py-1 text-[11px] text-white/70 transition-colors hover:border-white/30 hover:text-white"
                          >
                            Reset
                          </button>
                        </div>
                        <label className="block">
                          <div className="mb-1.5 flex items-center justify-between gap-3 text-[11px] text-white/60">
                            <span>Conversation area height</span>
                            <span>{mobileBubbleLayout.messagesAreaHeightPct}%</span>
                          </div>
                          <input
                            type="range"
                            min={MOBILE_MESSAGES_AREA_PCT_MIN}
                            max={MOBILE_MESSAGES_AREA_PCT_MAX}
                            step={1}
                            value={mobileBubbleLayout.messagesAreaHeightPct}
                            onChange={(e) => setMobileBubbleLayout((prev) => ({ ...prev, messagesAreaHeightPct: Number(e.target.value) }))}
                            onPointerDown={(e) => e.stopPropagation()}
                            onTouchStart={(e) => e.stopPropagation()}
                            style={{ touchAction: "none" }}
                            className="w-full accent-teal-400"
                            aria-label="Adjust the height of the messages area on mobile"
                          />
                        </label>
                        <label className="mt-3 block">
                          <div className="mb-1.5 flex items-center justify-between gap-3 text-[11px] text-white/60">
                            <span>Avatar horizontal position</span>
                            <span>{mobileBubbleLayout.avatarOffsetXPct > 0 ? "+" : ""}{mobileBubbleLayout.avatarOffsetXPct}%</span>
                          </div>
                          <input
                            type="range"
                            min={AVATAR_OFFSET_X_PCT_MIN}
                            max={AVATAR_OFFSET_X_PCT_MAX}
                            step={1}
                            value={mobileBubbleLayout.avatarOffsetXPct}
                            onChange={(e) => setMobileBubbleLayout((prev) => ({ ...prev, avatarOffsetXPct: Number(e.target.value) }))}
                            onPointerDown={(e) => e.stopPropagation()}
                            onTouchStart={(e) => e.stopPropagation()}
                            style={{ touchAction: "none" }}
                            className="w-full accent-teal-400"
                            aria-label="Nudge the avatar left or right to center it"
                          />
                          <div className="mt-1 flex justify-between text-[10px] text-white/30">
                            <span>← left</span>
                            <span>center</span>
                            <span>right →</span>
                          </div>
                        </label>
                      </div>
                    )}
                  </div>
                </div>
              )}

              <button
                onClick={() => setShowAvatar(false)}
                className="absolute top-2 right-2 p-1 rounded-lg text-white/30 hover:text-white/70 transition-colors pointer-events-auto"
                aria-label="Hide avatar"
              >
                <ChevronDown size={14} />
              </button>
              {persona && (
                <button
                  onClick={() => setPersona(null)}
                  className="absolute top-12 left-2 px-2 py-0.5 rounded-full text-xs text-white/40 hover:text-white/80 border border-white/10 hover:border-white/30 transition-colors pointer-events-auto"
                >
                  Reset
                </button>
              )}
            </div>
          )}

          {/* Restore-avatar button — when the user hides the avatar (via the
              chevron above), the entire avatar block unmounts including its
              own controls.  The desktop header has a separate toggle, but on
              mobile there's no way back without this floating pill. */}
          {!showAvatar && (
            <button
              type="button"
              onClick={() => setShowAvatar(true)}
              className="absolute top-2 left-1/2 -translate-x-1/2 z-20 inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-[#0a0a16]/80 px-3 py-1.5 text-[11px] font-medium tracking-wide text-white/75 backdrop-blur-md shadow-lg hover:text-white hover:border-white/30 transition-colors"
              data-testid="button-show-avatar"
              aria-label="Show avatar"
            >
              <ChevronDown size={12} className="rotate-180" />
              Show avatar
            </button>
          )}

          {/* Messages area */}
          <div
            ref={messagesScrollRef}
            className="relative z-10 mt-auto mb-0 overflow-y-auto overflow-x-hidden px-3 pb-3 pt-2 sm:px-6 sm:py-4 transition-colors"
            style={{
              maxHeight: `${mobileBubbleLayout.messagesAreaHeightPct}%`,
              overflowAnchor: "none",
              ...(currentTint ? {
                background: `linear-gradient(180deg, ${currentTint.bgB}, transparent 60%)`,
                boxShadow: `inset 0 1px 0 ${currentTint.glow}`,
              } : {}),
            }}
          >
            {/* Per-mode "Continuing from last message" banner. Tells the user
                which mode's history is loaded and whether there's prior
                context. Color matches the mode tint. */}
            {currentTint && currentChatMode && (
              <div
                className="mx-auto mb-2 max-w-4xl flex items-center justify-center gap-2 rounded-full border px-3 py-1 text-[11px] font-medium tracking-wide transition-all duration-300"
                style={{
                  borderColor: currentTint.border,
                  background:  `linear-gradient(90deg, ${currentTint.bgA}, ${currentTint.bgB})`,
                  color:       currentTint.hex,
                  boxShadow:   `0 0 14px ${currentTint.glow}`,
                }}
                data-testid="banner-mode-history"
              >
                <span>{currentModeEmoji}</span>
                <span className="font-semibold">{currentModeLabel} Mode</span>
                <span className="text-white/55">— {messages.length > 0 ? "Continuing from last message" : "Starting fresh in this mode"}</span>
              </div>
            )}
            <div className="mx-auto flex max-w-4xl flex-col gap-4 rounded-[2rem] border border-white/8 bg-[linear-gradient(180deg,rgba(9,12,31,0.7),rgba(9,12,31,0.38))] px-3 py-3 shadow-[0_22px_60px_rgba(0,0,0,0.28)] backdrop-blur-xl md:gap-6 md:px-6 md:py-5">
              {messages.length === 0 && (
                <div className="mx-auto flex max-w-2xl flex-col items-center justify-center px-4 py-8 text-center md:py-10">
                  <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-3.5 py-1.5 text-[11px] font-semibold uppercase tracking-[0.22em] text-primary/90">
                    <Sparkles className="h-3.5 w-3.5" />
                    Speak with Vance
                  </div>
                  <h2 className="max-w-xl font-serif text-2xl leading-tight text-white sm:text-3xl">A calmer, sharper space for conversation, research, and live builds.</h2>
                  <p className="mt-3 max-w-xl text-sm leading-relaxed text-white/58 sm:text-[15px]">
                    {showAvatar
                      ? "Ask for ideas, browse the web, switch voices, or tell Vance exactly what to build — the assistant and studio now live together in one cleaner workspace."
                      : "Ask for ideas, browse the web, switch voices, or tell Vance exactly what to build — even with the avatar hidden, the workspace stays focused and ready."}
                  </p>
                  <div className="mt-5 flex flex-wrap items-center justify-center gap-2.5 text-[11px] text-white/48 sm:text-xs">
                    <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5">Chat naturally</span>
                    <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5">Search the web</span>
                    <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5">Build live in-app</span>
                  </div>
                </div>
              )}

              {!showAllMessages && messages.length > MESSAGES_TAIL_LIMIT && (
                <button
                  type="button"
                  onClick={() => setShowAllMessages(true)}
                  className="mx-auto -mb-1 inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/5 hover:bg-white/10 hover:border-white/25 px-3 py-1 text-[11px] font-medium text-white/70 hover:text-white transition-colors"
                  data-testid="button-show-earlier-messages"
                >
                  <ChevronDown size={12} className="rotate-180" />
                  Show {messages.length - MESSAGES_TAIL_LIMIT} earlier {messages.length - MESSAGES_TAIL_LIMIT === 1 ? "message" : "messages"}
                </button>
              )}
              {(showAllMessages ? messages : messages.slice(-MESSAGES_TAIL_LIMIT)).map((msg, idx) => {
                const isUser = msg.role === "user";
                return (
                  <div key={msg.clientId} data-testid={`message-${idx}`} className={`flex message-enter ${isUser ? "flex-col items-end pl-6 md:pl-12" : "items-start gap-3 md:gap-4 pr-4 md:pr-12"}`}>
                    {!isUser && (
                      <div className={`w-7 h-7 md:w-8 md:h-8 rounded-full shrink-0 flex items-center justify-center shadow-lg border border-white/20 mt-1 overflow-hidden ${msg.isBuildResult ? "bg-gradient-to-br from-violet-500 to-violet-700" : msg.isResearchResult ? "bg-gradient-to-br from-teal-500 to-cyan-600" : "bg-gradient-to-br from-violet-500 to-cyan-500"}`}>
                        {msg.isBuildResult ? <Code size={12} className="text-white" /> : msg.isResearchResult ? <BookOpen size={12} className="text-white" /> : avatarUrl ? <img src={avatarUrl} alt="Vance" className="w-full h-full object-cover" style={{ objectPosition: "center 15%" }} /> : <div className="w-1.5 h-1.5 md:w-2 md:h-2 rounded-full bg-white shadow-[0_0_10px_rgba(255,255,255,0.8)]" />}
                      </div>
                    )}
                    <div className={`relative group ${isUser ? "max-w-[92%] md:max-w-[85%]" : "flex-1 min-w-0 max-w-full md:max-w-[85%] flex flex-col gap-2"}`}>
                      {/* Per-bubble delete X. Hidden while a message is mid-stream */}
                      {/* (no point deleting a half-written reply — Stop handles that). */}
                      {/* Faint by default, brighter on hover/tap. Positioned at the */}
                      {/* outer corner of the bubble row: top-left for user (which is */}
                      {/* right-aligned, so the X sits on the bubble's left edge), */}
                      {/* top-right for assistant. Tap target is ~28px to stay easily */}
                      {/* hittable on touch without crowding the bubble. */}
                      {!msg.streaming && (
                        <button
                          type="button"
                          onClick={() => handleDeleteMessage(msg)}
                          className={`absolute -top-1.5 z-10 flex h-6 w-6 items-center justify-center rounded-full bg-black/55 border border-white/15 text-white/55 hover:text-white hover:bg-black/80 backdrop-blur-sm shadow-md opacity-60 group-hover:opacity-100 transition-opacity ${isUser ? "-left-1.5" : "-right-1.5"}`}
                          aria-label="Delete this message"
                          title="Delete this message"
                          data-testid={`button-delete-message-${idx}`}
                        >
                          <X size={12} strokeWidth={2.5} />
                        </button>
                      )}
                      {!isUser && msg.files && msg.files.length > 0 && (
                        <div className="flex flex-col gap-1.5">
                          {msg.files.map((f) => (
                            <a
                              key={f.url}
                              href={f.url}
                              download={f.name}
                              data-testid={`link-download-${f.name}`}
                              className="flex items-center gap-3 rounded-2xl border border-teal-400/30 bg-teal-500/[0.08] hover:bg-teal-500/[0.14] transition-colors px-3.5 py-2.5 text-white/90 no-underline"
                            >
                              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-teal-500/20 border border-teal-400/40">
                                <FileText size={16} className="text-teal-200" />
                              </span>
                              <span className="flex-1 min-w-0">
                                <span className="block truncate font-medium text-[13.5px] md:text-sm">{f.name}</span>
                                <span className="block truncate text-[11px] text-white/50">
                                  {formatFileSize(f.sizeBytes)}{f.description ? ` · ${f.description}` : ""}
                                </span>
                              </span>
                              <span className="shrink-0 text-[11px] font-medium text-teal-200/90 px-2 py-1 rounded-md bg-teal-500/15 border border-teal-400/30">Download</span>
                            </a>
                          ))}
                        </div>
                      )}
                      {msg.imageUrl && (
                        <button
                          type="button"
                          onClick={() => window.dispatchEvent(new CustomEvent("vance-open-lightbox", { detail: { url: msg.imageUrl as string, label: isUser ? "Attached image you sent" : "Attached image" } }))}
                          className={`block overflow-hidden rounded-2xl border bg-transparent p-0 text-left cursor-zoom-in ${isUser ? "border-white/10 bg-white/5" : "border-white/10 bg-white/[0.03]"}`}
                          aria-label="Open attached image"
                        >
                          <img
                            src={msg.imageUrl}
                            alt={isUser ? "Attached image you sent" : "Attached image"}
                            className="block h-auto max-h-[18rem] w-full max-w-[min(85vw,22rem)] object-contain bg-black/20 sm:max-w-sm"
                            loading="lazy"
                          />
                        </button>
                      )}
                      {/* Multi-image gen: stack additional thumbnails directly under the */}
                      {/* main image. Each is independently clickable to open the lightbox */}
                      {/* with a numbered label so the user can tell Vance "I like number 3". */}
                      {/* Numbering is 1-based and includes the primary imageUrl as #1. */}
                      {msg.extraImageUrls && msg.extraImageUrls.length > 0 && msg.extraImageUrls.map((extraUrl, extraIdx) => (
                        <button
                          key={extraUrl}
                          type="button"
                          onClick={() => window.dispatchEvent(new CustomEvent("vance-open-lightbox", { detail: { url: extraUrl, label: `Option ${extraIdx + 2}` } }))}
                          className="block overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03] p-0 text-left cursor-zoom-in"
                          aria-label={`Open option ${extraIdx + 2}`}
                        >
                          <img
                            src={extraUrl}
                            alt={`Option ${extraIdx + 2}`}
                            className="block h-auto max-h-[18rem] w-full max-w-[min(85vw,22rem)] object-contain bg-black/20 sm:max-w-sm"
                            loading="lazy"
                          />
                        </button>
                      ))}
                      {(msg.content || (!msg.isBuildResult && !msg.isResearchResult && msg.streaming && !msg.browsingQuery)) && (
                        isUser ? (
                          <div
                            className="relative rounded-3xl rounded-tr-sm border border-primary/12 bg-[linear-gradient(180deg,rgba(255,255,255,0.12),rgba(255,255,255,0.07))] px-4 py-3 text-[14px] leading-relaxed whitespace-pre-wrap break-words text-white shadow-[0_14px_36px_rgba(0,0,0,0.2)] backdrop-blur-md md:px-5 md:py-3.5 md:text-[15px]"
                            {...longPressCopyHandlers(msg.content, msg.clientId)}
                            data-testid={`bubble-user-${idx}`}
                          >
                            {renderWithLinks(msg.content)}
                            {copiedMsgId === msg.clientId && (
                              <span className="pointer-events-none absolute -top-2 right-2 rounded-full bg-teal-500/95 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-white shadow-lg shadow-teal-900/40 animate-[fadeIn_120ms_ease-out]">Copied</span>
                            )}
                          </div>
                        ) : (
                          <div className="flex flex-col gap-1.5">
                            {/* Small coloured mode label that sits ABOVE Vance's reply.
                                Replaces the in-text "🟣 **[Conversation Mode - Purple]**"
                                header — the tag is now a UI chip, never part of the
                                stored message content, never on user bubbles, never
                                read aloud by TTS. */}
                            {!msg.isBuildResult && !msg.isResearchResult && currentChatMode && currentTint && (
                              <span
                                data-testid={`label-mode-${currentChatMode}-${idx}`}
                                className="self-start inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider"
                                style={{
                                  color: currentTint.hex,
                                  backgroundColor: currentTint.bgA,
                                  border: `1px solid ${currentTint.border}`,
                                }}
                              >
                                <span className="inline-block w-1.5 h-1.5 rounded-full" style={{ backgroundColor: currentTint.hex, boxShadow: `0 0 8px ${currentTint.glow}` }} />
                                {currentChatMode === "website" ? "Website Build" : currentChatMode === "build" ? "Regular Build" : "Conversation"}
                              </span>
                            )}
                          <div
                            className="relative rounded-[1.6rem] border border-white/6 bg-white/[0.035] px-4 py-3 text-[14px] leading-relaxed text-white/90 shadow-[0_10px_30px_rgba(0,0,0,0.12)] whitespace-pre-wrap break-words md:px-5 md:text-[15px]"
                            {...(msg.content && !msg.streaming ? longPressCopyHandlers(stripModeTag(msg.content), msg.clientId) : {})}
                            data-testid={`bubble-assistant-${idx}`}
                          >
                            {copiedMsgId === msg.clientId && (
                              <span className="pointer-events-none absolute -top-2 right-2 rounded-full bg-teal-500/95 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-white shadow-lg shadow-teal-900/40 animate-[fadeIn_120ms_ease-out]">Copied</span>
                            )}
                            {msg.content ? renderWithLinks(stripModeTag(msg.content), ttsHighlight && ttsHighlight.msgClientId === msg.clientId ? { start: ttsHighlight.start, end: ttsHighlight.end } : null) : (msg.streaming && !msg.browsingQuery ? (
                              <span className="flex gap-1 items-center h-4">
                                <span className="w-1.5 h-1.5 rounded-full bg-white/40 animate-bounce" style={{ animationDelay: "0ms" }} />
                                <span className="w-1.5 h-1.5 rounded-full bg-white/40 animate-bounce" style={{ animationDelay: "150ms" }} />
                                <span className="w-1.5 h-1.5 rounded-full bg-white/40 animate-bounce" style={{ animationDelay: "300ms" }} />
                              </span>
                            ) : "")}
                            {msg.streaming && msg.content && <span className="inline-block w-0.5 h-4 bg-teal-300 ml-0.5 animate-pulse" />}
                          </div>
                          </div>
                        )
                      )}
                      {!isUser && !msg.streaming && !msg.isBuildResult && !msg.isResearchResult && msg.content && msg.content.trim().length > 0 && ttsEnabled && (
                        <button
                          type="button"
                          data-testid={`button-replay-tts-${idx}`}
                          onClick={() => replayMessageTTS(msg.content, msg.clientId)}
                          className="self-start inline-flex items-center gap-1.5 text-[11px] md:text-xs text-white/40 hover:text-teal-300 transition-colors px-2 py-1 -ml-2 rounded-full hover:bg-white/5"
                          title="Replay this message"
                          aria-label="Replay this message"
                        >
                          <RotateCcw className="w-3 h-3" />
                          <span>Replay</span>
                        </button>
                      )}
                      {msg.isBuildResult && (msg.buildEvents?.length || msg.buildStream || msg.streaming) && (
                        <BuildProgress
                          events={msg.buildEvents ?? []}
                          currentPhase={msg.buildPhase}
                          streamText={msg.buildStream}
                          isStreaming={!!msg.streaming}
                        />
                      )}
                      {msg.intake && (
                        <IntakeCard
                          intake={msg.intake}
                          disabled={isSending}
                          onSubmit={(text) => {
                            setMessages((prev) => prev.map((m) => m.clientId === msg.clientId ? { ...m, intake: { ...m.intake!, status: "submitted" } } : m));
                            saveIntakeStatus(conversationId, msg.id, "submitted");
                            void sendTextMessage(text);
                          }}
                          onSkip={() => {
                            setMessages((prev) => prev.map((m) => m.clientId === msg.clientId ? { ...m, intake: { ...m.intake!, status: "skipped" } } : m));
                            saveIntakeStatus(conversationId, msg.id, "skipped");
                          }}
                        />
                      )}
                      {msg.proposal && (
                        <ProposalCard
                          proposal={msg.proposal}
                          disabled={isSending}
                          onAccept={(text) => {
                            const kind = msg.proposal?.kind ?? "app";
                            setMessages((prev) => prev.map((m) => m.clientId === msg.clientId ? { ...m, proposal: { instruction: text, kind, status: "accepted" } } : m));
                            saveProposalStatus(conversationId, msg.id, text, "accepted");
                            // App proposals → Build Mode (edits Vance's own
                            // codebase). Website proposals → regular chat
                            // message so Vance can call update_zip /
                            // create_zip / create_text_file in this turn.
                            if (kind === "website") {
                              void sendTextMessage(`Yes, do this:\n\n${text}`);
                            } else {
                              void sendBuildInstruction(text);
                            }
                          }}
                          onEdit={() => setMessages((prev) => prev.map((m) => m.clientId === msg.clientId ? { ...m, proposal: { ...m.proposal!, status: "editing" } } : m))}
                          onSaveEdit={(text) => setMessages((prev) => prev.map((m) => m.clientId === msg.clientId ? { ...m, proposal: { instruction: text, kind: m.proposal?.kind ?? "app", status: "pending" } } : m))}
                          onCancel={() => {
                            setMessages((prev) => prev.map((m) => m.clientId === msg.clientId ? { ...m, proposal: { ...m.proposal!, status: "cancelled" } } : m));
                            saveProposalStatus(conversationId, msg.id, msg.proposal?.instruction ?? "", "cancelled");
                          }}
                          onRetry={msg.proposal?.kind === "website" ? () => {
                            // Re-ship the same spec with a fresh design pack.
                            // Backend recognises "retry build" as re-acceptance
                            // of the most recent proposal fence in this conv,
                            // counts prior zips to set variation index, then
                            // ships via the deterministic template short-circuit.
                            void sendTextMessage("retry build");
                          } : undefined}
                        />
                      )}
                      {msg.createdAt && !msg.streaming && (
                        <div className={`text-[10.5px] text-white/35 px-1 ${isUser ? "self-end" : "self-start"}`} title={new Date(msg.createdAt).toLocaleString("en-US", { timeZone: "America/New_York" })}>
                          {formatTimeEastern(msg.createdAt)}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}

              {voiceTranscript && (
                <div className="flex items-start gap-3 md:gap-4 pr-4 md:pr-12 message-enter">
                  <div className="w-7 h-7 md:w-8 md:h-8 rounded-full bg-gradient-to-br from-violet-500 to-cyan-500 shrink-0 flex items-center justify-center shadow-lg border border-white/20 mt-1">
                    <div className="w-1.5 h-1.5 md:w-2 md:h-2 rounded-full bg-white" />
                  </div>
                  <div className="flex-1 text-[14px] md:text-[15px] leading-relaxed text-white/70 italic pt-1">
                    {voiceTranscript}<span className="inline-block w-0.5 h-4 bg-teal-300 ml-0.5 animate-pulse" />
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>
          </div>
        </div>

        {/* Composer */}
        <div className="relative z-20 shrink-0 bg-gradient-to-t from-[#070914] via-[#070914]/94 to-transparent px-3 py-3 md:px-6 md:py-4">
          <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/12 to-transparent" />
          {isVoiceMode && !isBuildMode ? (
            <div className="flex flex-col items-center gap-2 py-3">
              <button
                data-testid="button-voice-record"
                onClick={() => void handleVoiceToggle()}
                disabled={isSending && !isRecording}
                className={`w-16 h-16 rounded-full flex items-center justify-center transition-all duration-300 border-2 ${isRecording ? "bg-red-500 border-red-400 text-white scale-110 shadow-lg shadow-red-500/30" : "bg-white/10 border-white/30 text-white hover:bg-white/20"}`}
              >
                {isRecording ? <MicOff size={22} /> : <Mic size={22} />}
              </button>
              <span className="text-xs text-white/60">{isRecording ? "Tap to send" : "Tap to speak"}</span>
            </div>
          ) : (
            <div className="max-w-3xl mx-auto w-full relative">
              {/* Attachment chip floats above */}
              {!isBuildMode && attachedImage && (
                <div className="absolute -top-12 left-4">
                  <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/10 shadow-lg text-xs font-medium text-white/80">
                    <img src={attachedImage.dataUrl} alt="" className="w-4 h-4 rounded object-cover" />
                    <span className="truncate max-w-[160px]">{attachedImage.name}</span>
                    <button
                      type="button"
                      data-testid="button-remove-chat-image"
                      onClick={clearAttachedImage}
                      className="p-0.5 hover:bg-white/20 rounded-full transition-colors ml-1"
                      aria-label="Remove attached image"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              )}

              {!isBuildMode && attachedFile && (
                <div className="absolute -top-12 left-4">
                  <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/10 shadow-lg text-xs font-medium text-white/80">
                    <FileText className="w-4 h-4 text-white/60" />
                    <span className="truncate max-w-[160px]" title={attachedFile.fileName}>{attachedFile.fileName}</span>
                    <span className="text-white/40 text-[10px]">
                      {attachedFile.truncated ? `${Math.round(attachedFile.charCount / 1000)}k / ${Math.round(attachedFile.originalChars / 1000)}k chars` : `${attachedFile.charCount.toLocaleString()} chars`}
                    </span>
                    <button
                      type="button"
                      data-testid="button-remove-chat-file"
                      onClick={clearAttachedFile}
                      className="p-0.5 hover:bg-white/20 rounded-full transition-colors ml-1"
                      aria-label="Remove attached file"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              )}

              {!isBuildMode && imageError && (
                <div data-testid="chat-image-error" className="mb-2 rounded-xl border border-red-400/40 bg-red-500/10 px-3 py-2 text-xs text-red-300">
                  {imageError}
                </div>
              )}

              {!isBuildMode && (
                <input
                  ref={attachmentInputRef}
                  type="file"
                  accept={CHAT_FILE_ACCEPT}
                  className="hidden"
                  onChange={(e) => void handleAttachmentChange(e)}
                />
              )}

              <div
                className={`flex items-end gap-1.5 rounded-[28px] border p-1.5 shadow-[0_18px_45px_rgba(0,0,0,0.34),inset_0_1px_0_rgba(255,255,255,0.12)] backdrop-blur-2xl transition-all md:gap-2 md:rounded-3xl md:p-2 ${isBuildMode ? "border-violet-400/30 bg-[linear-gradient(180deg,rgba(139,92,246,0.18),rgba(139,92,246,0.08))]" : currentTint ? "" : "border-white/10 bg-[linear-gradient(180deg,rgba(255,255,255,0.08),rgba(255,255,255,0.045))] focus-within:border-white/20 focus-within:bg-white/[0.08]"}`}
                style={!isBuildMode && currentTint ? {
                  borderColor: currentTint.border,
                  background:  `linear-gradient(180deg, ${currentTint.bgA}, ${currentTint.bgB})`,
                  boxShadow:   `0 18px 45px rgba(0,0,0,0.34), inset 0 1px 0 rgba(255,255,255,0.12), 0 0 22px ${currentTint.glow}`,
                } : undefined}
              >
                {!isBuildMode && (
                  <button
                    type="button"
                    data-testid="button-attach-chat-image"
                    onClick={() => attachmentInputRef.current?.click()}
                    disabled={isSending}
                    className="p-2.5 md:p-3 text-white/40 hover:text-white hover:bg-white/10 rounded-full transition-colors shrink-0 disabled:opacity-40"
                    title="Attach an image, PDF, or text/code file"
                    aria-label="Attach an image, PDF, or text/code file"
                  >
                    <ImagePlus className="w-4 h-4 md:w-5 md:h-5" />
                  </button>
                )}

                <textarea
                  data-testid="input-message"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder={isBuildMode ? "Describe what you want Vance to build or change…" : "Message Vance…"}
                  rows={1}
                  className="flex-1 bg-transparent border-0 resize-none outline-none py-2.5 md:py-3 px-1 md:px-2 text-white placeholder:text-white/30 max-h-[120px] md:max-h-[150px] min-h-[40px] md:min-h-[44px] text-[14px] md:text-[15px] leading-relaxed"
                  onInput={(e) => { const el = e.currentTarget; el.style.height = "auto"; el.style.height = `${el.scrollHeight}px`; }}
                />

                <div className="flex items-center gap-0.5 md:gap-1 shrink-0 pb-0.5 pr-0.5 md:pb-1 md:pr-1">
                  {isPlayingTTS && (
                    <button
                      type="button"
                      data-testid="button-stop-tts"
                      onClick={stopTTS}
                      title="Stop speaking"
                      aria-label="Stop speaking"
                      className="p-2 md:p-2.5 rounded-full bg-teal-500/20 text-teal-200 hover:bg-teal-500/30 border border-teal-400/40 transition-colors"
                    >
                      <VolumeX className="w-4 h-4 md:w-5 md:h-5" />
                    </button>
                  )}
                  {isSending ? (
                    <button
                      data-testid="button-stop-generation"
                      onClick={stopGeneration}
                      title="Stop and edit your message"
                      className="p-2 md:p-2.5 rounded-full bg-red-500/20 text-red-300 hover:bg-red-500/30 border border-red-400/40 transition-colors animate-pulse"
                    >
                      <Square size={16} fill="currentColor" />
                    </button>
                  ) : (
                    <button
                      data-testid="button-send-message"
                      onClick={handleSubmit}
                      disabled={!input.trim() && !attachedImage && !attachedFile}
                      className={`p-2 md:p-2.5 rounded-full transition-all disabled:opacity-40 ${isBuildMode ? "bg-violet-400 text-black hover:bg-violet-300 shadow-[0_0_20px_rgba(167,139,250,0.4)]" : "bg-white text-black hover:bg-white/90 shadow-[0_0_20px_rgba(255,255,255,0.2)]"} ml-0.5 md:ml-1`}
                    >
                      {isBuildMode ? <Code className="w-4 h-4 md:w-5 md:h-5" /> : <ArrowUp className="w-4 h-4 md:w-5 md:h-5" />}
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      <AvatarSettingsModal isOpen={showAvatarModal} onClose={() => setShowAvatarModal(false)} currentAvatarUrl={avatarUrl} currentBodyModelUrl={bodyModelUrl} onSave={(url) => setAvatarUrl(url || null)} onSaveBodyModel={async (url) => {
        const next = url || null;
        setBodyModelUrl(next);
        try {
          await fetch("/api/vance/profile", {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            credentials: "include",
            body: JSON.stringify({ bodyModelUrl: url }),
          });
        } catch {
          /* swallow — UI already reflects the change; user can retry */
        }
      }} />

      {/* Regular Build (orange) password gate. Shown whenever the user is in
          orange build mode — either via the toggle button (`isBuildMode`) or
          by viewing/creating an orange-tagged chat (`currentChatMode==="build"`)
          — and hasn't unlocked yet for this session. Blue (website) and
          purple (chat) modes never see this. */}
      {(isBuildMode || currentChatMode === "build") && !buildUnlocked && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Enter password to access Regular Build Mode"
          className="fixed inset-0 z-[80] flex items-center justify-center bg-black/85 backdrop-blur-md p-4"
        >
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (buildPasswordInput === buildPassword) {
                unlockBuild();
                setBuildPasswordInput("");
                setBuildPasswordError(null);
              } else {
                setBuildPasswordError("Incorrect password. Try again.");
              }
            }}
            className="w-full max-w-sm rounded-2xl border border-orange-400/30 bg-[#0a0a16]/95 p-6 shadow-2xl backdrop-blur-2xl"
          >
            <div className="flex items-center gap-2 mb-4">
              <span className="text-2xl">🟠</span>
              <h2 className="text-lg font-semibold text-white">Regular Build Mode</h2>
            </div>
            <p className="text-sm text-white/70 mb-4">Enter password to access Regular Build Mode</p>
            <input
              type="password"
              autoFocus
              value={buildPasswordInput}
              onChange={(e) => { setBuildPasswordInput(e.target.value); if (buildPasswordError) setBuildPasswordError(null); }}
              placeholder="Password"
              className="w-full rounded-xl border border-white/15 bg-white/5 px-4 py-3 text-white placeholder-white/40 outline-none focus:border-orange-400/60 focus:bg-white/10"
              data-testid="input-build-password"
            />
            {buildPasswordError && (
              <p className="mt-2 text-xs text-red-300" data-testid="text-build-password-error">{buildPasswordError}</p>
            )}
            <div className="mt-5 flex gap-2">
              <button
                type="button"
                onClick={() => {
                  // Bail out of build mode entirely — back to whatever the
                  // chat's underlying mode is, or chat if none.
                  setIsBuildMode(false);
                  if (currentChatMode === "build" && conversationId != null) {
                    setChatModeForConv(conversationId, "chat");
                  }
                  setBuildPasswordInput("");
                  setBuildPasswordError(null);
                }}
                className="flex-1 rounded-xl border border-white/15 bg-white/5 px-4 py-2.5 text-sm text-white/80 hover:bg-white/10 transition-colors"
                data-testid="button-build-password-cancel"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 rounded-xl border border-orange-400/40 bg-orange-500/20 px-4 py-2.5 text-sm font-semibold text-orange-100 hover:bg-orange-500/30 transition-colors"
                data-testid="button-build-password-unlock"
              >
                Unlock
              </button>
            </div>
          </form>
        </div>
      )}

      {lightbox && (
        <div
          data-testid="screenshot-lightbox"
          role="dialog"
          aria-modal="true"
          aria-label={lightbox.label}
          className="fixed inset-0 z-[60] flex flex-col items-center justify-center bg-black/85 backdrop-blur-sm p-3 sm:p-6"
          onClick={() => setLightbox(null)}
        >
          <button
            type="button"
            onClick={() => setLightbox(null)}
            aria-label="Close screenshot preview"
            className="absolute top-3 right-3 p-2 rounded-full bg-white/10 text-white border border-white/15 hover:bg-white/20 transition-colors"
          >
            <X size={18} />
          </button>
          <img
            src={lightbox.url}
            alt={lightbox.label}
            onClick={(e) => e.stopPropagation()}
            className="max-h-[85vh] max-w-full rounded-lg border border-white/15 shadow-2xl object-contain"
          />
          <div className="mt-3 text-xs text-white/80 max-w-[90vw] text-center">{lightbox.label}</div>
        </div>
      )}
    </div>
  );
}
