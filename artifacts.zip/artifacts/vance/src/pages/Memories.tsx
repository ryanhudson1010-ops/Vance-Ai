import { useState } from "react";
import { Trash2, Brain, Globe, MessageCircle, User, Search, Pin, PinOff, Heart, Sparkles, BookOpen } from "lucide-react";
import {
  useListVanceMemories,
  useDeleteVanceMemory,
  useUpdateVanceMemory,
  getListVanceMemoriesQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

const categoryIcons: Record<string, React.ReactNode> = {
  user_fact: <User size={14} />,
  preference: <Heart size={14} />,
  self_knowledge: <Sparkles size={14} />,
  world_knowledge: <Globe size={14} />,
  research: <BookOpen size={14} />,
  conversation: <MessageCircle size={14} />,
  interest: <Brain size={14} />,
  general: <Brain size={14} />,
};

const categoryLabels: Record<string, string> = {
  user_fact: "About You",
  preference: "Preferences",
  self_knowledge: "About Vance",
  world_knowledge: "World Knowledge",
  research: "Research",
  conversation: "From Conversations",
  interest: "Interests",
  general: "General",
};

// One coloured tint per category. Hex pairs: hex (text/dot) + rgba border + rgba bg.
// Gives each pill its own personality without leaving the cohesive purple/blue palette.
const categoryTint: Record<string, { hex: string; border: string; bg: string }> = {
  user_fact:       { hex: "#A78BFA", border: "rgba(167,139,250,0.40)", bg: "rgba(167,139,250,0.12)" },
  preference:      { hex: "#F472B6", border: "rgba(244,114,182,0.40)", bg: "rgba(244,114,182,0.12)" },
  self_knowledge:  { hex: "#22D3EE", border: "rgba(34,211,238,0.40)",  bg: "rgba(34,211,238,0.12)"  },
  world_knowledge: { hex: "#60A5FA", border: "rgba(96,165,250,0.40)",  bg: "rgba(96,165,250,0.12)"  },
  research:        { hex: "#34D399", border: "rgba(52,211,153,0.40)",  bg: "rgba(52,211,153,0.12)"  },
  conversation:    { hex: "#9B59B6", border: "rgba(155,89,182,0.40)",  bg: "rgba(155,89,182,0.12)"  },
  interest:        { hex: "#FBBF24", border: "rgba(251,191,36,0.40)",  bg: "rgba(251,191,36,0.12)"  },
  general:         { hex: "#94A3B8", border: "rgba(148,163,184,0.40)", bg: "rgba(148,163,184,0.12)" },
};
const PINNED_TINT = { hex: "#F5B34A", border: "rgba(245,179,74,0.50)", bg: "rgba(245,179,74,0.14)" };

export default function Memories() {
  const queryClient = useQueryClient();
  const { data: memories, isLoading } = useListVanceMemories();
  const deleteMemory = useDeleteVanceMemory();
  const updateMemory = useUpdateVanceMemory();
  const [filter, setFilter] = useState<string>("all");
  const [search, setSearch] = useState("");

  const categories = ["all", "pinned", ...Array.from(new Set(memories?.map((m) => m.category) ?? []))];

  // Pinned memories float to the top, then everything sorts by recency.
  const sorted = memories
    ?.slice()
    .sort((a, b) => {
      if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });

  const filtered = sorted?.filter((m) => {
    const matchesCategory =
      filter === "all" ||
      (filter === "pinned" ? m.pinned : m.category === filter);
    const matchesSearch =
      !search || m.content.toLowerCase().includes(search.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleDelete = async (id: number) => {
    await deleteMemory.mutateAsync({ id });
    queryClient.invalidateQueries({ queryKey: getListVanceMemoriesQueryKey() });
  };

  const handleTogglePin = async (id: number, currentlyPinned: boolean) => {
    await updateMemory.mutateAsync({ id, data: { pinned: !currentlyPinned } });
    queryClient.invalidateQueries({ queryKey: getListVanceMemoriesQueryKey() });
  };

  const totalCount = memories?.length ?? 0;
  const pinnedCount = memories?.filter((m) => m.pinned).length ?? 0;

  return (
    <div className="relative min-h-full">
      {/* Aurora accent blobs — same vocabulary as the Chat page */}
      <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -left-24 -top-24 h-72 w-72 rounded-full bg-violet-500/15 blur-3xl" />
        <div className="absolute right-[-6rem] top-32 h-72 w-72 rounded-full bg-cyan-500/10 blur-3xl" />
        <div className="absolute left-1/3 bottom-[-4rem] h-64 w-64 rounded-full bg-fuchsia-500/10 blur-3xl" />
      </div>

      <div className="relative max-w-3xl mx-auto px-4 py-8 md:py-10">
        {/* Header card */}
        <div className="mb-6 rounded-3xl border border-white/8 bg-white/[0.04] backdrop-blur-2xl px-5 py-5 md:px-7 md:py-6 shadow-[0_18px_60px_rgba(0,0,0,0.32)]">
          <div className="flex items-start gap-4">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-violet-500/30 to-cyan-500/20 border border-white/15 flex items-center justify-center shrink-0">
              <Brain size={20} className="text-white/90" />
            </div>
            <div className="flex-1 min-w-0">
              <h1 className="font-serif text-2xl md:text-3xl text-foreground leading-tight">What Vance Remembers</h1>
              <p className="text-muted-foreground text-[13px] md:text-sm mt-1">
                Everything Vance has stored — about you, about the world, from your conversations.
              </p>
            </div>
          </div>
          <div className="mt-4 flex items-center gap-3 text-[11px] uppercase tracking-[0.16em] text-white/50">
            <span><span className="text-white/80 font-semibold">{totalCount}</span> total</span>
            <span className="w-1 h-1 rounded-full bg-white/30" />
            <span className="inline-flex items-center gap-1 text-amber-300/90"><Pin size={10} /> {pinnedCount} pinned</span>
          </div>
        </div>

        {/* Search */}
        <div className="flex items-center gap-2 rounded-2xl border border-white/10 bg-white/[0.05] backdrop-blur-xl px-4 py-3 mb-3 shadow-[inset_0_1px_0_rgba(255,255,255,0.04)] focus-within:border-violet-400/40 focus-within:bg-white/[0.07] transition-colors">
          <Search size={16} className="text-muted-foreground" />
          <input
            data-testid="input-search-memories"
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search memories…"
            className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground outline-none"
          />
          {search && (
            <button onClick={() => setSearch("")} className="text-[11px] text-muted-foreground hover:text-white px-2 py-0.5 rounded-md hover:bg-white/10 transition-colors">Clear</button>
          )}
        </div>

        {/* Category filter */}
        <div className="flex gap-2 flex-wrap mb-6">
          {categories.map((cat) => {
            const tint = cat === "pinned" ? PINNED_TINT : (categoryTint[cat] ?? null);
            const active = filter === cat;
            return (
              <button
                key={cat}
                data-testid={`button-filter-${cat}`}
                onClick={() => setFilter(cat)}
                className="px-3 py-1.5 rounded-full text-[11.5px] font-medium tracking-wide transition-all border"
                style={
                  active && tint
                    ? { color: tint.hex, backgroundColor: tint.bg, borderColor: tint.border, boxShadow: `0 0 14px ${tint.border}` }
                    : active
                    ? { color: "#fff", backgroundColor: "rgba(255,255,255,0.12)", borderColor: "rgba(255,255,255,0.25)" }
                    : { color: "rgba(255,255,255,0.62)", backgroundColor: "rgba(255,255,255,0.035)", borderColor: "rgba(255,255,255,0.08)" }
                }
              >
                {cat === "all" ? "All" : cat === "pinned" ? "📌 Pinned" : categoryLabels[cat] ?? cat}
              </button>
            );
          })}
        </div>

        {/* Memory list */}
        {isLoading && (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-20 rounded-2xl border border-white/8 bg-white/[0.03] animate-pulse" />
            ))}
          </div>
        )}

        {!isLoading && filtered?.length === 0 && (
          <div className="flex flex-col items-center py-20 text-center">
            <div className="w-14 h-14 rounded-2xl bg-white/[0.04] border border-white/10 flex items-center justify-center mb-4">
              <Brain size={22} className="text-muted-foreground" />
            </div>
            <p className="text-muted-foreground text-sm">
              {search || filter !== "all"
                ? "Nothing matches your search"
                : "Vance hasn't stored any memories yet. Start a conversation."}
            </p>
          </div>
        )}

        <div className="space-y-2.5">
          {filtered?.map((memory) => {
            const tint = memory.pinned ? PINNED_TINT : (categoryTint[memory.category] ?? categoryTint.general);
            return (
              <div
                key={memory.id}
                data-testid={`memory-${memory.id}`}
                className="group flex items-start gap-3 rounded-2xl border border-white/8 bg-white/[0.035] backdrop-blur-xl px-4 py-3.5 transition-all hover:bg-white/[0.06] hover:border-white/15 hover:-translate-y-[1px] shadow-[0_10px_30px_rgba(0,0,0,0.18)]"
                style={memory.pinned ? { borderColor: tint.border, backgroundImage: `linear-gradient(180deg, ${tint.bg}, transparent 70%)` } : undefined}
              >
                <div
                  className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5 border"
                  style={{ color: tint.hex, backgroundColor: tint.bg, borderColor: tint.border }}
                >
                  {categoryIcons[memory.category] ?? <Brain size={14} />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[14px] text-foreground leading-relaxed">{memory.content}</p>
                  <div className="flex items-center gap-2 mt-2 flex-wrap">
                    <span
                      className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10.5px] font-medium tracking-wide border"
                      style={{ color: tint.hex, backgroundColor: tint.bg, borderColor: tint.border }}
                    >
                      {categoryLabels[memory.category] ?? memory.category}
                    </span>
                    <span className="text-[11px] text-muted-foreground">
                      {new Date(memory.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                    </span>
                    {memory.pinned && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10.5px] font-medium border" style={{ color: PINNED_TINT.hex, backgroundColor: PINNED_TINT.bg, borderColor: PINNED_TINT.border }}>
                        <Pin size={10} /> Always remembered
                      </span>
                    )}
                  </div>
                </div>
                <button
                  data-testid={`button-pin-memory-${memory.id}`}
                  onClick={() => handleTogglePin(memory.id, memory.pinned)}
                  title={memory.pinned ? "Unpin (let it age out naturally)" : "Pin (Vance always remembers this)"}
                  className={`p-1.5 rounded-lg transition-all flex-shrink-0 mt-0.5 ${
                    memory.pinned
                      ? "text-amber-300 opacity-100 hover:bg-amber-300/10"
                      : "text-muted-foreground hover:text-violet-300 hover:bg-violet-300/10 opacity-0 group-hover:opacity-100"
                  }`}
                >
                  {memory.pinned ? <PinOff size={13} /> : <Pin size={13} />}
                </button>
                <button
                  data-testid={`button-delete-memory-${memory.id}`}
                  onClick={() => handleDelete(memory.id)}
                  className="opacity-0 group-hover:opacity-100 p-1.5 rounded-lg hover:bg-destructive/15 text-muted-foreground hover:text-destructive transition-all flex-shrink-0 mt-0.5"
                >
                  <Trash2 size={13} />
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
