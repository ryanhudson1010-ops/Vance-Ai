import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ChevronRight, RefreshCw, TrendingUp, TrendingDown, Activity } from "lucide-react";

const COIN_IDS = ["ripple", "bitcoin", "ethereum"] as const;
const PRICE_URL = `https://api.coingecko.com/api/v3/simple/price?ids=${COIN_IDS.join(",")}&vs_currencies=usd&include_24hr_change=true`;
const CHART_DAYS = 7;

type CoinId = (typeof COIN_IDS)[number];

type AssetMeta = {
  id: CoinId;
  symbol: string;
  name: string;
  // Per-coin gradient + glow tint. Hex pairs feed inline styles so we get
  // smooth radial accents that no Tailwind utility can express.
  hex: string;
  glow: string;
};

type AssetQuote = {
  price: number;
  change24h: number;
  points: number[];
  chartEstimated?: boolean;
};

type AssetMap = Record<CoinId, AssetQuote>;

type PricePayload = Partial<Record<CoinId, { usd?: number; usd_24h_change?: number }>>;
type MarketChartPayload = { prices?: Array<[number, number]> };

const ASSETS: AssetMeta[] = [
  { id: "ripple",   symbol: "XRP", name: "Ripple",   hex: "#22D3EE", glow: "rgba(34,211,238,0.30)" },
  { id: "bitcoin",  symbol: "BTC", name: "Bitcoin",  hex: "#FBBF24", glow: "rgba(251,191,36,0.30)" },
  { id: "ethereum", symbol: "ETH", name: "Ethereum", hex: "#A78BFA", glow: "rgba(167,139,250,0.30)" },
];

function formatPrice(value: number, symbol: string) {
  const maximumFractionDigits = symbol === "XRP" ? 4 : 2;
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: maximumFractionDigits,
    maximumFractionDigits,
  }).format(value);
}

function formatChange(value: number) {
  const prefix = value > 0 ? "+" : "";
  return `${prefix}${value.toFixed(2)}%`;
}

function buildChartPath(points: number[]) {
  if (!points.length) return "";
  if (points.length === 1) return "M0,50 L100,50";

  const min = Math.min(...points);
  const max = Math.max(...points);
  const range = max - min || 1;

  return points
    .map((point, index) => {
      const x = (index / (points.length - 1)) * 100;
      const y = 50 - ((point - min) / range) * 40;
      return `${index === 0 ? "M" : "L"}${x.toFixed(2)},${y.toFixed(2)}`;
    })
    .join(" ");
}

function buildAreaPath(points: number[]) {
  const line = buildChartPath(points);
  if (!line) return "";
  return `${line} L100,50 L0,50 Z`;
}

function buildFallbackPoints(price: number, change24h: number) {
  const changeRatio = change24h / 100;
  const previousPrice = changeRatio <= -0.99 ? price : price / (1 + changeRatio);
  const points = Array.from({ length: CHART_DAYS }, (_, index) => {
    const progress = index / (CHART_DAYS - 1);
    const easedProgress = 1 - (1 - progress) * (1 - progress);
    const wave = Math.sin(progress * Math.PI * 2) * price * 0.01;
    return previousPrice + (price - previousPrice) * easedProgress + wave;
  });

  return points.map((point) => (Number.isFinite(point) ? point : price));
}

function AssetCard({ asset, quote }: { asset: AssetMeta; quote: AssetQuote }) {
  const positive = quote.change24h >= 0;
  const lineColor = positive ? "#34D399" : "#F87171";
  const areaColor = positive ? "rgba(52,211,153,0.18)" : "rgba(248,113,113,0.18)";
  const chartPath = buildChartPath(quote.points);
  const areaPath = buildAreaPath(quote.points);
  const TrendIcon = positive ? TrendingUp : TrendingDown;
  const gradientId = `area-${asset.id}`;

  return (
    <div
      className="relative overflow-hidden rounded-3xl border border-white/8 bg-white/[0.04] backdrop-blur-2xl p-5 md:p-6 shadow-[0_22px_60px_rgba(0,0,0,0.32)] transition-transform hover:-translate-y-[2px]"
      style={{
        backgroundImage: `radial-gradient(circle at 0% 0%, ${asset.glow}, transparent 55%), linear-gradient(180deg, rgba(255,255,255,0.04), rgba(255,255,255,0.015))`,
      }}
    >
      {/* Coin chip */}
      <div className="mb-4 flex items-start justify-between gap-4">
        <div className="flex items-center gap-3">
          <div
            className="w-11 h-11 rounded-2xl flex items-center justify-center text-base font-bold border"
            style={{ color: asset.hex, backgroundColor: `${asset.glow}`, borderColor: `${asset.hex}55`, boxShadow: `0 0 18px ${asset.glow}` }}
          >
            {asset.symbol.slice(0, 1)}
          </div>
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-[0.22em]" style={{ color: asset.hex }}>{asset.symbol}</p>
            <h2 className="font-serif text-xl text-foreground leading-tight">{asset.name}</h2>
          </div>
        </div>
        <span
          className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-semibold border ${positive ? "text-emerald-300" : "text-red-300"}`}
          style={{ borderColor: positive ? "rgba(52,211,153,0.35)" : "rgba(248,113,113,0.35)", backgroundColor: positive ? "rgba(52,211,153,0.10)" : "rgba(248,113,113,0.10)" }}
        >
          <TrendIcon size={12} />
          {formatChange(quote.change24h)}
        </span>
      </div>

      <p
        data-testid={asset.symbol === "XRP" ? "text-xrp-price" : `text-${asset.symbol.toLowerCase()}-price`}
        className="font-serif text-[2.6rem] md:text-[2.9rem] leading-none tracking-tight text-foreground"
      >
        {formatPrice(quote.price, asset.symbol)}
      </p>
      <p
        data-testid={asset.symbol === "XRP" ? "text-xrp-change" : `text-${asset.symbol.toLowerCase()}-change`}
        className={`mt-2 text-[12px] ${positive ? "text-emerald-300/90" : "text-red-300/90"}`}
      >
        {formatChange(quote.change24h)} past 24 hours
      </p>

      <div className="mt-5 rounded-2xl border border-white/8 bg-black/25 p-3">
        <div className="mb-2 flex items-center justify-between text-[10px] font-medium uppercase tracking-[0.18em] text-white/45">
          <span className="inline-flex items-center gap-1.5"><Activity size={10} /> 7 day trend</span>
          <span>{quote.chartEstimated ? "Estimated" : "Live"}</span>
        </div>
        <svg viewBox="0 0 100 50" className="h-24 w-full overflow-visible" aria-label={`${asset.name} price chart`} preserveAspectRatio="none">
          <defs>
            <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={areaColor} />
              <stop offset="100%" stopColor="transparent" />
            </linearGradient>
          </defs>
          <path d="M0,49 L100,49" stroke="rgba(255,255,255,0.08)" strokeWidth="0.5" fill="none" />
          {areaPath && <path d={areaPath} fill={`url(#${gradientId})`} />}
          <path d={chartPath} stroke={lineColor} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" fill="none" />
        </svg>
      </div>
    </div>
  );
}

export default function Xrp() {
  const [quotes, setQuotes] = useState<AssetMap | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [refreshWarning, setRefreshWarning] = useState<string | null>(null);
  const [chartFallbackNotice, setChartFallbackNotice] = useState<string | null>(null);
  const [lastUpdatedAt, setLastUpdatedAt] = useState<number | null>(null);
  const [refreshMessage, setRefreshMessage] = useState<string | null>(null);
  const [refreshCooldownUntil, setRefreshCooldownUntil] = useState(0);
  const refreshMessageTimeoutRef = useRef<number | null>(null);
  const refreshCooldownTimeoutRef = useRef<number | null>(null);
  const refreshInFlightRef = useRef(false);
  const refreshCooldownUntilRef = useRef(0);
  const hasUsableDataRef = useRef(false);
  const assetSectionRefs = useRef<Record<CoinId, HTMLDivElement | null>>({
    ripple: null,
    bitcoin: null,
    ethereum: null,
  });

  const scrollToAsset = useCallback((assetId: CoinId) => {
    assetSectionRefs.current[assetId]?.scrollIntoView({ behavior: "smooth", block: "start" });
  }, []);

  const fetchQuotes = useCallback(async (mode: "initial" | "refresh" = "initial") => {
    if (refreshInFlightRef.current) return;

    const hasUsableData = hasUsableDataRef.current;
    refreshInFlightRef.current = true;

    if (mode === "initial") {
      setIsLoading(true);
      if (!hasUsableData) setError(null);
    } else {
      setIsRefreshing(true);
      setRefreshWarning(null);
      setRefreshMessage("Refreshing prices…");
    }

    try {
      if (mode === "initial") setRefreshWarning(null);
      if (!hasUsableData) setChartFallbackNotice(null);

      const priceResponse = await fetch(PRICE_URL, { cache: "no-store" });
      if (!priceResponse.ok) throw new Error(`Price request failed with status ${priceResponse.status}`);

      const priceData = (await priceResponse.json()) as PricePayload;
      const chartResponses = await Promise.all(
        COIN_IDS.map(async (coinId) => {
          try {
            const response = await fetch(
              `https://api.coingecko.com/api/v3/coins/${coinId}/market_chart?vs_currency=usd&days=${CHART_DAYS}&interval=daily`,
              { cache: "no-store" },
            );
            if (!response.ok) return [coinId, null, response.status] as const;
            const data = (await response.json()) as MarketChartPayload;
            return [coinId, data, null] as const;
          } catch {
            return [coinId, null, null] as const;
          }
        }),
      );

      let usedEstimatedCharts = false;
      let hitRateLimit = false;
      const nextQuotes = COIN_IDS.reduce((accumulator, coinId) => {
        const quote = priceData[coinId];
        const chartEntry = chartResponses.find(([id]) => id === coinId);
        const marketChart = chartEntry?.[1];
        const chartStatus = chartEntry?.[2];
        const price = quote?.usd;
        const change24h = quote?.usd_24h_change;
        const livePoints = marketChart?.prices?.map(([, pointPrice]) => pointPrice).filter((point) => typeof point === "number") ?? [];

        if (typeof price !== "number" || typeof change24h !== "number") {
          throw new Error(`CoinGecko returned an unexpected price payload for ${coinId}.`);
        }

        const points = livePoints.length > 0 ? livePoints : buildFallbackPoints(price, change24h);
        const chartEstimated = livePoints.length === 0;
        if (chartEstimated) usedEstimatedCharts = true;
        if (chartStatus === 429) hitRateLimit = true;

        accumulator[coinId] = { price, change24h, points, chartEstimated };
        return accumulator;
      }, {} as AssetMap);

      if (hitRateLimit) {
        setChartFallbackNotice("CoinGecko is rate-limiting some chart requests right now, so a few trend lines are estimated while live prices remain current.");
      } else if (usedEstimatedCharts) {
        setChartFallbackNotice("Some mini charts are estimated from the latest market move when CoinGecko sparkline data is temporarily unavailable.");
      } else {
        setChartFallbackNotice(null);
      }

      setQuotes(nextQuotes);
      hasUsableDataRef.current = true;
      setError(null);
      setRefreshWarning(null);
      setLastUpdatedAt(Date.now());
      setRefreshMessage(mode === "refresh" ? "Prices updated just now." : null);
    } catch (caughtError) {
      const message = caughtError instanceof Error ? caughtError.message : "Unable to load crypto prices.";
      const detail = message === "Failed to fetch" ? "The connection to CoinGecko was interrupted." : message;
      if (hasUsableData) {
        setRefreshWarning(`Refresh didn’t go through, so you’re still viewing the last successful market snapshot. ${detail}`);
        setRefreshMessage("Refresh missed — keeping the latest saved prices on screen.");
      } else {
        setError(detail);
      }
    } finally {
      refreshInFlightRef.current = false;
      if (mode === "refresh") {
        const cooldownUntil = Date.now() + 1500;
        refreshCooldownUntilRef.current = cooldownUntil;
        setRefreshCooldownUntil(cooldownUntil);
      }
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, []);

  const handleRefresh = useCallback(() => {
    if (refreshInFlightRef.current || isLoading || isRefreshing) return;
    if (Date.now() < refreshCooldownUntilRef.current) {
      setRefreshMessage("Just refreshed — give it a moment before trying again.");
      setRefreshCooldownUntil(refreshCooldownUntilRef.current);
      return;
    }
    void fetchQuotes("refresh");
  }, [fetchQuotes, isLoading, isRefreshing]);

  useEffect(() => { void fetchQuotes(); }, [fetchQuotes]);

  useEffect(() => {
    if (!refreshMessage) {
      if (refreshMessageTimeoutRef.current !== null) {
        window.clearTimeout(refreshMessageTimeoutRef.current);
        refreshMessageTimeoutRef.current = null;
      }
      return;
    }
    refreshMessageTimeoutRef.current = window.setTimeout(() => {
      setRefreshMessage(null);
      refreshMessageTimeoutRef.current = null;
    }, 2600);
    return () => {
      if (refreshMessageTimeoutRef.current !== null) {
        window.clearTimeout(refreshMessageTimeoutRef.current);
        refreshMessageTimeoutRef.current = null;
      }
    };
  }, [refreshMessage]);

  useEffect(() => {
    if (refreshCooldownUntil <= Date.now()) {
      if (refreshCooldownTimeoutRef.current !== null) {
        window.clearTimeout(refreshCooldownTimeoutRef.current);
        refreshCooldownTimeoutRef.current = null;
      }
      return;
    }
    refreshCooldownTimeoutRef.current = window.setTimeout(() => {
      setRefreshCooldownUntil(0);
      refreshCooldownTimeoutRef.current = null;
    }, refreshCooldownUntil - Date.now());
    return () => {
      if (refreshCooldownTimeoutRef.current !== null) {
        window.clearTimeout(refreshCooldownTimeoutRef.current);
        refreshCooldownTimeoutRef.current = null;
      }
    };
  }, [refreshCooldownUntil]);

  useEffect(() => () => {
    if (refreshMessageTimeoutRef.current !== null) window.clearTimeout(refreshMessageTimeoutRef.current);
    if (refreshCooldownTimeoutRef.current !== null) window.clearTimeout(refreshCooldownTimeoutRef.current);
  }, []);

  const leadAsset = useMemo(() => (quotes ? quotes.ripple : null), [quotes]);
  const hasUsableData = quotes !== null && leadAsset !== null;
  const isRefreshCoolingDown = refreshCooldownUntil > Date.now();
  const refreshDisabled = isLoading || isRefreshing || isRefreshCoolingDown;
  const refreshLabel = isLoading ? "Loading…" : isRefreshing ? "Refreshing…" : isRefreshCoolingDown ? "Please wait…" : "Refresh";
  const lastUpdatedLabel = lastUpdatedAt
    ? (() => {
        const updatedAt = new Date(lastUpdatedAt);
        const now = new Date();
        const isSameDay = updatedAt.toDateString() === now.toDateString();
        const timeLabel = updatedAt.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
        return isSameDay
          ? `Last updated today at ${timeLabel}`
          : `Last updated ${updatedAt.toLocaleDateString([], { month: "short", day: "numeric" })} at ${timeLabel}`;
      })()
    : null;
  const refreshStatus = error && !hasUsableData
    ? "Live crypto prices are unavailable right now."
    : isLoading
      ? "Loading the latest market snapshot…"
      : isRefreshing
        ? "Refreshing XRP, BTC, and ETH…"
        : refreshWarning
          ? `Latest refresh missed — prices remain from ${lastUpdatedLabel?.replace(/^Last updated /, "") ?? "the last successful update"}.`
          : isRefreshCoolingDown
            ? "Just refreshed — you can check again in a moment."
            : refreshMessage ?? (hasUsableData ? "Live prices are up to date." : "Ready to refresh.");

  return (
    <div className="relative min-h-full">
      {/* Aurora accent blobs */}
      <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -left-24 -top-20 h-72 w-72 rounded-full bg-cyan-500/12 blur-3xl" />
        <div className="absolute right-[-6rem] top-32 h-72 w-72 rounded-full bg-amber-400/10 blur-3xl" />
        <div className="absolute left-1/3 bottom-[-4rem] h-72 w-72 rounded-full bg-violet-500/10 blur-3xl" />
      </div>

      <div className="relative mx-auto max-w-5xl px-4 py-8 pb-10 sm:py-10">
        {/* Header card */}
        <div className="mb-6 rounded-3xl border border-white/8 bg-white/[0.04] backdrop-blur-2xl px-5 py-5 md:px-7 md:py-6 shadow-[0_18px_60px_rgba(0,0,0,0.32)]">
          <div className="flex flex-col gap-5 sm:flex-row sm:items-start sm:justify-between">
            <div className="flex items-start gap-4">
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-cyan-500/30 to-violet-500/20 border border-white/15 flex items-center justify-center shrink-0">
                <Activity size={20} className="text-white/90" />
              </div>
              <div>
                <h1 className="font-serif text-2xl md:text-3xl text-foreground leading-tight">Crypto</h1>
                <p className="text-muted-foreground text-[13px] md:text-sm mt-1 max-w-md">
                  Live XRP, Bitcoin, and Ethereum pricing with 7-day trend charts from CoinGecko.
                </p>
              </div>
            </div>

            <div className="flex flex-col items-start gap-2 sm:items-end">
              <button
                type="button"
                data-testid="button-refresh-xrp"
                onClick={handleRefresh}
                disabled={refreshDisabled}
                aria-busy={isRefreshing}
                aria-label={isRefreshing ? "Refreshing crypto prices" : isRefreshCoolingDown ? "Refresh temporarily unavailable" : "Refresh crypto prices"}
                className="inline-flex min-h-10 touch-manipulation items-center gap-2 rounded-xl border border-white/10 bg-white/[0.05] px-4 py-2 text-xs font-medium text-white/85 shadow-[inset_0_1px_0_rgba(255,255,255,0.06)] transition-colors hover:border-cyan-400/40 hover:bg-cyan-400/10 hover:text-white disabled:cursor-not-allowed disabled:opacity-50 disabled:hover:border-white/10 disabled:hover:bg-white/[0.05]"
              >
                <RefreshCw size={14} className={isRefreshing ? "animate-spin" : ""} />
                {refreshLabel}
              </button>
              <div className="space-y-0.5 text-right" aria-live="polite" aria-atomic="true">
                <p className="text-[11px] text-muted-foreground">{refreshStatus}</p>
                {lastUpdatedLabel ? (
                  <p className="text-[10px] uppercase tracking-[0.18em] text-cyan-300/70">{lastUpdatedLabel}</p>
                ) : null}
              </div>
            </div>
          </div>

          {/* Jump-to chips */}
          <div className="mt-5 flex flex-wrap items-center gap-2">
            <span className="text-[10px] font-semibold uppercase tracking-[0.22em] text-white/40">Jump to</span>
            {ASSETS.map((asset) => (
              <button
                key={asset.id}
                type="button"
                onClick={() => scrollToAsset(asset.id)}
                className="inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-[11px] font-medium tracking-wide transition-all hover:-translate-y-[1px]"
                style={{ color: asset.hex, borderColor: `${asset.hex}55`, backgroundColor: `${asset.glow}` }}
              >
                <span>{asset.symbol}</span>
                <ChevronRight size={11} />
              </button>
            ))}
          </div>
        </div>

        {isLoading ? (
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {Array.from({ length: 3 }).map((_, index) => (
              <div key={index} className="rounded-3xl border border-white/8 bg-white/[0.03] backdrop-blur-xl p-6">
                <div className="space-y-4">
                  <div className="h-5 w-20 animate-pulse rounded-lg bg-white/[0.06]" />
                  <div className="h-12 w-40 animate-pulse rounded-xl bg-white/[0.06]" />
                  <div className="h-4 w-28 animate-pulse rounded-lg bg-white/[0.06]" />
                  <div className="h-28 w-full animate-pulse rounded-xl bg-white/[0.06]" />
                </div>
              </div>
            ))}
          </div>
        ) : error && !hasUsableData ? (
          <div className="rounded-3xl border border-red-400/30 bg-red-500/[0.06] backdrop-blur-xl p-6">
            <div className="space-y-3">
              <p className="font-serif text-2xl text-foreground">Unable to load crypto prices</p>
              <p className="leading-relaxed text-sm text-red-300">{error}</p>
            </div>
          </div>
        ) : quotes && leadAsset ? (
          <div className="space-y-5">
            {/* Lead market view */}
            <div
              className="relative overflow-hidden rounded-3xl border border-white/8 bg-white/[0.04] backdrop-blur-2xl p-6 md:p-7 shadow-[0_22px_60px_rgba(0,0,0,0.32)]"
              style={{ backgroundImage: `radial-gradient(circle at 100% 0%, rgba(34,211,238,0.18), transparent 55%)` }}
            >
              <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-cyan-300/90">Lead market view</p>
                  <h2 className="mt-2 font-serif text-4xl md:text-5xl text-foreground tracking-tight">{formatPrice(leadAsset.price, "XRP")}</h2>
                  <p className="mt-3 max-w-2xl text-sm text-muted-foreground">
                    XRP stays pinned at the top, with Bitcoin and Ethereum live just below for a simple crypto watchlist.
                  </p>
                </div>
                <p className={`inline-flex items-center gap-1.5 self-start text-base font-semibold rounded-full px-3 py-1.5 border ${leadAsset.change24h >= 0 ? "text-emerald-300" : "text-red-300"}`}
                  style={{ borderColor: leadAsset.change24h >= 0 ? "rgba(52,211,153,0.35)" : "rgba(248,113,113,0.35)", backgroundColor: leadAsset.change24h >= 0 ? "rgba(52,211,153,0.10)" : "rgba(248,113,113,0.10)" }}
                >
                  {leadAsset.change24h >= 0 ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                  {formatChange(leadAsset.change24h)} past 24 hours
                </p>
              </div>
            </div>

            {refreshWarning ? (
              <div className="rounded-2xl border border-amber-400/25 bg-amber-400/10 px-4 py-3 text-sm text-amber-100 backdrop-blur-xl">
                <p className="font-medium text-amber-50">Refresh paused</p>
                <p className="mt-1 leading-relaxed text-amber-100/90">{refreshWarning}</p>
              </div>
            ) : null}

            {chartFallbackNotice ? (
              <div className="rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-3 text-sm text-muted-foreground backdrop-blur-xl">
                {chartFallbackNotice}
              </div>
            ) : null}

            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              {ASSETS.map((asset) => (
                <div
                  key={asset.id}
                  id={`asset-${asset.id}`}
                  ref={(node) => { assetSectionRefs.current[asset.id] = node; }}
                  className="scroll-mt-28 sm:scroll-mt-24"
                >
                  <AssetCard asset={asset} quote={quotes[asset.id]} />
                </div>
              ))}
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}
