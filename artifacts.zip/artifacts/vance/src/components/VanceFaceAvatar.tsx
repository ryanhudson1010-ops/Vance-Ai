import { Component, type ReactNode } from "react";
import { motion } from "framer-motion";
import VanceAvatar3D, { type AvatarState, type Persona, type Emote } from "./VanceAvatar3D";

// If the configured body GLB fails to load (e.g. ephemeral upload path got
// wiped on Autoscale redeploy → 404, or the file is corrupt), useGLTF throws
// inside the R3F Suspense boundary and crashes the entire avatar tree, which
// in our case white-screens the chat page. Catch that here and fall back to
// the holographic orb so the app stays usable until the user re-sets their
// avatar in Settings.
class AvatarErrorBoundary extends Component<{ fallback: ReactNode; children: ReactNode }, { hadError: boolean }> {
  state = { hadError: false };
  static getDerivedStateFromError() { return { hadError: true }; }
  componentDidCatch() { /* swallow — fallback handles UX */ }
  render() { return this.state.hadError ? this.props.fallback : this.props.children; }
}

interface Props {
  state: AvatarState;
  persona: Persona;
  avatarUrl: string | null; // ignored — photo avatars removed by user request
  emote: Emote | null;
  bodyModelUrl: string | null;
  // Camera controls are now hoisted into Chat.tsx so they can render as a
  // floating overlay outside the avatar's draggable wrapper. Pass current
  // zoom + rotation values down to the 3D scene.
  zoom?: number;
  rotY?: number;
  // Live audio amplitude (0–1) sampled by Chat.tsx's Web Audio analyser.
  // Drives jaw/mouth movement on the 3D model in sync with TTS playback.
  // Ref-based to avoid per-frame React re-renders.
  audioAmpRef?: { readonly current: number };
}

// Holographic CSS fallback — rendered when no GLB body model is configured.
// Replaces what would otherwise be an empty black canvas. Pulses softly when
// the avatar is "speaking" so the user still gets a clear talking indicator
// without a 3D rig.
function HolographicOrb({ state, persona }: { state: AvatarState; persona: Persona }) {
  const primary = persona?.primary || "#8B5CF6";
  const accent = persona?.accent || "#06B6D4";
  const glow = persona?.glow || "rgba(139,92,246,0.45)";
  const initial = (persona?.name?.[0] ?? "V").toUpperCase();
  const speaking = state === "speaking";
  const thinking = state === "thinking";
  const listening = state === "listening";

  return (
    <div
      className="relative w-full h-full overflow-hidden flex items-center justify-center"
      style={{ background: "transparent" }}
    >
      {/* Outer breathing ring — speaking pulses faster + brighter */}
      <motion.div
        className="absolute rounded-full pointer-events-none"
        style={{ width: "62%", aspectRatio: "1 / 1", border: `2px solid ${primary}`, opacity: 0.35 }}
        animate={{
          scale: speaking ? [1, 1.08, 1] : [1, 1.03, 1],
          opacity: speaking ? [0.45, 0.75, 0.45] : [0.25, 0.45, 0.25],
        }}
        transition={{ duration: speaking ? 0.9 : 3.2, repeat: Infinity, ease: "easeInOut" }}
      />
      {/* Mid ring */}
      <motion.div
        className="absolute rounded-full pointer-events-none"
        style={{ width: "48%", aspectRatio: "1 / 1", border: `1px solid ${accent}`, opacity: 0.5 }}
        animate={{ rotate: 360 }}
        transition={{ duration: thinking ? 6 : 24, repeat: Infinity, ease: "linear" }}
      />
      {/* Core orb */}
      <motion.div
        className="relative rounded-full flex items-center justify-center"
        style={{
          width: "38%",
          aspectRatio: "1 / 1",
          background: `radial-gradient(circle at 30% 30%, ${accent}, ${primary} 55%, #0a0612 100%)`,
          boxShadow: `0 0 80px 6px ${glow}, inset 0 0 40px ${glow}`,
        }}
        animate={{
          y: [0, -6, 0],
          boxShadow: speaking
            ? [`0 0 80px 6px ${glow}`, `0 0 130px 14px ${glow}`, `0 0 80px 6px ${glow}`]
            : `0 0 80px 6px ${glow}`,
        }}
        transition={{
          y: { duration: 4, repeat: Infinity, ease: "easeInOut" },
          boxShadow: speaking
            ? { duration: 0.7, repeat: Infinity, ease: "easeInOut" }
            : { duration: 0.4 },
        }}
      >
        <span
          className="text-white/90 font-light select-none"
          style={{ fontSize: "clamp(2rem, 8vw, 4.5rem)", textShadow: `0 0 20px ${glow}` }}
        >
          {initial}
        </span>
      </motion.div>
      {/* Listening shimmer — small dots orbiting */}
      {listening && (
        <motion.div
          className="absolute rounded-full pointer-events-none"
          style={{ width: "70%", aspectRatio: "1 / 1" }}
          animate={{ rotate: 360 }}
          transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
        >
          {[0, 120, 240].map((deg) => (
            <span
              key={deg}
              className="absolute w-2 h-2 rounded-full"
              style={{
                left: "50%",
                top: 0,
                background: accent,
                boxShadow: `0 0 12px ${accent}`,
                transform: `translate(-50%,0) rotate(${deg}deg) translateY(0)`,
                transformOrigin: `0 50%`,
              }}
            />
          ))}
        </motion.div>
      )}
      {/* Vignette intentionally removed for frameless look. */}
    </div>
  );
}

export default function VanceFaceAvatar({ state, persona, emote, bodyModelUrl, zoom = 1, rotY = 0, audioAmpRef }: Props) {
  const hasBody = !!(bodyModelUrl && bodyModelUrl.trim());
  if (!hasBody) {
    return <HolographicOrb state={state} persona={persona} />;
  }
  return (
    <AvatarErrorBoundary fallback={<HolographicOrb state={state} persona={persona} />}>
      <VanceAvatar3D state={state} persona={persona} emote={emote} bodyModelUrl={bodyModelUrl} zoom={zoom} rotY={rotY} audioAmpRef={audioAmpRef} />
    </AvatarErrorBoundary>
  );
}
