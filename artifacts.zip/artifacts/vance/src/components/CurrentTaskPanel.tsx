import { useEffect, useState, type ReactNode } from "react";
import { Globe, Code2, MessageSquare, X, Activity } from "lucide-react";

const BUILD_RESULTS_KEY = "vance-build-results-v1";

const COLORS = {
  website: "#4A90E2",
  build:   "#FF9500",
  chat:    "#9B59B6",
  idle:    "#9CA3AF",
} as const;

interface SavedBuildResult {
  filesChanged?: string[];
  screenshots?: Array<{ url: string; label: string; ts: number }>;
  errorMessage?: string;
}

export interface BuildEntry {
  convId:       number;
  title:        string;
  filesChanged: string[];
  isWebsite:    boolean;
  failed:       boolean;
}

interface Conv {
  id:    number;
  title: string;
}

interface Props {
  conversations:  Conv[] | undefined;
  currentConvId:  number | null;
  isSending:      boolean;
  isBuildMode:    boolean;
  isResearching:  boolean;
  onSelectConv:   (id: number) => void;
  chatMode?:      "website" | "build" | "chat";
}

const MODE_LABEL = {
  website: "Website Build",
  build:   "Code Build",
  chat:    "Conversation",
} as const;

const MODE_ICON_COLOR = {
  website: COLORS.website,
  build:   COLORS.build,
  chat:    COLORS.chat,
} as const;

const FRONTEND_FILE_RE = /artifacts\/vance\/|\.tsx?$|\.css$|\.html?$/i;

export function loadBuilds(): BuildEntry[] {
  try {
    const raw = JSON.parse(localStorage.getItem(BUILD_RESULTS_KEY) ?? "{}") as Record<string, SavedBuildResult>;
    return Object.entries(raw).map(([key, val]) => {
      const [convIdStr, sig = ""] = key.split("::");
      const filesChanged = val.filesChanged ?? [];
      return {
        convId:       Number(convIdStr) || 0,
        title:        sig.trim() || "Build",
        filesChanged,
        isWebsite:    filesChanged.length > 0 && filesChanged.every(f => FRONTEND_FILE_RE.test(f)),
        failed:       Boolean(val.errorMessage),
      };
    }).filter(b => b.convId > 0);
  } catch {
    return [];
  }
}

// Categorize a message/title into one of three buckets.
// WEBSITE wins over BUILD when both keyword sets match (e.g. "build new homepage"
// → website), because the website intent is more specific.
export function categorizeText(text: string): "build" | "website" | "chat" {
  const s = (text || "").toLowerCase();
  const websiteHit = /\b(website|web app|webapp|web-app|page|pages|ui|frontend|front-end|homepage|landing\s*page|landing|html|css|tailwind|layout|theme|navbar|sidebar|hero|footer|header)\b/.test(s);
  const buildHit   = /\b(build|add|recode|implement|fix|fixes|fixing|feature|bug|refactor|edit|change|update|create|make|tweak|improve|integrate|wire|hook|debug)\b/.test(s);
  if (websiteHit) return "website";
  if (buildHit)   return "build";
  return "chat";
}

const categorizeConvTitle = categorizeText;

export function CurrentTaskPanel({ conversations, currentConvId, isSending, isBuildMode, isResearching, onSelectConv, chatMode }: Props) {
  const [open,   setOpen]   = useState(false);
  const [builds, setBuilds] = useState<BuildEntry[]>([]);

  useEffect(() => {
    if (!open) return;
    setBuilds(loadBuilds());
  }, [open]);

  const status =
    isSending && isBuildMode ? { label: "Building…",   color: COLORS.build }
    : isResearching          ? { label: "Researching…", color: COLORS.website }
    : isSending              ? { label: "Thinking…",    color: COLORS.chat }
    : isBuildMode            ? { label: "Build mode",   color: COLORS.build }
    :                          { label: "Idle",         color: COLORS.idle };

  const websiteBuilds = builds.filter(b => b.isWebsite).slice(0, 8);
  const codeBuilds    = builds.filter(b => !b.isWebsite).slice(0, 8);

  // Categorize conversations by title keywords
  const websiteConvs: Conv[] = [];
  const buildConvs:   Conv[] = [];
  const chatConvs:    Conv[] = [];
  for (const c of conversations ?? []) {
    const cat = categorizeConvTitle(c.title);
    if      (cat === "website") websiteConvs.push(c);
    else if (cat === "build")   buildConvs.push(c);
    else                        chatConvs.push(c);
  }

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 hover:border-white/20 text-xs font-medium text-white/80 transition-all"
        title="Current task & history"
        data-testid="button-current-task"
        style={chatMode ? { borderColor: `${MODE_ICON_COLOR[chatMode]}55` } : undefined}
      >
        <span className="relative flex w-2 h-2">
          {(isSending || isResearching) && (
            <span
              className="absolute inline-flex w-full h-full rounded-full opacity-60 animate-ping"
              style={{ background: status.color }}
            />
          )}
          <span className="relative inline-flex w-2 h-2 rounded-full" style={{ background: status.color }} />
        </span>
        <span className="truncate max-w-[100px]">{status.label}</span>
        {chatMode && (
          <span
            className="ml-1 px-1.5 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wide"
            style={{ background: `${MODE_ICON_COLOR[chatMode]}33`, color: MODE_ICON_COLOR[chatMode] }}
          >
            {chatMode === "website" ? "Web" : chatMode === "build" ? "Code" : "Chat"}
          </span>
        )}
      </button>

      {open && (
        <>
          <div
            className="fixed inset-0 z-[60] bg-black/50 backdrop-blur-sm"
            onClick={() => setOpen(false)}
          />
          <div className="fixed left-2 right-2 top-16 sm:left-4 sm:right-auto sm:w-[440px] z-[61] rounded-2xl border border-white/10 bg-[#0a0a16]/95 backdrop-blur-2xl shadow-2xl overflow-hidden max-h-[82vh] flex flex-col">
            {/* Header */}
            <div className="flex items-center justify-between px-4 py-3 border-b border-white/10">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-white/60" />
                <div>
                  <div className="text-sm font-semibold text-white leading-tight">Current Task</div>
                  <div className="text-[10px] text-white/40">Live status & categorised history</div>
                </div>
              </div>
              <button
                onClick={() => setOpen(false)}
                className="p-1.5 rounded-lg hover:bg-white/10 text-white/60 hover:text-white transition-colors"
                aria-label="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Active task */}
            <div className="px-4 py-3 border-b border-white/5 bg-white/[0.02]">
              <div className="text-[10px] uppercase tracking-wider text-white/40 mb-1.5 font-semibold">Active</div>
              <div className="flex items-center gap-2.5">
                <span className="relative flex w-2.5 h-2.5">
                  {(isSending || isResearching) && (
                    <span
                      className="absolute inline-flex w-full h-full rounded-full opacity-50 animate-ping"
                      style={{ background: status.color }}
                    />
                  )}
                  <span className="relative inline-flex w-2.5 h-2.5 rounded-full" style={{ background: status.color }} />
                </span>
                <span className="text-sm text-white">{status.label}</span>
              </div>
              {chatMode && (
                <div
                  className="mt-2.5 w-full flex items-center justify-between px-3 py-2 rounded-lg"
                  style={{
                    background: `linear-gradient(90deg, ${MODE_ICON_COLOR[chatMode]}33, ${MODE_ICON_COLOR[chatMode]}0d 70%, transparent)`,
                    borderLeft: `3px solid ${MODE_ICON_COLOR[chatMode]}`,
                  }}
                  data-testid="display-chat-mode"
                >
                  <div className="flex flex-col items-start">
                    <span className="text-[9px] uppercase tracking-wider text-white/40 font-bold">Chat mode</span>
                    <span className="text-sm font-semibold" style={{ color: MODE_ICON_COLOR[chatMode] }}>
                      {MODE_LABEL[chatMode]}
                    </span>
                  </div>
                  <span className="text-[10px] text-white/40 font-medium">Tap pill at top to switch</span>
                </div>
              )}
            </div>

            {/* Scrollable body */}
            <div className="flex-1 overflow-y-auto py-1">
              <Section
                title="Website Builds"
                color={COLORS.website}
                icon={<Globe className="w-3.5 h-3.5" />}
                items={[
                  ...websiteBuilds.map(b => ({ id: b.convId, title: b.title, sub: `${b.filesChanged.length} files`, failed: b.failed })),
                  ...websiteConvs.filter(c => !websiteBuilds.some(b => b.convId === c.id)).map(c => ({ id: c.id, title: c.title, sub: c.id === currentConvId ? "current" : "", failed: false })),
                ]}
                onPick={id => { onSelectConv(id); setOpen(false); }}
                empty="No website builds yet"
              />
              <Section
                title="Code Builds"
                color={COLORS.build}
                icon={<Code2 className="w-3.5 h-3.5" />}
                items={[
                  ...codeBuilds.map(b => ({ id: b.convId, title: b.title, sub: `${b.filesChanged.length} files`, failed: b.failed })),
                  ...buildConvs.filter(c => !codeBuilds.some(b => b.convId === c.id)).map(c => ({ id: c.id, title: c.title, sub: c.id === currentConvId ? "current" : "", failed: false })),
                ]}
                onPick={id => { onSelectConv(id); setOpen(false); }}
                empty="No code builds yet"
              />
              <Section
                title="Conversations"
                color={COLORS.chat}
                icon={<MessageSquare className="w-3.5 h-3.5" />}
                items={chatConvs.slice(0, 15).map(c => ({ id: c.id, title: c.title, sub: c.id === currentConvId ? "current" : "", failed: false }))}
                onPick={id => { onSelectConv(id); setOpen(false); }}
                empty="No conversations yet"
              />
              <div className="h-2" />
            </div>
          </div>
        </>
      )}
    </>
  );
}

function Section({ title, color, icon, items, onPick, empty }: {
  title:  string;
  color:  string;
  icon:   ReactNode;
  items:  Array<{ id: number; title: string; sub: string; failed: boolean }>;
  onPick: (id: number) => void;
  empty:  string;
}) {
  return (
    <div className="px-3 py-2 border-b border-white/[0.04] last:border-b-0">
      {/* Section header */}
      <div className="flex items-center gap-2 px-1 py-1.5">
        <span
          className="flex items-center justify-center w-5 h-5 rounded"
          style={{ background: `${color}26`, color }}
        >
          {icon}
        </span>
        <span
          className="text-[10px] uppercase tracking-[0.08em] font-bold"
          style={{ color }}
        >
          {title}
        </span>
        <span
          className="text-[10px] font-semibold ml-auto px-1.5 py-0.5 rounded-full"
          style={{ color, background: `${color}1a` }}
        >
          {items.length}
        </span>
      </div>
      {items.length === 0 ? (
        <div className="px-2 py-2 text-[11px] text-white/25 italic">{empty}</div>
      ) : (
        <div className="flex flex-col gap-1 mt-1">
          {items.map((it, i) => (
            <button
              key={`${it.id}-${i}`}
              onClick={() => onPick(it.id)}
              className="w-full flex items-stretch gap-2 px-2 py-2 rounded-lg text-left transition-all group hover:scale-[1.01] active:scale-[0.99]"
              style={{
                background: `linear-gradient(90deg, ${color}1f, ${color}07 60%, transparent)`,
                borderLeft: `3px solid ${color}`,
                opacity: it.failed ? 0.55 : 1,
              }}
            >
              <span
                className={`text-[12.5px] leading-snug truncate flex-1 font-medium ${it.failed ? "line-through" : ""}`}
                style={{ color: it.failed ? "rgba(255,255,255,0.4)" : "rgba(255,255,255,0.95)" }}
              >
                {it.title}
              </span>
              {it.sub && (
                <span
                  className="text-[10px] shrink-0 self-center px-1.5 py-0.5 rounded font-semibold"
                  style={{
                    color,
                    background: it.sub === "current" ? `${color}33` : "transparent",
                  }}
                >
                  {it.sub}
                </span>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
