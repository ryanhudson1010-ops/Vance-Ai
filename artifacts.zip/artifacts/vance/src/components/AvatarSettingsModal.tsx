import { useCallback, useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Upload, Loader2, Check, ExternalLink, Trash2, FolderUp } from "lucide-react";
import JSZip from "jszip";
import { invalidateAnimCache, type AnimName } from "./VanceAvatar3D";

// If the user picks a .zip, extract all .glb/.fbx entries inside it (any depth).
// Returns the same File[] shape the rest of the bulk flow expects.
async function extractZipEntries(zipFile: File): Promise<File[]> {
  const zip = await JSZip.loadAsync(await zipFile.arrayBuffer());
  const out: File[] = [];
  const entries = Object.values(zip.files).filter((e) => !e.dir);
  for (const entry of entries) {
    const lower = entry.name.toLowerCase();
    if (!lower.endsWith(".glb") && !lower.endsWith(".fbx")) continue;
    // Strip folder path so the matcher only sees the bare filename
    const baseName = entry.name.split("/").pop() ?? entry.name;
    // Skip macOS metadata cruft from zips made on Mac
    if (baseName.startsWith("._") || baseName.startsWith(".DS_Store")) continue;
    const blob = await entry.async("blob");
    out.push(new File([blob], baseName, { type: lower.endsWith(".glb") ? "model/gltf-binary" : "application/octet-stream" }));
  }
  return out;
}

// Filename-aware aliases. Maps extra keywords a Mixamo download filename
// might use to the canonical slot id. The auto-router checks BOTH the slot
// id's own tokens AND its alias keywords. Highest match-score wins.
const FILENAME_ALIASES: Record<string, string[]> = {
  idle: ["idle", "breathing", "standing"],
  talk: ["talk", "talking", "speaking"],
  nod_yes: ["nod", "yes", "head nod", "nodding"],
  shake_no: ["shake", "no", "head shake", "shaking head"],
  hard_nod: ["hard nod", "strong nod", "agree"],
  long_nod: ["long nod", "slow nod"],
  sarcastic_nod: ["sarcastic", "smug nod"],
  annoyed_shake: ["annoyed", "irritated"],
  thoughtful_shake: ["thoughtful", "thinking", "ponder"],
  happy: ["happy", "joy", "cheer"],
  angry: ["angry", "mad", "furious"],
  cocky: ["cocky", "smug", "confident"],
  ack: ["ack", "acknowledge", "okay", "ok gesture", "thumbs"],
  dismiss: ["dismiss", "wave off", "shoo"],
  look_away: ["look away", "looking away", "avert"],
  weight_shift: ["weight shift", "shift weight", "fidget"],
  sigh: ["sigh", "exhale"],
  box_idle: ["box idle", "hold box", "holding box", "idle box"],
  box_walk: ["box walk", "walk box", "carry box", "walking box"],
  box_turn: ["box turn", "turn box", "carrying turn"],
  kneel_idle: ["kneel", "kneeling"],
  dig_seeds: ["dig", "seeds", "planting seeds"],
  pull_plant: ["pull plant", "pulling", "harvest"],
  plant_tree: ["plant tree", "planting tree"],
  plant: ["plant"],
  holding_idle: ["holding idle", "hold idle"],
  holding_walk: ["holding walk", "hold walk", "walk holding"],
  holding_turn_l: ["holding turn l", "hold turn left", "turn left"],
  holding_turn_r: ["holding turn r", "hold turn right", "turn right"],
  watering: ["watering", "water plants"],
  pick_fruit: ["pick fruit", "picking fruit", "harvest fruit"],
  milk_cow: ["milk cow", "milking"],
  wheel_idle: ["wheel idle", "wheelbarrow idle"],
  wheel_walk: ["wheel walk", "push wheelbarrow", "pushing"],
  wheel_turn: ["wheel turn", "wheelbarrow turn"],
  wheel_dump: ["wheel dump", "dump wheelbarrow", "tip"],
};

function normaliseName(s: string): string {
  return s.toLowerCase().replace(/\.[^.]+$/, "").replace(/[_\-()[\]]/g, " ").replace(/\s+/g, " ").trim();
}

// Score how well a filename matches a slot. We award points for every
// alias phrase whose words ALL appear in the filename, weighted by phrase
// length (longer phrase = more specific). Returns 0 if nothing matches.
function scoreSlot(filename: string, slotId: string): number {
  const norm = normaliseName(filename);
  const tokens = norm.split(" ");
  const phrases = [slotId.replace(/_/g, " "), ...(FILENAME_ALIASES[slotId] ?? [])];
  let best = 0;
  for (const phrase of phrases) {
    const words = phrase.split(" ").filter(Boolean);
    const allPresent = words.every((w) => tokens.includes(w));
    if (allPresent) {
      best = Math.max(best, words.length * 10 + phrase.length);
    }
  }
  return best;
}

function routeFiles(files: File[], allSlotIds: string[]): {
  routed: Array<{ slotId: string; file: File; score: number }>;
  unmatched: File[];
} {
  // Greedy: each file picks its best-scoring still-available slot. If two files
  // both want the same slot, the higher-scoring one wins; the loser tries its
  // next-best slot. Multi-pass settle.
  const claims = new Map<string, { file: File; score: number }>();
  const unmatched: File[] = [];
  const fileBest = files.map((file) => {
    const ranked = allSlotIds
      .map((slotId) => ({ slotId, score: scoreSlot(file.name, slotId) }))
      .filter((r) => r.score > 0)
      .sort((a, b) => b.score - a.score);
    return { file, ranked, ptr: 0 };
  });
  // Iterate up to N rounds (bounded by total files to avoid infinite loops).
  for (let round = 0; round < files.length + 2; round++) {
    let changed = false;
    for (const entry of fileBest) {
      if (entry.ptr >= entry.ranked.length) continue;
      const target = entry.ranked[entry.ptr];
      if (!target) continue;
      const existing = claims.get(target.slotId);
      if (!existing) {
        claims.set(target.slotId, { file: entry.file, score: target.score });
        changed = true;
      } else if (target.score > existing.score) {
        // Bump the existing claimant — they need to look at next-best.
        const bumped = fileBest.find((f) => f.file === existing.file);
        if (bumped) { bumped.ptr++; changed = true; }
        claims.set(target.slotId, { file: entry.file, score: target.score });
      } else if (target.score < existing.score) {
        entry.ptr++;
        changed = true;
      }
      // equal score: keep the first one, this loser tries next-best
      if (existing && target.score === existing.score && existing.file !== entry.file) {
        entry.ptr++;
        changed = true;
      }
    }
    if (!changed) break;
  }
  const routed: Array<{ slotId: string; file: File; score: number }> = [];
  const claimedFiles = new Set<File>();
  for (const [slotId, info] of claims) {
    routed.push({ slotId, file: info.file, score: info.score });
    claimedFiles.add(info.file);
  }
  for (const f of files) {
    if (!claimedFiles.has(f)) unmatched.push(f);
  }
  return { routed, unmatched };
}

type Slot = { id: AnimName; label: string; emoji: string };
type AnimStatus = { name: AnimName; uploaded: boolean; sizeBytes: number; format?: "glb" | "fbx" | null };

const BASE_SLOTS: Slot[] = [
  { id: "idle", label: "Idle", emoji: "🧍" },
  { id: "talk", label: "Talk", emoji: "💬" },
];
const EMOTE_SLOTS: Slot[] = [
  // Gestures (conversational)
  { id: "nod_yes",          label: "Nod Yes",        emoji: "✅" },
  { id: "shake_no",         label: "Shake No",       emoji: "❌" },
  { id: "hard_nod",         label: "Hard Nod",       emoji: "💯" },
  { id: "long_nod",         label: "Long Nod",       emoji: "🙇" },
  { id: "sarcastic_nod",    label: "Sarcastic Nod",  emoji: "😏" },
  { id: "annoyed_shake",    label: "Annoyed Shake",  emoji: "😒" },
  { id: "thoughtful_shake", label: "Thoughtful",     emoji: "🤔" },
  { id: "happy",            label: "Happy",          emoji: "😄" },
  { id: "angry",            label: "Angry",          emoji: "😠" },
  { id: "cocky",            label: "Cocky",          emoji: "😎" },
  { id: "ack",              label: "Acknowledge",    emoji: "👌" },
  { id: "dismiss",          label: "Dismiss",        emoji: "🙅" },
  { id: "look_away",        label: "Look Away",      emoji: "👀" },
  { id: "weight_shift",     label: "Weight Shift",   emoji: "🕴️" },
  { id: "sigh",             label: "Sigh",           emoji: "😮‍💨" },
  // Farming
  { id: "box_idle",       label: "Hold Box",       emoji: "📦" },
  { id: "box_walk",       label: "Walk w/ Box",    emoji: "🚶" },
  { id: "box_turn",       label: "Turn w/ Box",    emoji: "🔄" },
  { id: "kneel_idle",     label: "Kneel",          emoji: "🦵" },
  { id: "dig_seeds",      label: "Plant Seeds",    emoji: "🌱" },
  { id: "pull_plant",     label: "Pull Plant",     emoji: "🌿" },
  { id: "plant_tree",     label: "Plant Tree",     emoji: "🌳" },
  { id: "plant",          label: "Plant",          emoji: "🪴" },
  { id: "holding_idle",   label: "Hold",           emoji: "🤲" },
  { id: "holding_walk",   label: "Walk Holding",   emoji: "🚶‍♂️" },
  { id: "holding_turn_l", label: "Turn L Hold",    emoji: "↩️" },
  { id: "holding_turn_r", label: "Turn R Hold",    emoji: "↪️" },
  { id: "watering",       label: "Water",          emoji: "💧" },
  { id: "pick_fruit",     label: "Pick Fruit",     emoji: "🍎" },
  { id: "milk_cow",       label: "Milk Cow",       emoji: "🐄" },
  { id: "wheel_idle",     label: "Wheelbarrow",    emoji: "🛒" },
  { id: "wheel_walk",     label: "Push Cart",      emoji: "🚜" },
  { id: "wheel_turn",     label: "Cart Turn",      emoji: "🔃" },
  { id: "wheel_dump",     label: "Dump Cart",      emoji: "🗑️" },
];

function AnimUploadPanel({
  title, subtitle, slots, statuses, onUpload, onRemove, busy, error,
}: {
  title: string;
  subtitle: string;
  slots: Slot[];
  statuses: Record<string, AnimStatus>;
  onUpload: (name: AnimName, file: File) => void;
  onRemove: (name: AnimName) => void;
  busy: AnimName | null;
  error: string | null;
}) {
  return (
    <div className="rounded-xl bg-accent/30 border border-border p-3 space-y-2">
      <p className="text-xs font-medium text-foreground">{title}</p>
      <p className="text-[11px] text-muted-foreground/80 leading-snug">{subtitle}</p>
      <div className="grid grid-cols-2 gap-1.5 pt-1">
        {slots.map((slot) => {
          const st = statuses[slot.id] ?? { name: slot.id, uploaded: false, sizeBytes: 0 };
          const isBusy = busy === slot.id;
          return (
            <div key={slot.id} className="flex items-center gap-1.5 rounded-lg border border-border bg-background/40 px-2 py-1.5">
              <span className="text-base leading-none">{slot.emoji}</span>
              <div className="flex-1 min-w-0">
                <div className="text-[11px] text-foreground font-medium truncate">{slot.label}</div>
                <div className="text-[10px] text-muted-foreground/70 truncate">
                  {st.uploaded ? `${st.format?.toUpperCase() ?? ""} · ${(st.sizeBytes / 1024).toFixed(0)} KB` : "Not uploaded"}
                </div>
              </div>
              <label className="relative cursor-pointer p-1 rounded hover:bg-accent/60 text-muted-foreground hover:text-foreground transition-colors min-w-[24px] min-h-[24px] flex items-center justify-center" title={st.uploaded ? "Replace" : "Upload"}>
                <input
                  type="file"
                  accept="*/*"
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  disabled={isBusy}
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) onUpload(slot.id, f);
                    e.target.value = "";
                  }}
                />
                {isBusy ? <Loader2 size={12} className="animate-spin" /> : st.uploaded ? <Check size={12} className="text-primary" /> : <Upload size={12} />}
              </label>
              {st.uploaded && !isBusy && (
                <button
                  type="button"
                  onClick={() => onRemove(slot.id)}
                  className="p-1 rounded hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors"
                  title="Remove"
                >
                  <Trash2 size={12} />
                </button>
              )}
            </div>
          );
        })}
      </div>
      {error && <p className="text-[11px] text-destructive">{error}</p>}
    </div>
  );
}

function AnimationsSection() {
  const [statuses, setStatuses] = useState<Record<string, AnimStatus>>({});
  const [busy, setBusy] = useState<AnimName | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [bulkBusy, setBulkBusy] = useState(false);
  const [bulkReport, setBulkReport] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      const res = await fetch("/api/vance/emotes", { credentials: "include" });
      if (!res.ok) return;
      const data = (await res.json()) as { emotes: AnimStatus[] };
      const next: Record<string, AnimStatus> = {};
      for (const e of data.emotes) next[e.name] = e;
      setStatuses(next);
    } catch {}
  }, []);

  useEffect(() => { void refresh(); }, [refresh]);

  const upload = useCallback(async (name: AnimName, file: File) => {
    setErr(null);
    if (file.size === 0) return setErr("That file is empty.");
    if (file.size > 60 * 1024 * 1024) return setErr("File is too large (max 60 MB).");
    setBusy(name);
    try {
      const buf = await file.arrayBuffer();
      const res = await fetch(`/api/vance/emotes/${name}`, {
        method: "POST",
        headers: { "Content-Type": "application/octet-stream" },
        body: buf,
        credentials: "include",
      });
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j.error ?? "Upload failed");
      }
      invalidateAnimCache(name);
      await refresh();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Upload failed");
    } finally {
      setBusy(null);
    }
  }, [refresh]);

  const remove = useCallback(async (name: AnimName) => {
    setErr(null);
    setBusy(name);
    try {
      await fetch(`/api/vance/emotes/${name}`, { method: "DELETE", credentials: "include" });
      invalidateAnimCache(name);
      await refresh();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Delete failed");
    } finally {
      setBusy(null);
    }
  }, [refresh]);

  // Bulk upload — pick many files (or a single .zip), auto-route each to its
  // best-matching slot.
  const bulkUpload = useCallback(async (rawFiles: File[]) => {
    setErr(null);
    setBulkReport(null);
    if (rawFiles.length === 0) return;
    setBulkBusy(true);
    // If a single .zip was picked, expand it into its entries first.
    let files: File[] = rawFiles;
    try {
      if (rawFiles.length === 1 && /\.zip$/i.test(rawFiles[0]!.name)) {
        setBulkReport(`Unzipping ${rawFiles[0]!.name}…`);
        files = await extractZipEntries(rawFiles[0]!);
        if (files.length === 0) {
          setBulkBusy(false);
          setErr("That zip didn't contain any .glb or .fbx files.");
          return;
        }
        setBulkReport(`Found ${files.length} animation file${files.length === 1 ? "" : "s"} in zip — routing…`);
      }
    } catch (e) {
      setBulkBusy(false);
      setErr(e instanceof Error ? `Couldn't read zip: ${e.message}` : "Couldn't read that zip.");
      return;
    }
    const allSlotIds = [...BASE_SLOTS, ...EMOTE_SLOTS].map((s) => s.id);
    const { routed, unmatched } = routeFiles(files, allSlotIds);
    if (routed.length === 0) {
      setBulkBusy(false);
      setErr(`Couldn't match any of those ${files.length} file${files.length === 1 ? "" : "s"} to a slot. Try renaming them so the slot name (e.g. "nod yes") appears in the filename.`);
      return;
    }
    let ok = 0;
    let failed = 0;
    for (const { slotId, file } of routed) {
      try {
        if (file.size === 0 || file.size > 60 * 1024 * 1024) { failed++; continue; }
        const buf = await file.arrayBuffer();
        const res = await fetch(`/api/vance/emotes/${slotId}`, {
          method: "POST",
          headers: { "Content-Type": "application/octet-stream" },
          body: buf,
          credentials: "include",
        });
        if (!res.ok) { failed++; continue; }
        invalidateAnimCache(slotId as AnimName);
        ok++;
      } catch {
        failed++;
      }
    }
    await refresh();
    setBulkBusy(false);
    const parts: string[] = [];
    parts.push(`${ok} uploaded`);
    if (failed > 0) parts.push(`${failed} failed`);
    if (unmatched.length > 0) parts.push(`${unmatched.length} unmatched (${unmatched.slice(0, 3).map((f) => f.name).join(", ")}${unmatched.length > 3 ? "…" : ""})`);
    setBulkReport(parts.join(" · "));
  }, [refresh]);

  return (
    <>
      <div className="rounded-xl bg-accent/30 border border-border p-3 space-y-2">
        <div className="flex items-center justify-between gap-2">
          <div className="min-w-0">
            <p className="text-xs font-medium text-foreground">Bulk upload</p>
            <p className="text-[11px] text-muted-foreground/80 leading-snug">
              Pick a .zip from Mixamo, OR multi-select a bunch of .fbx / .glb files at once — each one auto-routes to its slot by name (e.g. "Nod Yes.fbx" → Nod Yes).
            </p>
          </div>
          <label className={`relative shrink-0 cursor-pointer flex items-center gap-1.5 rounded-lg border border-border bg-background/60 hover:bg-background/80 px-2.5 py-1.5 text-[11px] font-medium transition-colors ${bulkBusy ? "opacity-60 pointer-events-none" : ""}`}>
            <input
              type="file"
              accept="*/*"
              multiple
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              disabled={bulkBusy}
              onChange={(e) => {
                const fs = Array.from(e.target.files ?? []);
                e.target.value = "";
                if (fs.length > 0) {
                  setBulkReport(`Got ${fs.length} file${fs.length === 1 ? "" : "s"} — uploading…`);
                  void bulkUpload(fs);
                }
              }}
            />
            {bulkBusy ? <Loader2 size={12} className="animate-spin" /> : <FolderUp size={12} />}
            {bulkBusy ? "Uploading…" : "Upload pack"}
          </label>
        </div>
        {bulkReport && <p className="text-[11px] text-muted-foreground">{bulkReport}</p>}
      </div>
      <AnimUploadPanel
        title="Base animations"
        subtitle="Idle = standing/breathing pose. Talk = used while Vance is speaking. Both loop and crossfade automatically."
        slots={BASE_SLOTS}
        statuses={statuses}
        onUpload={upload}
        onRemove={remove}
        busy={busy}
        error={err}
      />
      <AnimUploadPanel
        title="Emote animations"
        subtitle="Drop in Mixamo .fbx or .glb downloads (Skin: Without Skin, 30fps). No conversion needed."
        slots={EMOTE_SLOTS}
        statuses={statuses}
        onUpload={upload}
        onRemove={remove}
        busy={busy}
        error={null}
      />
    </>
  );
}

interface Props {
  isOpen: boolean;
  onClose: () => void;
  currentAvatarUrl: string | null; // ignored — kept for caller compat
  currentBodyModelUrl: string | null;
  onSave: (url: string) => void; // ignored — kept for caller compat
  onSaveBodyModel: (url: string) => void;
}

export default function AvatarSettingsModal({ isOpen, onClose, currentBodyModelUrl, onSaveBodyModel }: Props) {
  const [bodyUrl, setBodyUrl] = useState(currentBodyModelUrl ?? "");
  const [isUploading, setIsUploading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setBodyUrl(currentBodyModelUrl ?? "");
      setSaved(false);
      setError(null);
    }
  }, [isOpen, currentBodyModelUrl]);

  const uploadFile = useCallback(async (file: File) => {
    setError(null);
    if (file.size === 0) return setError("That file is empty.");
    if (file.size > 60 * 1024 * 1024) return setError("File is too large (max 60 MB).");
    setIsUploading(true);
    try {
      const res = await fetch("/api/vance/body-model/upload", {
        method: "POST",
        body: file,
        headers: { "Content-Type": "application/octet-stream" },
        credentials: "include",
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error ?? "Upload failed");
      }
      const data = (await res.json()) as { url: string };
      setBodyUrl(data.url);
      setSaved(false);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Upload failed");
    } finally {
      setIsUploading(false);
    }
  }, []);

  const handleSave = useCallback(async () => {
    const url = bodyUrl.trim();
    if (url && !/^(https?:\/\/|\/)/i.test(url)) {
      setError("URL must start with http(s):// or /");
      return;
    }
    setIsSaving(true);
    setError(null);
    try {
      onSaveBodyModel(url);
      setSaved(true);
      setTimeout(() => setSaved(false), 1600);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Save failed");
    } finally {
      setIsSaving(false);
    }
  }, [bodyUrl, onSaveBodyModel]);

  const handleClear = useCallback(() => {
    setBodyUrl("");
    onSaveBodyModel("");
    setSaved(true);
    setTimeout(() => setSaved(false), 1600);
  }, [onSaveBodyModel]);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <motion.div
            className="absolute inset-0 bg-background/80 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />

          <motion.div
            className="relative z-10 w-full max-w-md bg-card border border-border rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]"
            initial={{ scale: 0.94, opacity: 0, y: 10 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.94, opacity: 0, y: 10 }}
            transition={{ type: "spring", stiffness: 320, damping: 28 }}
          >
            <div className="flex items-center justify-between px-5 py-4 border-b border-border shrink-0">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-primary/20 border border-primary/30 flex items-center justify-center">
                  <div className="w-2 h-2 rounded-full bg-primary" />
                </div>
                <span className="font-serif text-foreground font-medium">Vance's 3D Body</span>
              </div>
              <button onClick={onClose} className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-accent transition-colors">
                <X size={16} />
              </button>
            </div>

            <div className="p-5 space-y-4 overflow-y-auto overscroll-contain flex-1" style={{ WebkitOverflowScrolling: "touch" }}>
              <div className="rounded-xl bg-accent/30 border border-border p-3 space-y-2">
                <p className="text-xs font-medium text-foreground">How to give Vance a new body</p>
                <ol className="text-xs text-muted-foreground/80 space-y-1 list-decimal pl-4">
                  <li>Open a free creator below and design your character.</li>
                  <li>Export it as a <span className="font-mono text-foreground/80">.glb</span> file (Mixamo-rigged works best).</li>
                  <li>Upload the file or paste its URL, then save.</li>
                </ol>
                <div className="flex flex-wrap gap-x-3 gap-y-1.5 pt-1">
                  <a href="https://readyplayer.me/" target="_blank" rel="noopener noreferrer" className="text-xs text-primary hover:underline inline-flex items-center gap-1">
                    Ready Player Me <ExternalLink size={10} />
                  </a>
                  <a href="https://avaturn.me/" target="_blank" rel="noopener noreferrer" className="text-xs text-primary hover:underline inline-flex items-center gap-1">
                    Avaturn <ExternalLink size={10} />
                  </a>
                  <a href="https://www.mixamo.com/" target="_blank" rel="noopener noreferrer" className="text-xs text-primary hover:underline inline-flex items-center gap-1">
                    Mixamo <ExternalLink size={10} />
                  </a>
                </div>
              </div>

              <div>
                <label className="text-xs text-muted-foreground mb-1.5 block">Upload .glb file</label>
                <input
                  ref={fileRef}
                  type="file"
                  accept="*/*"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) void uploadFile(f);
                    e.target.value = "";
                  }}
                  className="hidden"
                />
                <button
                  onClick={() => fileRef.current?.click()}
                  disabled={isUploading}
                  className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl border-2 border-dashed border-border hover:border-primary/40 hover:bg-primary/5 transition-colors text-sm text-muted-foreground hover:text-foreground disabled:opacity-50"
                >
                  {isUploading ? <><Loader2 size={14} className="animate-spin" /> Uploading…</> : <><Upload size={14} /> Choose .glb file</>}
                </button>
              </div>

              <div>
                <label className="text-xs text-muted-foreground mb-1.5 block">…or paste a model URL</label>
                <input
                  type="text"
                  value={bodyUrl}
                  onChange={(e) => { setBodyUrl(e.target.value); setSaved(false); }}
                  placeholder="https://models.readyplayer.me/your-id.glb"
                  className="w-full bg-background border border-border rounded-xl px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/60 outline-none focus:border-primary/50 transition-colors"
                />
              </div>

              {error && <p className="text-xs text-destructive">{error}</p>}

              <div className="flex gap-2">
                <button
                  onClick={handleSave}
                  disabled={isSaving || isUploading}
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-primary/20 hover:bg-primary/30 text-primary border border-primary/30 text-sm font-medium transition-colors disabled:opacity-50"
                >
                  {isSaving ? <><Loader2 size={14} className="animate-spin" /> Saving…</> : saved ? <><Check size={14} /> Saved</> : "Save"}
                </button>
                {currentBodyModelUrl && (
                  <button
                    onClick={handleClear}
                    className="px-4 py-2.5 rounded-xl border border-border hover:border-destructive/40 hover:bg-destructive/5 text-sm text-muted-foreground hover:text-destructive transition-colors"
                  >
                    Reset
                  </button>
                )}
              </div>

              {currentBodyModelUrl && (
                <p className="text-[11px] text-muted-foreground/70 truncate">
                  Current: <span className="font-mono text-foreground/70">{currentBodyModelUrl}</span>
                </p>
              )}

              <AnimationsSection />
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
