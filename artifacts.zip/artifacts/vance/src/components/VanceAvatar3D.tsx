import { Suspense, useEffect, useRef, useState } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { useGLTF, useAnimations, OrbitControls } from "@react-three/drei";
type OrbitControlsImpl = React.ComponentRef<typeof OrbitControls>;
import { motion } from "framer-motion";
import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { FBXLoader } from "three/examples/jsm/loaders/FBXLoader.js";

export type AvatarState = "idle" | "thinking" | "speaking" | "listening";
export type Persona = { name?: string; description?: string; primary: string; accent: string; glow: string } | null;

// One-shot emotes the user picks from the picker. The list is open-ended
// so users can keep adding new uploads without code changes; the server
// validates against an allowlist (EMOTE_NAMES in routes/vance/index.ts).
export type Emote = string;
export const EMOTE_DURATION_DEFAULT = 2.5;
export const EMOTE_DURATIONS: Record<string, number> = {
  box_idle: 3.0, box_walk: 3.0, box_turn: 1.8,
  kneel_idle: 3.0, dig_seeds: 4.0, pull_plant: 3.0, plant_tree: 4.0, plant: 3.5,
  holding_idle: 3.0, holding_walk: 3.0, holding_turn_l: 1.8, holding_turn_r: 1.8,
  watering: 3.5, pick_fruit: 3.0, milk_cow: 4.0,
  wheel_idle: 3.0, wheel_walk: 3.0, wheel_turn: 2.0, wheel_dump: 3.5,
  nod_yes: 1.6, shake_no: 1.8, hard_nod: 1.6, long_nod: 2.4, sarcastic_nod: 2.0,
  annoyed_shake: 1.8, thoughtful_shake: 2.2,
  happy: 2.4, angry: 2.2, cocky: 2.4, ack: 1.8, dismiss: 1.8,
  look_away: 2.0, weight_shift: 2.0, sigh: 2.4,
};
export function emoteDuration(name: string): number {
  return EMOTE_DURATIONS[name] ?? EMOTE_DURATION_DEFAULT;
}
// Base looping animations swapped automatically based on avatar state.
export type BaseAnim = "idle" | "talk";
// Anything the user can upload via the avatar settings modal.
export type AnimName = Emote | BaseAnim;

interface Props {
  state: AvatarState;
  persona: Persona;
  emote: Emote | null;
  bodyModelUrl: string | null;
}

function findClip(names: string[], wanted: string): string | null {
  const w = wanted.toLowerCase();
  return names.find((n) => n.toLowerCase().includes(w)) ?? null;
}

// Return a clone of `clip` whose track names have been rewritten to match the
// actual bone names on the target rig. Mixamo uses `mixamorig:Hips` in source
// FBX, but three.js's FBXLoader strips the colon (→ `mixamorigHips`). RPM /
// most "Without Skin" rigs use the bare `Hips`. Without this rewrite the
// mixer silently binds zero tracks → T-pose. We try common variants per bone
// and take the first that exists on the rig. Always clones because clips are
// cached across body switches.
function retargetClipToRig(clip: THREE.AnimationClip, boneNames: Set<string>): THREE.AnimationClip {
  const out = clip.clone();
  // Strip root motion: Mixamo idle/talk include big position keys on Hips
  // that translate the whole character off-screen. We only want in-place
  // animation, so drop every `.position` track (humanoid skeletons only put
  // position on the root anyway; bones rotate via `.quaternion`).
  out.tracks = out.tracks.filter((t) => !t.name.endsWith(".position"));
  let bound = 0;
  const sampleTrack = out.tracks[0]?.name ?? "(no tracks)";
  for (const track of out.tracks) {
    const dot = track.name.lastIndexOf(".");
    if (dot < 0) continue;
    const raw = track.name.slice(0, dot);
    const prop = track.name.slice(dot);
    if (boneNames.has(raw)) { bound++; continue; }
    const base = raw.replace(/^mixamorig[:_]?/i, "");
    const candidates = [base, `mixamorig:${base}`, `mixamorig_${base}`, `mixamorig${base}`];
    for (const c of candidates) {
      if (boneNames.has(c)) { track.name = c + prop; bound++; break; }
    }
  }
  // Ship a single diagnostic for each load so we can see in server logs which
  // names are on the rig vs in the clip when retargeting fails.
  void fetch("/api/vance/errors", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "include",
    body: JSON.stringify({
      source: "vance-anim-diag",
      message: `clip="${clip.name}" bound=${bound}/${out.tracks.length} sampleTrack="${sampleTrack}" rigBones=${boneNames.size} sampleRig=${JSON.stringify([...boneNames].slice(0, 20))}`,
    }),
  }).catch(() => {});
  return out;
}

// Fetch + parse an animation file (Mixamo .glb or .fbx) on demand. Strips
// "mixamorig:" / "Armature|" track prefixes so the clip retargets onto
// whatever Mixamo-compatible rig Vance's body uses. Cached by name so each
// animation parses once per session; the upload UI calls invalidateAnimCache
// after a re-upload to force a fresh load.
const animClipCache = new Map<AnimName, Promise<THREE.AnimationClip | null>>();
function loadAnimClip(name: AnimName): Promise<THREE.AnimationClip | null> {
  const cached = animClipCache.get(name);
  if (cached) return cached;
  const promise = (async (): Promise<THREE.AnimationClip | null> => {
    try {
      const res = await fetch(`/api/vance/emotes/file/${name}`, { credentials: "include" });
      if (!res.ok) return null;
      const buf = await res.arrayBuffer();
      const head = new TextDecoder("ascii").decode(new Uint8Array(buf, 0, Math.min(23, buf.byteLength)));
      let clip: THREE.AnimationClip | null = null;
      if (head.startsWith("glTF")) {
        const loader = new GLTFLoader();
        const gltf = await new Promise<{ animations: THREE.AnimationClip[] }>((resolve, reject) => {
          loader.parse(buf, "", (g) => resolve(g as unknown as { animations: THREE.AnimationClip[] }), reject);
        });
        clip = gltf.animations?.[0] ?? null;
      } else {
        const loader = new FBXLoader();
        const fbx = loader.parse(buf, "");
        clip = fbx.animations?.[0] ?? null;
      }
      if (clip) {
        for (const track of clip.tracks) {
          track.name = track.name
            .replace(/^mixamorig:/, "")
            .replace(/^.*\|/, "")
            .replace(/\.bones\[mixamorig:/, ".bones[");
        }
      }
      return clip;
    } catch {
      return null;
    }
  })();
  animClipCache.set(name, promise);
  return promise;
}

// Public helper so the upload UI can drop the in-memory cache after a
// re-upload (so the next load reads the fresh file from disk) AND so any
// mounted Model can re-resolve its base loop without a full remount.
export function invalidateAnimCache(name?: AnimName) {
  if (name) animClipCache.delete(name);
  else animClipCache.clear();
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("vance-anim-changed", { detail: { name: name ?? null } }));
  }
}
// Backwards-compat alias for older callers (still used elsewhere).
export const invalidateEmoteCache = invalidateAnimCache;

function Model({ url, state, emote, userRotY, audioAmpRef }: { url: string; state: AvatarState; emote: Emote | null; userRotY: number; audioAmpRef?: { readonly current: number } }) {
  const group = useRef<THREE.Group>(null);
  const gltf = useGLTF(url);
  const { actions, names, mixer } = useAnimations(gltf.animations, group);
  // The currently-running base loop (idle or talk action). The emote effect
  // reads this so it knows which action to fade back to when the emote ends.
  const baseActionRef = useRef<THREE.AnimationAction | null>(null);
  // Bumped by `invalidateAnimCache` so the base effect re-resolves after an
  // upload (without remounting the whole Model and reloading the body GLB).
  const [animVersion, setAnimVersion] = useState(0);
  // Bone names of the loaded body, used to retarget Mixamo track names so the
  // animation actually drives the rig (otherwise the action runs silently and
  // the avatar stays in T-pose). Stable for the lifetime of this Model — when
  // bodyModelUrl changes, useGLTF gives us a new gltf and this effect re-runs.
  const bonesRef = useRef<Set<string>>(new Set());
  useEffect(() => {
    // Collect EVERY named Object3D in the scene, not just things flagged as
    // Bone — three.js's GLTFLoader leaves many joints as plain Object3D, and
    // the mixer's PropertyBinding searches the whole hierarchy by name. Also
    // pull from any SkinnedMesh.skeleton.bones in case joints are referenced
    // there but aren't part of the scene-graph children.
    const names = new Set<string>();
    gltf.scene.traverse((o) => {
      if (o.name) names.add(o.name);
      const sm = o as THREE.SkinnedMesh;
      if (sm.isSkinnedMesh && sm.skeleton) {
        for (const b of sm.skeleton.bones) if (b.name) names.add(b.name);
      }
    });
    bonesRef.current = names;
  }, [gltf.scene]);

  // Discover lip-sync targets ONCE per loaded GLB. Two paths:
  //   - Morph targets (Ready Player Me / blendshape-based avatars): we look
  //     for the first matching mouth-open / jaw-open / viseme blend on every
  //     SkinnedMesh and store an (mesh, index) pair. Multiple meshes may
  //     have them (head + teeth) and we drive all of them.
  //   - Jaw bone (Mixamo / classic skeletal rigs): we rotate this bone on
  //     X to open the mouth when no morph target is available.
  // Animation tracks rarely touch the jaw, so writing rotation in our own
  // useFrame after the mixer's update wins reliably for typical rigs.
  const lipsRef = useRef<{
    jawBone: THREE.Bone | null;
    morphTargets: Array<{ mesh: THREE.SkinnedMesh; index: number }>;
  }>({ jawBone: null, morphTargets: [] });
  useEffect(() => {
    // Substring matchers — different rigs use different naming conventions.
    // Jaw: covers "Jaw", "mixamorig:Jaw", "Bip01_Jaw", "Bone_Jaw", "JawBone" etc.
    // Morphs: covers Ready Player Me ("mouthOpen", "jawOpen", "viseme_*"),
    // VRoid ("Mouth_Open", "Fcl_MTH_A"), Daz ("Mouth Open"), generic "open".
    const isJawName = (n: string) => /(^|[^a-z])jaw([^a-z]|$)/i.test(n);
    const MORPH_PATTERNS = [
      /jawopen/i, /mouthopen/i, /mouth.?open/i, /viseme.?aa/i, /viseme.?o/i,
      /viseme.?e/i, /fcl.?mth.?a/i, /^aa$/i, /open.?mouth/i,
    ];
    let jawBone: THREE.Bone | null = null;
    const morphTargets: Array<{ mesh: THREE.SkinnedMesh; index: number }> = [];
    // Diagnostics — collected so we can log what we found vs. what's available
    const allMorphNames: string[] = [];
    const allBoneCandidates: string[] = [];
    gltf.scene.traverse((o) => {
      if ((o as THREE.Bone).isBone) {
        if (/jaw|mouth|teeth|chin/i.test(o.name)) allBoneCandidates.push(o.name);
        if (!jawBone && isJawName(o.name)) jawBone = o as THREE.Bone;
      }
      const sm = o as THREE.SkinnedMesh;
      if (sm.isSkinnedMesh && sm.morphTargetDictionary && sm.morphTargetInfluences) {
        for (const name of Object.keys(sm.morphTargetDictionary)) allMorphNames.push(name);
        for (const name of Object.keys(sm.morphTargetDictionary)) {
          if (MORPH_PATTERNS.some((p) => p.test(name))) {
            const idx = sm.morphTargetDictionary[name];
            if (idx !== undefined) { morphTargets.push({ mesh: sm, index: idx }); break; }
          }
        }
      }
    });
    lipsRef.current = { jawBone, morphTargets };
    // Log once per GLB load so the user can check what got picked up.
    // eslint-disable-next-line no-console
    console.info("[Vance lip-sync]", {
      jawBone: jawBone ? (jawBone as THREE.Bone).name : null,
      morphTargetsFound: morphTargets.length,
      allMorphNamesSample: allMorphNames.slice(0, 40),
      jawMouthBoneCandidates: allBoneCandidates,
    });
  }, [gltf.scene]);

  useEffect(() => {
    const handler = () => setAnimVersion((v) => v + 1);
    window.addEventListener("vance-anim-changed", handler);
    return () => window.removeEventListener("vance-anim-changed", handler);
  }, []);

  // Choose and play the appropriate base loop for the current AvatarState.
  //   speaking  → uploaded talk.fbx if present, else uploaded idle, else GLB idle
  //   otherwise → uploaded idle if present, else GLB "idle" clip, else first GLB clip
  useEffect(() => {
    if (!mixer) return;
    let cancelled = false;
    void (async () => {
      const wantTalk = state === "speaking";
      let clip: THREE.AnimationClip | null = null;
      if (wantTalk) clip = await loadAnimClip("talk");
      if (!clip) clip = await loadAnimClip("idle");
      if (cancelled) return;

      let nextAction: THREE.AnimationAction | null = null;
      if (clip) {
        nextAction = mixer.clipAction(retargetClipToRig(clip, bonesRef.current));
      } else {
        const glbName = findClip(names, "idle") ?? names[0] ?? null;
        nextAction = glbName ? actions[glbName] ?? null : null;
      }

      const prev = baseActionRef.current;
      if (prev && prev !== nextAction) prev.fadeOut(0.3);
      if (nextAction) nextAction.reset().setLoop(THREE.LoopRepeat, Infinity).fadeIn(0.3).play();
      baseActionRef.current = nextAction;
    })();
    return () => { cancelled = true; };
  }, [state, actions, names, mixer, animVersion]);

  // One-shot emote layer. Plays on top of the base loop and fades back to
  // whatever base is currently active when it finishes (so emoting while
  // speaking returns to the talk loop, not the idle loop).
  useEffect(() => {
    if (!emote || !mixer) return;
    let cancelled = false;
    let cleanup: (() => void) | null = null;
    void (async () => {
      const clip = await loadAnimClip(emote);
      if (cancelled || !clip) {
        if (!clip) {
          // eslint-disable-next-line no-console
          console.warn(`[Vance] Emote "${emote}" not uploaded yet. Add it via Avatar Settings → Emotes.`);
        }
        return;
      }
      // Drive the back-to-idle transition off the clip's ACTUAL duration,
      // not a hardcoded EMOTE_DURATIONS entry.  If the timer fires before
      // the clip's last keyframe, the arm gets cut mid-swing and the
      // crossfade to idle reads as a visible "pump."  Cap at 8s so a
      // long dance/sleep clip doesn't lock the avatar out of idle forever.
      // Subtract the blend-out window so the crossfade STARTS while the
      // emote is still on its final pose, not after it's been clamped
      // and held idle for a frame.
      const BLEND = 0.5;
      const clipDur = Math.min(clip.duration, 8);
      const fallback = emoteDuration(emote);
      const totalSec = Math.max(clipDur, fallback);
      const triggerSec = Math.max(0.1, totalSec - BLEND);

      const action = mixer.clipAction(retargetClipToRig(clip, bonesRef.current));
      action.reset().setLoop(THREE.LoopOnce, 1).clampWhenFinished = true;
      const base = baseActionRef.current;
      let stopTimer: number | null = null;
      let emoteFinished = false;
      const fullyReleaseEmote = (delayMs: number) => {
        if (stopTimer !== null) window.clearTimeout(stopTimer);
        stopTimer = window.setTimeout(() => {
          action.stopFading();
          action.enabled = false;
          action.stop();
          stopTimer = null;
          emoteFinished = true;
        }, delayMs);
      };
      if (base) {
        // crossFadeFrom warps both actions' weights together so the bones
        // blend smoothly instead of snapping. We also stop "fadeOut"-ing
        // the base while the emote plays — keeping it at low weight under
        // the emote means there's something coherent to fade back into.
        base.enabled = true;
        action.crossFadeFrom(base, 0.25, false).play();
      } else {
        action.fadeIn(0.25).play();
      }

      const t = window.setTimeout(() => {
        if (base) {
          base.enabled = true;
          base.crossFadeFrom(action, BLEND, false).play();
        } else {
          action.fadeOut(BLEND);
        }
        fullyReleaseEmote(BLEND * 1000 + 30);
      }, triggerSec * 1000);

      cleanup = () => {
        window.clearTimeout(t);
        // If the emote already gracefully ended (timer fired, action stopped),
        // do NOT re-blend — that re-enables the action, gives it weight again,
        // and causes a visible "arms popping up" 280ms flash between turns.
        if (emoteFinished) return;
        action.stopFading();
        if (base) {
          base.enabled = true;
          base.crossFadeFrom(action, 0.25, false).play();
        } else {
          action.fadeOut(0.25);
        }
        fullyReleaseEmote(280);
      };
    })();
    return () => {
      cancelled = true;
      if (cleanup) cleanup();
    };
  }, [emote, mixer]);

  useFrame((s) => {
    if (!group.current) return;
    const t = s.clock.elapsedTime;
    const speakBoost = state === "speaking" ? 1.4 : 1;
    group.current.position.y = -1.35 + Math.sin(t * 1.3) * 0.012 * speakBoost;
    group.current.rotation.y = userRotY + Math.sin(t * 0.4) * 0.04;

    // Audio-driven lip sync — ONLY apply when we have a real amplitude
    // signal. If we wrote zeros every frame, we'd overwrite any jaw/mouth
    // motion already baked into the talk.fbx animation, leaving the mouth
    // permanently shut whenever TTS isn't routed through our analyser.
    // By skipping the write when amp ≈ 0, the underlying animation track
    // (if any) wins and the mouth still moves with the talking emote.
    const amp = audioAmpRef?.current ?? 0;
    const speaking = state === "speaking";
    if (speaking && amp > 0.01) {
      const open = Math.min(1, amp);
      const { jawBone, morphTargets } = lipsRef.current;
      if (jawBone) jawBone.rotation.x = open * 0.4;
      for (const m of morphTargets) {
        if (m.mesh.morphTargetInfluences) m.mesh.morphTargetInfluences[m.index] = open;
      }
    }
  });

  return (
    <group ref={group} position={[0, -1.35, 0]} scale={1.15}>
      <primitive object={gltf.scene} />
    </group>
  );
}

// Drives OrbitControls imperatively from the external `zoom` prop so the
// floating zoom buttons in Chat.tsx still work alongside touch/mouse input.
// Sets the camera distance from the orbit target whenever `zoom` changes —
// OrbitControls then owns smoothing via its damping. Touch input is the
// primary interaction; this driver only nudges things on explicit button
// presses.
function CameraDriver({ controlsRef, zoom, restoredDistanceRef }: { controlsRef: React.RefObject<OrbitControlsImpl | null>; zoom: number; restoredDistanceRef: React.RefObject<number | null> }) {
  const { camera } = useThree();
  const lastZoom = useRef(zoom);
  const seenRestore = useRef(false);
  useFrame(() => {
    const c = controlsRef.current;
    if (!c) return;
    // First frame after a restore: align lastZoom to the restored distance
    // so we don't overwrite it. We compute the equivalent zoom value and
    // store it as the new baseline.
    if (!seenRestore.current && restoredDistanceRef.current !== null) {
      seenRestore.current = true;
      lastZoom.current = zoom; // ignore current zoom prop, treat restored as baseline
      restoredDistanceRef.current = null;
      return;
    }
    if (lastZoom.current !== zoom) {
      const target = c.target;
      const offset = camera.position.clone().sub(target);
      const desired = 3.4 / Math.max(0.1, zoom);
      const len = offset.length() || 0.0001;
      offset.multiplyScalar(desired / len);
      camera.position.copy(target).add(offset);
      lastZoom.current = zoom;
      c.update();
    }
  });
  return null;
}

export default function VanceAvatar3D({ state, persona, emote, bodyModelUrl, zoom = 1, rotY = 0, audioAmpRef }: Props & { zoom?: number; rotY?: number; audioAmpRef?: { readonly current: number } }) {
  // No fallback body. If the user hasn't picked one, render an empty stage —
  // the parent (VanceFaceAvatar) decides whether to show the holographic CSS
  // avatar in that case.
  const url = bodyModelUrl && bodyModelUrl.trim() ? bodyModelUrl : null;
  const controlsRef = useRef<OrbitControlsImpl | null>(null);

  // Persist camera position + orbit target so the avatar's pose survives a
  // page reload / PWA close. Saved to localStorage on every "change" event
  // (debounced via rAF), restored once on mount AFTER OrbitControls is wired
  // up. Stored under a single key so it's trivial to clear if a future bug
  // ever requires a reset.
  const POSE_KEY = "vance-avatar3d-pose-v1";
  useEffect(() => {
    let cancelled = false;
    let saveCleanup: (() => void) | null = null;

    // OrbitControls is mounted inside the R3F Canvas (a separate React
    // sub-tree), so `controlsRef.current` is NOT populated synchronously
    // when this outer effect first runs. Poll on rAF until it appears,
    // then restore the saved pose AND wire up the change listener.
    const tryWire = () => {
      if (cancelled) return;
      const c = controlsRef.current;
      if (!c) {
        requestAnimationFrame(tryWire);
        return;
      }

      // Restore the saved pose (camera position + orbit target).
      try {
        const raw = localStorage.getItem(POSE_KEY);
        if (raw) {
          const p = JSON.parse(raw) as { cam?: [number, number, number]; tgt?: [number, number, number] };
          if (p.cam && p.tgt) {
            c.object.position.set(p.cam[0], p.cam[1], p.cam[2]);
            c.target.set(p.tgt[0], p.tgt[1], p.tgt[2]);
            c.update();
            // Sync CameraDriver's "lastZoom" baseline so it doesn't
            // immediately overwrite the restored distance on the next frame.
            // We do this by setting the parent's zoom-mirror ref below.
            restoredDistanceRef.current = c.object.position.distanceTo(c.target);
          }
        }
      } catch { /* corrupt entry — ignore, user gets default pose */ }

      // Save (rAF-debounced — `change` fires every frame during a drag).
      let pending = 0;
      const save = () => {
        if (pending) return;
        pending = requestAnimationFrame(() => {
          pending = 0;
          const cam = c.object.position;
          const tgt = c.target;
          try {
            localStorage.setItem(POSE_KEY, JSON.stringify({
              cam: [cam.x, cam.y, cam.z],
              tgt: [tgt.x, tgt.y, tgt.z],
            }));
          } catch { /* quota / private mode — silently skip */ }
        });
      };
      c.addEventListener("change", save);
      saveCleanup = () => {
        c.removeEventListener("change", save);
        if (pending) cancelAnimationFrame(pending);
      };
    };

    requestAnimationFrame(tryWire);
    return () => {
      cancelled = true;
      saveCleanup?.();
    };
  }, []);

  // Marker the CameraDriver checks on its first run: if a pose was just
  // restored, suppress the one-shot zoom-prop sync so we don't immediately
  // overwrite the restored distance with `3.4 / zoom`.
  const restoredDistanceRef = useRef<number | null>(null);

  // Lock the page from scrolling while the user is actively touching the
  // avatar (so a one-finger orbit drag doesn't also scroll the chat list
  // behind it), and restore the previous overflow on release. We snapshot
  // the prior values so we don't trample any other component's lock.
  const scrollLockRef = useRef<{ body: string; html: string } | null>(null);
  const lockScroll = () => {
    if (scrollLockRef.current) return;
    scrollLockRef.current = {
      body: document.body.style.overflow,
      html: document.documentElement.style.overflow,
    };
    document.body.style.overflow = "hidden";
    document.documentElement.style.overflow = "hidden";
  };
  const unlockScroll = () => {
    const prev = scrollLockRef.current;
    if (!prev) return;
    document.body.style.overflow = prev.body;
    document.documentElement.style.overflow = prev.html;
    scrollLockRef.current = null;
  };
  // Belt-and-suspenders: if the component unmounts mid-drag, restore.
  useEffect(() => () => unlockScroll(), []);

  // iOS Safari / PWA: a downward swipe at the top of the page triggers
  // pull-to-refresh or the PWA's pull-to-dismiss gesture, which React's
  // *passive* onTouchMove handler can't cancel. Attach a NON-passive
  // listener so we can preventDefault and keep the gesture inside the
  // canvas. Also pin body position during the drag — `overflow:hidden`
  // alone doesn't stop iOS rubber-band scrolling.
  const wrapperRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    const el = wrapperRef.current;
    if (!el) return;
    const onTouch = (e: TouchEvent) => {
      // Always cancel inside the avatar — the OrbitControls reads pointer
      // events directly, so blocking the touch default doesn't break it.
      e.preventDefault();
    };
    el.addEventListener("touchmove", onTouch, { passive: false });
    el.addEventListener("touchstart", onTouch, { passive: false });
    return () => {
      el.removeEventListener("touchmove", onTouch);
      el.removeEventListener("touchstart", onTouch);
    };
  }, []);

  return (
    <div
      ref={wrapperRef}
      className="relative w-full h-full overflow-hidden"
      style={{ background: "transparent", touchAction: "none", overscrollBehavior: "contain" }}
      onPointerDown={lockScroll}
      onPointerUp={unlockScroll}
      onPointerCancel={unlockScroll}
      onPointerLeave={unlockScroll}
    >
      <Canvas
        camera={{ position: [0, 0.5, 3.4], fov: 42 }}
        gl={{ antialias: true, alpha: true }}
        dpr={[1, 2]}
        style={{ background: "transparent", touchAction: "none" }}
      >
        <ambientLight intensity={1.0} />
        <directionalLight position={[2, 3, 4]} intensity={1.2} />
        <directionalLight position={[-2, 1, -1]} intensity={0.4} />
        {/* Touch + mouse interactivity:
              - one-finger drag / left-mouse drag → orbit (rotate)
              - two-finger pinch                 → zoom (dolly)
              - two-finger drag / right-mouse    → pan
              - mouse wheel                      → zoom
            Pan is bounded by `screenSpacePanning` so the model stays in
            world-space (no drift into infinity). Keeps the existing zoom
            buttons working via CameraDriver above. */}
        <OrbitControls
          ref={controlsRef as never}
          enablePan
          screenSpacePanning
          panSpeed={0.8}
          enableDamping
          dampingFactor={0.1}
          rotateSpeed={0.7}
          minDistance={0.6}
          maxDistance={14}
          minPolarAngle={Math.PI * 0.02}
          maxPolarAngle={Math.PI * 0.98}
          zoomSpeed={1.2}
          target={[0, 0.5, 0]}
          touches={{ ONE: THREE.TOUCH.ROTATE, TWO: THREE.TOUCH.DOLLY_PAN }}
          mouseButtons={{ LEFT: THREE.MOUSE.ROTATE, MIDDLE: THREE.MOUSE.DOLLY, RIGHT: THREE.MOUSE.PAN }}
        />
        <CameraDriver controlsRef={controlsRef} zoom={zoom} restoredDistanceRef={restoredDistanceRef} />
        <Suspense fallback={null}>
          {url && <Model url={url} state={state} emote={emote} userRotY={rotY} audioAmpRef={audioAmpRef} />}
        </Suspense>
      </Canvas>
      {/* Vignette intentionally removed — was creating the dark "box" look
          around the avatar. Canvas now renders fully transparent so the
          avatar floats directly on the page background. */}
    </div>
  );
}

