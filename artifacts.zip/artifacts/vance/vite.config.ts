import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "path";
// Runtime-error overlay disabled: in this single-user PWA the THREE.js
// WebGL renderer can fail transiently on the first mount in some browsers
// (especially after HMR or when a tab loses GPU context). The overlay
// blocks the WHOLE app for what is functionally a recoverable warning,
// leaving the user staring at a red modal they can't dismiss without
// technical knowledge. Removing the plugin keeps the same errors in the
// browser console for development, but lets the rest of the app render.

// PORT and BASE_PATH are required for `vite dev` / `vite preview` (the
// workflow wires them up). For `vite build` they're irrelevant — production
// is served as static files behind the deployment proxy, and the deployment
// builder runs `vite build` WITHOUT these env vars. Treat them as optional
// here and let the dev/preview server commands enforce their own checks.
const isBuild = process.argv.includes("build");
const rawPort = process.env.PORT;
const port = rawPort ? Number(rawPort) : 5173;

if (!isBuild) {
  if (!rawPort) {
    throw new Error(
      "PORT environment variable is required but was not provided.",
    );
  }
  if (Number.isNaN(port) || port <= 0) {
    throw new Error(`Invalid PORT value: "${rawPort}"`);
  }
}

const basePath = process.env.BASE_PATH ?? "/";

if (!isBuild && !process.env.BASE_PATH) {
  throw new Error(
    "BASE_PATH environment variable is required but was not provided.",
  );
}

export default defineConfig({
  base: basePath,
  plugins: [
    react(),
    tailwindcss(),
    ...(process.env.NODE_ENV !== "production" &&
    process.env.REPL_ID !== undefined
      ? [
          await import("@replit/vite-plugin-cartographer").then((m) =>
            m.cartographer({
              root: path.resolve(import.meta.dirname, ".."),
            }),
          ),
          await import("@replit/vite-plugin-dev-banner").then((m) =>
            m.devBanner(),
          ),
        ]
      : []),
  ],
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "src"),
      "@assets": path.resolve(import.meta.dirname, "..", "..", "attached_assets"),
    },
    dedupe: ["react", "react-dom"],
  },
  root: path.resolve(import.meta.dirname),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true,
  },
  server: {
    port,
    strictPort: true,
    host: "0.0.0.0",
    allowedHosts: true,
    fs: {
      strict: true,
    },
  },
  preview: {
    port,
    host: "0.0.0.0",
    allowedHosts: true,
  },
});
