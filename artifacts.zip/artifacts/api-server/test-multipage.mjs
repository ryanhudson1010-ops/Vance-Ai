import { build } from "esbuild";
import AdmZip from "adm-zip";
import { writeFileSync } from "fs";
import { pathToFileURL } from "url";
import path from "path";
const result = await build({
  entryPoints: ["./src/lib/website-template.ts"],
  bundle: true, format: "esm", platform: "node", target: "node22",
  write: false, external: ["adm-zip"],
});
const outPath = path.resolve("./test-bundle.mjs");
writeFileSync(outPath, result.outputFiles[0].text);
const mod = await import(pathToFileURL(outPath).href);
const spec = mod.parseWebsiteSpec(JSON.stringify({
  businessName: "You'll Have It Maid, LLC",
  tagline: "Sparkling clean homes across Yadkin County",
  description: "Friendly, professional cleaning serving Hamptonville, NC and the surrounding area. Free estimates on every job.",
  phone: "(803) 792-5749", email: "Youllhaveitmaid2016@gmail.com",
  city: "Hamptonville", state: "NC", hours: "Mon-Fri 8am-6pm, Sat by appointment",
  palette: "soft-green", multiPage: true, zipName: "youll-have-it-maid",
  services: [
    { title: "Basic Clean", description: "Routine top-to-bottom tidy: dust, vacuum, mop, kitchen and bathrooms." },
    { title: "Deep Clean", description: "Thorough reset including baseboards, blinds, inside appliances, and detail work." },
    { title: "Post-Construction Clean", description: "Dust, debris, and residue removal after a remodel or build." },
    { title: "Move-In / Move-Out Clean", description: "Leave it spotless or arrive to spotless — every surface, inside cabinets, appliances." },
  ],
  about: { heading: "Locally Owned", body: "We're a small, family-run team based right here in Hamptonville. Every clean is treated like it's our own home — careful, thorough, and finished on time.\n\nMonthly, bi-weekly, weekly, and one-time visits. Free estimates always." },
  serviceArea: ["Hamptonville", "Yadkinville", "Jonesville", "Elkin", "Boonville", "East Bend"],
  cta: "Get a Free Estimate"
}));
if (!spec) { console.error("PARSE FAILED"); process.exit(1); }
console.log("Parsed. multiPage:", spec.multiPage);
const { zipName, buffer, fileCount } = mod.buildWebsiteZip(spec);
console.log("zipName:", zipName, "size:", buffer.length, "files:", fileCount);
const zip = new AdmZip(buffer);
for (const e of zip.getEntries()) console.log(" -", e.entryName, e.header.size, "bytes");
const get = (n) => zip.getEntry(n)?.getData().toString("utf8") ?? "";
const idx = get("index.html"), abt = get("about.html"), svc = get("services.html"), ctc = get("contact.html");
console.log("nav links present in index:", ['about','services','contact'].every(p => idx.includes(`href="${p}.html"`)));
console.log("sticky header in all 4:", [idx,abt,svc,ctc].every(h => h.includes('class="sticky top-0')));
console.log("about active link:", abt.includes('href="about.html" class="font-semibold"'));
console.log("services active link:", svc.includes('href="services.html" class="font-semibold"'));
console.log("contact active link:", ctc.includes('href="contact.html" class="font-semibold"'));
const total = [idx,abt,svc,ctc].reduce((n,h)=>n+(h.match(/REPLACE IMAGE/g)||[]).length, 0);
console.log("TOTAL REPLACE IMAGE blocks:", total);
console.log("phone on all 4:", [idx,abt,svc,ctc].every(h => h.includes("(803) 792-5749")));
console.log("email on all 4:", [idx,abt,svc,ctc].every(h => h.includes("Youllhaveitmaid2016@gmail.com")));
console.log("README mentions REPLACE IMAGE:", (zip.getEntry("README.md")?.getData().toString() || "").includes("REPLACE IMAGE"));
