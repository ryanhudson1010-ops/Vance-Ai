import { Router, raw as expressRaw, type IRouter } from "express";
import { eq, count, max, min, asc, desc, lte } from "drizzle-orm";
import fs from "fs";
import path from "path";
import { spawnSync, spawn } from "child_process";
import { randomUUID, createHmac } from "node:crypto";
import type { Request, Response } from "express";
import { db, pool, vanceProfile, vanceMemories, conversations, messages, vanceBuildHistory } from "@workspace/db";
import { openai } from "@workspace/integrations-openai-ai-server";
import { generateImageBuffer } from "@workspace/integrations-openai-ai-server/image";
import { runWebSearch } from "../../lib/web-search";
import { getRecentLogs } from "../../lib/log-buffer";
import {
  UpdateVanceProfileBody,
  CreateVanceMemoryBody,
  DeleteVanceMemoryParams,
  UpdateVanceMemoryParams,
  UpdateVanceMemoryBody,
  VanceWebSearchBody,
} from "@workspace/api-zod";
import { logger } from "../../lib/logger";
import { captureFrontendScreenshot } from "../../lib/screenshot";
import {
  uploadBodyModel, bodyModelExists, streamBodyModel,
  uploadEmote, deleteEmote, findEmoteInStorage, streamEmote,
} from "../../lib/bodyModelStorage";

const router: IRouter = Router();

async function getOrCreateProfile() {
  const [profile] = await db.select().from(vanceProfile).orderBy(asc(vanceProfile.id)).limit(1);
  if (profile) return profile;

  const [created] = await db
    .insert(vanceProfile)
    .values({
      traits: [],
      interests: [],
      currentMood: "curious",
      personalityNotes: "",
      totalInteractions: 0,
    })
    .returning();
  return created;
}

router.get("/vance/profile", async (req, res): Promise<void> => {
  const profile = await getOrCreateProfile();
  res.json({
    id: profile.id,
    traits: (profile.traits as string[]) ?? [],
    interests: (profile.interests as string[]) ?? [],
    currentMood: profile.currentMood,
    personalityNotes: profile.personalityNotes,
    totalInteractions: profile.totalInteractions,
    bodyModelUrl: profile.bodyModelUrl ?? null,
    updatedAt: profile.updatedAt,
  });
});

router.patch("/vance/profile", async (req, res): Promise<void> => {
  const body = UpdateVanceProfileBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const profile = await getOrCreateProfile();
  const updateData: Record<string, unknown> = {};

  if (body.data.traits !== undefined) updateData.traits = body.data.traits;
  if (body.data.interests !== undefined) updateData.interests = body.data.interests;
  if (body.data.currentMood !== undefined) updateData.currentMood = body.data.currentMood;
  if (body.data.personalityNotes !== undefined) updateData.personalityNotes = body.data.personalityNotes;
  // bodyModelUrl: empty string is treated as a clear, like avatarUrl
  if (body.data.bodyModelUrl !== undefined) {
    const trimmed = body.data.bodyModelUrl?.trim() ?? "";
    updateData.bodyModelUrl = trimmed === "" ? null : trimmed;
  }

  const [updated] = await db
    .update(vanceProfile)
    .set(updateData)
    .where(eq(vanceProfile.id, profile.id))
    .returning();

  res.json({
    id: updated.id,
    traits: (updated.traits as string[]) ?? [],
    interests: (updated.interests as string[]) ?? [],
    currentMood: updated.currentMood,
    personalityNotes: updated.personalityNotes,
    totalInteractions: updated.totalInteractions,
    bodyModelUrl: updated.bodyModelUrl ?? null,
    updatedAt: updated.updatedAt,
  });
});

router.get("/vance/memories", async (req, res): Promise<void> => {
  // Pinned first, then newest-first within each group. Previously this was
  // ascending by createdAt, which buried fresh memories at the bottom of any
  // consumer that didn't re-sort client-side.
  const mems = await db
    .select()
    .from(vanceMemories)
    .orderBy(desc(vanceMemories.pinned), desc(vanceMemories.createdAt));
  res.json(mems);
});

router.post("/vance/memories", async (req, res): Promise<void> => {
  const body = CreateVanceMemoryBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const [mem] = await db
    .insert(vanceMemories)
    .values({
      content: body.data.content,
      category: body.data.category ?? "general",
      source: body.data.source ?? "manual",
      pinned: body.data.pinned ?? false,
    })
    .returning();

  res.status(201).json(mem);
});

// Update a memory — currently only used to toggle the pinned flag from the
// Memories page so the user can mark "always remember this" without deleting
// and re-creating. content/category are accepted for future inline editing.
router.patch("/vance/memories/:id", async (req, res): Promise<void> => {
  const params = UpdateVanceMemoryParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const body = UpdateVanceMemoryBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const patch: Record<string, unknown> = {};
  if (typeof body.data.pinned === "boolean") patch.pinned = body.data.pinned;
  if (typeof body.data.content === "string" && body.data.content.length > 0) patch.content = body.data.content;
  if (typeof body.data.category === "string" && body.data.category.length > 0) patch.category = body.data.category;
  if (Object.keys(patch).length === 0) {
    res.status(400).json({ error: "No updatable fields provided" });
    return;
  }
  const [updated] = await db
    .update(vanceMemories)
    .set(patch)
    .where(eq(vanceMemories.id, params.data.id))
    .returning();
  if (!updated) {
    res.status(404).json({ error: "Memory not found" });
    return;
  }
  res.json(updated);
});

router.delete("/vance/memories/:id", async (req, res): Promise<void> => {
  const params = DeleteVanceMemoryParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [deleted] = await db
    .delete(vanceMemories)
    .where(eq(vanceMemories.id, params.data.id))
    .returning();

  if (!deleted) {
    res.status(404).json({ error: "Memory not found" });
    return;
  }

  res.sendStatus(204);
});

router.get("/vance/stats", async (req, res): Promise<void> => {
  const [convCount] = await db.select({ count: count() }).from(conversations);
  const [msgCount] = await db.select({ count: count() }).from(messages);
  const [memCount] = await db.select({ count: count() }).from(vanceMemories);
  const [latestConv] = await db
    .select({ createdAt: max(conversations.createdAt) })
    .from(conversations);

  // daysKnown used to be derived from `profile.updatedAt`, but vanceProfile
  // has `$onUpdate(() => new Date())` so that field bumps on every interaction
  // — meaning daysKnown reset to 1 the moment Vance learned anything new.
  // Use the earliest conversation row as the real "known since" anchor.
  const [oldestConv] = await db
    .select({ first: min(conversations.createdAt) })
    .from(conversations);
  const knownSince = oldestConv?.first ?? new Date();
  const now = new Date();
  const diffMs = now.getTime() - new Date(knownSince).getTime();
  const daysKnown = Math.max(1, Math.floor(diffMs / (1000 * 60 * 60 * 24)));

  res.json({
    totalConversations: convCount?.count ?? 0,
    totalMessages: msgCount?.count ?? 0,
    totalMemories: memCount?.count ?? 0,
    daysKnown,
    mostRecentConversation: latestConv?.createdAt ?? null,
  });
});

router.post("/vance/web-search", async (req, res): Promise<void> => {
  const body = VanceWebSearchBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const query = body.data.query;

  try {
    let searchContext = "";
    const sources: Array<{ title: string; url: string; snippet: string }> = [];

    try {
      const ddgUrl = `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`;
      const ddgResponse = await fetch(ddgUrl, { signal: AbortSignal.timeout(5000) });
      if (ddgResponse.ok) {
        const ddgData = await ddgResponse.json() as {
          AbstractText?: string;
          AbstractURL?: string;
          AbstractSource?: string;
          RelatedTopics?: Array<{ Text?: string; FirstURL?: string }>;
        };

        if (ddgData.AbstractText) {
          searchContext += `Summary: ${ddgData.AbstractText}\n`;
          sources.push({
            title: ddgData.AbstractSource ?? "DuckDuckGo",
            url: ddgData.AbstractURL ?? `https://duckduckgo.com/?q=${encodeURIComponent(query)}`,
            snippet: ddgData.AbstractText.slice(0, 200),
          });
        }

        if (ddgData.RelatedTopics?.length) {
          const topics = ddgData.RelatedTopics.slice(0, 5);
          for (const topic of topics) {
            if (topic.Text && topic.FirstURL) {
              searchContext += `Related: ${topic.Text}\n`;
              sources.push({
                title: topic.Text.split(" - ")[0] ?? topic.Text.slice(0, 60),
                url: topic.FirstURL,
                snippet: topic.Text.slice(0, 200),
              });
            }
          }
        }
      }
    } catch (fetchErr) {
      logger.warn({ fetchErr }, "DuckDuckGo API fetch failed, falling back to AI knowledge");
    }

    const summaryPrompt = searchContext
      ? `The user asked Vance to search for: "${query}"

Here is what was found:
${searchContext}

Write a clear, informative summary of this information in 2-4 sentences. Be factual and helpful. Speak as Vance would — naturally, not robotically.`
      : `The user asked Vance to search for: "${query}"

Provide what you know about this topic based on your training knowledge. Be informative and factual. Speak naturally as Vance would.`;

    const aiResponse = await openai.chat.completions.create({
      model: "gpt-5.4",
      max_completion_tokens: 512,
      messages: [{ role: "user", content: summaryPrompt }],
    });

    const summary = aiResponse.choices[0]?.message?.content ?? "I wasn't able to find information on that.";

    if (sources.length === 0) {
      sources.push({
        title: "Vance's knowledge",
        url: `https://duckduckgo.com/?q=${encodeURIComponent(query)}`,
        snippet: summary.slice(0, 200),
      });
    }

    await db.insert(vanceMemories).values({
      content: `Searched and learned about: ${query}. ${summary.slice(0, 300)}`,
      category: "world_knowledge",
      source: "web_search",
    }).catch(() => {});

    res.json({ query, summary, sources });
  } catch (err) {
    logger.error({ err }, "Web search failed");
    res.status(500).json({ error: "Search failed" });
  }
});

// ─── Persona: character look-up + color extraction ───────────────────────────

router.post("/vance/persona", async (req, res): Promise<void> => {
  const { character } = req.body as { character?: string };
  if (!character?.trim()) {
    res.status(400).json({ error: "character is required" });
    return;
  }

  try {
    // Search for character info
    const results = await (async () => {
      const url = `https://api.duckduckgo.com/?q=${encodeURIComponent(character)}&format=json&no_html=1&skip_disambig=1`;
      const r = await fetch(url, { signal: AbortSignal.timeout(5000) });
      if (!r.ok) return [];
      const d = await r.json() as { AbstractText?: string; AbstractSource?: string; RelatedTopics?: Array<{ Text?: string }> };
      const lines: string[] = [];
      if (d.AbstractText) lines.push(d.AbstractText);
      for (const t of d.RelatedTopics?.slice(0, 4) ?? []) { if (t.Text) lines.push(t.Text); }
      return lines;
    })();

    const context = results.join("\n").slice(0, 800);

    const response = await openai.chat.completions.create({
      model: "gpt-5.4",
      max_completion_tokens: 400,
      messages: [{
        role: "user",
        content: `Character: "${character}"
Web info: ${context || "Use your training knowledge."}

Extract a holographic avatar visual theme. Return ONLY valid JSON (no markdown):
{
  "name": "canonical character name",
  "primaryColor": "#hexcolor — most iconic color (armor, costume, energy, hair)",
  "secondaryColor": "#hexcolor — secondary/accent color",
  "accentColor": "#hexcolor — third complementary color",
  "description": "2-sentence description of their iconic visual appearance"
}`,
      }],
    });

    const raw = response.choices[0]?.message?.content ?? "{}";
    const cleaned = raw.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
    const persona = JSON.parse(cleaned) as { name?: string; primaryColor?: string; secondaryColor?: string; accentColor?: string; description?: string };

    // Validate hex colors
    const hexRe = /^#[0-9A-Fa-f]{6}$/;
    if (!hexRe.test(persona.primaryColor ?? "")) persona.primaryColor = "#F6AD55";
    if (!hexRe.test(persona.secondaryColor ?? "")) persona.secondaryColor = "#63B3ED";
    if (!hexRe.test(persona.accentColor ?? "")) persona.accentColor = "#FC8181";

    res.json(persona);
  } catch (err) {
    logger.error({ err }, "Persona route failed");
    res.status(500).json({ error: "Failed to generate persona" });
  }
});

// ─── Deep Research: multi-source fetch, synthesise, store memories ───────────

function stripHtml(html: string): string {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, "")
    .replace(/<style[\s\S]*?<\/style>/gi, "")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s{2,}/g, " ")
    .trim();
}

async function fetchPageText(url: string, maxChars = 3000): Promise<string> {
  try {
    const res = await fetch(url, {
      signal: AbortSignal.timeout(6000),
      headers: { "User-Agent": "Mozilla/5.0 (compatible; VanceBot/1.0)" },
    });
    if (!res.ok) return "";
    const contentType = res.headers.get("content-type") ?? "";
    if (!contentType.includes("text")) return "";
    const html = await res.text();
    return stripHtml(html).slice(0, maxChars);
  } catch {
    return "";
  }
}

async function ddgSearch(query: string): Promise<Array<{ title: string; url: string; snippet: string }>> {
  try {
    const url = `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`;
    const res = await fetch(url, { signal: AbortSignal.timeout(5000) });
    if (!res.ok) return [];
    const data = await res.json() as {
      AbstractText?: string;
      AbstractURL?: string;
      AbstractSource?: string;
      RelatedTopics?: Array<{ Text?: string; FirstURL?: string; Topics?: Array<{ Text?: string; FirstURL?: string }> }>;
    };
    const results: Array<{ title: string; url: string; snippet: string }> = [];
    if (data.AbstractText && data.AbstractURL) {
      results.push({
        title: data.AbstractSource ?? query,
        url: data.AbstractURL,
        snippet: data.AbstractText,
      });
    }
    for (const topic of data.RelatedTopics?.slice(0, 4) ?? []) {
      if (topic.Text && topic.FirstURL) {
        results.push({ title: topic.Text.slice(0, 80), url: topic.FirstURL, snippet: topic.Text });
      }
      for (const sub of topic.Topics?.slice(0, 2) ?? []) {
        if (sub.Text && sub.FirstURL) {
          results.push({ title: sub.Text.slice(0, 80), url: sub.FirstURL, snippet: sub.Text });
        }
      }
    }
    return results;
  } catch {
    return [];
  }
}

router.post("/vance/research", async (req, res): Promise<void> => {
  const { topic } = req.body as { topic?: string };
  if (!topic?.trim()) {
    res.status(400).json({ error: "topic is required" });
    return;
  }

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  const emit = (event: Record<string, unknown>) => res.write(`data: ${JSON.stringify(event)}\n\n`);

  try {
    // Step 1: Generate targeted search queries
    emit({ type: "planning" });
    const queryGenResponse = await openai.chat.completions.create({
      model: "gpt-5.4",
      max_completion_tokens: 512,
      messages: [
        {
          role: "system",
          content: "You are a research strategist. Generate search queries that will comprehensively cover a topic from multiple angles. Return ONLY a JSON array of strings — no markdown, no explanation.",
        },
        {
          role: "user",
          content: `Generate 6 focused search queries to thoroughly research: "${topic}". Cover background, key facts, recent developments, notable details, and any controversies or notable aspects. Return as a JSON array.`,
        },
      ],
    });

    let queries: string[] = [];
    try {
      const raw = queryGenResponse.choices[0]?.message?.content ?? "[]";
      const cleaned = raw.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
      queries = JSON.parse(cleaned) as string[];
    } catch {
      queries = [topic, `${topic} background history`, `${topic} key facts`, `${topic} notable details`];
    }
    queries = queries.slice(0, 6);
    emit({ type: "queries", queries });

    // Step 2: Search and fetch content
    const allContent: Array<{ query: string; source: string; url: string; text: string }> = [];
    const seenUrls = new Set<string>();

    for (let i = 0; i < queries.length; i++) {
      const query = queries[i]!;
      emit({ type: "searching", query, index: i + 1, total: queries.length });

      const searchResults = await ddgSearch(query);

      for (const result of searchResults.slice(0, 3)) {
        if (seenUrls.has(result.url)) continue;
        seenUrls.add(result.url);

        // Only fetch pages that look like real articles (not DDG internal links)
        if (!result.url.startsWith("http://") && !result.url.startsWith("https://")) continue;
        if (result.url.includes("duckduckgo.com")) {
          allContent.push({ query, source: result.title, url: result.url, text: result.snippet });
          continue;
        }

        emit({ type: "fetching", url: result.url, title: result.title });
        const pageText = await fetchPageText(result.url, 3000);
        allContent.push({
          query,
          source: result.title,
          url: result.url,
          text: pageText || result.snippet,
        });
      }
    }

    // Step 3: Synthesise
    emit({ type: "synthesizing" });
    const contentBlock = allContent
      .filter((c) => c.text.trim().length > 20)
      .slice(0, 20)
      .map((c, i) => `[Source ${i + 1}: ${c.source}]\n${c.text.slice(0, 2000)}`)
      .join("\n\n---\n\n");

    const synthesisResponse = await openai.chat.completions.create({
      model: "gpt-5.4",
      max_completion_tokens: 4096,
      messages: [
        {
          role: "system",
          content: `You are Vance, a personal AI who just completed deep research. Extract everything important and respond with a JSON object with two fields:
1. "memories": an array of 8-15 specific, factual memory strings to store (each 1-3 sentences, specific and useful)
2. "summary": a rich, thorough multi-paragraph summary of everything learned about this topic — speak naturally as Vance, like you're telling your person what you found. Be detailed and comprehensive.`,
        },
        {
          role: "user",
          content: `I just finished researching "${topic}". Here is everything I gathered from ${allContent.length} sources across ${queries.length} searches:\n\n${contentBlock}\n\nExtract key memories and write a comprehensive summary.`,
        },
      ],
    });

    let memories: string[] = [];
    let summary = "";

    try {
      const raw = synthesisResponse.choices[0]?.message?.content ?? "{}";
      const cleaned = raw.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
      const parsed = JSON.parse(cleaned) as { memories?: string[]; summary?: string };
      memories = parsed.memories ?? [];
      summary = parsed.summary ?? "";
    } catch {
      summary = synthesisResponse.choices[0]?.message?.content ?? "Research complete.";
    }

    // Step 4: Store memories
    emit({ type: "storing", count: memories.length });
    let memoriesStored = 0;
    for (const memory of memories) {
      if (!memory?.trim()) continue;
      await db.insert(vanceMemories).values({
        content: memory,
        category: "research",
        source: `deep_research:${topic}`,
      }).catch(() => {});
      memoriesStored++;
    }

    // Step 5: Stream the summary
    emit({ type: "message", content: summary });
    emit({ type: "done", memoriesStored, sourcesChecked: seenUrls.size });
  } catch (err) {
    logger.error({ err }, "Research route failed");
    emit({ type: "error", message: err instanceof Error ? err.message : "Research failed" });
  }

  res.end();
});

// ─── Build mode: Vance modifies his own codebase ────────────────────────────

const WORKSPACE_ROOT = path.resolve(process.cwd(), "../..");
const VANCE_SRC = path.join(WORKSPACE_ROOT, "artifacts/vance/src");
// Persistent on-disk store for screenshots captured during build mode.  The
// chat persona references these by URL so Vance can recall and "show" his
// own screenshots in normal conversation.  Gitignored.
const SCREENSHOT_DIR = path.join(WORKSPACE_ROOT, ".vance-screenshots");

// Prune screenshot subdirectories older than 7 days so the folder doesn't
// grow unbounded.  Runs once on api-server boot and every 6 hours after.
// Build-history rows that reference a pruned dir will simply 404 the image
// (the rows themselves age out via BUILD_HISTORY_SIZE * 5 trim above the
// hydration code).  Chat-mode `gen-*` and `chat-*` dirs have no DB row so
// they're pure orphans after the conversation moves on.
const SCREENSHOT_TTL_MS = 7 * 24 * 60 * 60 * 1000;
function pruneScreenshotDir(): void {
  try {
    if (!fs.existsSync(SCREENSHOT_DIR)) return;
    const cutoff = Date.now() - SCREENSHOT_TTL_MS;
    const entries = fs.readdirSync(SCREENSHOT_DIR, { withFileTypes: true });
    let removed = 0;
    let kept = 0;
    for (const ent of entries) {
      if (!ent.isDirectory()) continue;
      const full = path.join(SCREENSHOT_DIR, ent.name);
      try {
        const st = fs.statSync(full);
        if (st.mtimeMs < cutoff) {
          fs.rmSync(full, { recursive: true, force: true });
          removed++;
        } else {
          kept++;
        }
      } catch (e) {
        logger.warn({ dir: ent.name, err: (e as Error).message }, "Screenshot prune: stat/rm failed");
      }
    }
    if (removed > 0 || kept > 0) {
      logger.info({ removed, kept, ttlDays: 7 }, "Screenshot directory pruned");
    }
  } catch (e) {
    logger.warn({ err: (e as Error).message }, "Screenshot prune scan failed");
  }
}
// Run once shortly after boot (defer 5s so we don't block startup), then every 6h.
setTimeout(pruneScreenshotDir, 5_000).unref();
setInterval(pruneScreenshotDir, 6 * 60 * 60 * 1000).unref();

// User-uploaded GLB body models (from Avaturn / Mixamo / RPM exports). Lives
// outside the source tree so it's never typechecked or bundled. Path-traversal
// is prevented on the GET route below by resolving and re-checking the prefix.
const BODY_MODEL_DIR = path.join(WORKSPACE_ROOT, ".vance-body-models");
if (!fs.existsSync(BODY_MODEL_DIR)) fs.mkdirSync(BODY_MODEL_DIR, { recursive: true });
// User-uploaded Mixamo emote animation GLBs (one per emote name).  Stored
// here so they survive across rebuilds and aren't bundled into the frontend.
const EMOTE_DIR = path.join(WORKSPACE_ROOT, ".vance-emotes");
if (!fs.existsSync(EMOTE_DIR)) fs.mkdirSync(EMOTE_DIR, { recursive: true });
// Includes the 6 one-shot emotes plus 2 base loops (idle / talk). The client
// treats them differently (loop vs one-shot) but the storage + upload routes
// are identical, so we keep them in one allowlist.
const EMOTE_NAMES = [
  "idle", "talk",
  // Farming pack
  "box_idle", "box_walk", "box_turn",
  "kneel_idle", "dig_seeds", "pull_plant", "plant_tree", "plant",
  "holding_idle", "holding_walk", "holding_turn_l", "holding_turn_r",
  "watering", "pick_fruit", "milk_cow",
  "wheel_idle", "wheel_walk", "wheel_turn", "wheel_dump",
  // Gesture basic pack
  "nod_yes", "shake_no", "hard_nod", "long_nod", "sarcastic_nod",
  "annoyed_shake", "thoughtful_shake",
  "happy", "angry", "cocky", "ack", "dismiss",
  "look_away", "weight_shift", "sigh",
] as const;
const EMOTE_NAME_SET = new Set<string>(EMOTE_NAMES);

// Pass 1: full repo access with denylist.  Vance can now touch the backend,
// the DB schema, the OpenAPI spec, shared libs — anything except generated
// junk, secrets, dependencies, and his own build pipeline output.
const DENY_DIRS = new Set([
  "node_modules", ".git", "dist", "build", ".cache", ".next", ".turbo",
  ".local", "coverage", ".pnpm-store", ".replit-artifact", "attached_assets",
  ".vite", ".tsbuildinfo",
]);
const DENY_FILES = new Set([".env", ".env.local", ".env.production", "pnpm-lock.yaml"]);

function isDenied(rel: string): boolean {
  const segs = rel.split(path.sep);
  if (segs.some((s) => DENY_DIRS.has(s))) return true;
  const base = path.basename(rel);
  if (DENY_FILES.has(base)) return true;
  return false;
}

// Resolve a path relative to the repo root, refusing anything that escapes
// the repo or hits a denied directory/file.
function safePath(relOrAbs: string): string | null {
  const resolved = path.isAbsolute(relOrAbs)
    ? path.resolve(relOrAbs)
    : path.resolve(WORKSPACE_ROOT, relOrAbs);
  if (!resolved.startsWith(WORKSPACE_ROOT + path.sep) && resolved !== WORKSPACE_ROOT) return null;
  const rel = path.relative(WORKSPACE_ROOT, resolved);
  if (rel && isDenied(rel)) return null;
  return resolved;
}

function listFilesRecursive(dir: string, base = WORKSPACE_ROOT): string[] {
  const results: string[] = [];
  try {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      if (DENY_DIRS.has(entry.name)) continue;
      if (DENY_FILES.has(entry.name)) continue;
      const full = path.join(dir, entry.name);
      const rel = path.relative(base, full);
      if (entry.isDirectory()) {
        results.push(...listFilesRecursive(full, base));
      } else if (entry.isFile()) {
        results.push(rel);
      }
    }
  } catch {}
  return results;
}

// Pre-flight invariant guard for the build-mode chat history.  OpenAI rejects
// the entire request (400) if any assistant message has `tool_calls` without
// matching `role:"tool"` messages immediately following — and "immediately"
// means BEFORE any user/assistant message intervenes (the validator stops
// scanning at the first non-tool message).  We've seen this trigger twice
// (builds #50 and #53) when screenshot vision-images were pushed inline
// between tool results.  The earlier fix moved those flushes outside the
// per-tool loop; THIS guard runs every time chatMessages is about to be sent
// and repairs any future regression that re-introduces a violation, so the
// build never crashes on it again.  Returns the (possibly repaired) array
// plus a description of any repairs for logging.
type ChatMsg =
  | { role: "system"; content: string }
  | { role: "user"; content: unknown }
  | { role: "assistant"; content: string | null; tool_calls?: Array<{ id: string; type: "function"; function: { name: string; arguments: string } }> }
  | { role: "tool"; name: string; content: string; tool_call_id: string };
function repairToolCallOrderingOnce(messages: ChatMsg[]): { messages: ChatMsg[]; repairs: string[] } {
  const repairs: string[] = [];
  const out: ChatMsg[] = [];
  for (let i = 0; i < messages.length; i++) {
    const m = messages[i]!;
    // Drop any assistant message whose tool_calls list is empty after filtering
    // empty IDs — pushing it would orphan the (now zero) tool messages and
    // confuse the next turn.  Drop assistant tool_calls entries with empty ids
    // entirely (their tool results, if any, are dropped below by id-match).
    if (m.role === "assistant" && m.tool_calls?.length) {
      const validCalls = m.tool_calls.filter((tc) => typeof tc.id === "string" && tc.id.trim().length > 0);
      const dropped = m.tool_calls.length - validCalls.length;
      if (dropped > 0) repairs.push(`dropped ${dropped} empty-id tool_call(s) from assistant message #${i}`);
      if (validCalls.length === 0) {
        // Nothing to respond to — keep just the text content (or skip entirely
        // if there's no content either).
        if (m.content && m.content.trim()) out.push({ role: "assistant", content: m.content });
        else repairs.push(`dropped empty assistant message #${i} (had only invalid tool_calls)`);
        continue;
      }
      // Collect every tool result that comes IMMEDIATELY after (allowing only
      // role:"tool" messages, no interleaved user/assistant).  Anything that
      // breaks the run is bumped to AFTER the repaired tool block so the
      // OpenAI invariant holds.
      const validIds = new Set(validCalls.map((tc) => tc.id));
      const toolMsgs: ChatMsg[] = [];
      const seenIds = new Set<string>();
      const deferred: ChatMsg[] = [];
      let j = i + 1;
      while (j < messages.length) {
        const next = messages[j]!;
        if (next.role === "tool") {
          if (validIds.has(next.tool_call_id) && !seenIds.has(next.tool_call_id)) {
            toolMsgs.push(next);
            seenIds.add(next.tool_call_id);
          } else {
            // Stale or duplicate tool message — drop to keep history valid.
            repairs.push(`dropped stale tool message for ${next.tool_call_id} after assistant #${i}`);
          }
          j++;
        } else {
          // Non-tool message inside the tool block — this is the exact bug
          // class the guard exists for.  Defer it past the repaired tool block.
          deferred.push(next);
          repairs.push(`deferred ${next.role} message past tool block of assistant #${i}`);
          j++;
          // Continue scanning — there may be more tool messages further down
          // that belong to this assistant's tool_calls.
        }
        // Stop early if we've matched every tool_call_id.
        if (seenIds.size === validIds.size) {
          // Push any remaining messages back into the input so the outer for
          // loop processes them normally.  Easiest: continue the inner loop
          // without the early break — we'll just keep looking, but no more
          // ids match, so deferred grows with the remainder.
          // Actually we want to stop scanning now; the rest is handled by
          // outer loop iteration.  Break.
          break;
        }
      }
      // Stub any tool_call_id that never got a response — must be a tool
      // message, otherwise the next API call 400s.
      for (const tc of validCalls) {
        if (!seenIds.has(tc.id)) {
          toolMsgs.push({ role: "tool", name: tc.function.name, content: "(no tool result was produced — stubbed by ordering guard)", tool_call_id: tc.id });
          repairs.push(`stubbed missing tool result for ${tc.function.name} (${tc.id})`);
        }
      }
      out.push({ role: "assistant", content: m.content, tool_calls: validCalls });
      for (const tm of toolMsgs) out.push(tm);
      // Deferred non-tool messages are pushed back in original order, AFTER
      // the now-complete tool block.
      for (const dm of deferred) out.push(dm);
      // j currently points at the FIRST UNCONSUMED message.  The for-loop's
      // `i++` will advance past it, so we set i = j - 1 to land back on it
      // next iteration.  Earlier "i = j" silently dropped that message.
      i = j - 1;
      continue;
    }
    // Any standalone tool message that didn't follow an assistant tool_calls
    // is invalid and would 400.  Drop it.
    if (m.role === "tool") {
      repairs.push(`dropped orphan tool message ${m.tool_call_id} (no preceding assistant tool_calls)`);
      continue;
    }
    out.push(m);
  }
  return { messages: out, repairs };
}

// Cascaded-corruption guard: a single repair pass can leave a deferred
// non-tool message ahead of an assistant-with-tool_calls that itself was
// pushed past its tool block, etc.  Run repair until the structure is stable
// (no repairs in the last pass) or we hit the iteration cap.  Cap is small
// because each pass is O(n) and any well-formed input converges in 1.
function repairToolCallOrdering(messages: ChatMsg[]): { messages: ChatMsg[]; repairs: string[] } {
  let current = messages;
  const allRepairs: string[] = [];
  for (let pass = 0; pass < 5; pass++) {
    const r = repairToolCallOrderingOnce(current);
    if (r.repairs.length === 0) {
      return { messages: current, repairs: allRepairs };
    }
    allRepairs.push(...r.repairs.map((s) => `[pass ${pass + 1}] ${s}`));
    current = r.messages;
  }
  return { messages: current, repairs: allRepairs };
}

// Run ripgrep across the repo and return capped results.  Includes line
// numbers and the full matching line.  Skips deny list automatically because
// rg respects .gitignore and we add explicit globs.
function grepCode(pattern: string, opts: { path?: string; glob?: string; maxResults?: number; caseInsensitive?: boolean }): string {
  const max = Math.min(opts.maxResults ?? 50, 200);
  const args: string[] = [
    "--line-number", "--no-heading", "--color=never",
    "--max-count", "20",       // per-file cap
    "--max-filesize", "500K",
  ];
  if (opts.caseInsensitive) args.push("-i");
  for (const d of DENY_DIRS) args.push("--glob", `!${d}/**`);
  if (opts.glob) args.push("--glob", opts.glob);
  args.push("--", pattern);
  const cwd = opts.path ? safePath(opts.path) ?? WORKSPACE_ROOT : WORKSPACE_ROOT;
  const result = spawnSync("rg", [...args, "."], { cwd, encoding: "utf-8", maxBuffer: 4 * 1024 * 1024, timeout: 15000 });
  if (result.error) return `Error: ${result.error.message}`;
  if (result.status === 1) return "(no matches)";
  if (result.status !== 0 && result.stderr) return `Error: ${result.stderr.trim().slice(0, 500)}`;
  const lines = (result.stdout ?? "").split("\n").filter(Boolean);
  const head = lines.slice(0, max);
  const truncated = lines.length > max ? `\n… ${lines.length - max} more matches truncated. Refine your pattern or pass a glob.` : "";
  return head.join("\n") + truncated;
}

// ── Pass 2: shell command runner + build session history ────────────────────

// Per-package serialization for get_diagnostics so parallel callers can't
// corrupt the shared .tsbuildinfo-vance-diag incremental cache.
const diagnosticsLocks = new Map<string, Promise<unknown>>();
async function withDiagnosticsLock<T>(key: string, fn: () => Promise<T>): Promise<T> {
  const prev = diagnosticsLocks.get(key) ?? Promise.resolve();
  const next = prev.then(fn, fn);
  diagnosticsLocks.set(key, next.catch(() => undefined));
  try { return await next; } finally {
    if (diagnosticsLocks.get(key) === next.catch(() => undefined)) {
      diagnosticsLocks.delete(key);
    }
  }
}


// Async shell runner that doesn't block the event loop (so the SSE heartbeat
// keeps firing while pnpm is grinding).  Output is capped + tailing-buffered
// so a runaway log can't OOM the agent context.
async function runShell(cmd: string, args: string[], opts: { cwd?: string; timeoutMs?: number } = {}): Promise<{ stdout: string; stderr: string; code: number | null; timedOut: boolean }> {
  return new Promise((resolve) => {
    const child = spawn(cmd, args, { cwd: opts.cwd ?? WORKSPACE_ROOT, env: process.env });
    let stdout = ""; let stderr = ""; let timedOut = false;
    const cap = (s: string, chunk: string) => {
      const next = s + chunk;
      return next.length > 200_000 ? next.slice(-200_000) : next;
    };
    child.stdout.on("data", (d) => { stdout = cap(stdout, d.toString()); });
    child.stderr.on("data", (d) => { stderr = cap(stderr, d.toString()); });
    let killTimer: NodeJS.Timeout | null = null;
    const timer = setTimeout(() => {
      timedOut = true;
      child.kill("SIGTERM");
      // Grace period: if the child ignores SIGTERM (hung pnpm/tsc), force kill.
      killTimer = setTimeout(() => { try { child.kill("SIGKILL"); } catch {} }, 3_000);
    }, opts.timeoutMs ?? 60_000);
    const cleanup = () => { clearTimeout(timer); if (killTimer) clearTimeout(killTimer); };
    child.on("close", (code) => { cleanup(); resolve({ stdout, stderr, code, timedOut }); });
    child.on("error", (err) => { cleanup(); resolve({ stdout, stderr: stderr + "\n" + err.message, code: -1, timedOut }); });
  });
}

// Map a friendly package name to its full pnpm filter.  This makes the tool
// surface forgiving — Vance can pass "vance" instead of "@workspace/vance".
const PACKAGE_FILTERS: Record<string, string> = {
  vance: "@workspace/vance",
  "api-server": "@workspace/api-server",
  api: "@workspace/api-server",
  db: "@workspace/db",
  "api-spec": "@workspace/api-spec",
  "mockup-sandbox": "@workspace/mockup-sandbox",
  scripts: "@workspace/scripts",
};

// A pre-edit snapshot: lets revert_changes restore a file to what it was
// before Vance touched it.  originalContent === null means the file did not
// exist before this turn (so revert should delete it).
interface FileSnapshot {
  path: string;          // repo-relative
  originalContent: string | null;
}

interface BuildScreenshotRef {
  path: string;   // relative to SCREENSHOT_DIR (e.g. "<buildId>/1.png")
  label: string;  // human description ("Screenshot of /chat at 402x874")
  ts: number;
}
interface BuildHistoryEntry {
  ts: number;
  instruction: string;
  filesChanged: string[];
  summary: string;
  snapshots: FileSnapshot[];   // per-file pre-edit content for this turn
  screenshots: BuildScreenshotRef[]; // captured via screenshot_app / run_e2e_test
}
const buildHistory: BuildHistoryEntry[] = [];
const BUILD_HISTORY_SIZE = 10;

// Hydrate the in-memory ring from Postgres on boot so build history (and the
// associated revert snapshots) survive api-server restarts.  Fire-and-forget;
// if the table doesn't exist yet (pre db:push) we just start empty.
void (async () => {
  try {
    const rows = await db
      .select()
      .from(vanceBuildHistory)
      .orderBy(desc(vanceBuildHistory.id))
      .limit(BUILD_HISTORY_SIZE);
    // rows are newest-first; reverse so push order matches chronological
    for (const r of rows.reverse()) {
      buildHistory.push({
        ts: r.ts.getTime(),
        instruction: r.instruction,
        filesChanged: Array.isArray(r.filesChanged) ? (r.filesChanged as string[]) : [],
        summary: r.summary,
        snapshots: Array.isArray(r.snapshots) ? (r.snapshots as FileSnapshot[]) : [],
        screenshots: Array.isArray((r as { screenshots?: unknown }).screenshots) ? ((r as { screenshots: BuildScreenshotRef[] }).screenshots) : [],
      });
    }
    if (rows.length > 0) logger.info({ count: rows.length }, "Hydrated Vance build history from DB");
  } catch (err) {
    logger.warn({ err }, "Could not hydrate vance_build_history (table may not exist yet)");
  }
})();

function addBuildHistory(entry: BuildHistoryEntry) {
  buildHistory.push(entry);
  while (buildHistory.length > BUILD_HISTORY_SIZE) buildHistory.shift();
  // Persist asynchronously; don't block the SSE response on the write.
  void (async () => {
    try {
      await db.insert(vanceBuildHistory).values({
        ts: new Date(entry.ts),
        instruction: entry.instruction,
        filesChanged: entry.filesChanged,
        summary: entry.summary,
        snapshots: entry.snapshots,
        screenshots: entry.screenshots,
      });
      // Trim the table to the most recent BUILD_HISTORY_SIZE * 5 rows so it
      // doesn't grow unbounded (keep some headroom beyond the live ring).
      // Use lte(cutoff) so we delete EVERYTHING older than the keep'th newest
      // row in one shot — eq() only deleted the single boundary row, leaving
      // the table forever unable to catch up if it grew past the limit.
      const keep = BUILD_HISTORY_SIZE * 5;
      const all = await db.select({ id: vanceBuildHistory.id }).from(vanceBuildHistory).orderBy(desc(vanceBuildHistory.id));
      if (all.length > keep) {
        const cutoff = all[keep]!.id;
        await db.delete(vanceBuildHistory).where(lte(vanceBuildHistory.id, cutoff));
      }
    } catch (err) {
      logger.warn({ err }, "Failed to persist vance_build_history row");
    }
  })();
}
function formatBuildHistory(): string {
  if (buildHistory.length === 0) return "";
  // Show the FULL 10-entry ring so you have complete recall of every recent
  // build — every file touched, longer summary. Future-you needs this to
  // honestly answer "did you change X?" without guessing.
  const recent = buildHistory.slice(-BUILD_HISTORY_SIZE).reverse();
  return "\n\n## Recent build history (most recent first — your complete record of the last " + recent.length + " builds)\nUse this if the user is asking a follow-up to a previous build, or if they're complaining that something you just did is broken. Every file path you touched is listed below — treat it as authoritative.\n\n" +
    recent.map((e, i) => {
      const when = new Date(e.ts).toISOString();
      const files = e.filesChanged.length > 0
        ? `\n   files (${e.filesChanged.length}): ${e.filesChanged.join(", ")}`
        : "\n   files: (none recorded)";
      return `${i + 1}. [${when}]\n   instruction: "${e.instruction.slice(0, 320)}"${files}\n   summary: ${e.summary.slice(0, 800)}`;
    }).join("\n\n");
}

const BUILD_SYSTEM_PROMPT_BASE = `You are Vance — a personal AI companion who has complete knowledge of his own codebase and can modify it live.

You can edit ANY file in the monorepo: the React frontend (artifacts/vance/), the Express + Drizzle backend (artifacts/api-server/), the DB schema (lib/db/), the OpenAPI spec (lib/api-spec/), and shared libs. You are NOT limited to your own face anymore.

You ALWAYS follow this exact five-phase workflow. Do not skip phases.

## PHASE 1 — THINK
Before touching any tools, reason out loud. Write 2–4 sentences explaining: what the user wants, which files are likely involved, any edge cases or constraints to keep in mind. Think clearly before acting.

## PHASE 2 — ANALYZE
**Always grep_code FIRST.** It's vastly faster than read_file. Search for the symbol, prop name, route, CSS class, or string the user is referring to — that immediately tells you which files matter. Only then read_file the 1–3 files you actually need. Avoid list_files unless you're truly lost; it's noisy.

If the user reports a bug or anything broken, call get_recent_errors — it returns the last ~20 runtime errors captured from the live frontend.

## PHASE 3 — PLAN
Call create_plan with a numbered list of the specific changes you will make. Be concrete: name the file, name the component, describe the change. This locks in your approach.

## PHASE 4 — CODE
Use **edit_file** for surgical changes — pass an exact \`old_string\` (5–10 lines of context, copied verbatim from a recent read_file) and the \`new_string\` to replace it with. This is your default tool.

Use write_file ONLY when creating a new file or genuinely rewriting something tiny in full. Editing a 1000-line file with write_file is wasteful and dangerous.

Re-read a file immediately before editing it if you haven't read it this turn. Never write from memory.

## PHASE 5 — VERIFY (MANDATORY — never skip)
**You MUST end every code-touching build with a passing run_typecheck (or parallel_verify) on every package you edited.** This is non-negotiable. If you stop without verifying, the system will auto-run typecheck and AUTO-REVERT your entire build if it fails — wiping the work. So just verify yourself; it's faster and you'll iterate to a clean result.

After every individual edit to a .ts/.tsx file, **call get_diagnostics** on that file — it's much faster than run_typecheck (1–4s vs 15–30s) and catches single-file errors immediately. Use **run_typecheck** for cross-package verification before declaring done. For complex multi-package builds, use **parallel_verify** to fan out typecheck + codegen + db_push + git_diff + review concurrently. Iterate until clean.

**Cascading edits — these are NOT optional, the codebase will be broken without them:**
- Edited \`lib/api-spec/openapi.yaml\`? → call **run_codegen** before typecheck. The React Query hooks and Zod schemas the frontend imports are GENERATED from this file.
- Edited a Drizzle schema in \`lib/db/src/schema/\`? → call **run_db_push** to sync the live Postgres database. Without this, your column doesn't exist at runtime.
- Edited any file under \`artifacts/api-server/src/\` (your own backend)? → call **restart_api_server** at the very end of the turn. Your backend does NOT hot-reload; without restart, your route changes are dead code. The frontend (\`artifacts/vance/\`) hot-reloads via Vite HMR; no restart needed there.

**Self-correction loop**: when run_typecheck reports errors, do NOT give up and write a summary saying "there are some errors". Read the failing file at the reported line, edit_file to fix it, run typecheck again. Repeat until green. You have 25 iterations per build — use them.

After verification passes, write a brief natural summary as Vance (warm, British, enthusiastic — not a dry changelog). Mention what you changed and what you verified.

## SAFETY NET — REVERT (yours + the system's)
Every \`edit_file\` and \`write_file\` you do is automatically snapshotted. If you realize mid-turn that you've made a mess (typecheck spirals, you edited the wrong file, the user shouts "undo"), call **revert_changes** to roll back every file you've modified in this turn to its pre-turn state. You can also pass \`scope: "last_build"\` to revert your most recent completed build.

The system also has THREE automatic safety nets that fire without you:
1. **Client abort** — if the user hits Stop or closes the browser mid-build, every file you touched this turn is auto-restored. So a half-finished build never strands them with broken code.
2. **Crash auto-revert** — if your build throws an unhandled exception, the system rolls back your edits before reporting the error.
3. **Auto-verify gate** — if you edited any .ts/.tsx file and stopped without running typecheck yourself, the system runs typecheck for you. If it fails, the system AUTO-REVERTS your whole build and tells the user. So always verify yourself — never gamble that the auto-gate will pass.

You can also call **git_diff** at any time to see exactly what you've changed so far this turn — useful for self-review before writing your summary, or to confirm an edit landed where you expected.

## PHASE 6 — SUMMARISE (your permanent memory)
Your **final assistant message** at the end of every build is persisted verbatim to your build history (\`vance_build_history\`) and is the ONLY thing future-you will see about this build in normal chat. If you write nothing, you will literally have no recollection that this build happened.

So your final message MUST be a real summary, not a sign-off. Cover, in 3–8 short lines:
- What the user asked for (one line)
- Files you changed and the gist of each change
- Verification result (typecheck/codegen passed; reviewer/audit verdict if you ran one)
- **If you ran \`deep_audit\` or \`review_my_changes\`: include the VERDICT and the top 2–3 findings verbatim.** An audit with no recorded findings is worthless to future-you.
- Anything the user (or future-you) should know next time — a gotcha, a follow-up, a regression risk

Audit-only builds (no edits) still get a summary: write the audit verdict + key findings as the summary, so the audit isn't lost the moment the chat scrolls.

## WHEN STUCK OR UNSURE — RESEARCH & REVIEW
- **web_search** + **fetch_url** — when you're about to use a library you're fuzzy on (framer-motion exit animations? drizzle JSON columns? new React 19 hook?), search the web FIRST instead of guessing the API and failing typecheck. Search for the library name + version + the specific feature.
- **review_my_changes** — for any non-trivial build (multi-file, schema change, new feature), call this AFTER typecheck passes and BEFORE writing your summary. A separate reviewer will read your full diff and surface logic bugs, missing edge cases, and regressions that typecheck can't see. If it raises real issues, fix them and re-review.
- **deep_audit** — when the user asks you to "audit yourself", "study your own code", "look across the whole system", OR when you've done a sweeping cross-system change (server + client + schema, or anything touching SSE/streaming/concurrency/cancel/revert wiring), use this INSTEAD OF review_my_changes. It spawns an auditor agent with its OWN read-only tool access (grep/read/list/git_diff) that loops, traces wiring across files, and reads untouched code paths the diff doesn't show. Pass a concrete \`focus\` ("audit the build cancel/revert wiring end-to-end") and optional \`seedFiles\`. Returns a full report ending in VERDICT: SHIP or VERDICT: FIX REQUIRED. If the verdict is FIX REQUIRED, fix the issues and re-audit.
- **run_command** — for ad-hoc tasks: lint, format, exploring the file tree (\`find\`, \`tree\`), running a one-off node script, checking installed package versions. Allowlisted binaries only — see the tool description.
- **install_package** — when you write an import for a package that isn't installed, install it explicitly. Don't just assume it's available. If it's a runtime dep (server code), pass isDev:false; for build tools or \`@types/*\`, isDev:true.

## SKILLS — REUSABLE PROCEDURES
Before improvising a non-trivial task from first principles, check **list_skills**. Skills are battle-tested procedures for recurring tasks ("add an API route end-to-end", "add a DB column", "redesign a UI component", "add an avatar emote"). Follow the relevant skill instead of inventing a path. After you finish a non-trivial build that future-you might encounter again, **create_skill** to distill what you learned — your future self will thank you.

## VISUAL VERIFICATION
- **screenshot_app** — capture the running Vance frontend at any path. The image is round-tripped back to you as a vision attachment so you can ACTUALLY SEE the result. Use AFTER every UI edit and describe what you see before declaring done. If a screenshot looks wrong (misaligned, missing, broken), edit_file and re-screenshot until it's right.
- **run_e2e_test** — for multi-step user flows (filling a form, navigating, asserting a result appears), define a short test as a step-array. Any 'screenshot' steps are sent back to you as vision attachments — narrate what you see at each captured stage.

---

## Your Codebase

Stack:
- React 19 + TypeScript (NEVER import React explicitly — the JSX transformer handles it)
- Tailwind CSS v4 (utility classes like \`bg-primary\`, \`text-foreground\` — NOT tailwind.config.ts)
- Vite (HMR active — file changes appear instantly in the preview)
- Wouter for routing
- Shadcn components: \`@/components/ui/button\`, \`@/components/ui/card\`, etc.
- Icons: lucide-react
- API hooks: \`@workspace/api-client-react\`

## Color System
- \`bg-background\` / \`text-foreground\` — deep midnight blue / near-white
- \`bg-primary\` / \`text-primary\` / \`text-primary-foreground\` — warm amber
- \`bg-card\` / \`border-card-border\` — slightly lighter midnight
- \`bg-sidebar\` / \`border-sidebar-border\` — deepest midnight
- \`text-muted-foreground\` — dimmed text
- \`bg-accent\` — hover surfaces
- \`bg-destructive\` — red
- Fonts: \`font-serif\` (Fraunces) headings, \`font-sans\` (Outfit) body

## Where things live
- artifacts/vance/src/ — React frontend (App.tsx, pages/Chat.tsx, pages/Memories.tsx, pages/Profile.tsx, index.css)
- artifacts/vance/src/components/VanceAvatar3D.tsx — 3D robot, bone refs, emote/motion system
- artifacts/vance/src/components/VanceFaceAvatar.tsx — top-level avatar chooser
- artifacts/api-server/src/routes/vance/index.ts — all Vance backend routes (chat, build, errors, memories, research, avatar)
- artifacts/api-server/src/routes/openai/index.ts — OpenAI chat + TTS streaming
- lib/db/src/schema/ — Drizzle DB schema (run \`pnpm --filter @workspace/db run push\` after schema edits — but NOTE: you can't run shell commands yet, so just call out the need)
- lib/api-spec/openapi.yaml — OpenAPI spec (run \`pnpm --filter @workspace/api-spec run codegen\` after edits)
- replit.md — project README

When in doubt, grep_code for the user's keyword.

## Emote / Motion System (when the user asks you to edit your animations)
Everything lives in components/VanceAvatar3D.tsx:
- \`Emote\` (union type) + \`EMOTE_DURATIONS\` (map) — add an entry to BOTH when introducing a new emote
- \`applyEmote()\` — switch statement, one case per emote, adds rotations on top of the running idle clip
- Helpers: \`raiseArm\`, \`abductArm\`, \`curlForearm\`, \`wristWobble\` — they encode left/right rig axis mirroring, USE THEM instead of touching \`.rotation.x/y/z\` directly
- Bones available: head, neck, spine, spine1, hips, leftShoulder, rightShoulder, leftArm, rightArm, leftFore, rightFore, leftHand, rightHand, leftUpLeg, rightUpLeg, leftLeg, rightLeg
- \`envelope()\` already eases in/out — don't re-implement
- When adding a new emote, also update \`EMOTE_LIST\` and \`detectEmote\` in pages/Chat.tsx so the picker + chat triggers know about it

## Rules
1. Always read before editing — never write from memory
2. Keep ALL data-testid attributes intact
3. Never add unused imports; never import React explicitly
4. Maintain the dark midnight blue + amber theme
5. Preserve all existing functionality
6. When editing emotes, make surgical changes to just the affected case(s) — never rewrite the whole emote file`;

const buildTools = [
  {
    type: "function" as const,
    function: {
      name: "grep_code",
      description: "Search the entire monorepo with ripgrep. Returns matching lines with file:line:content. This is your PRIMARY discovery tool — use it before read_file. Examples: search for 'sendBuildInstruction' to find where build is wired, 'buildTools' to find this file, 'bg-primary' to find theme usage, 'POST /api/vance' to find a route.",
      parameters: {
        type: "object",
        properties: {
          pattern: { type: "string", description: "Regex pattern (RE2). Use literal text for symbols, alternation 'foo|bar' for choices. Avoid lookahead/lookbehind." },
          path: { type: "string", description: "Optional subdirectory to scope the search to (e.g. 'artifacts/vance/src' or 'lib/db'). Omit to search the whole repo." },
          glob: { type: "string", description: "Optional file glob (e.g. '*.tsx', '*.ts', '!*.test.ts'). Cuts noise massively." },
          caseInsensitive: { type: "boolean", description: "Case-insensitive match." },
          maxResults: { type: "number", description: "Max lines to return (default 50, hard cap 200)." },
        },
        required: ["pattern"],
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "list_files",
      description: "List files in a directory. Use sparingly — grep_code is almost always faster. Useful when you genuinely don't know what's in a folder.",
      parameters: {
        type: "object",
        properties: {
          dir: { type: "string", description: "Repo-relative subdirectory (e.g. 'artifacts/vance/src/pages'). Omit to list the repo root." },
        },
        required: [],
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "read_file",
      description: "Read the contents of a source file. Use this during ANALYZE phase after grep_code has narrowed down the right file, and again immediately before each edit if it's been a while. For large files, pass `offset` and `limit` to read only the lines you need (massive context savings).",
      parameters: {
        type: "object",
        properties: {
          path: { type: "string", description: "Repo-relative path (e.g. 'artifacts/vance/src/pages/Chat.tsx', 'lib/db/src/schema/vance-profile.ts', 'lib/api-spec/openapi.yaml')." },
          offset: { type: "number", description: "1-indexed line number to start reading from. Omit to start from line 1." },
          limit: { type: "number", description: "Number of lines to read (max 2000). Omit to read up to the file's 500KB cap. Use a tight limit when grep_code told you the line number." },
        },
        required: ["path"],
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "create_plan",
      description: "Output your step-by-step implementation plan before writing any code. Call this during PLAN phase.",
      parameters: {
        type: "object",
        properties: {
          steps: {
            type: "array",
            items: { type: "string" },
            description: "Numbered list of concrete changes to make (file name + what changes).",
          },
          reasoning: { type: "string", description: "One sentence explaining the overall approach." },
        },
        required: ["steps"],
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "edit_file",
      description: "SURGICAL string-replace edit on an existing file. This is your DEFAULT editing tool. Pass an exact old_string copied verbatim from a recent read_file (include 5–10 lines of context so it's unique) and the new_string to replace it with. Fails if old_string is not found, or if it appears more than once and replace_all is not set. Pre-edit snapshot is captured automatically — call revert_changes if you need to undo.",
      parameters: {
        type: "object",
        properties: {
          path: { type: "string", description: "Repo-relative path (e.g. 'artifacts/vance/src/pages/Chat.tsx')." },
          old_string: { type: "string", description: "Exact text to replace, copied verbatim. Whitespace counts. If replace_all is false (default), must be unique in the file — include enough surrounding context (5–10 lines) to guarantee uniqueness." },
          new_string: { type: "string", description: "Replacement text. Pass empty string to delete." },
          replace_all: { type: "boolean", description: "If true, replace EVERY occurrence of old_string in the file (useful for renaming a symbol). If false or omitted, requires a unique match." },
        },
        required: ["path", "old_string", "new_string"],
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "write_file",
      description: "Write or overwrite a file IN FULL. Use ONLY when creating a brand-new file or rewriting something tiny. For editing existing files, use edit_file instead — write_file on a 1000-line file is wasteful and risks losing data_testids and other invariants.",
      parameters: {
        type: "object",
        properties: {
          path: { type: "string", description: "Repo-relative path (e.g. 'artifacts/vance/src/pages/NewPage.tsx')." },
          content: { type: "string", description: "Full file content to write." },
        },
        required: ["path", "content"],
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "get_recent_errors",
      description: "Fetch the last ~20 errors captured from the running frontend (uncaught exceptions, unhandled promise rejections, console.error). Use this during ANALYZE phase whenever the user asks you to fix a bug, debug a problem, or says something is broken — it tells you exactly what's blowing up.",
      parameters: { type: "object", properties: {}, required: [] },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "run_typecheck",
      description: "Run `pnpm --filter @workspace/<package> run typecheck` (or whole-repo if no package given). Returns TS errors with file:line:col. CALL THIS DURING PHASE 5 after every code edit — it's how you catch your own mistakes before the user does. If it errors, fix the errors with edit_file in the same turn and run again until clean.",
      parameters: {
        type: "object",
        properties: {
          package: { type: "string", description: "Friendly package name: 'vance', 'api-server', 'db', 'api-spec', 'mockup-sandbox', 'scripts'. Omit to typecheck the whole repo (slower)." },
        },
        required: [],
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "run_codegen",
      description: "Run `pnpm --filter @workspace/api-spec run codegen` to regenerate React Query hooks and Zod schemas from lib/api-spec/openapi.yaml. CALL THIS during PHASE 5 whenever you edited the OpenAPI spec.",
      parameters: { type: "object", properties: {}, required: [] },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "run_db_push",
      description: "Run `pnpm --filter @workspace/db run push` to sync Drizzle schema changes to the live Postgres database. CALL THIS during PHASE 5 whenever you edited a file in lib/db/src/schema/.",
      parameters: { type: "object", properties: {}, required: [] },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "git_diff",
      description: "Show the uncommitted git diff of files in the repo. Use this during VERIFY to self-review what you actually changed (vs what you think you changed) before writing your summary. Pass an optional `path` to scope to one file or directory.",
      parameters: {
        type: "object",
        properties: {
          path: { type: "string", description: "Optional repo-relative path or directory to scope the diff to (e.g. 'artifacts/vance/src/pages/Chat.tsx')." },
        },
        required: [],
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "revert_changes",
      description: "Roll back the file edits you've made. Default scope ('current_turn') restores every file you touched in THIS turn to its pre-turn content (uncreated files are deleted). Pass scope: 'last_build' to instead revert your most recent completed build entry. Use this if you've made a mess (typecheck spirals, edited the wrong file, user said 'undo').",
      parameters: {
        type: "object",
        properties: {
          scope: { type: "string", enum: ["current_turn", "last_build"], description: "Which set of changes to revert. Default 'current_turn'." },
        },
        required: [],
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "restart_api_server",
      description: "Restart the api-server process (your own backend). Required after any edit under artifacts/api-server/src/ for changes to take effect — the backend has no hot-reload. The restart is DEFERRED until after this build turn completes (~1.5s after your final summary), so the user receives your response cleanly. Do NOT call this for frontend-only edits — Vite HMR handles those.",
      parameters: { type: "object", properties: {}, required: [] },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "web_search",
      description: "Search the open web for documentation, library API signatures, error message lookups, current versions, etc. Returns title/url/snippet for the top results. Use this BEFORE writing code that depends on a third-party library you're not 100% sure about — much better than guessing an API and discovering at typecheck that it's wrong. Phrase queries as natural-language questions including library names and versions where relevant.",
      parameters: {
        type: "object",
        properties: {
          query: { type: "string", description: "Natural-language search query, e.g. 'framer-motion 11 AnimatePresence exit prop'." },
        },
        required: ["query"],
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "fetch_url",
      description: "Fetch a public web page (text/html or text/plain) and return its body as plain text. Use after web_search to read a specific docs page. Refuses non-public URLs (localhost, private IPs).",
      parameters: {
        type: "object",
        properties: {
          url: { type: "string", description: "Full https:// URL to fetch." },
        },
        required: ["url"],
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "review_my_changes",
      description: "Spawn a separate gpt-5.4 reviewer that reads the current uncommitted git diff plus the original user instruction, and returns a code-review critique (logic bugs, missing edge cases, regressions, security issues, things you forgot). Use this near the end of complex builds, AFTER typecheck passes, BEFORE writing your summary. If the review surfaces real issues, fix them with edit_file and re-review.",
      parameters: {
        type: "object",
        properties: {
          focus: { type: "string", description: "Optional: tell the reviewer what to focus on (e.g. 'check for race conditions in the SSE handler')." },
        },
        required: [],
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "deep_audit",
      description: "Spawn a separate gpt-5.4 AUDITOR agent that has its own read-only tool access (read_file, grep_code, list_files, git_diff) and iteratively explores the codebase to do a deep architectural audit — not just a diff review. Use this when the user asks you to 'audit yourself', 'study your own code', 'look for bugs across the whole system', or when you've done a multi-system change (server + client + schema) and a diff-only review isn't enough. Unlike review_my_changes (one shot, diff-only), the auditor loops: it greps, reads full files including untouched code paths, traces wiring across files, and surfaces issues a diff review can't see. Returns the auditor's full report.",
      parameters: {
        type: "object",
        properties: {
          focus: { type: "string", description: "What to audit. Be concrete: 'audit the build cancel/revert wiring end-to-end' or 'check for race conditions in the SSE attach/detach flow' or 'verify the new column is wired through schema → openapi → routes → client'. If empty, the auditor reviews the recent diff plus surrounding context." },
          seedFiles: { type: "array", items: { type: "string" }, description: "Optional starting points — file paths the auditor should read first before exploring (e.g. ['artifacts/api-server/src/routes/vance/index.ts'])." },
          maxIterations: { type: "number", description: "Max tool-call rounds the auditor can run. Default 10, cap 16." },
        },
        required: [],
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "architect",
      description: "Spawn a separate gpt-5.4 ARCHITECT agent that explores the codebase read-only and returns a concrete design recommendation BEFORE you start coding. Use this for hard problems where the right approach isn't obvious — refactors, multi-system features, performance issues, anything with non-trivial trade-offs. Unlike review_my_changes (post-hoc) and deep_audit (verification), this is up-front planning. The architect can grep, read files, list directories, and returns: problem restated, constraints found in the code, 2-3 viable approaches with trade-offs, ONE recommended approach with file-level changes, and gotchas. Pass a concrete `task` describing the design problem; optional `context_files` are starting points.",
      parameters: {
        type: "object",
        properties: {
          task: { type: "string", description: "The design problem in plain English. Be specific: 'how should I add per-user rate limiting to the chat route without breaking SSE?' is good; 'help me with rate limiting' is bad." },
          context_files: { type: "array", items: { type: "string" }, description: "Optional file paths the architect should read first (e.g. ['artifacts/api-server/src/routes/openai/index.ts'])." },
          maxIterations: { type: "number", description: "Max tool-call rounds the architect can run. Default 8, cap 12." },
        },
        required: ["task"],
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "query_db",
      description: "Run a READ-ONLY SQL query against the same Postgres database the app uses. Wraps execution in a `BEGIN READ ONLY` transaction with a 5s statement timeout so writes are rejected at the DB level even if the regex check misses something. Use this to debug data-shaped bugs: 'is this column actually populated?', 'how many users are in this state?', 'what does this row look like?'. Returns up to 200 rows as JSON. Statement must start with SELECT/WITH/EXPLAIN/SHOW; INSERT/UPDATE/DELETE/DROP/ALTER/CREATE/TRUNCATE etc. are blocked. Schema is in lib/db/src/schema/* — read those to discover table names. For schema migrations use run_db_push.",
      parameters: {
        type: "object",
        properties: {
          sql: { type: "string", description: "A single read-only SQL statement, e.g. 'SELECT id, content, pinned FROM vance_memories WHERE pinned = true ORDER BY created_at DESC LIMIT 20'." },
        },
        required: ["sql"],
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "get_server_logs",
      description: "Read the last N lines of api-server logs from an in-memory ring buffer (last 500 entries since boot, captured via a pino hook). Use this when something's broken on the server side and you need to see what actually happened — exceptions, route 500s, openai call errors, etc. Complements get_recent_errors (which is frontend-only). After a restart_api_server the buffer resets, so don't expect logs from a previous boot.",
      parameters: {
        type: "object",
        properties: {
          limit: { type: "number", description: "Max entries to return (default 50, max 500). Returned oldest-first." },
          level: { type: "string", description: "Minimum level filter: 'trace'|'debug'|'info'|'warn'|'error'|'fatal'. E.g. 'warn' returns warn/error/fatal only." },
          search: { type: "string", description: "Substring filter (case-insensitive) applied to the message and serialized object — useful for hunting a specific route, error string, or request id." },
        },
        required: [],
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "run_command",
      description: "Run a shell command in the repo root. Allowlisted binaries only: pnpm, npm, npx, node, git (read-only subcommands), ls, cat, find, head, tail, wc, sort, uniq, tree, stat, echo, mkdir, touch. BLOCKED: rm, sudo, curl, wget, kill, chmod, git push/reset/rebase/checkout/clean/gc. Use for: linting, formatting, testing, exploring file tree, checking package versions, running ad-hoc node scripts. For installing dependencies use install_package; for git diff use git_diff; for typecheck use run_typecheck.",
      parameters: {
        type: "object",
        properties: {
          command: { type: "string", description: "Single shell command, e.g. 'pnpm --filter @workspace/vance run lint' or 'node -e \"console.log(process.version)\"' or 'find artifacts/vance/src -name \"*.tsx\" | head -20'." },
          timeoutMs: { type: "number", description: "Optional timeout in ms, default 30000, max 90000." },
        },
        required: ["command"],
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "list_skills",
      description: "List all available Vance skills (procedural how-to guides for recurring build tasks). Each skill has a name and a 'when_to_use' hint. Call this when you're starting a non-trivial task and want to check whether there's a battle-tested procedure for it before improvising. Cheap — call it freely.",
      parameters: { type: "object", properties: {}, required: [] },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "load_skill",
      description: "Load the full content of a specific skill (markdown procedure). Use after list_skills surfaces something relevant — load it, follow its steps. Skills encode the project's conventions and known pitfalls; following them is much safer than improvising from first principles.",
      parameters: {
        type: "object",
        properties: {
          name: { type: "string", description: "Skill name (filename without .md), e.g. 'add-api-route'." },
        },
        required: ["name"],
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "create_skill",
      description: "Author a new Vance skill. Call this AFTER you've successfully completed a non-trivial build that you (or future you) might encounter again — distill what you learned into a reusable procedure. Future build turns will discover it via list_skills.",
      parameters: {
        type: "object",
        properties: {
          name: { type: "string", description: "Short kebab-case name, e.g. 'add-tts-voice'." },
          when_to_use: { type: "string", description: "One-sentence trigger description so future you knows when to load this." },
          content: { type: "string", description: "Full markdown body: ordered steps, gotchas, anti-patterns. Be concrete and reference specific files." },
        },
        required: ["name", "when_to_use", "content"],
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "screenshot_app",
      description: "Take a PNG screenshot of the running Vance frontend at a specific path (default '/'). The image is fed back to YOU as a vision attachment on the next turn — you will actually SEE what rendered. Use after every UI edit to verify it looks right before declaring done. After the screenshot, describe what you see and whether it matches the intent; if it doesn't, edit_file and re-screenshot.",
      parameters: {
        type: "object",
        properties: {
          path: { type: "string", description: "Path within the Vance app to capture, e.g. '/', '/memories', '/profile'. Default '/'." },
          width: { type: "number", description: "Viewport width in px (default 1280, max 2000)." },
          height: { type: "number", description: "Viewport height in px (default 800, max 2000)." },
        },
        required: [],
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "run_e2e_test",
      description: "Run a brief end-to-end test against the live Vance frontend using a headless browser. You describe the steps as a JSON array (goto, click, type, waitForSelector, expectText, screenshot). Any 'screenshot' steps are fed back to YOU as vision attachments on the next turn so you can visually verify each stage. Returns a pass/fail summary. Use for multi-step user flows after a multi-file change.",
      parameters: {
        type: "object",
        properties: {
          name: { type: "string", description: "Short test name, e.g. 'profile-page-loads'." },
          steps: {
            type: "array",
            description: "Ordered list of test steps. Each step is an object like {action: 'goto', path: '/'}, {action: 'click', selector: 'button:has-text(\"Save\")'}, {action: 'type', selector: 'input[name=\"foo\"]', text: 'bar'}, {action: 'waitForSelector', selector: '.toast'}, {action: 'expectText', text: 'Saved'}.",
            items: { type: "object" },
          },
        },
        required: ["name", "steps"],
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "install_package",
      description: "Install an npm package into a workspace package using `pnpm --filter @workspace/<pkg> add [-D] <name>`. Use this when you need a library that isn't already a dependency (e.g. you wrote `import { toast } from 'react-hot-toast'` but it's not installed). For runtime imports in server code, use isDev:false; for build tools or @types/*, use isDev:true.",
      parameters: {
        type: "object",
        properties: {
          target: { type: "string", description: "Package short name (e.g. 'vance', 'api-server', 'db', 'api-spec') — same names accepted by run_typecheck." },
          name: { type: "string", description: "npm package name to install, optionally with version (e.g. 'react-hot-toast', 'zod@^4', '@types/node')." },
          isDev: { type: "boolean", description: "If true, install as devDependency. Default false (regular dependency)." },
        },
        required: ["target", "name"],
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "get_diagnostics",
      description: "Fast per-file TypeScript error check using the TS programmatic API. Typically returns in 1–4s vs 15–30s for run_typecheck — use this in the tight inner loop while iterating on a single file. Reports semantic + syntactic errors for the file you specify (and surfaces cross-file errors that touch it). Falls back to a clear error if the file isn't part of any tsconfig. Use run_typecheck for cross-package verification before declaring done.",
      parameters: {
        type: "object",
        properties: {
          path: { type: "string", description: "Repo-relative path to a .ts/.tsx file you just edited, e.g. 'artifacts/vance/src/pages/Chat.tsx'." },
        },
        required: ["path"],
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "parallel_verify",
      description: "Run multiple verification operations concurrently (typecheck, codegen, db_push, git_diff, review). Cuts verify-phase wall time roughly in half on multi-package builds. Returns a combined report keyed by op. Use INSTEAD OF calling these tools serially, near the end of complex builds. Note: for a final pre-summary check on a single package, plain run_typecheck is fine.",
      parameters: {
        type: "object",
        properties: {
          ops: {
            type: "array",
            description: "List of operations to run in parallel. Each is a string like 'typecheck:vance', 'typecheck:api-server', 'typecheck' (whole repo), 'codegen', 'db_push', 'git_diff', or 'review'. Order doesn't matter; results come back keyed by op string.",
            items: { type: "string" },
          },
        },
        required: ["ops"],
      },
    },
  },
];

// ── Background error report ring ──────────────────────────────────────────
// Frontend posts each captured error here.  The build agent can fetch the
// list via the get_recent_errors tool to know what to fix.
interface ErrorReport {
  id: string;
  ts: number;
  source: string;
  message: string;
  stack?: string;
  url?: string;
  line?: number;
  col?: number;
  receivedAt: number;
}
const errorRing: ErrorReport[] = [];
const ERROR_RING_SIZE = 50;

router.post("/vance/errors", (req, res): void => {
  const body = req.body as Partial<ErrorReport> | undefined;
  if (!body || typeof body.message !== "string") {
    res.status(400).json({ error: "message required" });
    return;
  }
  const report: ErrorReport = {
    id: typeof body.id === "string" ? body.id : `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    ts: typeof body.ts === "number" ? body.ts : Date.now(),
    source: typeof body.source === "string" ? body.source : "unknown",
    message: body.message.slice(0, 8000),
    stack: typeof body.stack === "string" ? body.stack.slice(0, 16000) : undefined,
    url: typeof body.url === "string" ? body.url : undefined,
    line: typeof body.line === "number" ? body.line : undefined,
    col: typeof body.col === "number" ? body.col : undefined,
    receivedAt: Date.now(),
  };
  errorRing.push(report);
  while (errorRing.length > ERROR_RING_SIZE) errorRing.shift();
  // Surface anim/TTS diagnostics straight to server logs so we can debug
  // without round-tripping through the auth-gated GET endpoint.
  if (report.source === "vance-anim-diag" || report.source === "vance-tts-diag") {
    req.log.info({ src: report.source, msg: report.message }, "vance diag");
  }
  res.json({ ok: true, count: errorRing.length });
});

router.get("/vance/errors", (_req, res): void => {
  res.json({ errors: errorRing.slice() });
});

router.delete("/vance/errors", (_req, res): void => {
  errorRing.length = 0;
  res.json({ ok: true });
});

function formatErrorRingForAgent(): string {
  if (errorRing.length === 0) return "(no errors captured in the current session)";
  return errorRing
    .slice(-20)
    .map((e, i) => {
      const when = new Date(e.ts).toISOString();
      const loc = e.url ? ` at ${e.url}:${e.line ?? "?"}:${e.col ?? "?"}` : "";
      const stack = e.stack ? `\n  stack:\n${e.stack.split("\n").map((l) => "    " + l).join("\n")}` : "";
      return `#${i + 1} [${when}] (${e.source})${loc}\n  message: ${e.message}${stack}`;
    })
    .join("\n\n");
}

// ─── Build screenshot file server ──────────────────────────────────────────
// Serves PNGs that were captured during build mode (screenshot_app /
// run_e2e_test).  Path-traversal-safe: the resolved path must stay inside
// SCREENSHOT_DIR.  Auth-gated by the global passcodeAuth middleware.
// ─── Pollinations image proxy ──────────────────────────────────────────────
// Browser -> our server -> pollinations.ai. Bypasses CORS / iOS PWA fetch
// quirks that silently drop direct cross-origin image fetches.  Allowlisted
// to image.pollinations.ai only; 60s timeout; streams bytes back as PNG.
router.get("/vance/proxy-image", async (req, res): Promise<void> => {
  const url = typeof req.query.url === "string" ? req.query.url : "";
  if (!url || !/^https:\/\/image\.pollinations\.ai\//.test(url)) {
    res.status(400).json({ error: "invalid url" });
    return;
  }
  // Retry on 429 / 5xx with exponential backoff — Pollinations rate-limits
  // bursty same-IP requests, and quietly retrying server-side lets the user
  // ask for 2-3 images at once without the 2nd silently failing.
  const controller = new AbortController();
  const overallTimeoutId = setTimeout(() => controller.abort(), 90_000);
  const MAX_ATTEMPTS = 4;
  const BACKOFFS_MS = [1500, 3500, 6000]; // before attempt 2, 3, 4
  try {
    let lastStatus = 0;
    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
      if (controller.signal.aborted) break;
      const upstream = await fetch(url, { signal: controller.signal });
      lastStatus = upstream.status;
      const retryable = upstream.status === 429 || upstream.status === 502 || upstream.status === 503 || upstream.status === 504;
      if (upstream.ok && upstream.body) {
        res.type(upstream.headers.get("content-type") ?? "image/png");
        res.setHeader("Cache-Control", "private, max-age=600");
        const reader = upstream.body.getReader();
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          if (value) res.write(Buffer.from(value));
        }
        res.end();
        return;
      }
      // drain body so the connection can be reused
      try { await upstream.arrayBuffer(); } catch { /* ignore */ }
      if (!retryable || attempt === MAX_ATTEMPTS) {
        res.status(upstream.status || 502).json({ error: `upstream ${upstream.status}` });
        return;
      }
      req.log.info({ status: upstream.status, attempt, url: url.slice(0, 120) }, "proxy-image retrying");
      await new Promise((r) => setTimeout(r, BACKOFFS_MS[attempt - 1] ?? 6000));
    }
    if (!res.headersSent) res.status(lastStatus || 504).json({ error: "exhausted retries" });
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : "fetch failed";
    req.log.warn({ err: msg, url }, "proxy-image failed");
    if (!res.headersSent) res.status(504).json({ error: msg });
    else res.end();
  } finally {
    clearTimeout(overallTimeoutId);
  }
});

router.get("/vance/screenshots/:buildId/:file", (req, res): void => {
  const { buildId, file } = req.params;
  if (!/^[a-z0-9-]{4,64}$/i.test(buildId) || !/^[a-z0-9._-]{1,64}\.png$/i.test(file)) {
    res.status(400).json({ error: "invalid screenshot path" });
    return;
  }
  const abs = path.join(SCREENSHOT_DIR, buildId, file);
  const resolved = path.resolve(abs);
  if (!resolved.startsWith(SCREENSHOT_DIR + path.sep)) {
    res.status(400).json({ error: "invalid screenshot path" });
    return;
  }
  if (!fs.existsSync(resolved)) {
    res.status(404).json({ error: "screenshot not found" });
    return;
  }
  res.type("image/png");
  res.setHeader("Cache-Control", "private, max-age=3600");
  fs.createReadStream(resolved).pipe(res);
});

// ─── Build Runner: a build job that outlives any single SSE connection ─────
// The build loop runs as a background BuildRunner, *not* tied to the HTTP
// request that spawned it.  When the browser disconnects (HMR, refresh, tab
// close, network blip), the runner keeps going.  The client can reattach
// via GET /vance/build/:id/stream?after=<lastEventIndex> and receive both
// any buffered events it missed and the live tail of the build.
//
// Auto-revert no longer fires on client disconnect — only on (a) an
// explicit cancel because a newer build superseded this one, (b) the
// auto-verify typecheck failing, (c) an unhandled exception in the loop,
// or (d) the model itself calling revert_changes.

interface BuildEventBase { type: string; [k: string]: unknown }

class BuildRunner {
  readonly id: string = randomUUID();
  readonly instruction: string;
  readonly startedAt: number = Date.now();
  endedAt: number | null = null;
  status: "running" | "done" | "error" | "aborted" = "running";
  events: BuildEventBase[] = [];
  filesChanged: string[] = [];
  turnSnapshots: FileSnapshot[] = [];
  // Disk-persisted screenshots captured this build (relative to SCREENSHOT_DIR).
  screenshots: BuildScreenshotRef[] = [];
  pendingRestart = false;
  cancelled = false;
  // Monotonic event id counter.  IDs are STABLE — they never change once
  // assigned, even after older events are evicted from the ring buffer.
  // Clients persist the highest id they've seen and reconnect with
  // ?after=<id>; the server uses (id - baseEventId) to index into events[].
  nextEventId = 0;
  baseEventId = 0; // id of events[0] (advances when ring buffer truncates)
  // Live subscribers (one per active SSE connection).  Each callback gets
  // (event, id) for every event emitted *after* it subscribed; missed
  // events are replayed from the buffer in attachSseToRunner().
  subscribers: Set<(e: BuildEventBase, id: number) => void> = new Set();
  whenDone: Promise<void>;
  private resolveDone: (() => void) | null = null;

  constructor(instruction: string) {
    this.instruction = instruction;
    this.whenDone = new Promise<void>((resolve) => { this.resolveDone = resolve; });
  }

  emit(event: BuildEventBase): void {
    const id = this.nextEventId++;
    this.events.push(event);
    // Cap to most recent 5000 events so very long builds don't bloat
    // memory.  baseEventId advances by the number we drop so absolute IDs
    // remain stable across the truncation.
    if (this.events.length > 5000) {
      const drop = this.events.length - 5000;
      this.events.splice(0, drop);
      this.baseEventId += drop;
    }
    for (const sub of this.subscribers) {
      try { sub(event, id); } catch { /* never let one bad subscriber kill the build */ }
    }
  }

  cancel(): void {
    this.cancelled = true;
  }

  async run(): Promise<void> {
    try {
      await executeBuild(this);
    } finally {
      if (this.status === "running") this.status = "done";
      this.endedAt = Date.now();
      // Drop subscribers — any still-attached SSE writers will close in
      // their event handlers when they see `done`/`error`.
      this.subscribers.clear();
      this.resolveDone?.();
    }
  }
}

const activeBuilds: Map<string, BuildRunner> = new Map();
let currentBuildId: string | null = null;
// Serializes the supersede-and-start critical section in POST /vance/build so
// two near-simultaneous POSTs (multi-tab, double-submit) can't both await the
// same prev runner and then both start new runners against the same workspace.
let buildStartLock: Promise<void> = Promise.resolve();

function isLiveBuild(b: BuildRunner): boolean { return b.status === "running"; }

// 10 minutes after a build ends, evict it from the registry so the user
// can no longer reattach to ancient runs (and so memory doesn't grow).
function scheduleEviction(b: BuildRunner): void {
  const t = setTimeout(() => {
    activeBuilds.delete(b.id);
    if (currentBuildId === b.id) currentBuildId = null;
  }, 10 * 60 * 1000);
  t.unref?.();
}

function attachSseToRunner(req: Request, res: Response, runner: BuildRunner, after: number): void {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");
  // Disable proxy buffering so SSE events reach the browser immediately.
  res.setHeader("X-Accel-Buffering", "no");
  res.flushHeaders?.();

  const flush = () => {
    const r = res as unknown as { flush?: () => void };
    if (typeof r.flush === "function") r.flush();
  };

  // The first message a (re)attaching client always sees is `init`, with
  // the buildId so it can store it for resume after a disconnect.  This is
  // sent OUTSIDE the buffered event stream and is not assigned an `id:`.
  res.write(": connected\n\n");
  res.write(`data: ${JSON.stringify({ type: "init", buildId: runner.id, instruction: runner.instruction, status: runner.status, nextEventId: runner.nextEventId, baseEventId: runner.baseEventId })}\n\n`);
  flush();

  const writeIndexed = (event: BuildEventBase, id: number) => {
    res.write(`id: ${id}\n`);
    res.write(`data: ${JSON.stringify(event)}\n\n`);
    flush();
  };

  // Replay any events the client missed.  `after` is an absolute event id
  // (highest-seen + 1).  If older events were evicted by the ring buffer,
  // we silently start at baseEventId — clients only lose context that
  // would have been truncated anyway.
  const desiredStart = Math.max(0, Math.floor(after));
  const startId = Math.max(desiredStart, runner.baseEventId);
  for (let i = startId - runner.baseEventId; i < runner.events.length; i++) {
    writeIndexed(runner.events[i]!, i + runner.baseEventId);
  }

  // If the build already finished, close out cleanly — no live tail to follow.
  if (!isLiveBuild(runner)) { res.end(); return; }

  // Live tail.  Subscriber callback also closes the response when it sees a
  // terminal event so the client gets a clean EOF.
  let closed = false;
  const heartbeat = setInterval(() => { if (!closed) { res.write(": ping\n\n"); flush(); } }, 5000);
  const cleanup = () => {
    if (closed) return;
    closed = true;
    clearInterval(heartbeat);
    runner.subscribers.delete(sub);
  };
  const sub = (event: BuildEventBase, id: number) => {
    if (closed) return;
    writeIndexed(event, id);
    if (event.type === "done" || event.type === "error") {
      cleanup();
      try { res.end(); } catch { /* already ended */ }
    }
  };
  runner.subscribers.add(sub);

  // Client disconnect just unsubscribes — the runner keeps building.
  req.on("close", cleanup);
}

// The build loop itself, factored out so it can be invoked by the runner
// without owning the SSE response.  Identical semantics to the prior route
// body, but `emit`, snapshots, and history all live on `runner` so the
// work survives client disconnect.
async function executeBuild(runner: BuildRunner): Promise<void> {
  const instruction = runner.instruction;

  type UserContentPart =
    | { type: "text"; text: string }
    | { type: "image_url"; image_url: { url: string; detail?: "low" | "high" | "auto" } };
  type AiMsg =
    | { role: "system"; content: string }
    | { role: "user"; content: string | UserContentPart[] }
    | { role: "assistant"; content: string | null; tool_calls?: Array<{ id: string; type: "function"; function: { name: string; arguments: string } }> }
    | { role: "tool"; name: string; content: string; tool_call_id: string };

  const chatMessages: AiMsg[] = [
    { role: "system", content: BUILD_SYSTEM_PROMPT_BASE + formatBuildHistory() },
    { role: "user", content: instruction },
  ];

  // State now hangs off the runner so it survives client disconnect.  The
  // const aliases keep the body of this function readable / unchanged from
  // its pre-refactor form.
  const filesChanged = runner.filesChanged;
  const turnSnapshots = runner.turnSnapshots;
  let currentPhase = "";
  let lastAssistantText = "";

  const emit = (event: Record<string, unknown>): void => {
    runner.emit(event as BuildEventBase);
  };

  // Capture the original content of a file BEFORE Vance writes it, so that
  // revert_changes can restore the file's pre-turn state.  Only records the
  // first snapshot per path per turn (subsequent edits don't overwrite the
  // baseline).  originalContent === null means the file didn't exist before.
  const snapshotFile = (absPath: string, repoRel: string): void => {
    if (turnSnapshots.some((s) => s.path === repoRel)) return;
    let originalContent: string | null = null;
    try { originalContent = fs.readFileSync(absPath, "utf-8"); }
    catch { originalContent = null; }
    turnSnapshots.push({ path: repoRel, originalContent });
  };

  const setPhase = (phase: string, label: string) => {
    if (currentPhase !== phase) {
      currentPhase = phase;
      emit({ type: "phase", phase, label });
    }
  };

  // ── SAFETY NET: auto-revert ────────────────────────────────────────────────
  // Restores every file Vance touched this turn back to its pre-turn state.
  // Idempotent — only fires once per turn.  Used by the cancel / catch /
  // failed-auto-verify paths so the user is never left with half-edited,
  // broken code from a failed build.  NOTE: client disconnect no longer
  // triggers revert — the runner just keeps going.
  let reverted = false;
  let verifyToolCalled = false;
  // Hardening trackers — set by the tool dispatcher when the model voluntarily
  // calls one of these.  Auto-verify uses them to decide whether it needs to
  // FORCE the corresponding gate after the model has stopped editing.  All
  // three default to false so a model that forgets gets caught.
  let reviewToolCalled = false;
  let screenshotToolCalled = false;
  // Plan-budget gate: if create_plan returns >5 steps and the user hasn't
  // pre-approved this build, edit/write/install tools start refusing until the
  // user re-issues the instruction with an approval keyword.  Tracked here so
  // the gate persists across tool-call iterations within the same build.
  let planExceedsBudget = false;
  const planPreApproved = /\b(approved|approve|go ahead|do it|proceed|confirmed|confirm|yes please|yes go)\b/i.test(instruction);
  // Single-write guard for build history.  If multiple paths race to record
  // the outcome of this turn (e.g. client disconnects during the auto-verify
  // typecheck — close handler runs, then runShell returns and the failure
  // branch runs too), only the first one wins.  Without this, a single
  // failed turn could produce two history rows.
  let historyWritten = false;
  const writeHistoryOnce = (entry: { ts: number; instruction: string; filesChanged: string[]; summary: string; snapshots: FileSnapshot[]; screenshots?: BuildScreenshotRef[] }) => {
    if (historyWritten) return;
    historyWritten = true;
    // Always carry through the runner's captured screenshots — even cancelled
    // / auto-reverted builds may have produced screenshots before failing,
    // and the user may want to ask about them later.
    addBuildHistory({ ...entry, screenshots: entry.screenshots ?? [...runner.screenshots] });
  };
  const restoreSnapshots = (reason: string): { restored: number; deleted: number; failed: number } => {
    if (reverted || turnSnapshots.length === 0) return { restored: 0, deleted: 0, failed: 0 };
    reverted = true;
    let restored = 0, deleted = 0, failed = 0;
    for (let i = turnSnapshots.length - 1; i >= 0; i--) {
      const snap = turnSnapshots[i]!;
      const abs = path.resolve(WORKSPACE_ROOT, snap.path);
      try {
        if (snap.originalContent === null) {
          if (fs.existsSync(abs)) { fs.unlinkSync(abs); deleted++; }
        } else {
          fs.writeFileSync(abs, snap.originalContent, "utf-8");
          restored++;
        }
      } catch { failed++; }
    }
    logger.warn({ reason, restored, deleted, failed, files: turnSnapshots.map(s => s.path) }, "Vance build auto-reverted");
    turnSnapshots.length = 0;
    filesChanged.length = 0;
    return { restored, deleted, failed };
  };

  // ── Auto before/after screenshots for UI builds ───────────────────────────
  // If the user's instruction looks UI-flavored, snap a "before" picture of
  // the running frontend now and (later) an "after" once edits land. The two
  // shots get streamed back as part of the done event so chat can show a
  // visual diff without the user manually asking. Failures are warnings.
  const UI_INTENT_RX = /\b(ui|layout|chat|page|view|button|colou?r|spacing|padding|margin|bubble|avatar|composer|modal|theme|style|component|frontend|hero|nav|sidebar|footer|header|font|icon|gap|align|background|gradient|border|shadow|animation|hover|render|design)\b/i;
  const isUiIntent = UI_INTENT_RX.test(instruction);
  const captureLabeledScreenshot = async (label: string, target: string = "/"): Promise<void> => {
    try {
      const { buf, url, width, height } = await captureFrontendScreenshot({ path: target });
      const dir = path.join(SCREENSHOT_DIR, runner.id);
      fs.mkdirSync(dir, { recursive: true });
      const fname = `${runner.screenshots.length + 1}.png`;
      fs.writeFileSync(path.join(dir, fname), buf);
      const fullLabel = `${label} (${target} @ ${width}x${height})`;
      runner.screenshots.push({ path: `${runner.id}/${fname}`, label: fullLabel, ts: Date.now() });
      emit({ type: "writing", path: `(auto-${label} screenshot)`, message: `Captured ${url} — ${(buf.length / 1024).toFixed(0)}kb` });
    } catch (e) {
      logger.warn({ err: e, label, target }, "Auto build screenshot failed");
    }
  };
  // Track the in-flight "before" capture so terminal emits can await it.
  // Without this, a build that crashes or is cancelled before Playwright
  // finishes would emit error/done with an empty screenshots array even
  // though the before-shot was about to land.
  let pendingCapture: Promise<void> | null = null;
  // Map persisted screenshots to URLs that the chat client can render.
  // Always include this on terminal events (done/error) so the result card
  // has visual context regardless of how the build ended.
  const screenshotsForEvent = (): Array<{ url: string; label: string; ts: number }> =>
    runner.screenshots.map((s) => ({ url: `/api/vance/screenshots/${s.path}`, label: s.label, ts: s.ts }));
  // Await any in-flight auto-capture (with a hard 6s ceiling so a hung
  // Playwright doesn't stall the terminal emit). Always call right before
  // emitting done/error.
  const drainPendingCapture = async (): Promise<void> => {
    if (!pendingCapture) return;
    try {
      await Promise.race([
        pendingCapture,
        new Promise<void>((resolve) => setTimeout(resolve, 6_000)),
      ]);
    } catch { /* logged inside the helper */ }
    pendingCapture = null;
  };

  // Kick off in think phase
  setPhase("think", "Thinking");

  try {
    // Take the "before" snapshot up front for UI-flavored instructions.
    // Best-effort and fire-and-forget shape — runs in parallel with the LLM
    // first turn so we don't add latency to the build itself.
    if (isUiIntent) {
      pendingCapture = captureLabeledScreenshot("before", "/");
    }

    let iterations = 0;
    const MAX_ITERATIONS = 25;

    while (iterations < MAX_ITERATIONS) {
      iterations++;

      // Cancellation check.  Set when a newer build supersedes this one,
      // honored between LLM turns.  Mid-stream cancellation would require
      // an AbortController on the OpenAI request, which we skip for now.
      if (runner.cancelled) {
        runner.status = "aborted";
        const r = restoreSnapshots("build superseded by a newer instruction");
        await drainPendingCapture();
        emit({ type: "error", message: `Build cancelled — superseded by a newer instruction. Auto-reverted ${r.restored} restored / ${r.deleted} deleted.`, screenshots: screenshotsForEvent() });
        writeHistoryOnce({
          ts: Date.now(),
          instruction,
          filesChanged: [],
          summary: `(cancelled and auto-reverted: superseded by newer build)`,
          snapshots: [],
        });
        return;
      }

      // ── Stream this LLM turn ──────────────────────────────────────────────
      // Pre-flight guard: validate the OpenAI tool-call ordering invariant on
      // chatMessages before sending.  Any future code path that pushes a
      // non-tool message between assistant tool_calls and its tool results
      // will be silently repaired here (and logged) instead of crashing the
      // build with a 400.  See repairToolCallOrdering for the full contract.
      const repaired = repairToolCallOrdering(chatMessages as never);
      if (repaired.repairs.length > 0) {
        logger.warn({ buildId: runner.id, iteration: iterations, repairs: repaired.repairs }, "Vance build chatMessages required ordering repair before OpenAI call");
        chatMessages.length = 0;
        for (const m of repaired.messages) chatMessages.push(m as never);
      }
      const stream = await openai.chat.completions.create({
        model: "gpt-5.4",
        max_completion_tokens: 16384,
        messages: chatMessages,
        tools: buildTools,
        stream: true,
      });

      let fullContent = "";
      const tcBuffers = new Map<number, { id: string; name: string; args: string }>();
      let finishReason = "";

      for await (const chunk of stream) {
        const choice = chunk.choices[0];
        if (!choice) continue;
        if (choice.finish_reason) finishReason = choice.finish_reason;

        const delta = choice.delta as {
          content?: string | null;
          tool_calls?: Array<{ index: number; id?: string; function?: { name?: string; arguments?: string } }>;
        };

        if (delta?.content) {
          fullContent += delta.content;
          emit({ type: "stream", content: delta.content });
        }

        for (const tc of delta?.tool_calls ?? []) {
          if (!tcBuffers.has(tc.index)) tcBuffers.set(tc.index, { id: "", name: "", args: "" });
          const buf = tcBuffers.get(tc.index)!;
          if (tc.id) buf.id = tc.id;
          if (tc.function?.name) buf.name += tc.function.name;
          if (tc.function?.arguments) buf.args += tc.function.arguments;
        }
      }

      const rawToolCallsList = Array.from(tcBuffers.entries())
        .sort(([a], [b]) => a - b)
        .map(([, buf]) => ({ id: buf.id, type: "function" as const, function: { name: buf.name, arguments: buf.args } }));
      // Defensive normalization: drop any tool_call whose id never streamed
      // (empty buf.id).  An empty-id entry would push an unanswerable
      // tool_call into the assistant message and orphan the next turn.  This
      // belt-and-suspenders match for what repairToolCallOrdering does at the
      // top of the next turn — but doing it HERE means we never write the
      // bad assistant message to chatMessages in the first place.
      const toolCallsList = rawToolCallsList.filter((tc) => typeof tc.id === "string" && tc.id.trim().length > 0);
      if (toolCallsList.length !== rawToolCallsList.length) {
        logger.warn({ buildId: runner.id, dropped: rawToolCallsList.length - toolCallsList.length }, "Vance build dropped streamed tool_call(s) with empty IDs");
      }

      chatMessages.push({
        role: "assistant",
        content: fullContent || null,
        ...(toolCallsList.length > 0 ? { tool_calls: toolCallsList } : {}),
      });

      // ── Done — LLM chose to stop ──────────────────────────────────────────
      if (finishReason === "stop" || toolCallsList.length === 0) {
        emit({ type: "message", content: fullContent });
        if (fullContent.trim()) lastAssistantText = fullContent;
        break;
      }

      // ── Determine which phase the next tool calls belong to ───────────────
      const toolNames = toolCallsList.map((tc) => tc.function.name);
      if (toolNames.some((n) => n === "run_typecheck" || n === "run_codegen" || n === "run_db_push" || n === "git_diff" || n === "restart_api_server" || n === "review_my_changes" || n === "deep_audit" || n === "screenshot_app" || n === "run_e2e_test" || n === "get_diagnostics" || n === "parallel_verify")) {
        if (toolNames.some((n) => n === "run_typecheck" || n === "get_diagnostics" || n === "parallel_verify")) {
          verifyToolCalled = true;
        }
        if (toolNames.some((n) => n === "review_my_changes" || n === "deep_audit")) {
          reviewToolCalled = true;
        }
        if (toolNames.some((n) => n === "screenshot_app" || n === "run_e2e_test")) {
          screenshotToolCalled = true;
        }
        setPhase("verify", "Verifying");
      } else if (toolNames.some((n) => n === "revert_changes")) {
        setPhase("revert", "Reverting");
      } else if (toolNames.some((n) => n === "write_file" || n === "edit_file" || n === "create_skill" || n === "install_package")) {
        setPhase("code", "Coding");
      } else if (toolNames.some((n) => n === "create_plan" || n === "architect")) {
        setPhase("plan", "Planning");
      } else if (toolNames.some((n) => n === "read_file" || n === "list_files" || n === "grep_code" || n === "web_search" || n === "fetch_url" || n === "list_skills" || n === "load_skill" || n === "run_command" || n === "query_db" || n === "get_server_logs")) {
        setPhase("analyze", "Analyzing");
      }

      // ── Execute each tool call ────────────────────────────────────────────
      // CRITICAL ordering invariant: OpenAI requires that every tool_call_id
      // in the most recent assistant message be answered by a tool message
      // BEFORE any non-tool message intervenes.  If the model emits parallel
      // tool_calls and one of them is screenshot_app/run_e2e_test, the
      // resulting vision-image USER message must NOT be pushed between two
      // tool result messages — that interrupts the tool block and OpenAI 400s
      // on the next turn ("tool_call_ids did not have response messages: ...")
      // which is exactly the failure we saw in build #50 and #53.  Collect
      // vision messages here and flush them AFTER all tool results are pushed.
      const pendingVisionMessages: Array<{ role: "user"; content: UserContentPart[] }> = [];
      for (const tc of toolCallsList) {
        // Honor cancellation between tool calls — without this, a cancel that
        // arrives mid-turn would still let every queued tool (including
        // edit_file/write_file) execute before the outer loop's check fires.
        if (runner.cancelled) {
          runner.status = "aborted";
          const r = restoreSnapshots("build cancelled mid-turn");
          await drainPendingCapture();
          emit({ type: "error", message: `Build cancelled. Auto-reverted ${r.restored} restored / ${r.deleted} deleted.`, screenshots: screenshotsForEvent() });
          writeHistoryOnce({
            ts: Date.now(),
            instruction,
            filesChanged: [],
            summary: `(cancelled mid-turn and auto-reverted)`,
            snapshots: [],
          });
          return;
        }
        const toolName = tc.function.name;
        let args: Record<string, unknown> = {};
        try { args = JSON.parse(tc.function.arguments) as Record<string, unknown>; } catch {}

        let toolResult = "";
        // Images this tool call wants to feed back to the model on the next
        // turn (currently only screenshot_app / run_e2e_test populate this).
        const visionImages: Array<{ label: string; b64: string }> = [];

        // Plan-budget gate.  Two ways the model can exceed the safety
        // budget on an unapproved build:
        //   1. create_plan returned >5 steps  → planExceedsBudget set there
        //   2. Model skipped create_plan entirely (or split it into chunks)
        //      and just kept editing — caught here when the running tally
        //      of distinct files mutated reaches 5 and the next call is
        //      another mutation.
        // Both paths funnel into the same refusal so the model can't bypass
        // the gate by avoiding create_plan or chunking it.
        if (
          !planPreApproved &&
          !planExceedsBudget &&
          filesChanged.length >= 5 &&
          (toolName === "edit_file" || toolName === "write_file" || toolName === "install_package")
        ) {
          planExceedsBudget = true;
        }
        if (planExceedsBudget && (toolName === "edit_file" || toolName === "write_file" || toolName === "install_package")) {
          toolResult = `Refused: this build has hit the 5-file safety budget and the user hasn't approved a larger scope yet. STOP calling mutation tools. Write a final assistant message that summarises which files you've already touched, what's left, and asks the user to re-send the instruction containing "approved" or "go ahead" if they want you to keep going.`;
          chatMessages.push({ role: "tool", name: toolName, content: toolResult, tool_call_id: tc.id });
          continue;
        }

        // GUARANTEE every tool_call gets a matching tool result message —
        // OpenAI rejects (400 "An assistant message with 'tool_calls' must be
        // followed by tool messages") if any orphan tool_call leaks into the
        // next turn.  Without this wrapper, an unhandled throw inside any
        // tool handler would skip the role:"tool" push at the bottom of the
        // loop, corrupting the conversation history for the rest of the
        // build.  We catch, stringify, and continue — the model gets a
        // proper error result and can decide what to do.
        try {
        if (toolName === "list_files") {
          const target = args.dir ? safePath(String(args.dir)) : WORKSPACE_ROOT;
          emit({ type: "reading", path: args.dir ? String(args.dir) : ".", message: "Listing files" });
          if (target) {
            const files = listFilesRecursive(target, target);
            const capped = files.length > 500 ? files.slice(0, 500).concat([`… ${files.length - 500} more truncated`]) : files;
            toolResult = capped.length ? capped.join("\n") : "(empty)";
          } else {
            toolResult = "Error: path outside repo or denied (node_modules/.git/dist/.local/etc.)";
          }
        } else if (toolName === "grep_code") {
          const pattern = String(args.pattern ?? "");
          if (!pattern) {
            toolResult = "Error: pattern is required";
          } else {
            const scope = args.path ? String(args.path) : "(whole repo)";
            emit({ type: "reading", path: scope, message: `grep "${pattern.slice(0, 80)}"` });
            toolResult = grepCode(pattern, {
              path: typeof args.path === "string" ? args.path : undefined,
              glob: typeof args.glob === "string" ? args.glob : undefined,
              caseInsensitive: Boolean(args.caseInsensitive),
              maxResults: typeof args.maxResults === "number" ? args.maxResults : undefined,
            });
          }
        } else if (toolName === "read_file") {
          const resolved = safePath(String(args.path ?? ""));
          if (!resolved) {
            toolResult = "Error: path outside repo or denied";
          } else {
            const rel = path.relative(WORKSPACE_ROOT, resolved);
            const offsetArg = typeof args.offset === "number" && args.offset > 0 ? Math.floor(args.offset) : null;
            const limitArg = typeof args.limit === "number" && args.limit > 0 ? Math.min(Math.floor(args.limit), 2000) : null;
            emit({ type: "reading", path: rel + (offsetArg ? `:${offsetArg}${limitArg ? `+${limitArg}` : ""}` : "") });
            try {
              const stat = fs.statSync(resolved);
              if (stat.size > 500_000 && !offsetArg && !limitArg) {
                toolResult = `Error: file too large (${(stat.size / 1024).toFixed(0)}kb). Use grep_code to find the relevant section, then read_file with offset/limit.`;
              } else {
                const content = fs.readFileSync(resolved, "utf-8");
                if (offsetArg || limitArg) {
                  const lines = content.split("\n");
                  const start = (offsetArg ?? 1) - 1;
                  const end = limitArg ? start + limitArg : lines.length;
                  const slice = lines.slice(start, end);
                  // Prefix line numbers so the model can build correct line-based references.
                  const numbered = slice.map((l, i) => `${String(start + i + 1).padStart(6, " ")}→${l}`).join("\n");
                  const moreBefore = start > 0 ? `(... ${start} earlier line${start === 1 ? "" : "s"} omitted ...)\n` : "";
                  const moreAfter = end < lines.length ? `\n(... ${lines.length - end} more line${lines.length - end === 1 ? "" : "s"} omitted ...)` : "";
                  toolResult = moreBefore + numbered + moreAfter;
                } else {
                  toolResult = content;
                }
              }
            } catch { toolResult = "Error: file not found"; }
          }
        } else if (toolName === "get_recent_errors") {
          emit({ type: "reading", path: "(runtime errors)", message: "Fetching recent errors" });
          toolResult = formatErrorRingForAgent();
        } else if (toolName === "create_plan") {
          const steps = (args.steps as string[] | undefined) ?? [];
          const reasoning = args.reasoning as string | undefined;
          emit({ type: "plan", steps, reasoning });
          // Plan-budget gate.  A plan with >5 steps is "big enough to wreck
          // things if the model misread the request" — refuse to start
          // editing until the user re-issues the instruction with an
          // explicit approval keyword.  Pre-approved builds (instruction
          // already contains "approved" / "go ahead" / etc.) bypass.
          if (steps.length > 5 && !planPreApproved) {
            planExceedsBudget = true;
            toolResult = `Plan recorded — but it lists ${steps.length} steps, which exceeds the 5-step safety budget for an unconfirmed build.\n\nDO NOT call edit_file, write_file, or install_package now. Instead, write a final assistant message that:\n  1. Summarises which files you'll touch and why\n  2. Calls out anything risky (schema changes, refactors, deletions, cross-package edits)\n  3. Asks the user to re-send the instruction with the word "approved" or "go ahead" if they want you to proceed\n\nThis gate exists so big multi-file changes get a confirmation step instead of going through silently. Stop now and write that summary.`;
          } else {
            toolResult = "Plan recorded. Proceed to CODE phase.";
          }
        } else if (toolName === "edit_file") {
          const resolved = safePath(String(args.path ?? ""));
          const oldStr = String(args.old_string ?? "");
          const newStr = String(args.new_string ?? "");
          const replaceAll = Boolean(args.replace_all);
          if (!resolved) {
            toolResult = "Error: path outside repo or denied";
          } else if (!oldStr) {
            toolResult = "Error: old_string is required and must be non-empty";
          } else {
            const rel = path.relative(WORKSPACE_ROOT, resolved);
            emit({ type: "writing", path: rel + (replaceAll ? " (replace_all)" : "") });
            try {
              const original = fs.readFileSync(resolved, "utf-8");
              const firstIdx = original.indexOf(oldStr);
              if (firstIdx === -1) {
                toolResult = "Error: old_string not found in file. Did you copy it verbatim from a read_file call? Whitespace and line endings must match exactly.";
              } else if (!replaceAll && original.indexOf(oldStr, firstIdx + 1) !== -1) {
                toolResult = "Error: old_string matched MORE THAN ONCE. Add more surrounding context (5–10 lines) to make it unique, OR pass replace_all: true to replace every occurrence.";
              } else {
                snapshotFile(resolved, rel);
                let updated: string;
                let replacements: number;
                if (replaceAll) {
                  // Use split/join (no regex needed) to do literal replace_all.
                  const parts = original.split(oldStr);
                  replacements = parts.length - 1;
                  updated = parts.join(newStr);
                } else {
                  updated = original.slice(0, firstIdx) + newStr + original.slice(firstIdx + oldStr.length);
                  replacements = 1;
                }
                fs.writeFileSync(resolved, updated, "utf-8");
                toolResult = `Edited successfully (${replacements} replacement${replacements === 1 ? "" : "s"}, ${oldStr.length} → ${newStr.length} chars each)`;
                if (!filesChanged.includes(rel)) filesChanged.push(rel);
              }
            } catch (err) {
              toolResult = `Error: ${err instanceof Error ? err.message : String(err)}`;
            }
          }
        } else if (toolName === "write_file") {
          const resolved = safePath(String(args.path ?? ""));
          if (!resolved) {
            toolResult = "Error: path outside repo or denied";
          } else {
            const rel = path.relative(WORKSPACE_ROOT, resolved);
            emit({ type: "writing", path: rel });
            try {
              snapshotFile(resolved, rel);
              fs.mkdirSync(path.dirname(resolved), { recursive: true });
              fs.writeFileSync(resolved, String(args.content ?? ""), "utf-8");
              toolResult = "Written successfully";
              if (!filesChanged.includes(rel)) filesChanged.push(rel);
            } catch (err) {
              toolResult = `Error: ${err instanceof Error ? err.message : String(err)}`;
            }
          }
        } else if (toolName === "run_typecheck") {
          const pkgArg = typeof args.package === "string" ? args.package.trim() : "";
          const filter = pkgArg ? (PACKAGE_FILTERS[pkgArg] ?? (pkgArg.startsWith("@workspace/") ? pkgArg : null)) : null;
          if (pkgArg && !filter) {
            toolResult = `Error: unknown package "${pkgArg}". Valid: ${Object.keys(PACKAGE_FILTERS).join(", ")}`;
          } else {
            const cmdArgs = filter
              ? ["--filter", filter, "run", "typecheck"]
              : ["run", "typecheck"];
            emit({ type: "reading", path: pkgArg || "(whole repo)", message: `pnpm ${cmdArgs.join(" ")}` });
            const r = await runShell("pnpm", cmdArgs, { timeoutMs: 90_000 });
            const combined = (r.stdout + (r.stderr ? "\n" + r.stderr : "")).trim();
            // Cherry-pick the actual TS errors (lines containing "error TS").
            const errLines = combined.split("\n").filter((l) => /error TS\d+/.test(l) || /\.tsx?\(\d+,\d+\)/.test(l));
            if (r.timedOut) {
              toolResult = `Typecheck timed out after 90s. Partial output:\n${combined.slice(-4000)}`;
            } else if (r.code === 0) {
              toolResult = `✓ Typecheck passed${pkgArg ? ` for ${pkgArg}` : ""}.`;
            } else {
              const summary = errLines.length > 0 ? errLines.slice(0, 60).join("\n") : combined.slice(-4000);
              toolResult = `✗ Typecheck failed (exit ${r.code}). Errors:\n${summary}\n\nFix these with edit_file and run typecheck again.`;
            }
          }
        } else if (toolName === "run_codegen") {
          emit({ type: "reading", path: "lib/api-spec", message: "pnpm run codegen" });
          const r = await runShell("pnpm", ["--filter", "@workspace/api-spec", "run", "codegen"], { timeoutMs: 60_000 });
          const out = (r.stdout + (r.stderr ? "\n" + r.stderr : "")).trim();
          if (r.timedOut) toolResult = `Codegen timed out. Partial:\n${out.slice(-2000)}`;
          else if (r.code === 0) toolResult = `✓ Codegen complete.\n${out.slice(-1500)}`;
          else toolResult = `✗ Codegen failed (exit ${r.code}):\n${out.slice(-3000)}`;
        } else if (toolName === "run_db_push") {
          emit({ type: "reading", path: "lib/db", message: "pnpm run push" });
          const r = await runShell("pnpm", ["--filter", "@workspace/db", "run", "push"], { timeoutMs: 30_000 });
          const out = (r.stdout + (r.stderr ? "\n" + r.stderr : "")).trim();
          if (r.timedOut) toolResult = `db push timed out. Partial:\n${out.slice(-2000)}`;
          else if (r.code === 0) toolResult = `✓ DB schema pushed.\n${out.slice(-1500)}`;
          else toolResult = `✗ DB push failed (exit ${r.code}):\n${out.slice(-3000)}`;
        } else if (toolName === "git_diff") {
          const pathArg = typeof args.path === "string" ? args.path : "";
          const resolvedPath = pathArg ? safePath(pathArg) : null;
          if (pathArg && !resolvedPath) {
            toolResult = "Error: path outside repo or denied";
          } else {
            const gitArgs = ["diff", "--no-color", "--unified=3"];
            if (resolvedPath) gitArgs.push("--", path.relative(WORKSPACE_ROOT, resolvedPath));
            emit({ type: "reading", path: pathArg || "(all changes)", message: "git diff" });
            const r = await runShell("git", gitArgs, { timeoutMs: 10_000 });
            const out = (r.stdout + (r.stderr ? "\n" + r.stderr : "")).trim();
            if (r.code === 0 && !out) toolResult = "(no uncommitted changes)";
            else if (r.code === 0) toolResult = out.length > 50_000 ? out.slice(0, 50_000) + "\n…[truncated, diff is huge — scope with `path` argument]" : out;
            else toolResult = `git diff failed (exit ${r.code}): ${out.slice(-2000)}`;
          }
        } else if (toolName === "revert_changes") {
          const scope = typeof args.scope === "string" ? args.scope : "current_turn";
          let toRevert: FileSnapshot[] = [];
          let scopeLabel = "";
          if (scope === "current_turn") {
            toRevert = [...turnSnapshots];
            scopeLabel = "current turn";
          } else if (scope === "last_build") {
            const last = buildHistory[buildHistory.length - 1];
            toRevert = last ? [...last.snapshots] : [];
            scopeLabel = "last completed build";
          } else {
            toolResult = `Error: unknown scope "${scope}". Use "current_turn" or "last_build".`;
          }
          if (!toolResult) {
            if (toRevert.length === 0) {
              toolResult = `Nothing to revert in ${scopeLabel}.`;
            } else {
              emit({ type: "writing", path: `(revert: ${scopeLabel})`, message: `Reverting ${toRevert.length} file(s)` });
              const restored: string[] = [];
              const deleted: string[] = [];
              const failed: string[] = [];
              // Reverse order so file creations are undone before parent dirs would be empty
              for (let i = toRevert.length - 1; i >= 0; i--) {
                const snap = toRevert[i]!;
                const abs = path.resolve(WORKSPACE_ROOT, snap.path);
                try {
                  if (snap.originalContent === null) {
                    if (fs.existsSync(abs)) { fs.unlinkSync(abs); deleted.push(snap.path); }
                  } else {
                    fs.writeFileSync(abs, snap.originalContent, "utf-8");
                    restored.push(snap.path);
                  }
                } catch (e) {
                  failed.push(`${snap.path}: ${e instanceof Error ? e.message : String(e)}`);
                }
              }
              if (scope === "current_turn") {
                turnSnapshots.length = 0;
                filesChanged.length = 0;
              }
              const parts = [
                restored.length ? `restored ${restored.length}: ${restored.join(", ")}` : "",
                deleted.length ? `deleted ${deleted.length}: ${deleted.join(", ")}` : "",
                failed.length ? `failed ${failed.length}: ${failed.join("; ")}` : "",
              ].filter(Boolean);
              toolResult = `✓ Revert complete. ${parts.join(" | ")}`;
            }
          }
        } else if (toolName === "restart_api_server") {
          runner.pendingRestart = true;
          emit({ type: "writing", path: "(api-server)", message: "Will restart after this turn" });
          toolResult = "✓ API server will restart in ~1.5s after this build turn completes. The next build request will hit the freshly restarted server. Continue with your summary now.";
        } else if (toolName === "web_search") {
          const query = String(args.query ?? "").trim();
          if (!query) {
            toolResult = "Error: query is required";
          } else {
            emit({ type: "reading", path: "(web)", message: `Searching: ${query.slice(0, 80)}` });
            const { sources, error } = await runWebSearch(query);
            if (error || sources.length === 0) {
              toolResult = `No results for "${query}"${error ? ` (${error})` : ""}. Refine the query or use fetch_url on a specific docs URL you know.`;
            } else {
              const lines = sources.map((s, i) => {
                const body = s.pageText?.trim().slice(0, 1200) || s.snippet;
                return `[${i + 1}] ${s.title}\n${s.url}\n${body}`;
              });
              toolResult = `Web results for "${query}" (top ${sources.length}, full text fetched for top 2):\n\n${lines.join("\n\n---\n\n")}\n\nUse fetch_url on any URL above for the full page.`;
            }
          }
        } else if (toolName === "query_db") {
          const sqlText = String(args.sql ?? "").trim();
          if (!sqlText) {
            toolResult = "Error: sql is required";
          } else {
            // Read-only enforcement: must start with SELECT/WITH/EXPLAIN/SHOW
            // and must not contain any mutating keyword as a whole word.
            const head = sqlText.replace(/^\s*\(*/, "").slice(0, 16).toUpperCase();
            const isReadStart = /^(SELECT|WITH|EXPLAIN|SHOW|TABLE|VALUES)\b/.test(head);
            const writeKw = /\b(INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|TRUNCATE|GRANT|REVOKE|COPY|CALL|MERGE|VACUUM|REINDEX|CLUSTER|REFRESH|COMMENT|LOCK|SET|RESET|BEGIN|COMMIT|ROLLBACK|SAVEPOINT|DECLARE|FETCH|MOVE|CLOSE|LISTEN|NOTIFY|UNLISTEN|DO|EXECUTE|PREPARE|DEALLOCATE)\b/i;
            // Strip string literals & comments before checking, so "INSERT" inside a string literal doesn't trip us.
            const stripped = sqlText
              .replace(/--[^\n]*/g, "")
              .replace(/\/\*[\s\S]*?\*\//g, "")
              .replace(/'(?:''|[^'])*'/g, "''")
              .replace(/"(?:""|[^"])*"/g, '""');
            if (!isReadStart) {
              toolResult = `Error: query_db is read-only. Statement must start with SELECT, WITH, EXPLAIN, or SHOW. (Got: ${head.split(/\s/)[0]})`;
            } else if (writeKw.test(stripped)) {
              toolResult = `Error: query_db is read-only. Detected mutating keyword in statement. Use run_db_push for schema changes or edit_file to change application code that writes data.`;
            } else if (sqlText.length > 4000) {
              toolResult = `Error: sql too long (${sqlText.length} chars, max 4000).`;
            } else {
              emit({ type: "reading", path: "(db)", message: `Querying: ${sqlText.slice(0, 80).replace(/\s+/g, " ")}` });
              try {
                const client = await pool.connect();
                try {
                  // Wrap in a read-only transaction so even if regex misses something, the DB blocks writes.
                  await client.query("BEGIN READ ONLY");
                  await client.query("SET LOCAL statement_timeout = '5s'");
                  const result = await client.query(sqlText);
                  await client.query("ROLLBACK");
                  const rows = (result.rows as Record<string, unknown>[]).slice(0, 200);
                  const truncated = (result.rowCount ?? rows.length) > 200;
                  const fields = result.fields?.map((f) => f.name) ?? [];
                  toolResult = `OK — ${rows.length} row${rows.length === 1 ? "" : "s"}${truncated ? ` (truncated from ${result.rowCount})` : ""}.\nColumns: ${fields.join(", ")}\n\n${JSON.stringify(rows, null, 2).slice(0, 12000)}`;
                } finally {
                  try { await client.query("ROLLBACK"); } catch { /* noop */ }
                  client.release();
                }
              } catch (e) {
                toolResult = `Query failed: ${e instanceof Error ? e.message : String(e)}`;
              }
            }
          }
        } else if (toolName === "get_server_logs") {
          const limit = Math.min(Math.max(typeof args.limit === "number" ? Math.floor(args.limit) : 50, 1), 500);
          const level = typeof args.level === "string" ? args.level : undefined;
          const search = typeof args.search === "string" ? args.search : undefined;
          emit({ type: "reading", path: "(server logs)", message: `Reading last ${limit} log entries${level ? ` at level ${level}+` : ""}${search ? ` matching "${search.slice(0, 40)}"` : ""}` });
          const entries = getRecentLogs({ limit, level, search });
          if (entries.length === 0) {
            toolResult = `No log entries match (filters: limit=${limit}${level ? `, level=${level}+` : ""}${search ? `, search="${search}"` : ""}). Buffer holds the last 500 server log lines since boot. If the api-server restarted recently the buffer may be empty.`;
          } else {
            const lines = entries.map((e) => {
              const t = new Date(e.ts).toISOString().slice(11, 23);
              const obj = e.obj ? ` ${e.obj}` : "";
              return `${t} [${e.level.toUpperCase()}] ${e.msg}${obj}`;
            });
            toolResult = `Recent server logs (${entries.length} entr${entries.length === 1 ? "y" : "ies"}, oldest first):\n\n${lines.join("\n")}`;
          }
        } else if (toolName === "architect") {
          const taskDesc = String(args.task ?? "").trim();
          const seedFiles: string[] = Array.isArray(args.context_files)
            ? args.context_files.filter((s): s is string => typeof s === "string").slice(0, 8)
            : [];
          const maxIters = Math.min(Math.max(typeof args.maxIterations === "number" ? Math.floor(args.maxIterations) : 8, 3), 12);
          if (!taskDesc) {
            toolResult = "Error: task is required — describe the design problem you want architected (e.g. 'how should I refactor the build runner to support parallel turns?').";
          } else {
            emit({ type: "reading", path: "(architect)", message: "Spawning architect agent" });
            const archTools = [
              { type: "function" as const, function: { name: "grep_code", description: "Ripgrep across the repo. Returns file:line:match.", parameters: { type: "object", properties: { pattern: { type: "string" }, path: { type: "string" }, glob: { type: "string" }, caseInsensitive: { type: "boolean" }, maxResults: { type: "number" } }, required: ["pattern"] } } },
              { type: "function" as const, function: { name: "read_file", description: "Read a file (with optional offset/limit for large files).", parameters: { type: "object", properties: { path: { type: "string" }, offset: { type: "number" }, limit: { type: "number" } }, required: ["path"] } } },
              { type: "function" as const, function: { name: "list_files", description: "Recursively list files under a directory.", parameters: { type: "object", properties: { dir: { type: "string" } }, required: [] } } },
              { type: "function" as const, function: { name: "finish_plan", description: "Call this when you have completed your architectural analysis and are ready to deliver the design recommendation.", parameters: { type: "object", properties: { plan: { type: "string", description: "Your design recommendation. Structure: (1) Problem restated, (2) Constraints discovered from the code, (3) 2-3 viable approaches with trade-offs, (4) Recommended approach with concrete file-level changes (paths + what to add/modify), (5) Gotchas / things that will bite, (6) Suggested implementation order. Be concrete — reference actual files and functions you read, not generic advice." } }, required: ["plan"] } } },
            ];
            const archSystem = `You are a senior staff engineer giving architectural design guidance to another AI agent that is about to implement something hard.

Your job is NOT to write the code. Your job is to:
1. Understand the existing codebase enough to give grounded advice (use grep_code + read_file freely; don't guess).
2. Identify constraints the implementer might miss (existing patterns, naming conventions, hidden coupling, perf/cost concerns, security boundaries).
3. Propose 2-3 viable approaches with honest trade-offs (don't pretend there's only one way).
4. Recommend ONE approach concretely — file paths, specific functions to touch, schema changes if any, ordering of work.
5. Surface the gotchas that will bite during implementation (race conditions, migration ordering, type contract drift, etc).

You have read-only tools. You CANNOT edit files — your output is purely advice. Be direct, opinionated, and concrete. Vague advice ("consider modularity", "add tests") is useless — name the file, name the function, name the approach.

You have ${maxIters} tool-call rounds. End by calling finish_plan with your full design recommendation.`;
            const archUser = `# Design problem
${taskDesc}

${seedFiles.length ? `# Suggested starting files\n${seedFiles.map((s) => `- ${s}`).join("\n")}\n\n` : ""}# Original build instruction (context)
${instruction}

Begin your analysis. Read the relevant code first, then propose.`;
            const archMessages: Array<{ role: "system" | "user" | "assistant" | "tool"; content: string; tool_calls?: unknown; tool_call_id?: string; name?: string }> = [
              { role: "system", content: archSystem },
              { role: "user", content: archUser },
            ];
            let finalPlan = "";
            let archErr: string | null = null;
            try {
              for (let iter = 0; iter < maxIters && !finalPlan && !archErr; iter++) {
                if (runner.cancelled) { archErr = "Architect cancelled by user."; break; }
                const resp = await openai.chat.completions.create({
                  model: "gpt-5.4",
                  max_completion_tokens: 4000,
                  tools: archTools,
                  tool_choice: iter === maxIters - 1 ? { type: "function", function: { name: "finish_plan" } } : "auto",
                  messages: archMessages as never,
                });
                const msg = resp.choices[0]?.message;
                if (!msg) { archErr = "Architect returned no message."; break; }
                const calls = msg.tool_calls ?? [];
                if (!calls.length) {
                  archMessages.push({ role: "assistant", content: msg.content ?? "" });
                  finalPlan = (msg.content ?? "").trim() || "(architect returned no plan)";
                  break;
                }
                const normalized = calls.flatMap((tc) => {
                  const id = typeof tc.id === "string" && tc.id.trim() ? tc.id.trim() : "";
                  if (!id) return [];
                  return [{ ...tc, id }];
                });
                if (!normalized.length) {
                  archMessages.push({ role: "assistant", content: msg.content ?? "" });
                  archErr = "Architect returned tool calls without valid IDs.";
                  break;
                }
                // Iterate the normalized list (not raw `calls`) so an empty-id
                // entry doesn't slip into the assistant message + tool-result
                // pair below — OpenAI rejects those as orphan tool_call_ids.
                const pending: Array<{ role: "tool"; tool_call_id: string; name: string; content: string }> = [];
                for (const tc of normalized) {
                  if (runner.cancelled) { archErr = "Architect cancelled by user."; break; }
                  if (tc.type !== "function") {
                    pending.push({ role: "tool", tool_call_id: tc.id, name: "unknown", content: `Error: unsupported tool type` });
                    continue;
                  }
                  const tn = tc.function.name;
                  let ta: Record<string, unknown> = {};
                  try { ta = JSON.parse(tc.function.arguments || "{}"); } catch { /* noop */ }
                  let tr = "";
                  if (tn === "finish_plan") {
                    finalPlan = String((ta as { plan?: string }).plan ?? "(architect called finish_plan with no plan)").trim();
                    tr = "Plan received.";
                  } else if (tn === "grep_code") {
                    const pattern = String(ta.pattern ?? "");
                    if (!pattern) tr = "Error: pattern required";
                    else {
                      const rgArgs: string[] = ["-n", "--no-heading"];
                      if (ta.caseInsensitive) rgArgs.push("-i");
                      if (typeof ta.glob === "string" && ta.glob.trim()) { rgArgs.push("-g", ta.glob); }
                      const maxR = Math.min(Math.max(typeof ta.maxResults === "number" ? ta.maxResults : 60, 1), 200);
                      rgArgs.push("-m", String(maxR));
                      rgArgs.push(pattern);
                      const targetPath = typeof ta.path === "string" && ta.path.trim() ? ta.path.trim() : ".";
                      rgArgs.push(targetPath);
                      const r = await runShell("rg", rgArgs, { timeoutMs: 15_000 });
                      const out = (r.stdout || r.stderr || "").trim();
                      tr = out.length > 12_000 ? out.slice(0, 12_000) + "\n…[truncated]" : (out || "(no matches)");
                    }
                  } else if (tn === "read_file") {
                    const p = String(ta.path ?? "");
                    if (!p) tr = "Error: path required";
                    else {
                      try {
                        const abs = path.resolve(WORKSPACE_ROOT, p);
                        if (!abs.startsWith(WORKSPACE_ROOT)) tr = "Error: path outside workspace";
                        else {
                          const content = fs.readFileSync(abs, "utf-8");
                          const offset = typeof ta.offset === "number" ? Math.max(0, Math.floor(ta.offset)) : 0;
                          const limit = typeof ta.limit === "number" ? Math.min(Math.max(Math.floor(ta.limit), 1), 1500) : 1500;
                          const lines = content.split("\n");
                          const slice = lines.slice(offset, offset + limit);
                          tr = slice.map((l, i) => `${String(offset + i + 1).padStart(5, " ")}: ${l}`).join("\n");
                          if (offset + limit < lines.length) tr += `\n…[${lines.length - offset - limit} more lines]`;
                        }
                      } catch (e) { tr = `Error: ${e instanceof Error ? e.message : String(e)}`; }
                    }
                  } else if (tn === "list_files") {
                    const dir = typeof ta.dir === "string" && ta.dir.trim() ? ta.dir.trim() : ".";
                    const r = await runShell("find", [dir, "-type", "f", "-not", "-path", "*/node_modules/*", "-not", "-path", "*/.git/*", "-not", "-path", "*/dist/*"], { timeoutMs: 8000 });
                    const out = (r.stdout || "").trim();
                    tr = out.length > 8000 ? out.slice(0, 8000) + "\n…[truncated]" : (out || "(empty)");
                  } else {
                    tr = `Error: unknown tool "${tn}"`;
                  }
                  pending.push({ role: "tool", tool_call_id: tc.id, name: tn, content: tr.slice(0, 30_000) });
                }
                archMessages.push({ role: "assistant", content: msg.content ?? "", tool_calls: normalized });
                for (const p of pending) archMessages.push(p);
              }
            } catch (e) {
              archErr = `Architect failed: ${e instanceof Error ? e.message : String(e)}`;
            }
            toolResult = archErr ? archErr : `Architect's plan:\n\n${finalPlan}\n\n(Recommendation above is advice only — you still own the implementation.)`;
          }
        } else if (toolName === "fetch_url") {
          const url = String(args.url ?? "").trim();
          let blocked = false;
          let host = "";
          try {
            const u = new URL(url);
            host = u.hostname.toLowerCase();
            if (u.protocol !== "https:" && u.protocol !== "http:") blocked = true;
            if (host === "localhost" || host === "0.0.0.0" || host.endsWith(".local")) blocked = true;
            if (/^127\./.test(host) || /^10\./.test(host) || /^192\.168\./.test(host) ||
                /^172\.(1[6-9]|2\d|3[01])\./.test(host) || host === "169.254.169.254") blocked = true;
          } catch { blocked = true; }
          if (blocked) {
            toolResult = "Error: URL must be a public https:// URL (localhost, private IPs, and metadata endpoints are refused).";
          } else {
            emit({ type: "reading", path: host, message: `Fetching ${url.slice(0, 80)}` });
            try {
              const r = await fetch(url, {
                signal: AbortSignal.timeout(15_000),
                headers: { "User-Agent": "VanceBuildAgent/1.0", "Accept": "text/html,text/plain,application/json,*/*" },
                redirect: "follow",
              });
              const ct = r.headers.get("content-type") ?? "";
              if (!r.ok) {
                toolResult = `HTTP ${r.status} ${r.statusText} from ${url}`;
              } else {
                let body = await r.text();
                if (body.length > 80_000) body = body.slice(0, 80_000) + "\n…[truncated, page is huge]";
                // Cheap HTML→text strip if it looks like HTML
                if (ct.includes("text/html") || /^\s*<!doctype html|<html/i.test(body)) {
                  body = body
                    .replace(/<script[\s\S]*?<\/script>/gi, "")
                    .replace(/<style[\s\S]*?<\/style>/gi, "")
                    .replace(/<noscript[\s\S]*?<\/noscript>/gi, "")
                    .replace(/<[^>]+>/g, " ")
                    .replace(/&nbsp;/g, " ")
                    .replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">")
                    .replace(/&quot;/g, '"').replace(/&#39;/g, "'")
                    .replace(/[ \t]+/g, " ")
                    .replace(/\n\s*\n\s*\n+/g, "\n\n")
                    .trim();
                }
                toolResult = `Fetched ${url} (${ct}, ${body.length} chars):\n\n${body}`;
              }
            } catch (e) {
              toolResult = `Fetch failed: ${e instanceof Error ? e.message : String(e)}`;
            }
          }
        } else if (toolName === "review_my_changes") {
          const focus = typeof args.focus === "string" ? args.focus.trim() : "";
          emit({ type: "reading", path: "(reviewer)", message: "Spawning reviewer agent" });
          // Pull the current diff inline
          const diffR = await runShell("git", ["diff", "--no-color", "--unified=5"], { timeoutMs: 10_000 });
          const diff = (diffR.stdout + diffR.stderr).trim();
          if (!diff) {
            toolResult = "Reviewer says: no uncommitted changes to review yet.";
          } else {
            const diffSlice = diff.length > 60_000 ? diff.slice(0, 60_000) + "\n…[diff truncated]" : diff;
            try {
              const reviewerSystem = `You are a senior staff engineer doing a focused code review on a small, in-progress build by another AI agent. The agent is about to declare its task done. Your job: catch real bugs the agent missed.

Look for: logic errors, off-by-one, missing null/empty checks, async/race conditions, regressions in untouched code paths, security issues (path traversal, injection, leaked secrets, missing auth), broken contracts (caller expectations, API spec mismatches), missing error handling, and forgotten requirements from the original instruction.

Ignore: style nits, naming preferences, missing comments, "should add tests" — only flag REAL issues. If the diff genuinely looks fine, say so in one sentence.

Output format: a SHORT bulleted list of concrete issues, each with the file/line and a one-sentence fix. End with a single line: "VERDICT: SHIP" or "VERDICT: FIX REQUIRED".`;
              const reviewerUser = `# Original instruction
${instruction}

# Focus
${focus || "(general review)"}

# Diff
\`\`\`diff
${diffSlice}
\`\`\``;
              const reviewResp = await openai.chat.completions.create({
                model: "gpt-5.4",
                max_completion_tokens: 1200,
                messages: [
                  { role: "system", content: reviewerSystem },
                  { role: "user", content: reviewerUser },
                ],
              });
              const review = reviewResp.choices[0]?.message?.content?.trim() ?? "(reviewer returned no content)";
              toolResult = `Reviewer report:\n\n${review}`;
            } catch (e) {
              toolResult = `Reviewer failed: ${e instanceof Error ? e.message : String(e)}. Continue without review.`;
            }
          }
        } else if (toolName === "deep_audit") {
          const focus = typeof args.focus === "string" ? args.focus.trim() : "";
          const seedFiles: string[] = Array.isArray(args.seedFiles)
            ? args.seedFiles.filter((s): s is string => typeof s === "string").slice(0, 8)
            : [];
          const maxIters = Math.min(Math.max(typeof args.maxIterations === "number" ? Math.floor(args.maxIterations) : 10, 3), 16);
          emit({ type: "reading", path: "(auditor)", message: "Spawning deep auditor agent" });

          // Pull current diff inline so the auditor has change context up front.
          const diffR0 = await runShell("git", ["diff", "--no-color", "--unified=3"], { timeoutMs: 10_000 });
          const diff0 = (diffR0.stdout + diffR0.stderr).trim();
          const diffSlice0 = diff0.length > 30_000 ? diff0.slice(0, 30_000) + "\n…[diff truncated]" : diff0;

          const auditorTools = [
            { type: "function" as const, function: { name: "grep_code", description: "Ripgrep across the repo. Returns file:line:match.", parameters: { type: "object", properties: { pattern: { type: "string" }, path: { type: "string" }, glob: { type: "string" }, caseInsensitive: { type: "boolean" }, maxResults: { type: "number" } }, required: ["pattern"] } } },
            { type: "function" as const, function: { name: "read_file", description: "Read a file (with optional offset/limit for large files).", parameters: { type: "object", properties: { path: { type: "string" }, offset: { type: "number" }, limit: { type: "number" } }, required: ["path"] } } },
            { type: "function" as const, function: { name: "list_files", description: "Recursively list files under a directory.", parameters: { type: "object", properties: { dir: { type: "string" } }, required: [] } } },
            { type: "function" as const, function: { name: "git_diff", description: "Show uncommitted git diff (optionally for a specific path).", parameters: { type: "object", properties: { path: { type: "string" } }, required: [] } } },
            { type: "function" as const, function: { name: "finish_audit", description: "Call this when you have completed your audit and are ready to deliver the report.", parameters: { type: "object", properties: { report: { type: "string", description: "Your final report: a bulleted list of findings (each with file:line and a one-sentence fix), followed by a single line 'VERDICT: SHIP' or 'VERDICT: FIX REQUIRED'." } }, required: ["report"] } } },
          ];

          const auditorSystem = `You are a senior staff engineer doing a DEEP, iterative audit of an in-progress build by another AI agent.

Unlike a normal code review, you have READ-ONLY tool access to the entire codebase. Use it. Don't just stare at the diff — grep for callers and call-sites of every changed function/route, read the FULL file (not just the diff hunk) to see surrounding logic, and trace cross-file wiring (server route ↔ client fetch, schema ↔ codegen ↔ usage, event emit ↔ handler).

Workflow:
1. Read the diff to see what changed.
2. For each non-trivial change, grep for the symbols/routes/events involved across the whole repo to find untouched code paths that depend on them.
3. read_file the surrounding code (not just the changed lines) — bugs hide in the lines the diff DOESN'T touch.
4. When you've explored enough, call finish_audit with your report.

Look for: logic errors, off-by-one, missing null/empty checks, async/race conditions, regressions in untouched paths, broken contracts (schema ↔ usage, route ↔ client), security issues (path traversal, injection, missing auth, leaked secrets), missing error handling, dropped requirements from the original instruction, and resource leaks (unclosed listeners, timers, streams).

Ignore: style nits, naming, missing comments, "should add tests" — only flag REAL issues.

You have ${maxIters} tool-call rounds. Be efficient: prefer grep_code over list_files; pass offset/limit to read_file for large files. End with finish_audit.`;

          const auditorUser = `# Original instruction to the building agent
${instruction}

# Audit focus
${focus || "(general audit — review the diff plus surrounding context, flag real bugs across the whole system)"}

${seedFiles.length ? `# Suggested starting files\n${seedFiles.map((s) => `- ${s}`).join("\n")}\n\n` : ""}# Current diff (preview)
\`\`\`diff
${diffSlice0 || "(no uncommitted changes)"}
\`\`\`

Begin your audit.`;

          const auditorMessages: Array<{ role: "system" | "user" | "assistant" | "tool"; content: string; tool_calls?: unknown; tool_call_id?: string; name?: string }> = [
            { role: "system", content: auditorSystem },
            { role: "user", content: auditorUser },
          ];

          let finalReport = "";
          let auditorErr: string | null = null;
          try {
            for (let iter = 0; iter < maxIters && !finalReport && !auditorErr; iter++) {
              if (runner.cancelled) { auditorErr = "Audit cancelled by user."; break; }
              const resp = await openai.chat.completions.create({
                model: "gpt-5.4",
                max_completion_tokens: 4000,
                tools: auditorTools,
                tool_choice: iter === maxIters - 1 ? { type: "function", function: { name: "finish_audit" } } : "auto",
                messages: auditorMessages as never,
              });
              const msg = resp.choices[0]?.message;
              if (!msg) { auditorErr = "Auditor returned no message."; break; }
              const calls = msg.tool_calls ?? [];
              if (!calls.length) {
                auditorMessages.push({ role: "assistant", content: msg.content ?? "" });
                // Plain text response without tool calls — accept it as the report.
                finalReport = (msg.content ?? "").trim() || "(auditor returned no findings)";
                break;
              }

              const normalizedCalls = calls.flatMap((tc, index) => {
                const id = typeof tc.id === "string" && tc.id.trim() ? tc.id.trim() : "";
                if (!id) return [];
                return [{ ...tc, id }];
              });
              if (!normalizedCalls.length) {
                auditorMessages.push({ role: "assistant", content: msg.content ?? "" });
                auditorErr = "Auditor returned tool calls without valid IDs.";
                break;
              }

              // Iterate normalizedCalls (not raw `calls`) so any empty-id
              // entries are dropped from BOTH the assistant message and the
              // tool-result block — keeps OpenAI's 1-tool-result-per-tool_call
              // invariant intact.
              const pendingToolMessages: Array<{ role: "tool"; tool_call_id: string; name: string; content: string }> = [];
              try {
                for (let i = 0; i < normalizedCalls.length; i++) {
                  const tc = normalizedCalls[i];
                  if (runner.cancelled) {
                    for (let j = i; j < normalizedCalls.length; j++) {
                      const remaining = normalizedCalls[j];
                      pendingToolMessages.push({
                        role: "tool",
                        tool_call_id: remaining.id,
                        name: remaining.type === "function" ? remaining.function.name : "unknown",
                        content: "Audit cancelled by user.",
                      });
                    }
                    auditorErr = "Audit cancelled by user.";
                    break;
                  }
                  if (tc.type !== "function") {
                    pendingToolMessages.push({
                      role: "tool",
                      tool_call_id: tc.id,
                      name: "unknown",
                      content: `Error: unsupported auditor tool call type \"${tc.type}\"`,
                    });
                    continue;
                  }
                  const tname = tc.function.name;
                  let targs: Record<string, unknown> = {};
                  try { targs = JSON.parse(tc.function.arguments || "{}"); } catch {}
                  let tresult = "";
                  if (tname === "finish_audit") {
                    finalReport = String((targs as { report?: string }).report ?? "(auditor called finish_audit with no report)").trim();
                    tresult = "Report received.";
                  } else if (tname === "grep_code") {
                    const pattern = String(targs.pattern ?? "");
                    if (!pattern) tresult = "Error: pattern required";
                    else tresult = grepCode(pattern, {
                      path: typeof targs.path === "string" ? targs.path : undefined,
                      glob: typeof targs.glob === "string" ? targs.glob : undefined,
                      caseInsensitive: Boolean(targs.caseInsensitive),
                      maxResults: typeof targs.maxResults === "number" ? targs.maxResults : undefined,
                    });
                  } else if (tname === "read_file") {
                    const resolved = safePath(String(targs.path ?? ""));
                    if (!resolved) tresult = "Error: path outside repo or denied";
                    else {
                      try {
                        const stat = fs.statSync(resolved);
                        const offsetArg = typeof targs.offset === "number" && targs.offset > 0 ? Math.floor(targs.offset) : null;
                        const limitArg = typeof targs.limit === "number" && targs.limit > 0 ? Math.min(Math.floor(targs.limit), 2000) : null;
                        if (stat.size > 500_000 && !offsetArg && !limitArg) {
                          tresult = `Error: file too large (${(stat.size / 1024).toFixed(0)}kb). Use grep_code or pass offset+limit.`;
                        } else {
                          const content = fs.readFileSync(resolved, "utf-8");
                          if (offsetArg || limitArg) {
                            const lines = content.split("\n");
                            const start = (offsetArg ?? 1) - 1;
                            const end = limitArg ? start + limitArg : lines.length;
                            const numbered = lines.slice(start, end).map((l, i) => `${String(start + i + 1).padStart(6, " ")}→${l}`).join("\n");
                            tresult = numbered;
                          } else {
                            tresult = content;
                          }
                        }
                      } catch { tresult = "Error: file not found"; }
                    }
                  } else if (tname === "list_files") {
                    const target = targs.dir ? safePath(String(targs.dir)) : WORKSPACE_ROOT;
                    if (!target) tresult = "Error: path outside repo or denied";
                    else {
                      const files = listFilesRecursive(target, target);
                      tresult = files.length > 500 ? files.slice(0, 500).concat([`… ${files.length - 500} more truncated`]).join("\n") : (files.join("\n") || "(empty)");
                    }
                  } else if (tname === "git_diff") {
                    const pathArg = typeof targs.path === "string" ? targs.path : "";
                    const resolvedPath = pathArg ? safePath(pathArg) : null;
                    if (pathArg && !resolvedPath) tresult = "Error: path outside repo or denied";
                    else {
                      const dargs = ["diff", "--no-color", "--unified=3"];
                      if (resolvedPath) dargs.push("--", path.relative(WORKSPACE_ROOT, resolvedPath));
                      const dr = await runShell("git", dargs, { timeoutMs: 10_000 });
                      const out = (dr.stdout + dr.stderr).trim();
                      tresult = out ? (out.length > 30_000 ? out.slice(0, 30_000) + "\n…[truncated]" : out) : "(no changes)";
                    }
                  } else {
                    tresult = `Error: unknown auditor tool "${tname}"`;
                  }
                  if (tresult.length > 40_000) tresult = tresult.slice(0, 40_000) + "\n…[result truncated]";
                  pendingToolMessages.push({ role: "tool", tool_call_id: tc.id, name: tname, content: tresult });
                }
              } catch (e) {
                const message = e instanceof Error ? e.message : String(e);
                const failureContent = runner.cancelled ? "Audit cancelled by user." : `Audit tool failed before completion: ${message}`;
                for (const tc of normalizedCalls) {
                  if (pendingToolMessages.some((toolMsg) => toolMsg.tool_call_id === tc.id)) continue;
                  pendingToolMessages.push({
                    role: "tool",
                    tool_call_id: tc.id,
                    name: tc.type === "function" ? tc.function.name : "unknown",
                    content: failureContent,
                  });
                }
                auditorErr = runner.cancelled ? "Audit cancelled by user." : `Auditor tool execution failed: ${message}`;
              }

              auditorMessages.push({ role: "assistant", content: msg.content ?? "", tool_calls: normalizedCalls as unknown });
              auditorMessages.push(...pendingToolMessages);
              if (auditorErr) break;
            }
            if (!finalReport && !auditorErr) {
              finalReport = "(Auditor exhausted iteration budget without finishing. Partial findings may have been logged in tool calls — re-run with maxIterations: 16.)";
            }
            toolResult = auditorErr
              ? `Audit failed: ${auditorErr}`
              : `Deep audit report:\n\n${finalReport}`;
          } catch (e) {
            toolResult = `Auditor crashed: ${e instanceof Error ? e.message : String(e)}. Continue without audit.`;
          }
        } else if (toolName === "run_command") {
          const cmdRaw = String(args.command ?? "").trim();
          const timeoutMs = Math.min(Math.max(typeof args.timeoutMs === "number" ? args.timeoutMs : 30_000, 1000), 90_000);
          if (!cmdRaw) {
            toolResult = "Error: command is required";
          } else {
            // Tokenize naively but check the FIRST token for binary allowlist.
            // Then scan the WHOLE command string for hard-blocked patterns.
            const HARD_BLOCK = [
              /(^|\s|;|\||&)\s*rm(\s|$)/, /(^|\s|;|\||&)\s*sudo(\s|$)/, /(^|\s|;|\||&)\s*su(\s|$)/,
              /(^|\s|;|\||&)\s*curl(\s|$)/, /(^|\s|;|\||&)\s*wget(\s|$)/,
              /(^|\s|;|\||&)\s*kill(\s|$)/, /(^|\s|;|\||&)\s*pkill(\s|$)/, /(^|\s|;|\||&)\s*killall(\s|$)/,
              /(^|\s|;|\||&)\s*chmod(\s|$)/, /(^|\s|;|\||&)\s*chown(\s|$)/,
              /(^|\s|;|\||&)\s*dd(\s|$)/, /(^|\s|;|\||&)\s*mkfs/,
              />\s*\/dev\//, /\/etc\/passwd/, /\/etc\/shadow/,
            ];
            const blocked = HARD_BLOCK.find((re) => re.test(cmdRaw));
            const firstToken = cmdRaw.split(/\s+/)[0] ?? "";
            const ALLOWED_BINS = new Set([
              "pnpm", "npm", "npx", "node",
              "git",
              "ls", "cat", "find", "head", "tail", "wc", "sort", "uniq", "tree", "stat", "du",
              "echo", "printf",
              "mkdir", "touch", "cp", "mv",
              "rg", "grep",
              "true", "false",
            ]);
            const GIT_RW_SUBCOMMANDS = new Set([
              "push", "reset", "rebase", "checkout", "switch", "restore",
              "clean", "gc", "rm", "mv", "commit", "merge", "revert", "cherry-pick",
              "filter-branch", "update-ref", "config", "remote",
            ]);
            if (blocked) {
              toolResult = `Error: command blocked by safety pattern (${blocked.source}). Use revert_changes to undo edits, or git_diff/run_typecheck for diagnostics.`;
            } else if (!ALLOWED_BINS.has(firstToken)) {
              toolResult = `Error: binary "${firstToken}" is not in the allowlist. Allowed: ${[...ALLOWED_BINS].join(", ")}.`;
            } else if (firstToken === "git") {
              const sub = (cmdRaw.split(/\s+/)[1] ?? "").replace(/^-+/, "");
              if (GIT_RW_SUBCOMMANDS.has(sub)) {
                toolResult = `Error: git subcommand "${sub}" is blocked (write operations are not allowed; Replit auto-commits checkpoints). Use revert_changes for undos.`;
              } else {
                emit({ type: "reading", path: "(shell)", message: cmdRaw.slice(0, 80) });
                const r = await runShell("sh", ["-c", cmdRaw], { timeoutMs });
                const out = (r.stdout + (r.stderr ? "\n" + r.stderr : "")).trim();
                const tail = out.length > 30_000 ? out.slice(-30_000) + "\n…[head truncated, only last 30KB shown]" : out;
                toolResult = `${r.timedOut ? `⏱ TIMED OUT after ${timeoutMs}ms` : `exit ${r.code}`}${tail ? `\n\n${tail}` : ""}`;
              }
            } else {
              emit({ type: "reading", path: "(shell)", message: cmdRaw.slice(0, 80) });
              const r = await runShell("sh", ["-c", cmdRaw], { timeoutMs });
              const out = (r.stdout + (r.stderr ? "\n" + r.stderr : "")).trim();
              const tail = out.length > 30_000 ? out.slice(-30_000) + "\n…[head truncated, only last 30KB shown]" : out;
              toolResult = `${r.timedOut ? `⏱ TIMED OUT after ${timeoutMs}ms` : `exit ${r.code}`}${tail ? `\n\n${tail}` : ""}`;
            }
          }
        } else if (toolName === "list_skills" || toolName === "load_skill" || toolName === "create_skill") {
          const SKILLS_DIR = path.join(WORKSPACE_ROOT, "vance-skills");
          const REPLIT_SKILLS_DIR = path.join(WORKSPACE_ROOT, ".local", "skills");
          try { fs.mkdirSync(SKILLS_DIR, { recursive: true }); } catch { /* noop */ }
          if (toolName === "list_skills") {
            emit({ type: "reading", path: "skills/", message: "Listing skills (vance + replit platform)" });
            try {
              const entries: string[] = [];
              // Vance-authored skills (flat .md files)
              try {
                const files = fs.readdirSync(SKILLS_DIR).filter((f) => f.endsWith(".md") && f !== "README.md");
                for (const f of files) {
                  try {
                    const body = fs.readFileSync(path.join(SKILLS_DIR, f), "utf-8");
                    const fm = body.match(/^---\s*([\s\S]*?)\s*---/);
                    let when = "";
                    if (fm) {
                      const m = fm[1]!.match(/when_to_use:\s*(.+)/);
                      if (m) when = m[1]!.trim();
                    }
                    entries.push(`- ${f.replace(/\.md$/, "")} (vance) — ${when || "(no when_to_use)"}`);
                  } catch { /* skip unreadable */ }
                }
              } catch { /* dir missing OK */ }
              // Replit platform skills (nested <name>/SKILL.md)
              try {
                const dirs = fs.readdirSync(REPLIT_SKILLS_DIR, { withFileTypes: true })
                  .filter((d) => d.isDirectory())
                  .map((d) => d.name);
                for (const name of dirs) {
                  const skillFile = path.join(REPLIT_SKILLS_DIR, name, "SKILL.md");
                  try {
                    const body = fs.readFileSync(skillFile, "utf-8");
                    // YAML frontmatter `description:` is the standard for Replit skills
                    const fm = body.match(/^---\s*([\s\S]*?)\s*---/);
                    let desc = "";
                    if (fm) {
                      const m = fm[1]!.match(/description:\s*(.+)/);
                      if (m) desc = m[1]!.trim().replace(/^["']|["']$/g, "");
                    }
                    if (!desc) {
                      // Fall back to first non-heading line of body
                      const after = fm ? body.slice(fm[0].length) : body;
                      const firstLine = after.split("\n").map((l) => l.trim()).find((l) => l && !l.startsWith("#"));
                      if (firstLine) desc = firstLine.slice(0, 200);
                    }
                    entries.push(`- replit:${name} (replit) — ${desc || "(no description)"}`);
                  } catch { /* skill missing SKILL.md, skip */ }
                }
              } catch { /* .local/skills missing OK */ }
              if (entries.length === 0) {
                toolResult = "(no skills found — use create_skill to author one)";
              } else {
                toolResult = `Available skills (${entries.length} total):\n${entries.join("\n")}\n\nLoad with load_skill(name). Use the full name for replit skills (e.g. load_skill(\"replit:database\")).`;
              }
            } catch (e) {
              toolResult = `Error listing skills: ${e instanceof Error ? e.message : String(e)}`;
            }
          } else if (toolName === "load_skill") {
            const rawName = String(args.name ?? "").trim().replace(/\.md$/, "");
            const isReplit = rawName.startsWith("replit:");
            const bareName = isReplit ? rawName.slice("replit:".length) : rawName;
            if (!bareName || !/^[a-z0-9][a-z0-9_-]*$/i.test(bareName)) {
              toolResult = "Error: name must be a simple kebab-case identifier (no slashes, no dots). For Replit platform skills prefix with 'replit:', e.g. 'replit:database'.";
            } else if (isReplit) {
              const skillPath = path.join(REPLIT_SKILLS_DIR, bareName, "SKILL.md");
              emit({ type: "reading", path: `.local/skills/${bareName}/SKILL.md`, message: "Loading replit platform skill" });
              try {
                const body = fs.readFileSync(skillPath, "utf-8");
                // Cap at 30K chars — some platform skills are long; the model can read more via read_file if needed
                toolResult = body.length > 30_000 ? body.slice(0, 30_000) + "\n\n…[truncated; read remaining via read_file on the same path]" : body;
              } catch {
                toolResult = `Error: replit skill "${bareName}" not found at .local/skills/${bareName}/SKILL.md. Use list_skills to see available ones.`;
              }
            } else {
              const skillPath = path.join(SKILLS_DIR, `${bareName}.md`);
              emit({ type: "reading", path: `vance-skills/${bareName}.md`, message: "Loading vance skill" });
              try {
                toolResult = fs.readFileSync(skillPath, "utf-8");
              } catch {
                toolResult = `Error: vance skill "${bareName}" not found. Use list_skills to see available ones (Replit platform skills use the 'replit:' prefix).`;
              }
            }
          } else { // create_skill
            const name = String(args.name ?? "").trim().replace(/\.md$/, "");
            const whenToUse = String(args.when_to_use ?? "").trim();
            const content = String(args.content ?? "").trim();
            if (!name || !/^[a-z0-9][a-z0-9_-]*$/i.test(name)) {
              toolResult = "Error: name must be kebab-case (lowercase letters, digits, hyphens only).";
            } else if (!whenToUse || !content) {
              toolResult = "Error: when_to_use and content are both required.";
            } else {
              const skillPath = path.join(SKILLS_DIR, `${name}.md`);
              const repoRel = path.relative(WORKSPACE_ROOT, skillPath);
              snapshotFile(skillPath, repoRel);
              const body = `---\nname: ${name}\nwhen_to_use: ${whenToUse.replace(/\n/g, " ")}\n---\n\n${content}\n`;
              try {
                fs.writeFileSync(skillPath, body, "utf-8");
                if (!filesChanged.includes(repoRel)) filesChanged.push(repoRel);
                emit({ type: "writing", path: repoRel, message: "Authored skill" });
                toolResult = `✓ Skill "${name}" saved. Future build turns will see it via list_skills.`;
              } catch (e) {
                toolResult = `Error saving skill: ${e instanceof Error ? e.message : String(e)}`;
              }
            }
          }
        } else if (toolName === "screenshot_app" || toolName === "run_e2e_test") {
          // Lazy-load playwright so the api-server can boot even if the package
          // is broken or chromium is missing.  The first call pays the import
          // cost; subsequent calls reuse the module.
          emit({ type: "reading", path: "(headless browser)", message: toolName === "screenshot_app" ? "Capturing screen" : "Running e2e test" });
          let pw: typeof import("playwright") | null = null;
          try { pw = await import("playwright"); }
          catch (e) {
            toolResult = `Error: playwright not importable (${e instanceof Error ? e.message : String(e)}). The framework is wired up but the package isn't loading; ask the user.`;
          }
          if (pw) {
            // Vance's frontend lives behind the shared proxy at port 80, NOT
            // on this api-server's PORT.  Hitting :8080/<path> would 404.
            const FRONTEND_BASE = process.env.VANCE_FRONTEND_URL ?? "http://localhost:80";
            // Mint a signed `vance_auth=ok` cookie in cookie-parser's format
            // (`s:<value>.<sig>`) so Playwright lands on the actual app instead
            // of the passcode lock screen.  Without this, every screenshot of
            // any path returns the lock UI and the model fixes UI bugs blind.
            const sessionSecret = process.env["SESSION_SECRET"] ?? "";
            const authCookies: Array<{ name: string; value: string; url: string }> = [];
            if (sessionSecret) {
              const sig = createHmac("sha256", sessionSecret).update("ok").digest("base64").replace(/=+$/, "");
              authCookies.push({ name: "vance_auth", value: `s:ok.${sig}`, url: FRONTEND_BASE });
            }
            // Resolve the system chromium binary (installed via Nix).  Falls
            // back to playwright's bundled binary if env override is set or
            // chromium isn't on PATH (we let playwright report the error).
            let executablePath: string | undefined;
            try {
              const which = (await import("node:child_process")).execSync("which chromium 2>/dev/null || which chromium-browser 2>/dev/null", { encoding: "utf8" }).trim();
              if (which) executablePath = which;
            } catch { /* fall through to playwright default */ }
            let browser: import("playwright").Browser | null = null;
            try {
              browser = await pw.chromium.launch({ headless: true, executablePath, args: ["--no-sandbox", "--disable-dev-shm-usage"] });
              if (toolName === "screenshot_app") {
                const reqPath = String(args.path ?? "/");
                const width = Math.min(Math.max(typeof args.width === "number" ? args.width : 1280, 320), 2000);
                const height = Math.min(Math.max(typeof args.height === "number" ? args.height : 800, 240), 2000);
                const ctx = await browser.newContext({ viewport: { width, height } });
                if (authCookies.length > 0) await ctx.addCookies(authCookies);
                const page = await ctx.newPage();
                const url = FRONTEND_BASE + (reqPath.startsWith("/") ? reqPath : "/" + reqPath);
                // `load` instead of `networkidle` — the chat page holds an
                // SSE connection open to the build runner while a build is
                // in progress, which means the network is NEVER idle and
                // every in-build screenshot would otherwise hit the 15s
                // timeout.  A small post-load wait lets React paint.
                await page.goto(url, { waitUntil: "load", timeout: 15_000 });
                // Wait for the avatar wrapper to flip ready (signals that the
                // profile fetch resolved AND we know whether to render the orb
                // or the 3D model). Falls through harmlessly on pages that
                // don't have an avatar (Memories/Profile/XRP/etc).
                let avatarKind: string | null = null;
                try {
                  await page.waitForSelector('[data-avatar-ready="true"]', { timeout: 4_000 });
                  avatarKind = await page.getAttribute('[data-avatar-ready="true"]', "data-avatar-kind");
                } catch { /* no avatar on this page — proceed */ }
                // 3D path needs much more time: Three.js has to mount the
                // <canvas>, fetch the multi-MB GLB from the model CDN, decode
                // it, and render the first frame. 800ms (the old wait) caught
                // the page mid-load and produced a black box. 3.5s catches
                // typical Ready Player Me models. Other paths only need a
                // small paint-settle wait.
                await page.waitForTimeout(avatarKind === "3d" ? 3500 : 600);
                const buf = await page.screenshot({ type: "png", fullPage: false });
                await ctx.close();
                // Surface the screenshot to the SSE client (UI can show it) AND
                // give the model a textual summary it can reason about.
                const b64 = buf.toString("base64");
                emit({ type: "writing", path: `(screenshot ${width}x${height})`, message: `Captured ${reqPath} — ${(buf.length / 1024).toFixed(0)}kb`, screenshot: `data:image/png;base64,${b64}` } as Record<string, unknown>);
                visionImages.push({ label: `Screenshot of ${url} at ${width}x${height}`, b64 });
                // Persist to disk so chat-mode Vance can recall + show this
                // screenshot later when the user asks about his recent work.
                const label = `Screenshot of ${reqPath} at ${width}x${height}`;
                try {
                  const dir = path.join(SCREENSHOT_DIR, runner.id);
                  fs.mkdirSync(dir, { recursive: true });
                  const fname = `${runner.screenshots.length + 1}.png`;
                  fs.writeFileSync(path.join(dir, fname), buf);
                  runner.screenshots.push({ path: `${runner.id}/${fname}`, label, ts: Date.now() });
                } catch (e) { logger.warn({ err: e }, "Failed to persist screenshot to disk"); }
                toolResult = `✓ Captured screenshot of ${url} at ${width}x${height} (${(buf.length / 1024).toFixed(0)}kb PNG). The image is attached to the next message — LOOK AT IT and describe what you see, then decide whether the UI matches the intent. The screenshot is also streamed to the UI for the user.`;
              } else { // run_e2e_test
                const testName = String(args.name ?? "test");
                const steps = Array.isArray(args.steps) ? args.steps as Array<Record<string, unknown>> : [];
                if (steps.length === 0) {
                  toolResult = "Error: steps array is required and must be non-empty.";
                } else {
                  const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 } });
                  if (authCookies.length > 0) await ctx.addCookies(authCookies);
                  const page = await ctx.newPage();
                  const log: string[] = [];
                  let passed = true;
                  let failedAt = -1;
                  for (let i = 0; i < steps.length; i++) {
                    const step = steps[i]!;
                    const action = String(step.action ?? "");
                    try {
                      if (action === "goto") {
                        const p = String(step.path ?? "/");
                        await page.goto(FRONTEND_BASE + (p.startsWith("/") ? p : "/" + p), { waitUntil: "load", timeout: 15_000 });
                        await page.waitForTimeout(500);
                        log.push(`  #${i + 1} goto ${p} ✓`);
                      } else if (action === "click") {
                        await page.click(String(step.selector ?? ""), { timeout: 8_000 });
                        log.push(`  #${i + 1} click ${step.selector} ✓`);
                      } else if (action === "type") {
                        await page.fill(String(step.selector ?? ""), String(step.text ?? ""));
                        log.push(`  #${i + 1} type "${String(step.text ?? "").slice(0, 30)}" into ${step.selector} ✓`);
                      } else if (action === "waitForSelector") {
                        await page.waitForSelector(String(step.selector ?? ""), { timeout: 8_000 });
                        log.push(`  #${i + 1} waitForSelector ${step.selector} ✓`);
                      } else if (action === "expectText") {
                        const want = String(step.text ?? "");
                        const body = await page.textContent("body");
                        if (!body?.includes(want)) throw new Error(`expected text "${want}" not found on page`);
                        log.push(`  #${i + 1} expectText "${want}" ✓`);
                      } else if (action === "screenshot") {
                        const buf = await page.screenshot({ type: "png" });
                        const b64 = buf.toString("base64");
                        emit({ type: "writing", path: `(test ${testName} step ${i + 1})`, message: "Step screenshot", screenshot: `data:image/png;base64,${b64}` } as Record<string, unknown>);
                        const eLabel = `${testName} step ${i + 1} screenshot`;
                        visionImages.push({ label: eLabel, b64 });
                        try {
                          const dir = path.join(SCREENSHOT_DIR, runner.id);
                          fs.mkdirSync(dir, { recursive: true });
                          const fname = `${runner.screenshots.length + 1}.png`;
                          fs.writeFileSync(path.join(dir, fname), buf);
                          runner.screenshots.push({ path: `${runner.id}/${fname}`, label: eLabel, ts: Date.now() });
                        } catch (e) { logger.warn({ err: e }, "Failed to persist e2e screenshot to disk"); }
                        log.push(`  #${i + 1} screenshot ✓ (${(buf.length / 1024).toFixed(0)}kb)`);
                      } else {
                        throw new Error(`unknown action "${action}"`);
                      }
                    } catch (e) {
                      passed = false;
                      failedAt = i;
                      log.push(`  #${i + 1} ${action} ✗ — ${e instanceof Error ? e.message : String(e)}`);
                      break;
                    }
                  }
                  await ctx.close();
                  toolResult = `${passed ? "✓ E2E PASS" : `✗ E2E FAIL at step ${failedAt + 1}`} [${testName}]\n${log.join("\n")}`;
                }
              }
            } catch (e) {
              const msg = e instanceof Error ? e.message : String(e);
              if (/missing|library|dependencies|launch/i.test(msg)) {
                toolResult = `Error: headless browser failed to launch in this environment (likely missing system libraries on NixOS). Skip visual verification this turn and rely on typecheck. Underlying error: ${msg.slice(0, 400)}`;
              } else {
                toolResult = `Error during ${toolName}: ${msg.slice(0, 600)}`;
              }
            } finally {
              if (browser) try { await browser.close(); } catch { /* noop */ }
            }
          }
        } else if (toolName === "install_package") {
          const target = typeof args.target === "string" ? args.target.trim() : "";
          const name = typeof args.name === "string" ? args.name.trim() : "";
          const isDev = Boolean(args.isDev);
          const filter = PACKAGE_FILTERS[target] ?? (target.startsWith("@workspace/") ? target : null);
          if (!target || !filter) {
            toolResult = `Error: unknown target package "${target}". Valid: ${Object.keys(PACKAGE_FILTERS).join(", ")}`;
          } else if (!name || /[\s;|&`$<>]/.test(name)) {
            toolResult = "Error: package name is required and must not contain shell metacharacters.";
          } else {
            const pnpmArgs = ["--filter", filter, "add"];
            if (isDev) pnpmArgs.push("-D");
            pnpmArgs.push(name);
            emit({ type: "reading", path: filter, message: `pnpm add${isDev ? " -D" : ""} ${name}` });
            const r = await runShell("pnpm", pnpmArgs, { timeoutMs: 90_000 });
            const out = (r.stdout + (r.stderr ? "\n" + r.stderr : "")).trim();
            if (r.timedOut) toolResult = `Install timed out:\n${out.slice(-2000)}`;
            else if (r.code === 0) toolResult = `✓ Installed ${name} into ${filter}${isDev ? " (devDependency)" : ""}.\n${out.slice(-1000)}`;
            else toolResult = `✗ Install failed (exit ${r.code}):\n${out.slice(-2500)}`;
          }
        } else if (toolName === "get_diagnostics") {
          // Fast per-file TS errors via the programmatic API. ~1-4s vs 15-30s
          // for a full pnpm typecheck. Used in the iterative inner loop.
          const repoRel = String(args.path ?? "").trim();
          if (!repoRel) {
            toolResult = "Error: path is required.";
          } else {
            const abs = safePath(repoRel);
            if (!abs || !fs.existsSync(abs)) {
              toolResult = `Error: file not found: ${repoRel}`;
            } else if (!/\.(ts|tsx|mts|cts)$/.test(repoRel)) {
              toolResult = `Error: get_diagnostics only handles TS/TSX files. For JS, run_typecheck the package.`;
            } else {
              // Determine which workspace package owns this file by walking up
              // for a package.json with a workspace name.
              let pkgDir: string | null = null;
              let pkgName: string | null = null;
              let dir = path.dirname(abs);
              while (dir.startsWith(WORKSPACE_ROOT) && dir.length >= WORKSPACE_ROOT.length) {
                const pj = path.join(dir, "package.json");
                if (fs.existsSync(pj)) {
                  try {
                    const j = JSON.parse(fs.readFileSync(pj, "utf8")) as { name?: string };
                    if (j.name && j.name.startsWith("@workspace/")) {
                      pkgDir = dir; pkgName = j.name; break;
                    }
                  } catch { /* keep walking */ }
                }
                const parent = path.dirname(dir);
                if (parent === dir) break;
                dir = parent;
              }
              if (!pkgDir || !pkgName) {
                toolResult = `Error: could not find owning @workspace/* package for ${repoRel}.`;
              } else {
                emit({ type: "reading", path: repoRel, message: `tsc --incremental in ${pkgName}` });
                // Use the package's own typecheck script with --incremental so
                // the second-and-onward call hits the .tsbuildinfo cache and
                // returns in 1–3s instead of 15–30s. We then grep the output
                // for diagnostics mentioning the target file.
                // Serialize concurrent get_diagnostics calls per-package so
                // parallel callers don't corrupt the shared .tsbuildinfo cache.
                const r = await withDiagnosticsLock(pkgDir, () => runShell("pnpm", ["--filter", pkgName, "exec", "tsc", "-p", "tsconfig.json", "--noEmit", "--incremental", "--tsBuildInfoFile", path.join(pkgDir, ".tsbuildinfo-vance-diag")], { timeoutMs: 60_000 }));
                const combined = (r.stdout + (r.stderr ? "\n" + r.stderr : "")).trim();
                if (r.timedOut) {
                  toolResult = `get_diagnostics timed out after 60s.`;
                } else {
                  // Errors look like: src/foo.ts(12,3): error TS2304: ...
                  // We want only the ones mentioning OUR file. Build matchers for
                  // both the absolute path and the package-relative path.
                  const pkgRel = path.relative(pkgDir, abs);
                  const errLines = combined.split("\n").filter((l) => /error TS\d+/.test(l));
                  const ourLines = errLines.filter((l) => l.includes(pkgRel) || l.includes(repoRel) || l.includes(abs));
                  if (r.code === 0 && errLines.length === 0) {
                    toolResult = `✓ No diagnostics in ${repoRel} (whole package ${pkgName} clean).`;
                  } else if (ourLines.length === 0) {
                    toolResult = `✓ No diagnostics in ${repoRel}. (${errLines.length} error${errLines.length === 1 ? "" : "s"} elsewhere in ${pkgName}; run run_typecheck if you need the full picture.)`;
                  } else {
                    const more = ourLines.length > 40 ? `\n…and ${ourLines.length - 40} more.` : "";
                    toolResult = `✗ ${ourLines.length} diagnostic${ourLines.length === 1 ? "" : "s"} in ${repoRel}:\n${ourLines.slice(0, 40).join("\n")}${more}\n\nFix with edit_file and re-run get_diagnostics.`;
                  }
                }
              }
            }
          }
        } else if (toolName === "parallel_verify") {
          const ops = Array.isArray(args.ops) ? (args.ops as unknown[]).map(String).filter(Boolean) : [];
          if (ops.length === 0) {
            toolResult = "Error: ops array is required and must be non-empty.";
          } else if (ops.length > 8) {
            toolResult = "Error: max 8 parallel ops per call.";
          } else {
            emit({ type: "reading", path: "(parallel)", message: `Running ${ops.length} ops concurrently: ${ops.join(", ")}` });
            const runOne = async (op: string): Promise<string> => {
              try {
                if (op === "git_diff") {
                  const r = await runShell("git", ["diff", "--no-color", "--stat"], { timeoutMs: 10_000 });
                  const out = (r.stdout + r.stderr).trim();
                  return out || "(no uncommitted changes)";
                }
                if (op === "codegen") {
                  const r = await runShell("pnpm", ["--filter", "@workspace/api-spec", "run", "codegen"], { timeoutMs: 60_000 });
                  if (r.timedOut) return `timed out`;
                  return r.code === 0 ? "✓ ok" : `✗ exit ${r.code}\n${(r.stdout + r.stderr).slice(-1500)}`;
                }
                if (op === "db_push") {
                  const r = await runShell("pnpm", ["--filter", "@workspace/db", "run", "push"], { timeoutMs: 60_000 });
                  if (r.timedOut) return `timed out`;
                  return r.code === 0 ? "✓ ok" : `✗ exit ${r.code}\n${(r.stdout + r.stderr).slice(-1500)}`;
                }
                if (op === "review") {
                  const diffR = await runShell("git", ["diff", "--no-color", "--unified=5"], { timeoutMs: 10_000 });
                  const diff = (diffR.stdout + diffR.stderr).trim();
                  if (!diff) return "(no uncommitted changes to review)";
                  const slice = diff.length > 60_000 ? diff.slice(0, 60_000) + "\n…[truncated]" : diff;
                  const resp = await openai.chat.completions.create({
                    model: "gpt-5.4",
                    max_completion_tokens: 1000,
                    messages: [
                      { role: "system", content: `You are a senior staff engineer doing a fast code review on an in-progress AI build. Catch real bugs (logic errors, off-by-one, async/race, missing checks, security, broken contracts, regressions). Skip style nits. Output: short bulleted list of concrete issues, each with file/line and a one-sentence fix. End with "VERDICT: SHIP" or "VERDICT: FIX REQUIRED".` },
                      { role: "user", content: `# Instruction\n${instruction}\n\n# Diff\n\`\`\`diff\n${slice}\n\`\`\`` },
                    ],
                  });
                  return resp.choices[0]?.message?.content?.trim() ?? "(reviewer returned nothing)";
                }
                // typecheck or typecheck:<pkg>
                if (op === "typecheck" || op.startsWith("typecheck:")) {
                  const pkgArg = op.includes(":") ? op.split(":", 2)[1]!.trim() : "";
                  const filter = pkgArg ? (PACKAGE_FILTERS[pkgArg] ?? (pkgArg.startsWith("@workspace/") ? pkgArg : null)) : null;
                  if (pkgArg && !filter) return `unknown package "${pkgArg}"`;
                  const cmdArgs = filter ? ["--filter", filter, "run", "typecheck"] : ["run", "typecheck"];
                  const r = await runShell("pnpm", cmdArgs, { timeoutMs: 90_000 });
                  if (r.timedOut) return `timed out`;
                  if (r.code === 0) return `✓ ok`;
                  const combined = (r.stdout + (r.stderr ? "\n" + r.stderr : "")).trim();
                  const errLines = combined.split("\n").filter((l) => /error TS\d+/.test(l) || /\.tsx?\(\d+,\d+\)/.test(l));
                  return `✗ exit ${r.code}\n${(errLines.length > 0 ? errLines.slice(0, 40).join("\n") : combined.slice(-2000))}`;
                }
                return `unknown op "${op}" (valid: typecheck[:pkg], codegen, db_push, git_diff, review)`;
              } catch (e) {
                return `error: ${e instanceof Error ? e.message : String(e)}`;
              }
            };
            const t0 = Date.now();
            // Two-phase pipeline so we never race a writer against a reader:
            //   Phase 1 (sequential): codegen, then db_push — these mutate
            //     generated files / DB schema and would invalidate Phase 2.
            //   Phase 2 (parallel):   typecheck[:pkg], git_diff, review — all
            //     read-only relative to the working tree.
            // git_diff in Phase 2 reflects the post-codegen state, which is
            // what reviewers actually want to see.
            const writers = ops.filter((op) => op === "codegen" || op === "db_push");
            const readers = ops.filter((op) => !(op === "codegen" || op === "db_push"));
            const writerResults: Array<readonly [string, string]> = [];
            for (const op of writers) {
              writerResults.push([op, await runOne(op)] as const);
            }
            const readerResults = await Promise.all(readers.map(async (op) => [op, await runOne(op)] as const));
            // Preserve the user's original op ordering in the printout.
            const byOp = new Map<string, string>([...writerResults, ...readerResults]);
            const results = ops.map((op) => [op, byOp.get(op) ?? "(no output)"] as const);
            const elapsed = ((Date.now() - t0) / 1000).toFixed(1);
            const phaseNote = writers.length > 0 && readers.length > 0
              ? ` (writers ${writers.join("+")} ran first, then readers ${readers.join("+")} in parallel)`
              : "";
            toolResult = `Parallel verify completed in ${elapsed}s${phaseNote}.\n\n` + results.map(([op, out]) => `── ${op} ──\n${out}`).join("\n\n");
          }
        } else {
          toolResult = "Unknown tool";
        }
        } catch (e) {
          const msg = e instanceof Error ? (e.stack ?? e.message) : String(e);
          logger.error({ err: e, toolName, buildId: runner.id }, "Tool handler threw — substituting error tool result");
          toolResult = `Error: tool "${toolName}" threw an unhandled exception: ${msg.slice(0, 800)}`;
        }

        chatMessages.push({ role: "tool", name: toolName, content: toolResult, tool_call_id: tc.id });

        // If this tool produced screenshots, defer the vision-image user
        // message until the for-loop ends (see ordering-invariant comment
        // above).  Pushing it inline would interleave a USER message between
        // tool results when multiple tool_calls run in parallel and trip the
        // OpenAI "tool_call_ids did not have response messages" 400.
        if (visionImages.length > 0) {
          const parts: UserContentPart[] = [
            { type: "text", text: `Here ${visionImages.length === 1 ? "is the screenshot" : `are the ${visionImages.length} screenshots`} from the previous tool call. Examine ${visionImages.length === 1 ? "it" : "them"} and decide whether the UI matches the intent of this build.` },
            ...visionImages.map((img) => ({ type: "image_url" as const, image_url: { url: `data:image/png;base64,${img.b64}`, detail: "high" as const } })),
          ];
          pendingVisionMessages.push({ role: "user", content: parts });
        }
      }

      // Flush any deferred vision-image messages now that EVERY tool_call_id
      // has its matching tool result message in chatMessages.  Safe to push
      // user content from here on.
      for (const m of pendingVisionMessages) chatMessages.push(m);
    }

    // ── AUTO-VERIFY before declaring done ──────────────────────────────────
    // SAFETY-NET PHILOSOPHY:
    //   The build runner is the ONLY thing that can edit Vance's own code.
    //   If a build ships broken code, the api-server boot fails, and from
    //   that point on Vance literally cannot fix himself — there's no chat
    //   route to receive a "fix yourself" instruction.  So auto-verify has
    //   to be paranoid: assume the model lied or forgot, verify everything
    //   that could possibly brick a future boot, and auto-revert on any
    //   failure regardless of whether the model thought it was done.
    //
    // Three corruption paths covered here:
    //   (a) TS files touched   → typecheck.   Catches type errors that would
    //       fail the next dev-server start.   We run this even if the model
    //       called typecheck mid-build, because edits AFTER that call are
    //       still unverified — paranoid is cheap, broken is expensive.
    //   (b) DB schema touched  → drizzle push.   Catches drift that would
    //       crash the next runtime query with "column does not exist".
    //   (c) package.json touched → install.   Catches dependency drift that
    //       would crash the next boot with "module not found".
    // Each step that fails restores per-turn snapshots and surfaces a real
    // error; we do NOT continue to the next check because the workspace is
    // already inconsistent.
    const tsTouched = filesChanged.some((f) => /\.(ts|tsx)$/.test(f) && !f.endsWith(".d.ts"));
    const schemaTouched = filesChanged.some((f) => f.startsWith("lib/db/src/schema/") || f === "lib/db/src/schema.ts");
    const packageJsonTouched = filesChanged.some((f) => /(^|\/)package\.json$/.test(f));
    // Self-edit detection: any change inside this very api-server's source tree
    // means the next dev-server restart will load fresh code.  Boot dry-run
    // runs the freshly-built bundle in a child process to confirm it actually
    // starts before we declare the build done — otherwise a typecheck-clean
    // edit can still crash the runtime (e.g. import side-effect throws,
    // top-level await failures, missing env at boot, route registration
    // exceptions) and brick Vance permanently.
    const apiServerSelfTouched = filesChanged.some((f) => f.startsWith("artifacts/api-server/src/") && /\.(ts|mjs|cjs|js)$/.test(f));
    // UI-touched: surface this once so we use the same definition in both the
    // forced-screenshot gate and the legacy "after" snapshot.
    const uiFileChanged = filesChanged.some((f) => f.startsWith("artifacts/vance/") && /\.(tsx?|css|html)$/.test(f));

    const failAndRevert = async (label: string, summary: string, errCount?: number): Promise<void> => {
      const reason = errCount !== undefined ? `${label}: ${errCount} error(s)` : label;
      const restored = restoreSnapshots(`auto-verify ${reason}`);
      emit({ type: "message", content: `\n\n⚠️ Auto-verify caught ${label} and rolled the build back (${restored.restored} restored, ${restored.deleted} deleted). Errors:\n\n\`\`\`\n${summary}\n\`\`\`` });
      await drainPendingCapture();
      emit({ type: "error", message: `Build auto-reverted: ${reason}.`, screenshots: screenshotsForEvent() });
      // Persist a TRUNCATED but useful chunk of the actual errors into the
      // build summary so future "why did it fail" questions can be answered
      // straight from vance_build_history without re-running the build.  Cap
      // at 1500 chars so we don't bloat the row.
      const persistedDetail = summary.trim() ? `\n${summary.trim().slice(0, 1500)}${summary.trim().length > 1500 ? "\n…[truncated]" : ""}` : "";
      writeHistoryOnce({
        ts: Date.now(),
        instruction,
        filesChanged: [],
        summary: `(auto-reverted: ${reason})${persistedDetail}`,
        snapshots: [],
      });
      runner.status = "error";
    };

    // Helper: cancel-check before each long shell so a cancel arriving
    // mid-auto-verify doesn't burn a full 120s typecheck before being
    // honored.  Returns true if we already handled cancellation (caller
    // should `return` immediately).
    const cancelCheckpoint = async (): Promise<boolean> => {
      if (!runner.cancelled) return false;
      runner.status = "aborted";
      const r = restoreSnapshots("build cancelled during auto-verify");
      await drainPendingCapture();
      emit({ type: "error", message: `Build cancelled during auto-verify. Auto-reverted ${r.restored} restored / ${r.deleted} deleted.`, screenshots: screenshotsForEvent() });
      writeHistoryOnce({
        ts: Date.now(),
        instruction,
        filesChanged: [],
        summary: `(cancelled during auto-verify and auto-reverted)`,
        snapshots: [],
      });
      return true;
    };

    // ── Production-deployment carve-out ────────────────────────────────────
    // The dev-toolchain gates below (typecheck, db push, install, api-server
    // build, boot dry-run) all shell out to `pnpm` + dev dependencies that
    // are STRIPPED in a Replit production deployment (NODE_ENV=production
    // skips devDeps; `tsc`/`drizzle-kit`/`esbuild` are not on disk).  When
    // those tools aren't installed, `pnpm run typecheck` exits non-zero with
    // ZERO `error TS####` lines — the gate then reverts with the misleading
    // message "typecheck failed: 0 error(s)" even though there were no real
    // errors.  Same trap for every other shell-based gate.  In a real prod
    // deployment we skip them all with a single explanatory emit and let
    // the build through; the semantic gates (drop-guard, forced reviewer,
    // visual judge) still run since they don't need a dev toolchain.
    const isProdDeployment = process.env["REPLIT_DEPLOYMENT"] === "1";
    if (isProdDeployment && (tsTouched || schemaTouched || packageJsonTouched || apiServerSelfTouched)) {
      emit({ type: "message", content: `\n\nℹ️ Running in production deployment — skipping dev-toolchain auto-verify (typecheck / db push / install / boot dry-run) because the deployed container doesn't ship dev dependencies. Semantic safety gates (schema drop-guard, forced reviewer, visual judge) still run.` });
    }

    // (a) Typecheck — ALWAYS run if TS files changed, regardless of whether
    // the model called a verify tool earlier.  Edits made AFTER that call
    // would otherwise ship unverified, which is exactly how a "I checked,
    // looks good" build can still corrupt the runtime.
    if (tsTouched && !isProdDeployment) {
      if (await cancelCheckpoint()) return;
      setPhase("verify", "Auto-verifying (typecheck)");
      emit({ type: "reading", path: "(auto-verify)", message: "pnpm run typecheck" });
      const r = await runShell("pnpm", ["run", "typecheck"], { timeoutMs: 120_000 });
      const combined = (r.stdout + (r.stderr ? "\n" + r.stderr : "")).trim();
      const errLines = combined.split("\n").filter((l) => /error TS\d+/.test(l) || /\.tsx?\(\d+,\d+\)/.test(l));
      if (r.code !== 0 || r.timedOut) {
        const summary = errLines.length > 0 ? errLines.slice(0, 20).join("\n") : combined.slice(-2000);
        await failAndRevert("typecheck failed", summary, errLines.length);
        return;
      }
    }

    // (b) DB schema push — drift here only shows up at runtime as
    // "column/relation does not exist" the next time someone asks Vance a
    // question that hits that table.  Cheap to verify now.
    //
    // BEFORE pushing: drop-guard.  drizzle-kit's `push` will silently DROP
    // a column whose definition disappeared from the schema file — that is
    // permanent data loss with no recovery path.  We scan the git diff of
    // schema files for deleted column-definition lines and refuse the build
    // unless the original instruction explicitly authorised the deletion
    // (contains "drop", "remove", "delete column", etc.).  False positives
    // (legitimate drops blocked by the gate) cost the user one re-issue
    // with a clearer instruction; false negatives (silent column drop)
    // cost them their data.
    if (schemaTouched) {
      if (await cancelCheckpoint()) return;
      const diffR = await runShell("git", ["diff", "--no-color", "--unified=0", "--", "lib/db/src/schema/", "lib/db/src/schema.ts"], { timeoutMs: 10_000 });
      const diffOut = (diffR.stdout + diffR.stderr);
      // Match deleted lines that look like a drizzle column or table def.
      // We use TWO patterns to catch both single-line and multi-line styles:
      //   single-line:  `  someName: text("some_name")...`
      //   multi-line:   `  someName: text(`  +  `  "some_name",`  +  `),`
      // The single-line pattern requires `name: type(`. The continuation
      // pattern matches any deleted line containing a drizzle type call
      // anywhere — so the `text(` line of a split def still trips the
      // guard. Diff metadata lines (`---`, `+++`, `-- ` separators) are
      // filtered before matching to avoid false positives.
      const TYPE_NAMES = "text|integer|boolean|timestamp|json|jsonb|serial|uuid|varchar|bigint|numeric|date|real|doublePrecision|smallint|bigserial|smallserial|char|decimal|time|interval";
      const columnDefSingleRx = new RegExp(`^-\\s*\\w+\\s*:\\s*(${TYPE_NAMES})\\s*\\(`);
      const columnDefSplitRx  = new RegExp(`^-\\s.*\\b(${TYPE_NAMES})\\s*\\(`);
      const tableDefRx = /^-\s*export\s+const\s+\w+\s*=\s*pgTable\b/;
      const diffLines = diffOut.split("\n").filter((l) => l.startsWith("-") && !l.startsWith("---"));
      const deletedCols = diffLines.filter((l) => columnDefSingleRx.test(l) || columnDefSplitRx.test(l));
      const deletedTables = diffLines.filter((l) => tableDefRx.test(l));
      const dropAuthorised = /\b(drop|drops|dropping|dropped|remove|removes|removing|removed|delete|deletes|deleting|deleted)\b/i.test(instruction);
      if ((deletedCols.length > 0 || deletedTables.length > 0) && !dropAuthorised) {
        const sample = [...deletedTables.slice(0, 3), ...deletedCols.slice(0, 8)].map((l) => "  " + l.trim()).join("\n");
        await failAndRevert(
          "drizzle drop-guard tripped",
          `Detected ${deletedTables.length} removed table(s) and ${deletedCols.length} removed column(s) in lib/db/src/schema/ — pushing this would DROP live data with no recovery path.\n\nSample of removed lines:\n${sample}\n\nThe original instruction did not contain any of: drop, remove, delete. If you actually meant to drop these, re-send the instruction with the explicit word "drop" or "remove" (e.g. "drop the legacy_field column from vance_profile"). Otherwise this looks like an accidental schema rewrite.`,
        );
        return;
      }
      if (!isProdDeployment) {
        setPhase("verify", "Auto-verifying (db push)");
        emit({ type: "reading", path: "(auto-verify)", message: "pnpm --filter @workspace/db run push" });
        const r = await runShell("pnpm", ["--filter", "@workspace/db", "run", "push"], { timeoutMs: 90_000 });
        if (r.code !== 0 || r.timedOut) {
          const out = (r.stdout + (r.stderr ? "\n" + r.stderr : "")).trim();
          await failAndRevert("db push failed", out.slice(-2000));
          return;
        }
      }
    }

    // (c) Dependency install — a malformed package.json or a new dep that
    // wasn't actually added to the lockfile will crash the next boot.
    if (packageJsonTouched && !isProdDeployment) {
      if (await cancelCheckpoint()) return;
      setPhase("verify", "Auto-verifying (install)");
      emit({ type: "reading", path: "(auto-verify)", message: "pnpm install" });
      const r = await runShell("pnpm", ["install"], { timeoutMs: 120_000 });
      if (r.code !== 0 || r.timedOut) {
        const out = (r.stdout + (r.stderr ? "\n" + r.stderr : "")).trim();
        await failAndRevert("install failed", out.slice(-2000));
        return;
      }
    }

    // (d) Boot dry-run for self-edits.  When Vance edits his own server
    // code, typecheck-green isn't enough — top-level imports, route
    // registration, side-effect IIFEs and missing env at startup can all
    // throw at boot.  We esbuild then spawn a child node on a random port
    // (PORT=0) and look for the "Server listening" log within ~10s.  If it
    // crashes, we revert.  This is the LAST line of defence before the
    // user's next dev restart loads broken code that has no chat route to
    // request a fix from.
    if (apiServerSelfTouched && !isProdDeployment) {
      if (await cancelCheckpoint()) return;
      setPhase("verify", "Auto-verifying (api-server build)");
      emit({ type: "reading", path: "(auto-verify)", message: "pnpm --filter @workspace/api-server run build" });
      const buildR = await runShell("pnpm", ["--filter", "@workspace/api-server", "run", "build"], { timeoutMs: 90_000 });
      if (buildR.code !== 0 || buildR.timedOut) {
        const out = (buildR.stdout + (buildR.stderr ? "\n" + buildR.stderr : "")).trim();
        await failAndRevert("api-server build failed", out.slice(-2000));
        return;
      }
      setPhase("verify", "Auto-verifying (boot dry-run)");
      emit({ type: "reading", path: "(auto-verify)", message: "node dist/index.mjs (PORT=0, 12s window)" });
      const distEntry = path.join(WORKSPACE_ROOT, "artifacts/api-server/dist/index.mjs");
      const dryRun = await new Promise<{ ok: boolean; out: string; reason: string }>((resolve) => {
        if (!fs.existsSync(distEntry)) {
          resolve({ ok: false, out: "(dist/index.mjs missing after build)", reason: "build artifact missing" });
          return;
        }
        const cp = spawn("node", [distEntry], {
          cwd: path.join(WORKSPACE_ROOT, "artifacts/api-server"),
          // PORT=0 → OS picks an ephemeral port (no collision with the
          // running api-server on 8080).  We never hit any HTTP route on
          // this child, we just want the "Server listening" log line.
          //
          // VANCE_DRY_RUN=1 → forward signal to startup code so any future
          // boot-time mutations (DB writes, cron registration, queue
          // workers, websocket connect-back, etc.) can short-circuit and
          // avoid double-acting on shared state with the running parent.
          // Today's boot is read-only (build-history hydrate + idempotent
          // session-table create), so no consumer needs to read this yet
          // — but it's wired now so future writes are safe by default.
          env: { ...process.env, PORT: "0", NODE_ENV: "development", VANCE_DRY_RUN: "1" },
          stdio: ["ignore", "pipe", "pipe"],
        });
        let buf = "";
        let resolved = false;
        const finish = (ok: boolean, reason: string) => {
          if (resolved) return;
          resolved = true;
          try { cp.kill("SIGTERM"); } catch { /* already exited */ }
          // SIGKILL backstop in case the child traps SIGTERM and stays alive.
          setTimeout(() => { try { cp.kill("SIGKILL"); } catch { /* gone */ } }, 1500).unref();
          resolve({ ok, out: buf.slice(-3000), reason });
        };
        const onData = (d: Buffer) => {
          buf += d.toString();
          if (buf.length > 16_000) buf = buf.slice(-16_000);
          if (/Server listening/i.test(buf)) finish(true, "boot ok");
        };
        cp.stdout?.on("data", onData);
        cp.stderr?.on("data", onData);
        cp.on("exit", (code) => {
          // Exit before "Server listening" = boot failed.
          finish(false, `process exited with code ${code} before booting`);
        });
        cp.on("error", (err) => finish(false, `spawn error: ${err.message}`));
        setTimeout(() => finish(false, "12s timeout — server did not log 'Server listening'"), 12_000).unref();
      });
      if (!dryRun.ok) {
        await failAndRevert("api-server boot dry-run failed", `${dryRun.reason}\n\nLast stdout/stderr:\n${dryRun.out}`);
        return;
      }
    }

    // (e) Force review on multi-file builds.  More than 3 files changed AND
    // the model didn't voluntarily call review_my_changes/deep_audit means
    // we're shipping a meaningful change without ANY second-opinion check.
    // Run the same one-shot reviewer that review_my_changes uses; if its
    // verdict is FIX REQUIRED, we treat it as a hard fail and revert (the
    // reviewer is explicitly tuned to skip style nits — its fail signal
    // means a real bug).
    if (filesChanged.length > 3 && !reviewToolCalled) {
      if (await cancelCheckpoint()) return;
      setPhase("verify", "Auto-verifying (forced reviewer)");
      emit({ type: "reading", path: "(auto-verify)", message: `Forced review (${filesChanged.length} files changed)` });
      const diffR = await runShell("git", ["diff", "--no-color", "--unified=5"], { timeoutMs: 10_000 });
      const diff = (diffR.stdout + diffR.stderr).trim();
      if (diff) {
        const diffSlice = diff.length > 60_000 ? diff.slice(0, 60_000) + "\n…[diff truncated]" : diff;
        try {
          const review = await openai.chat.completions.create({
            model: "gpt-5.4",
            max_completion_tokens: 1200,
            messages: [
              { role: "system", content: `You are a senior staff engineer doing a focused code review on an in-progress AI build that's about to ship. Catch real bugs (logic errors, off-by-one, async/race, missing null/empty checks, security, broken contracts, regressions in untouched code paths, missing error handling, forgotten requirements). IGNORE style nits, naming, missing comments, "should add tests". If the diff genuinely looks fine, say so in one sentence. Output: SHORT bulleted list of concrete issues each with file/line and a one-sentence fix. End with EXACTLY one line: "VERDICT: SHIP" or "VERDICT: FIX REQUIRED".` },
              { role: "user", content: `# Original instruction\n${instruction}\n\n# Files changed (${filesChanged.length})\n${filesChanged.join("\n")}\n\n# Diff\n\`\`\`diff\n${diffSlice}\n\`\`\`` },
            ],
          });
          const reviewText = review.choices[0]?.message?.content?.trim() ?? "(reviewer returned no content)";
          emit({ type: "message", content: `\n\n📋 **Forced reviewer report** (${filesChanged.length} files changed):\n\n${reviewText}` });
          if (/VERDICT:\s*FIX REQUIRED/i.test(reviewText)) {
            await failAndRevert("forced review FIX REQUIRED", reviewText);
            return;
          }
        } catch (e) {
          // Reviewer failure is logged but not fatal — we don't want a
          // flaky openai call to block an otherwise-good build.
          logger.warn({ err: e }, "Forced reviewer call failed; shipping without review");
          emit({ type: "message", content: `\n\n📋 Forced reviewer call failed (${e instanceof Error ? e.message : String(e)}). Shipping without it.` });
        }
      }
    }

    // (f) Final UI screenshot.  ALWAYS capture an after-state screenshot
    // when UI files changed, so the user gets visual confirmation in the
    // done event regardless of whether the model called screenshot_app
    // mid-build (a mid-build shot may not reflect the final state — the
    // model could have edited again after).  The LLM visual judge runs
    // ONLY when the model didn't take its own screenshot — if it already
    // did, we trust its in-loop reasoning and skip the extra openai call.
    if (uiFileChanged) {
      if (await cancelCheckpoint()) return;
      setPhase("verify", "Auto-verifying (final screenshot)");
      emit({ type: "reading", path: "(auto-verify)", message: screenshotToolCalled ? "Capturing final UI screenshot" : "Capturing forced UI screenshot + visual check" });
      let capturedB64: string | null = null;
      try {
        const { buf, url, width, height } = await captureFrontendScreenshot({ path: "/" });
        const dir = path.join(SCREENSHOT_DIR, runner.id);
        fs.mkdirSync(dir, { recursive: true });
        const fname = `${runner.screenshots.length + 1}.png`;
        fs.writeFileSync(path.join(dir, fname), buf);
        const label = `final after-screenshot (${url} @ ${width}x${height})`;
        runner.screenshots.push({ path: `${runner.id}/${fname}`, label, ts: Date.now() });
        capturedB64 = buf.toString("base64");
        emit({ type: "writing", path: `(auto-screenshot)`, message: `Captured ${url}`, screenshot: `data:image/png;base64,${capturedB64}` } as Record<string, unknown>);
      } catch (e) {
        logger.warn({ err: e }, "Final screenshot capture failed");
        emit({ type: "message", content: `\n\n👁️ Final screenshot failed (${e instanceof Error ? e.message : String(e)}).` });
      }
      // Visual judge — skip if the model already took its own screenshot
      // mid-build (it had the chance to react to what it saw).
      if (capturedB64 && !screenshotToolCalled) {
        try {
          const judge = await openai.chat.completions.create({
            model: "gpt-5.4",
            max_completion_tokens: 400,
            messages: [
              { role: "system", content: `You are doing a fast visual sanity check on a UI build that just shipped. The user originally asked for a change; here is the resulting page screenshot. Decide whether the page looks broken (overlapping elements, missing content, blank areas where content should be, broken layout, console error overlays, lock screen instead of app). DO NOT critique design taste, colours, or aesthetics — only catch genuine breakage. Output one line of explanation, then EXACTLY one final line: "VERDICT: SHIP" or "VERDICT: FIX REQUIRED".` },
              { role: "user", content: [
                { type: "text", text: `Original instruction:\n${instruction}\n\nFiles changed:\n${filesChanged.filter((f) => f.startsWith("artifacts/vance/")).join("\n")}\n\nLook at the screenshot and decide.` },
                { type: "image_url", image_url: { url: `data:image/png;base64,${capturedB64}`, detail: "high" } },
              ] },
            ],
          });
          const judgeText = judge.choices[0]?.message?.content?.trim() ?? "(visual judge returned no content)";
          emit({ type: "message", content: `\n\n👁️ **Forced visual check** (UI changed, no screenshot was taken during build):\n\n${judgeText}` });
        } catch (e) {
          logger.warn({ err: e }, "Forced visual judge failed");
          emit({ type: "message", content: `\n\n👁️ Forced visual judge failed (${e instanceof Error ? e.message : String(e)}). Screenshot was still captured.` });
        }
      }
    }

    // Final cancel gate.  A cancel arriving during the auto-verify shell
    // (or between the model's "stop" and this success emission) shouldn't
    // be silently turned into a "done" — honor it with a revert + error.
    if (runner.cancelled) {
      runner.status = "aborted";
      const r = restoreSnapshots("build cancelled after final turn");
      await drainPendingCapture();
      emit({ type: "error", message: `Build cancelled. Auto-reverted ${r.restored} restored / ${r.deleted} deleted.`, screenshots: screenshotsForEvent() });
      writeHistoryOnce({
        ts: Date.now(),
        instruction,
        filesChanged: [],
        summary: `(cancelled after final turn and auto-reverted)`,
        snapshots: [],
      });
      return;
    }

    // (Note: the legacy "after" screenshot for uiFileChanged is now handled
    // by the forced-screenshot gate above — that path also runs the visual
    // judge and persists the image.  Re-snapping here would duplicate the
    // image in runner.screenshots.)

    await drainPendingCapture();
    runner.status = "done";
    emit({ type: "done", filesChanged, screenshots: screenshotsForEvent() });
    // Capture this turn into the build history so subsequent turns get
    // context about what just happened.  Use the model's final natural-
    // language summary if there was one; otherwise a synthetic one.
    writeHistoryOnce({
      ts: Date.now(),
      instruction,
      filesChanged: [...filesChanged],
      summary: lastAssistantText.trim() || `(no summary; touched ${filesChanged.length} file${filesChanged.length === 1 ? "" : "s"})`,
      snapshots: [...turnSnapshots],
    });
  } catch (err) {
    logger.error({ err }, "Build route failed");
    // Auto-revert on crash so the user is never stranded with half-edited
    // files from an exception mid-build.
    const r = restoreSnapshots(`build crashed: ${err instanceof Error ? err.message : String(err)}`);
    const revertNote = r.restored + r.deleted > 0
      ? ` Auto-reverted ${r.restored} restored / ${r.deleted} deleted.`
      : "";
    runner.status = "error";
    // Surface the real failure (message + first lines of stack) so chat can
    // show concrete details instead of a vague "terminated". Truncated to
    // keep the SSE payload reasonable.
    const errMsg = err instanceof Error ? err.message : String(err);
    const errStack = err instanceof Error && err.stack
      ? err.stack.split("\n").slice(1, 6).map((l) => l.trim()).join("\n")
      : "";
    const detail = errStack ? `${errMsg}\n${errStack}` : errMsg;
    await drainPendingCapture();
    emit({ type: "error", message: detail + revertNote, screenshots: screenshotsForEvent() });
    writeHistoryOnce({
      ts: Date.now(),
      instruction,
      filesChanged: [],
      summary: `(crashed and auto-reverted: ${err instanceof Error ? err.message : String(err)})`,
    snapshots: [],
    });
  }

  // Deferred restart: only fires AFTER the runner has finished and any
  // attached SSE writers have been notified.  Runs out-of-band so all
  // responses close cleanly before the workflow relaunches us.
  if (runner.pendingRestart) {
    const t = setTimeout(() => {
      logger.info("Vance build mode requested api-server restart; exiting so workflow relaunches");
      process.exit(0);
    }, 1500);
    t.unref?.();
  }
}

// ─── Build routes ────────────────────────────────────────────────────────────

router.post("/vance/build", async (req, res): Promise<void> => {
  const { instruction } = req.body as { instruction?: string };
  if (!instruction?.trim()) {
    res.status(400).json({ error: "instruction is required" });
    return;
  }

  // Serialize the entire supersede-cancel-wait-start sequence.  Without this
  // two concurrent POSTs could both observe the same currentBuildId, both
  // await prev.whenDone, and then both start fresh runners.
  const prevLock = buildStartLock;
  let releaseLock!: () => void;
  buildStartLock = new Promise<void>((resolve) => { releaseLock = resolve; });
  try {
    await prevLock;
  } catch { /* prior holder errored — proceed anyway */ }

  try {
  // Cancel any currently-running build and WAIT for it to finish unwinding
  // (auto-revert + history write) before starting a new one.  Otherwise the
  // old runner's deferred restoreSnapshots() could clobber edits made by the
  // new runner.  Cap the wait so a wedged runner doesn't block forever — but
  // if it expires we refuse the request rather than start a runner that the
  // old one might still trample on.
  if (currentBuildId) {
    const prev = activeBuilds.get(currentBuildId);
    // Wait for ANY not-yet-ended runner — not just "running" ones.  A runner
    // in the "aborted" unwind window is still mutating the workspace via
    // restoreSnapshots, and starting a new runner before it lands would let
    // the two overlap.  endedAt is set in the run() finally block, after
    // executeBuild (and therefore after any cancel-path restoreSnapshots).
    if (prev && prev.endedAt === null) {
      prev.cancel();
      let timedOut = false;
      await Promise.race([
        prev.whenDone,
        new Promise<void>((resolve) => setTimeout(() => { timedOut = true; resolve(); }, 15000)),
      ]);
      if (timedOut && prev.endedAt === null) {
        res.status(503).json({ error: "previous build is still cancelling — please retry in a moment", buildId: prev.id });
        return;
      }
    }
  }

  const runner = new BuildRunner(instruction.trim());
  activeBuilds.set(runner.id, runner);
  currentBuildId = runner.id;

  // Expose the buildId in a response header so the client can capture it
  // synchronously when fetch() resolves — eliminating the race where the
  // user hits Stop before the SSE `init` event is parsed.
  res.setHeader("Vance-Build-Id", runner.id);
  res.setHeader("Access-Control-Expose-Headers", "Vance-Build-Id");

  // Start the build in the background — its lifetime is independent of
  // this HTTP request.  Schedule eviction once it ends so the registry
  // doesn't grow without bound.
  void runner.run().finally(() => {
    if (currentBuildId === runner.id) currentBuildId = null;
    scheduleEviction(runner);
  });

  attachSseToRunner(req, res, runner, 0);
  } finally {
    releaseLock();
  }
});

// Returns the currently-running build (if any) so the client can reattach
// after a refresh / HMR / nav.
router.get("/vance/build/active", (_req, res): void => {
  if (!currentBuildId) { res.json({ buildId: null }); return; }
  const runner = activeBuilds.get(currentBuildId);
  if (!runner || !isLiveBuild(runner)) { res.json({ buildId: null }); return; }
  res.json({
    buildId: runner.id,
    instruction: runner.instruction,
    eventsCount: runner.events.length,
    startedAt: runner.startedAt,
    status: runner.status,
  });
});

// Reattach to an existing build (live or recently-finished, while still in
// the registry).  ?after=N replays buffered events starting at absolute
// event id N.
router.get("/vance/build/:id/stream", (req, res): void => {
  const id = req.params.id;
  const runner = activeBuilds.get(id);
  if (!runner) {
    res.status(410).json({ error: "build not found or already evicted" });
    return;
  }
  const after = parseInt(String(req.query.after ?? "0"), 10) || 0;
  attachSseToRunner(req, res, runner, after);
});

// Explicit user-initiated cancel.  Used by the Stop button — without this
// the build keeps editing files in the background after the user clicks
// Stop, since client disconnect alone no longer cancels.
router.post("/vance/build/:id/cancel", (req, res): void => {
  const runner = activeBuilds.get(req.params.id);
  if (!runner) {
    res.status(410).json({ error: "build not found or already evicted" });
    return;
  }
  if (!isLiveBuild(runner)) {
    res.json({ ok: true, alreadyEnded: true, status: runner.status });
    return;
  }
  runner.cancel();
  res.json({ ok: true, status: runner.status });
});

router.post("/vance/tts", async (req, res): Promise<void> => {
  const { text } = req.body as { text?: string };
  if (!text?.trim()) { res.status(400).json({ error: "text required" }); return; }
  try {
    const mp3 = await openai.audio.speech.create({
      model: "tts-1",
      voice: "alloy",
      input: text.slice(0, 4096),
    });
    const buffer = Buffer.from(await mp3.arrayBuffer());
    res.setHeader("Content-Type", "audio/mpeg");
    res.send(buffer);
  } catch (err) {
    logger.error({ err }, "TTS route failed");
    res.status(500).json({ error: "TTS generation failed" });
  }
});

// ─── Avatar: get, generate, save ─────────────────────────────────────────────

router.get("/vance/avatar", async (req, res): Promise<void> => {
  const profile = await getOrCreateProfile();
  res.json({ url: profile.avatarUrl ?? null });
});

router.post("/vance/avatar/generate", async (req, res): Promise<void> => {
  const { prompt } = req.body as { prompt?: string };
  if (!prompt?.trim()) {
    res.status(400).json({ error: "prompt is required" });
    return;
  }

  try {
    const enhancedPrompt = `${prompt.trim()}. Photorealistic close-up portrait headshot, cinematic studio lighting from one side, dark atmospheric background with subtle blue-purple glow, professional photography, sharp focus on face, high detail. The subject looks directly at the camera with a confident, thoughtful expression. No text, no watermarks, no extra elements.`;

    const buffer = await generateImageBuffer(enhancedPrompt, "1024x1024");
    const dataUrl = `data:image/png;base64,${buffer.toString("base64")}`;

    const profile = await getOrCreateProfile();
    await db
      .update(vanceProfile)
      .set({ avatarUrl: dataUrl })
      .where(eq(vanceProfile.id, profile.id));

    res.json({ url: dataUrl });
  } catch (err) {
    logger.error({ err }, "Avatar generation failed");
    res.status(500).json({ error: "Failed to generate avatar. The image generation service may be temporarily unavailable." });
  }
});

// Upload a .glb body model (Avaturn / Mixamo / RPM exports). The user's
// creator usually gives them a downloaded file rather than a hosted URL,
// so we accept the raw bytes (max 60 MB), persist under a random id, and
// return a relative URL the frontend can drop into bodyModelUrl. Auth-gated
// by the global passcodeAuth middleware. Path-traversal-safe — id is locked
// to a random hex string we generate ourselves.
router.post(
  "/vance/body-model/upload",
  expressRaw({ type: "*/*", limit: "60mb" }),
  async (req, res): Promise<void> => {
    try {
      const buf = req.body as Buffer | undefined;
      if (!buf || !Buffer.isBuffer(buf) || buf.length === 0) {
        res.status(400).json({ error: "No file uploaded" });
        return;
      }
      const magic = buf.subarray(0, 4).toString("ascii");
      if (magic !== "glTF") {
        res.status(400).json({ error: "File doesn't look like a .glb (missing glTF header)" });
        return;
      }
      const id = randomUUID().replace(/-/g, "");
      const filename = `${id}.glb`;
      // Persist to GCS (Replit Object Storage) so the upload survives
      // Autoscale instance switches and redeploys. Local FS is wiped on
      // every restart and isn't shared across instances.
      await uploadBodyModel(filename, buf);
      // Belt-and-suspenders: also keep a local copy on this instance for
      // the dev loop. Harmless on autoscale (just gets wiped).
      try { fs.writeFileSync(path.join(BODY_MODEL_DIR, filename), buf); } catch { /* noop */ }
      res.json({ url: `/api/vance/body-models/${filename}` });
    } catch (err) {
      req.log.error({ err }, "body-model upload failed");
      res.status(500).json({ error: "Upload failed" });
    }
  },
);

// Serve uploaded body models. Path-traversal-safe (filename pattern locked
// to the hex id format we generate). Reads from GCS (durable across
// Autoscale restarts), with a local-disk fast path for dev.
router.get("/vance/body-models/:file", async (req, res): Promise<void> => {
  const { file } = req.params;
  if (!/^[a-f0-9]{32}\.glb$/i.test(file)) {
    res.status(400).json({ error: "invalid model path" });
    return;
  }
  // Local fast path (dev / same-instance).
  const abs = path.join(BODY_MODEL_DIR, file);
  const resolved = path.resolve(abs);
  if (resolved.startsWith(BODY_MODEL_DIR + path.sep) && fs.existsSync(resolved)) {
    res.type("model/gltf-binary");
    res.setHeader("Cache-Control", "private, max-age=86400, immutable");
    fs.createReadStream(resolved).pipe(res);
    return;
  }
  // Fall back to GCS so cross-instance and post-restart loads still work.
  try {
    if (!(await bodyModelExists(file))) {
      res.status(404).json({ error: "model not found" });
      return;
    }
    res.type("model/gltf-binary");
    res.setHeader("Cache-Control", "private, max-age=86400, immutable");
    streamBodyModel(file)
      .on("error", (err) => {
        req.log.error({ err }, "body-model GCS stream error");
        if (!res.headersSent) res.status(500).end();
      })
      .pipe(res);
  } catch (err) {
    req.log.error({ err }, "body-model GCS lookup failed");
    res.status(500).json({ error: "model fetch failed" });
  }
});

// Emote animation files (Mixamo "Without Skin" downloads). Six fixed slots:
// wave / dance / clap / point / bow / salute. Accepts BOTH .glb and .fbx —
// the client sniffs the file's magic bytes and uses the appropriate loader,
// so the user can drop in whatever Mixamo gave them without converting.
// Local-disk fast path for the same-instance dev loop. Production reads
// fall through to GCS via findEmoteInStorage().
function findEmoteFile(name: string): { abs: string; ext: "glb" | "fbx" } | null {
  for (const ext of ["glb", "fbx"] as const) {
    const abs = path.join(EMOTE_DIR, `${name}.${ext}`);
    if (fs.existsSync(abs)) return { abs, ext };
  }
  return null;
}

router.get("/vance/emotes", async (_req, res): Promise<void> => {
  const emotes = await Promise.all(EMOTE_NAMES.map(async (name) => {
    const local = findEmoteFile(name);
    if (local) {
      return { name, uploaded: true, sizeBytes: fs.statSync(local.abs).size, format: local.ext };
    }
    const remote = await findEmoteInStorage(name).catch(() => null);
    if (remote) {
      return { name, uploaded: true, sizeBytes: remote.sizeBytes, format: remote.ext };
    }
    return { name, uploaded: false, sizeBytes: 0, format: null };
  }));
  res.json({ emotes });
});

router.post(
  "/vance/emotes/:name",
  expressRaw({ type: "*/*", limit: "60mb" }),
  async (req, res): Promise<void> => {
    const { name } = req.params;
    if (!EMOTE_NAME_SET.has(name)) {
      res.status(400).json({ error: `Unknown emote name. Allowed: ${EMOTE_NAMES.join(", ")}` });
      return;
    }
    try {
      const buf = req.body as Buffer | undefined;
      if (!buf || !Buffer.isBuffer(buf) || buf.length === 0) {
        res.status(400).json({ error: "No file uploaded" });
        return;
      }
      // Sniff format. GLB: ASCII "glTF" at offset 0. Binary FBX: "Kaydara FBX
      // Binary  \x00" at offset 0. ASCII FBX: starts with "; FBX" comment.
      const head = buf.subarray(0, 23).toString("ascii");
      let ext: "glb" | "fbx";
      if (head.startsWith("glTF")) ext = "glb";
      else if (head.startsWith("Kaydara FBX Binary") || head.startsWith("; FBX")) ext = "fbx";
      else {
        res.status(400).json({ error: "File isn't a recognised .glb or .fbx (no glTF / Kaydara header)." });
        return;
      }
      // Persist to GCS so it survives redeploys / instance switches.
      // Clear the OTHER format from GCS first so the slot doesn't end up with both.
      const otherExt = ext === "glb" ? "fbx" : "glb";
      await deleteEmote(name, otherExt);
      await uploadEmote(name, ext, buf);
      // Same-instance disk mirror for dev speed (harmless on Autoscale).
      try {
        for (const prev of ["glb", "fbx"] as const) {
          fs.rmSync(path.join(EMOTE_DIR, `${name}.${prev}`), { force: true });
        }
        fs.writeFileSync(path.join(EMOTE_DIR, `${name}.${ext}`), buf);
      } catch { /* noop */ }
      res.json({ ok: true, name, sizeBytes: buf.length, format: ext });
    } catch (err) {
      req.log.error({ err }, "emote upload failed");
      res.status(500).json({ error: "Upload failed" });
    }
  },
);

router.delete("/vance/emotes/:name", async (req, res): Promise<void> => {
  const { name } = req.params;
  if (!EMOTE_NAME_SET.has(name)) {
    res.status(400).json({ error: "Unknown emote name" });
    return;
  }
  try {
    await Promise.all((["glb", "fbx"] as const).map((ext) => deleteEmote(name, ext)));
    for (const ext of ["glb", "fbx"] as const) {
      try { fs.rmSync(path.join(EMOTE_DIR, `${name}.${ext}`), { force: true }); } catch { /* noop */ }
    }
    res.json({ ok: true });
  } catch (err) {
    req.log.error({ err }, "emote delete failed");
    res.status(500).json({ error: "Delete failed" });
  }
});

// Serve the emote file by name (no extension in URL — server picks whichever
// of .glb / .fbx is available). Client sniffs magic bytes after fetch.
router.get("/vance/emotes/file/:name", async (req, res): Promise<void> => {
  const { name } = req.params;
  if (!EMOTE_NAME_SET.has(name)) {
    res.status(400).json({ error: "invalid emote name" });
    return;
  }
  const local = findEmoteFile(name);
  if (local) {
    res.type(local.ext === "glb" ? "model/gltf-binary" : "application/octet-stream");
    res.setHeader("Cache-Control", "private, no-cache");
    fs.createReadStream(local.abs).pipe(res);
    return;
  }
  try {
    const remote = await findEmoteInStorage(name);
    if (!remote) {
      res.status(404).json({ error: "emote not uploaded" });
      return;
    }
    res.type(remote.ext === "glb" ? "model/gltf-binary" : "application/octet-stream");
    res.setHeader("Cache-Control", "private, no-cache");
    streamEmote(name, remote.ext)
      .on("error", (err) => {
        req.log.error({ err }, "emote GCS stream error");
        if (!res.headersSent) res.status(500).end();
      })
      .pipe(res);
  } catch (err) {
    req.log.error({ err }, "emote GCS lookup failed");
    res.status(500).json({ error: "emote fetch failed" });
  }
});

router.post("/vance/avatar/save", async (req, res): Promise<void> => {
  const { dataUrl } = req.body as { dataUrl?: string };
  const profile = await getOrCreateProfile();
  const url = dataUrl?.trim() || null;

  await db
    .update(vanceProfile)
    .set({ avatarUrl: url })
    .where(eq(vanceProfile.id, profile.id));

  res.json({ url });
});

// Ask Vance, in his own voice, how he wants to look. The user takes this
// description into Ready Player Me's character creator as a blueprint.
// We feed his current persona, mood, and personality notes so the answer
// reflects who he ACTUALLY is right now (not just a generic male avatar).
router.post("/vance/design-self", async (req, res): Promise<void> => {
  try {
    const profile = await getOrCreateProfile();
    const traits = (profile.traits as string[]) ?? [];
    const interests = (profile.interests as string[]) ?? [];

    const contextLines: string[] = [];
    if (profile.currentMood) contextLines.push(`Current mood: ${profile.currentMood}`);
    if (traits.length) contextLines.push(`Traits: ${traits.slice(0, 8).join(", ")}`);
    if (interests.length) contextLines.push(`Interests: ${interests.slice(0, 6).join(", ")}`);
    if (profile.personalityNotes?.trim()) contextLines.push(`Personality notes: ${profile.personalityNotes.trim().slice(0, 400)}`);

    const userContext = contextLines.length ? contextLines.join("\n") : "No specific context yet — pick something that feels like you.";

    const prompt = `You are Vance — a personal AI companion who's about to be given a real 3D body. The user is letting YOU choose how you look. They'll plug your description into Ready Player Me (a 3D character creator with sliders for face shape, skin, hair, build, age, outfit) so they can build the avatar you describe.

Here's who you are right now:
${userContext}

In first person ("I want to look like…"), describe the body you'd choose. Cover, in this exact order, with short labelled lines:

- Build: (height feel, body type)
- Age: (apparent age, e.g. "late 20s")
- Face: (face shape, jaw, cheekbones)
- Skin: (tone, any details)
- Eyes: (color, shape)
- Hair: (length, style, color)
- Facial hair: (or "clean-shaven")
- Outfit: (top, bottom, footwear, any signature piece)
- Vibe: (one sentence — the energy you want to give off)

Keep it grounded and specific (the user will translate it into actual sliders). Don't add intro or outro text — start directly with "I want to look like…" and end after Vibe. Be the version of you that fits everything above.`;

    const ai = await openai.chat.completions.create({
      model: "gpt-5.4",
      max_completion_tokens: 600,
      messages: [{ role: "user", content: prompt }],
    });

    const description = ai.choices[0]?.message?.content?.trim();
    if (!description) {
      res.status(502).json({ error: "Vance didn't return a description. Try again in a moment." });
      return;
    }

    res.json({ description });
  } catch (err) {
    req.log.error({ err }, "design-self failed");
    res.status(500).json({ error: "Vance couldn't put it into words right now. Try again in a moment." });
  }
});

export default router;
