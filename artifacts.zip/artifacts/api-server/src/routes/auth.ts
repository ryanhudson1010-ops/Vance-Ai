import { Router, type Request, type Response } from "express";
import { AUTH_COOKIE_NAME, isAuthed } from "../middlewares/passcodeAuth";

const router: Router = Router();

const COOKIE_MAX_AGE_MS = 1000 * 60 * 60 * 24 * 365;

function cookieOptions() {
  return {
    httpOnly: true,
    secure: process.env["NODE_ENV"] === "production",
    sameSite: "lax" as const,
    signed: true,
    maxAge: COOKIE_MAX_AGE_MS,
    path: "/",
  };
}

// ─── Login rate limit ────────────────────────────────────────────────────────
// Single-user PIN → in-memory limiter is sufficient. 5 failed attempts within
// 15 minutes locks that IP out for 15 minutes from the first failure.
// Successful login clears the IP's counter.  Reset window is rolling on the
// FIRST failure only — additional failures inside the window do not extend it.
const RL_MAX_ATTEMPTS = 5;
const RL_WINDOW_MS = 15 * 60 * 1000;
type RlEntry = { count: number; firstFailAt: number };
const loginAttempts = new Map<string, RlEntry>();

function getClientIp(req: Request): string {
  // express.set("trust proxy") would let req.ip do this for us, but we don't
  // assume that's been set globally. Walk the standard chain manually.
  const fwd = String(req.headers["x-forwarded-for"] ?? "").split(",")[0]?.trim();
  return fwd || req.socket.remoteAddress || "unknown";
}

function rlCheck(ip: string): { allowed: boolean; retryAfterSec: number } {
  const now = Date.now();
  const entry = loginAttempts.get(ip);
  if (!entry) return { allowed: true, retryAfterSec: 0 };
  if (now - entry.firstFailAt >= RL_WINDOW_MS) {
    loginAttempts.delete(ip);
    return { allowed: true, retryAfterSec: 0 };
  }
  if (entry.count >= RL_MAX_ATTEMPTS) {
    return { allowed: false, retryAfterSec: Math.ceil((RL_WINDOW_MS - (now - entry.firstFailAt)) / 1000) };
  }
  return { allowed: true, retryAfterSec: 0 };
}

function rlRecordFailure(ip: string): void {
  const now = Date.now();
  const entry = loginAttempts.get(ip);
  if (!entry || now - entry.firstFailAt >= RL_WINDOW_MS) {
    loginAttempts.set(ip, { count: 1, firstFailAt: now });
  } else {
    entry.count += 1;
  }
}

function rlClear(ip: string): void {
  loginAttempts.delete(ip);
}

// Periodic GC so the map doesn't grow unbounded across long uptimes.  Cheap:
// O(n) scan every 30 minutes, expired entries dropped.
setInterval(() => {
  const now = Date.now();
  for (const [ip, e] of loginAttempts) {
    if (now - e.firstFailAt >= RL_WINDOW_MS) loginAttempts.delete(ip);
  }
}, 30 * 60 * 1000).unref();

router.get("/auth/me", (req: Request, res: Response): void => {
  res.json({ authenticated: isAuthed(req) });
});

router.post("/auth/login", (req: Request, res: Response): void => {
  const ip = getClientIp(req);
  const rl = rlCheck(ip);
  if (!rl.allowed) {
    res.setHeader("Retry-After", String(rl.retryAfterSec));
    res.status(429).json({ error: `Too many failed attempts. Try again in ${rl.retryAfterSec}s.` });
    return;
  }

  const passcode = String((req.body as { passcode?: unknown })?.passcode ?? "");
  const expected = process.env["VANCE_PASSCODE"] ?? "";
  if (!expected) {
    req.log.error("VANCE_PASSCODE env var is not set");
    res.status(500).json({ error: "Server passcode not configured. Set VANCE_PASSCODE." });
    return;
  }
  if (!passcode) {
    res.status(400).json({ error: "Passcode required" });
    return;
  }
  // Constant-time-ish compare.  Length-mismatch shortcut is fine here — this is
  // a single-user PIN gate, not a public credential.
  if (passcode.length !== expected.length) {
    rlRecordFailure(ip);
    res.status(401).json({ error: "Wrong passcode" });
    return;
  }
  let mismatch = 0;
  for (let i = 0; i < passcode.length; i++) {
    mismatch |= passcode.charCodeAt(i) ^ expected.charCodeAt(i);
  }
  if (mismatch !== 0) {
    rlRecordFailure(ip);
    res.status(401).json({ error: "Wrong passcode" });
    return;
  }
  rlClear(ip);
  res.cookie(AUTH_COOKIE_NAME, "ok", cookieOptions());
  res.json({ authenticated: true });
});

router.post("/auth/logout", (_req: Request, res: Response): void => {
  res.clearCookie(AUTH_COOKIE_NAME, { path: "/" });
  res.json({ authenticated: false });
});

export default router;
