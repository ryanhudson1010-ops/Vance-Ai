import path from "node:path";
import { Router, type IRouter } from "express";
import { FILE_DOWNLOAD_DIR } from "./openai/index";

// Public download route for Vance-produced files (created in chat via
// create_text_file / create_zip).
//
// Why this lives OUTSIDE the passcode-gated tree:
// iOS Safari (and standalone-PWA mode in particular) does NOT reliably attach
// the app's signed HttpOnly session cookie to download requests triggered by
// `<a href download>`. The result was that every tap on a download card
// returned `{"error":"unauthorized"}` (a tiny JSON body) which iOS then saved
// to disk as `<original>.json` — making it look like Vance had produced JSON
// files when in fact the real zip/text was sitting on the server untouched.
//
// Security model: the URL itself is the capability. `dir` is a server-minted
// random UUID (~10^36 search space) emitted only inside an authenticated chat
// session, the path-traversal guard pins resolution under FILE_DOWNLOAD_DIR,
// and the filename regex blocks anything but a safe basename. There is no
// directory listing endpoint, so an attacker would need to guess a full UUID
// to enumerate. This is the same pattern used for screenshot URLs.
const router: IRouter = Router();

router.get("/openai/files/:dir/:fileName", (req, res): void => {
  const { dir, fileName } = req.params as { dir: string; fileName: string };
  if (!/^[a-z0-9-]{8,64}$/i.test(dir) || !/^[a-z0-9._-]{1,80}$/i.test(fileName)) {
    res.status(400).json({ error: "invalid file path" });
    return;
  }
  const abs = path.join(FILE_DOWNLOAD_DIR, dir, fileName);
  const resolved = path.resolve(abs);
  if (!resolved.startsWith(FILE_DOWNLOAD_DIR + path.sep)) {
    res.status(400).json({ error: "invalid file path" });
    return;
  }
  res.sendFile(resolved, {
    // FILE_DOWNLOAD_DIR is `.vance-files` (a dotfile path component). Express
    // 5's `send` defaults to `dotfiles: "ignore"`, which 404s on ANY segment
    // starting with `.` — that was returning a 26-byte JSON error which iOS
    // saved as "<original>.json", making it look like Vance was producing
    // JSON files. Allow dotfiles so the real binary streams through.
    dotfiles: "allow",
    headers: {
      "Content-Disposition": `attachment; filename="${fileName.replace(/"/g, "")}"`,
      "Cache-Control": "private, max-age=3600",
    },
  }, (err) => {
    if (err && !res.headersSent) {
      res.status(404).json({ error: "file not found" });
    }
  });
});

export default router;
