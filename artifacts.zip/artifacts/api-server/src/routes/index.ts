import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import openaiRouter from "./openai";
import vanceRouter from "./vance";
import vanceFilesRouter from "./vance-files";
import { passcodeAuth } from "../middlewares/passcodeAuth";

const router: IRouter = Router();

// Public routes — no passcode required.
router.use(healthRouter);
router.use(authRouter);
// Vance-produced file downloads. Public on purpose — see vance-files.ts for
// the security rationale (iOS PWA cookie quirks + UUID-as-capability).
router.use(vanceFilesRouter);

// Everything below requires the passcode cookie.
router.use(passcodeAuth);
router.use(openaiRouter);
router.use(vanceRouter);

export default router;
