import { execSync } from "node:child_process";
import { createHmac } from "node:crypto";
import { logger } from "./logger";

export interface CaptureOptions {
  path: string;
  width?: number;
  height?: number;
  timeoutMs?: number;
}

export interface CaptureResult {
  buf: Buffer;
  url: string;
  width: number;
  height: number;
}

let cachedExecutablePath: string | undefined;
let executablePathResolved = false;

function resolveChromiumPath(): string | undefined {
  if (executablePathResolved) return cachedExecutablePath;
  executablePathResolved = true;
  try {
    const which = execSync(
      "which chromium 2>/dev/null || which chromium-browser 2>/dev/null",
      { encoding: "utf8" },
    ).trim();
    if (which) cachedExecutablePath = which;
  } catch {
    /* fall through to playwright default */
  }
  return cachedExecutablePath;
}

function buildAuthCookies(frontendBase: string): Array<{ name: string; value: string; url: string }> {
  const sessionSecret = process.env["SESSION_SECRET"] ?? "";
  if (!sessionSecret) return [];
  const sig = createHmac("sha256", sessionSecret).update("ok").digest("base64").replace(/=+$/, "");
  return [{ name: "vance_auth", value: `s:ok.${sig}`, url: frontendBase }];
}

/**
 * Capture a screenshot of the running Vance frontend.  Goes through the
 * shared proxy at port 80 (NOT the api-server's port) and injects a signed
 * `vance_auth=ok` cookie so the capture lands on the actual app instead of
 * the passcode lock screen.
 */
export async function captureFrontendScreenshot(opts: CaptureOptions): Promise<CaptureResult> {
  const frontendBase = process.env["VANCE_FRONTEND_URL"] ?? "http://localhost:80";
  const reqPath = opts.path.startsWith("/") ? opts.path : "/" + opts.path;
  const width = Math.min(Math.max(opts.width ?? 402, 320), 2000);
  const height = Math.min(Math.max(opts.height ?? 874, 240), 2000);
  const timeout = opts.timeoutMs ?? 15_000;

  let pw: typeof import("playwright");
  try {
    pw = await import("playwright");
  } catch (e) {
    throw new Error(`playwright not importable: ${e instanceof Error ? e.message : String(e)}`);
  }

  const executablePath = resolveChromiumPath();
  const browser = await pw.chromium.launch({
    headless: true,
    executablePath,
    args: ["--no-sandbox", "--disable-dev-shm-usage"],
  });
  try {
    const ctx = await browser.newContext({ viewport: { width, height } });
    const cookies = buildAuthCookies(frontendBase);
    if (cookies.length > 0) await ctx.addCookies(cookies);
    const page = await ctx.newPage();
    const url = frontendBase + reqPath;
    // `networkidle` deadlocks whenever the page holds an SSE/long-poll
    // open (e.g. /api/vance/build/<id>/stream while a build is running),
    // because the network is *never* idle.  `load` fires once the document
    // and its sub-resources are loaded; we then give React a brief moment
    // to paint before snapping the screenshot.
    await page.goto(url, { waitUntil: "load", timeout });
    await page.waitForTimeout(800);
    const buf = await page.screenshot({ type: "png", fullPage: false });
    await ctx.close();
    return { buf, url, width, height };
  } finally {
    try { await browser.close(); } catch (e) { logger.warn({ err: e }, "browser close failed"); }
  }
}

/**
 * Detect intent to capture a NEW screenshot right now (as opposed to
 * recalling a previously-taken one).  Phrases like "take a screenshot",
 * "screenshot the chat", "show me the app", "capture the page".
 */
export function detectCaptureIntent(text: string): boolean {
  const t = text.toLowerCase();
  // Verbs that imply asking for a fresh image now. "send (me)" added because
  // users say "send me a screenshot" expecting a fresh one (this previously
  // fell through to the build-history auto-attach and surfaced stale 404s).
  // We deliberately exclude broad verbs like "do", "make", "get" — they
  // collide with normal phrasing ("do this", "make a photo slot", "get the
  // image URL") and caused a real false-positive where accepting a website-
  // edit proposal that mentioned "photo slot" auto-captured the chat surface
  // and made Vance describe his own UI instead of doing the build.
  const verb = /\b(take|grab|capture|snap|give\s+me|send(\s+me)?|show\s+me)\b/;
  // Loose nouns ("picture", "photo", "view") only count when paired with a
  // subject that points at the app/chat/screen — otherwise things like
  // "photo slot", "hero image", "interior photo" trigger false positives.
  // The strict screenshot-family nouns trigger on their own.
  const strictNoun = /\b(screen\s*shot|screencap|screen\s*cap|snapshot)\b/;
  const looseNounWithSubject = /\b(picture|photo|view|image)\s+(of\s+)?(the\s+)?(app|chat|screen|page|ui|interface|conversation|memories|profile)\b/;
  if (verb.test(t) && (strictNoun.test(t) || looseNounWithSubject.test(t))) return true;
  // Direct imperatives like "screenshot it", "screenshot the chat now".
  if (/\bscreen\s*shot\s+(it|the|yourself|your\s*self|now|please|the\s+(app|chat|page|screen|ui))\b/.test(t)) return true;
  // "show me the app/chat/screen now"
  if (/\bshow\s+me\s+(the\s+)?(app|chat|page|screen|ui|memories|profile)\b/.test(t)) return true;
  // "what does it look like right now"
  if (/\b(what|how)\s+(does|do)\s+(it|the\s+\w+)\s+look(s)?\s+(like\s+)?(now|right\s+now|currently)\b/.test(t)) return true;
  // Plain visual questions where the only sensible answer is a fresh capture
  // of right now: "what do you see", "what are you seeing", "can you see
  // (the chat|yourself|me)".  These previously fell through to the build-
  // history auto-attach (which surfaced old 404 build screenshots and made
  // Vance describe them as if they were live).
  if (/\bwhat\s+(do|are)\s+you\s+see(ing)?\b/.test(t)) return true;
  if (/\bcan\s+you\s+see\s+(the|your|me|us|it|that)\b/.test(t)) return true;
  return false;
}

/**
 * Try to extract a target route from the user's message.  Defaults to "/".
 * Returns a frontend route path (with leading slash).
 */
export function extractCaptureTarget(text: string): string {
  const t = text.toLowerCase();
  // Explicit /paths win — but normalise the chat aliases to "/" because the
  // Vance frontend serves the chat at the root route; "/chat" falls through
  // to wouter's NotFound and 404s the screenshot.
  const pathMatch = t.match(/(?:^|\s)(\/[a-z0-9/_-]{1,40})\b/);
  if (pathMatch?.[1]) {
    const p = pathMatch[1];
    if (p === "/chat" || p === "/chats" || p === "/home" || p === "/index") return "/";
    return p;
  }
  if (/\bmemor(y|ies)\b/.test(t)) return "/memories";
  if (/\bprofile\b/.test(t)) return "/profile";
  if (/\bsettings?\b/.test(t)) return "/settings";
  // "the chat", "chat screen", "chat page", "main chat" → root.
  if (/\bchat(\s+(screen|page|view|window|ui|tab))?\b/.test(t)) return "/";
  return "/";
}
