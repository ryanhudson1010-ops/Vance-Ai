import { z } from "zod/v4";
import AdmZip from "adm-zip";

// ── Palette ────────────────────────────────────────────────────────────────
//
// Per-business palette is now FULLY user-driven: the spec carries the four
// hex colours (primary / secondary / background / accent) and the template
// derives every other shade it needs from them. There is no enum of
// "approved" palettes any more — anything the model picks (or the user
// dictates) flows through.
//
// The DEFAULT_PALETTE below is a neutral dark-navy + slate-gray + white +
// near-black accent that reads as modern/professional for almost any
// vertical (cleaning, gun shop, ATV, law firm, …). It's used only when
// the spec omits the palette field entirely.

const DEFAULT_PALETTE = {
  primary: "#1e3a8a", // dark navy — buttons, headers, accents
  secondary: "#64748b", // slate gray — secondary surfaces / hero gradient end
  background: "#ffffff", // page bg
  accent: "#0f172a", // near-black — strong text / dark CTA bg
  text: "#111827", // body text
} as const;

const HEX6 = /^#[0-9a-fA-F]{6}$/;

interface PaletteSpec {
  brand: string;       // primary
  brandDark: string;   // primary darkened (for dark-bg sections)
  brandLight: string;  // primary lightened (for hover/border tints)
  heroFrom: string;    // hero gradient start (= primary)
  heroTo: string;      // hero gradient end   (= secondary)
  textOnBrand: string; // text colour on top of primary surfaces
  background: string;  // page background
  accent: string;      // accent colour
  text: string;        // body text colour
}

function clamp(n: number, lo: number, hi: number): number {
  return n < lo ? lo : n > hi ? hi : n;
}

function hexToRgb(hex: string): { r: number; g: number; b: number } {
  const h = hex.replace("#", "");
  return {
    r: parseInt(h.slice(0, 2), 16),
    g: parseInt(h.slice(2, 4), 16),
    b: parseInt(h.slice(4, 6), 16),
  };
}

function rgbToHex(r: number, g: number, b: number): string {
  const h = (n: number) => clamp(Math.round(n), 0, 255).toString(16).padStart(2, "0");
  return `#${h(r)}${h(g)}${h(b)}`;
}

/** Mix `hex` toward black by `amount` (0..1). 0 = unchanged, 1 = black. */
function darken(hex: string, amount: number): string {
  const { r, g, b } = hexToRgb(hex);
  const f = 1 - clamp(amount, 0, 1);
  return rgbToHex(r * f, g * f, b * f);
}

/** Mix `hex` toward white by `amount` (0..1). 0 = unchanged, 1 = white. */
function lighten(hex: string, amount: number): string {
  const { r, g, b } = hexToRgb(hex);
  const f = clamp(amount, 0, 1);
  return rgbToHex(r + (255 - r) * f, g + (255 - g) * f, b + (255 - b) * f);
}

/** Pick black or white text for best contrast on a coloured background. */
function readableTextOn(hex: string): string {
  const { r, g, b } = hexToRgb(hex);
  // Standard sRGB relative luminance approximation.
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return luminance > 0.6 ? "#0f172a" : "#ffffff";
}

/**
 * Build the rendering palette from the user-supplied colours.
 * Only `primary`, `secondary`, `background`, and `accent` come from the
 * spec; brandDark / brandLight / textOnBrand are computed.
 */
function derivePaletteSpec(p: { primary: string; secondary: string; background: string; accent: string; text: string }): PaletteSpec {
  return {
    brand: p.primary,
    brandDark: darken(p.primary, 0.18),
    brandLight: lighten(p.primary, 0.85),
    heroFrom: p.primary,
    heroTo: p.secondary,
    textOnBrand: readableTextOn(p.primary),
    background: p.background,
    accent: p.accent,
    text: p.text,
  };
}

// ── Vibe → presentation tweaks ─────────────────────────────────────────────
//
// `vibe` is a free-form short string from the spec. We map common vibe
// keywords to extra Tailwind classes applied to headings, so the generated
// site actually feels different per business type. (Display-font selection
// now lives in the `fonts` field — see VERTICAL_DEFAULTS below for the
// per-vertical font picks that hydrate it when the spec omits it.)
const VIBE_PROFILES: Array<{ test: RegExp; headingClass: string }> = [
  { test: /tactical|rugged|industrial|military|combat|gunmetal/i, headingClass: "uppercase tracking-wider" },
  { test: /adventurous|bold|energetic|extreme|aggressive|action/i, headingClass: "uppercase italic" },
  { test: /elegant|luxury|premium|refined|sophisticated|upscale/i, headingClass: "tracking-tight" },
  { test: /playful|fun|friendly|whimsical|cheerful/i, headingClass: "tracking-tight" },
];

function vibeProfile(vibe: string): { headingClass: string } {
  if (!vibe) return { headingClass: "" };
  for (const p of VIBE_PROFILES) {
    if (p.test.test(vibe)) return { headingClass: p.headingClass };
  }
  return { headingClass: "" };
}

// ── Vertical-aware smart defaults ──────────────────────────────────────────
//
// When the spec leaves `palette` / `fonts` / `vibe` empty, we infer sensible
// per-vertical defaults from `businessType`. Each entry's regex matches free-
// form descriptors ("Tactical Firearms Shop", "Elegant Italian Restaurant",
// etc.) and contributes partial overrides on top of DEFAULT_PALETTE / Inter.
// Match order matters — the FIRST matching entry wins.
type PalettePartial = Partial<{ primary: string; secondary: string; accent: string; background: string; text: string }>;
type FontsPartial = Partial<{ heading: string; body: string }>;
// Stable, long-popular Unsplash photo IDs per vertical. URL pattern:
// `https://images.unsplash.com/photo-<id>?w=2000&q=80&auto=format&fit=crop`.
// These are all classics that have been on Unsplash for 5+ years with
// millions of downloads, so they're a safe deterministic default. If a user
// supplies their own `images.hero` in the spec it wins over this — these
// just stop the cleaning site from getting the generic mountain landscape
// the old Picsum default served.
// Prompt-driven image source. We tried two prior approaches that both
// failed: (1) hardcoded Unsplash photo IDs — IDs are opaque so several
// of mine pulled paintings/random scenes; (2) LoremFlickr keyword tags —
// Flickr tags are user-uploaded and noisy, so "clean,home" returned
// renovation-site photos. Pollinations.ai accepts a full English
// description prompt and returns a generated photograph matching it,
// for free, with no API key. The deterministic seed (hashed from the
// prompt) freezes which image gets served so the same build is stable.
// Latency: ~3-10s on first hit, cached after. Cloudflare/Pages caches
// the response, so the user's site visitors only pay it once per asset.
function poSeed(prompt: string): number {
  let h = 0;
  for (let i = 0; i < prompt.length; i++) h = ((h << 5) - h + prompt.charCodeAt(i)) | 0;
  return Math.abs(h) % 1000000;
}
const PO = (prompt: string, w = 800, h = 600) =>
  `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=${w}&height=${h}&nologo=true&seed=${poSeed(prompt)}`;
const PO_HERO = (p: string) => PO(p, 2000, 1200);
const PO_WIDE = (p: string) => PO(p, 1600, 900);
const PO_ABOUT = (p: string) => PO(p, 1200, 900);
const PO_CARD = (p: string) => PO(p, 800, 600);
const VERTICAL_DEFAULTS: Array<{
  test: RegExp;
  palette?: PalettePartial;
  fonts?: FontsPartial;
  vibe?: string;
  // Per-vertical CTA text — used when the spec doesn't supply one OR
  // supplies a call-shaped one ("Call Now"). Hospitality and destination
  // verticals (bar, restaurant, salon) get "Visit Us"/"Reserve a Table"
  // instead of the generic "Get a Free Estimate" service-business default.
  cta?: string;
  // When true, the always-on "Free Estimates" banner between hero and
  // services on the HOME page is skipped — bars/restaurants/salons don't
  // estimate anything, so the banner reads wrong.
  skipBanner?: boolean;
  // Picks which whole-page TEMPLATE the renderer uses. `"service"` is the
  // default (hero card + services grid + testimonials + contact form);
  // `"hospitality"` swaps in a destination-business layout (full-bleed
  // atmospheric hero + highlights strip + photo gallery + "Stop In"
  // find-us section + no contact form). Tag verticals where people come
  // TO the place (bars, restaurants, salons, event venues, shops).
  template?: "service" | "hospitality";
  // Used by the hospitality template as the "What's on" / highlights
  // strip when spec.services is empty. 3–5 short phrases that capture
  // the venue's offer at a glance ("Cold Beer on Tap", "Live Music Fri
  // & Sat", "Pool · Darts · Karaoke"). Never shown for service verticals.
  highlights?: string[];
  heroImage?: string;
  aboutImage?: string;
  servicesHeroImage?: string;
  contactImage?: string;
  // Per-vertical service-card photo bank. When the spec doesn't supply
  // `services[].image`, the renderer rotates through THIS list (cycling
  // by service index) so e.g. a cleaning site's service cards show
  // kitchens/bathrooms/windows — never random picsum cars. The user can
  // still swap any of them after the build (the REPLACE IMAGE comment
  // sits right above each img tag).
  serviceImages?: string[];
}> = [
  // Firearms / tactical. Prompts emphasise "professional photograph" so
  // pollinations renders photo-real images, not illustrations.
  { test: /\b(gun|firearm|ammo|tactical|rifle|pistol|shoot(?:ing)? range|gunsmith)\b/i,
    palette: { primary: "#1f2937", secondary: "#7f1d1d", accent: "#f59e0b", background: "#0a0a0a", text: "#f5f5f5" },
    fonts: { heading: "Oswald", body: "Roboto" },
    vibe: "tactical and rugged",
    cta: "Visit the Shop",
    skipBanner: true,
    template: "hospitality",
    highlights: ["Premium Firearms", "Friendly Staff", "Range On-Site", "Classes Available"],
    heroImage: PO_HERO("professional photograph of modern rifles arranged on dark tactical surface, dramatic moody lighting, high detail"),
    aboutImage: PO_ABOUT("professional photograph of a clean modern firearms shop interior with rifles on wall display, soft warm lighting"),
    servicesHeroImage: PO_WIDE("professional photograph of an indoor shooting range with lane dividers and target downrange, cinematic lighting"),
    contactImage: PO_WIDE("professional photograph of ammunition boxes and brass cartridges arranged on wood, soft studio lighting"),
    serviceImages: [
      PO_CARD("professional photograph of a modern semi-automatic rifle on dark surface, studio lighting"),
      PO_CARD("professional photograph of a handgun pistol on slate surface, dramatic lighting"),
      PO_CARD("professional photograph of an indoor shooting range with a person at the firing line, motion blur"),
      PO_CARD("professional photograph of brass ammunition cartridges in a row, macro detail"),
      PO_CARD("professional photograph of a gunsmith's workshop bench with tools and rifle parts, warm light"),
    ] },
  // ATV / power-sports / adventure
  { test: /\b(atv|utv|offroad|off-road|power\s*sports|motorcycle|dirt\s*bike|snowmobile|adventure|extreme)\b/i,
    palette: { primary: "#ea580c", secondary: "#1c1917", accent: "#facc15" },
    fonts: { heading: "Oswald", body: "Inter" },
    vibe: "adventurous and bold",
    cta: "Book a Test Ride",
    skipBanner: true,
    heroImage: PO_HERO("professional photograph of an ATV quad bike kicking up dust on a forest trail, golden hour, action shot"),
    aboutImage: PO_ABOUT("professional photograph of a clean modern powersports showroom with ATVs and UTVs, bright lighting"),
    servicesHeroImage: PO_WIDE("professional photograph of a dirt bike mid-jump on a motocross track, dramatic sky"),
    contactImage: PO_WIDE("professional photograph of a side-by-side UTV parked on a mountain ridge, scenic background"),
    serviceImages: [
      PO_CARD("professional photograph of a red ATV quad bike on a dirt trail, action shot"),
      PO_CARD("professional photograph of a dirt bike rider mid-air over a motocross jump"),
      PO_CARD("professional photograph of a UTV side-by-side driving through a rocky desert trail"),
      PO_CARD("professional photograph of an off-road motorcycle on a forest path at sunset"),
      PO_CARD("professional photograph of a snowmobile speeding across fresh snow, mountain backdrop"),
    ] },
  // Cleaning / janitorial / maid
  { test: /\b(clean(?:ing|er)?|maid|janitor(?:ial)?|housekeep|carpet|window\s*wash)\b/i,
    palette: { primary: "#0d9488", secondary: "#0f766e", accent: "#facc15" },
    // Fraunces = modern variable serif with warmth + personality. Far less
    // generic than Inter for a domestic/hospitality brand where the hero
    // wordmark (e.g. "You'll Have It Maid") needs to feel hand-crafted, not
    // SaaS-default. Inter body keeps service copy clean + readable.
    fonts: { heading: "Fraunces", body: "Inter" },
    vibe: "fresh and trustworthy",
    heroImage: PO_HERO("professional photograph of a sparkling clean modern white kitchen with sunlight streaming in, freshly cleaned countertops"),
    aboutImage: PO_ABOUT("professional photograph of a friendly house cleaner in uniform smiling while wiping a countertop, bright home interior"),
    servicesHeroImage: PO_WIDE("professional photograph of cleaning supplies — spray bottles, microfiber cloths, fresh flowers — arranged on a marble counter"),
    contactImage: PO_WIDE("professional photograph of a freshly cleaned bright living room with neatly arranged pillows, sunlight"),
    serviceImages: [
      // Each prompt describes a distinctly different cleaning scene so
      // service cards never look repetitive. Cycles by service index.
      PO_CARD("professional photograph of a spotless modern kitchen, sunlight, freshly wiped white countertops, no people"),
      PO_CARD("professional photograph of a sparkling clean bathroom with a polished chrome faucet, sunlight reflecting off white tile"),
      PO_CARD("professional photograph of a freshly vacuumed plush carpet with vacuum lines visible, bright living room"),
      PO_CARD("professional photograph of crystal clear glass windows being washed with a squeegee, sunlight streaming through"),
      PO_CARD("professional photograph of neatly folded white towels and bedsheets in a tidy laundry room"),
      PO_CARD("professional photograph of a mop on a freshly cleaned hardwood floor, sunlight, fresh and bright"),
    ] },
  // Restaurant / cafe / dining
  { test: /\b(restaurant|cafe|caf\u00e9|bistro|kitchen|dining|trattoria|pizzeria|bar\s*&\s*grill|eatery|steakhouse)\b/i,
    cta: "Reserve a Table",
    skipBanner: true,
    template: "hospitality",
    highlights: ["Seasonal Menu", "Locally Sourced", "Reservations Welcome", "Private Events"],
    palette: { primary: "#7c2d12", secondary: "#292524", accent: "#d4af37", background: "#fef7ed" },
    fonts: { heading: "Playfair Display", body: "Inter" },
    vibe: "warm and elegant",
    heroImage: PO_HERO("professional photograph of a warm cozy restaurant interior with candlelit tables, exposed brick wall, dim ambient lighting"),
    aboutImage: PO_ABOUT("professional photograph of a chef in white coat plating a gourmet dish in a clean restaurant kitchen"),
    servicesHeroImage: PO_WIDE("professional photograph of an elegantly plated gourmet entree on a white plate, top-down view, restaurant lighting"),
    contactImage: PO_WIDE("professional photograph of a beautifully set dinner table with wine glasses and linen napkins, warm candlelight"),
    serviceImages: [
      PO_CARD("professional photograph of a plated gourmet entree with garnish, top-down restaurant shot"),
      PO_CARD("professional photograph of a bowl of fresh italian pasta with sauce and herbs, restaurant lighting"),
      PO_CARD("professional photograph of a grilled steak with vegetables on a wooden board, smoke rising"),
      PO_CARD("professional photograph of an elegant dessert plated with berries and sauce drizzle"),
      PO_CARD("professional photograph of a glass of red wine on a candlelit restaurant table"),
      PO_CARD("professional photograph of a wood-fired pizza fresh out of the oven, restaurant kitchen"),
    ] },
  // Bar / pub / tavern / brewery / nightclub. Distinct from restaurant —
  // bars want dark moody interiors with warm amber lighting, neon, beer,
  // pool tables, jukeboxes — NOT plated food. Sits AFTER restaurant so
  // "bar & grill" still wins restaurant; plain "bar", "pub", "tavern",
  // "dive bar", "country bar", "sports bar", "lounge", "saloon",
  // "brewery", "taproom", "nightclub" fall through to here.
  { test: /\b(bar|pub|tavern|saloon|lounge|brewery|brewpub|taproom|alehouse|nightclub|cocktail|sports\s*bar|dive\s*bar|country\s*bar|honky\s*tonk|speakeasy|whiskey\s*bar|wine\s*bar)\b/i,
    cta: "Visit Us",
    skipBanner: true,
    template: "hospitality",
    highlights: ["Cold Beer on Tap", "Live Music Weekends", "Pool · Darts · Karaoke", "Open Late"],
    palette: { primary: "#7c2d12", secondary: "#1c1917", accent: "#f59e0b", background: "#0c0a09", text: "#fafaf9" },
    fonts: { heading: "Oswald", body: "Inter" },
    vibe: "warm and laid-back",
    heroImage: PO_HERO("professional photograph of a warm cozy neighborhood bar interior at night, dark wood bar top, glowing neon signs on brick wall, amber pendant lights, bottles backlit on the back bar"),
    aboutImage: PO_ABOUT("professional photograph of a bartender pouring a draft beer from a tap with foam crowning the glass, warm amber bar lighting, dark wood background"),
    servicesHeroImage: PO_WIDE("professional photograph of a row of cold draft beers in pint glasses on a dark wood bar top, condensation on the glass, warm pub lighting"),
    contactImage: PO_WIDE("professional photograph of a vintage jukebox glowing in the corner of a dimly lit bar, neon reflections on dark wood floor"),
    serviceImages: [
      PO_CARD("professional photograph of a cold draft beer being poured into a pint glass with foam, dark bar background"),
      PO_CARD("professional photograph of a whiskey cocktail on the rocks in a rocks glass on a dark wood bar, warm amber lighting"),
      PO_CARD("professional photograph of a pool table with green felt under a hanging amber pendant light, cue ball mid-shot"),
      PO_CARD("professional photograph of a basket of crispy bar wings and fries on a dark wood table, warm bar lighting"),
      PO_CARD("professional photograph of a live local band playing guitars on a small stage in a dimly lit bar, audience silhouettes"),
      PO_CARD("professional photograph of a row of liquor bottles backlit on the back bar shelves, dark moody atmosphere"),
    ] },
  // Law / finance / professional services
  { test: /\b(law(?:yer|firm)?|attorney|legal|paralegal|finance|financial|accounting|cpa|tax|bank|advisor|wealth|insurance)\b/i,
    cta: "Schedule a Consultation",
    skipBanner: true,
    palette: { primary: "#1e3a8a", secondary: "#475569", accent: "#b45309" },
    fonts: { heading: "Montserrat", body: "Inter" },
    vibe: "professional and trustworthy",
    heroImage: PO_HERO("professional photograph of an elegant law firm office with bookshelves of leather-bound law books, mahogany desk, warm lighting"),
    aboutImage: PO_ABOUT("professional photograph of two business professionals shaking hands in a modern office, natural light"),
    servicesHeroImage: PO_WIDE("professional photograph of an open law book and a wooden gavel on a polished desk, soft lighting"),
    contactImage: PO_WIDE("professional photograph of a modern conference room with leather chairs and a long polished table, city view"),
    serviceImages: [
      PO_CARD("professional photograph of a wooden judge's gavel resting on a sound block on a polished desk"),
      PO_CARD("professional photograph of an open leather law book with reading glasses, warm desk lamp"),
      PO_CARD("professional photograph of a business handshake between two professionals in suits, office background"),
      PO_CARD("professional photograph of a hand signing a legal contract with a fountain pen, close-up"),
      PO_CARD("professional photograph of a modern executive desk with laptop and notebook, city skyline view through window"),
    ] },
  // Salon / spa / wellness
  { test: /\b(salon|spa|beauty|wellness|yoga|pilates|massage|nail|barber|aesthetic)\b/i,
    cta: "Book an Appointment",
    skipBanner: true,
    template: "hospitality",
    highlights: ["Walk-Ins Welcome", "Talented Stylists", "Premium Products", "Relaxing Atmosphere"],
    palette: { primary: "#be185d", secondary: "#831843", accent: "#fbbf24", background: "#fdf2f8" },
    fonts: { heading: "Playfair Display", body: "Inter" },
    vibe: "elegant and refined",
    heroImage: PO_HERO("professional photograph of a serene luxury spa interior with stone walls, candles, and a massage table, soft warm lighting"),
    aboutImage: PO_ABOUT("professional photograph of a modern hair salon interior with styling chairs and mirrors, soft pink palette"),
    servicesHeroImage: PO_WIDE("professional photograph of a relaxing massage therapy room with stones and lit candles, calm atmosphere"),
    contactImage: PO_WIDE("professional photograph of an elegant beauty treatment room with white robe folded neatly, fresh flowers"),
    serviceImages: [
      PO_CARD("professional photograph of a woman getting a haircut in a modern salon chair, stylist working"),
      PO_CARD("professional photograph of a relaxing back massage in a candlelit spa room"),
      PO_CARD("professional photograph of a manicure in progress, hands with painted nails, salon background"),
      PO_CARD("professional photograph of a facial treatment with serums and brushes, white spa towel"),
      PO_CARD("professional photograph of a yoga studio with rolled mats and natural light, peaceful atmosphere"),
      PO_CARD("professional photograph of a classic barber shop interior with vintage chairs and mirrors"),
    ] },
  // Tech / SaaS / consulting
  { test: /\b(tech|software|saas|app|digital|consult(?:ing|ant)?|agency|studio|startup|dev(?:eloper)?)\b/i,
    palette: { primary: "#2563eb", secondary: "#1e40af", accent: "#22d3ee" },
    fonts: { heading: "Inter", body: "Inter" },
    vibe: "modern and clean",
    heroImage: PO_HERO("professional photograph of a modern open-plan tech office with developers at laptops, large monitors with code, bright natural light"),
    aboutImage: PO_ABOUT("professional photograph of a startup team collaborating around a glass conference table with laptops, modern office"),
    servicesHeroImage: PO_WIDE("professional photograph of a sleek laptop displaying a data analytics dashboard with charts, dark mode"),
    contactImage: PO_WIDE("professional photograph of a modern minimalist desk with a laptop and a smartphone, soft natural light"),
    serviceImages: [
      PO_CARD("professional photograph of a developer's hands typing on a laptop with colorful code on screen, dark room"),
      PO_CARD("professional photograph of a computer screen showing a colorful analytics dashboard with line and bar charts"),
      PO_CARD("professional photograph of a startup team brainstorming with sticky notes on a glass wall, smiling"),
      PO_CARD("professional photograph of a modern server room with rows of glowing blue server racks"),
      PO_CARD("professional photograph of a smartphone on a wooden desk displaying a sleek mobile app interface"),
    ] },
  // Fitness / gym / personal training / crossfit. Distinct from salon/spa
  // (which catches yoga/pilates/massage — gentler wellness). Gym vibe is
  // high-energy, dark, bold, weights + cardio.
  { test: /\b(gym|fitness|crossfit|cross\s*fit|personal\s*train(?:er|ing)|bootcamp|boot\s*camp|kickbox|martial\s*arts|mma|boxing|jiu\s*jitsu|karate|tae\s*kwon|weightlifting|strength\s*training|f45|orangetheory)\b/i,
    cta: "Start Your Trial",
    skipBanner: true,
    palette: { primary: "#dc2626", secondary: "#0a0a0a", accent: "#facc15", background: "#0c0a09", text: "#fafaf9" },
    fonts: { heading: "Oswald", body: "Inter" },
    vibe: "bold and energetic",
    heroImage: PO_HERO("professional photograph of a modern gym interior with rows of dumbbells, squat racks, and exposed industrial ceiling, dramatic lighting"),
    aboutImage: PO_ABOUT("professional photograph of a personal trainer coaching a client through a deadlift with proper form, gym background, focused expression"),
    servicesHeroImage: PO_WIDE("professional photograph of an athlete mid-jump in a crossfit box with chalk dust, dramatic lighting"),
    contactImage: PO_WIDE("professional photograph of a row of heavy kettlebells and weight plates on a rubber gym floor"),
    serviceImages: [
      PO_CARD("professional photograph of a person bench pressing a heavy barbell with a spotter, gym lighting"),
      PO_CARD("professional photograph of a CrossFit athlete doing kettlebell swings with chalk dust in the air"),
      PO_CARD("professional photograph of a personal trainer demonstrating proper squat form with a client, modern gym"),
      PO_CARD("professional photograph of a boxer hitting a heavy bag with hand wraps, dim gym lighting"),
      PO_CARD("professional photograph of a row of treadmills and ellipticals in a modern fitness center, bright lighting"),
      PO_CARD("professional photograph of a yoga or stretching session in a sunlit fitness studio"),
    ] },
  // Medical / dental / clinic / chiropractic / optometry. Clean clinical
  // aesthetic — bright whites, calm blues, friendly modern lighting.
  { test: /\b(dental|dentist|orthodontist|medical|clinic|doctor|physician|pediatric|family\s*medicine|chiropract|optometr|optical|eye\s*care|urgent\s*care|primary\s*care|veterinar|hospital|surgeon|physical\s*therapy|pt\s*clinic|dermatolog|cardiolog)\b/i,
    cta: "Book an Appointment",
    skipBanner: true,
    palette: { primary: "#0369a1", secondary: "#075985", accent: "#22c55e", background: "#f8fafc", text: "#0f172a" },
    fonts: { heading: "Montserrat", body: "Inter" },
    vibe: "professional and trustworthy",
    heroImage: PO_HERO("professional photograph of a modern medical clinic reception with bright natural light, clean white walls, friendly atmosphere"),
    aboutImage: PO_ABOUT("professional photograph of a friendly doctor in a white coat smiling, modern clinic background, soft natural light"),
    servicesHeroImage: PO_WIDE("professional photograph of a clean modern exam room with medical equipment, bright lighting"),
    contactImage: PO_WIDE("professional photograph of a modern medical clinic waiting area with comfortable seating and plants"),
    serviceImages: [
      PO_CARD("professional photograph of a dentist examining a patient's teeth with a mirror, modern dental office"),
      PO_CARD("professional photograph of a doctor listening to a patient's heart with a stethoscope, clinic setting"),
      PO_CARD("professional photograph of an optometrist fitting a patient with eyeglasses, modern optical shop"),
      PO_CARD("professional photograph of a chiropractor adjusting a patient's back on a treatment table"),
      PO_CARD("professional photograph of a physical therapist guiding a patient through a stretch, bright therapy gym"),
      PO_CARD("professional photograph of a clean dental chair and equipment in a modern dental office, white tile"),
    ] },
  // Pet services — grooming, daycare, boarding, walking, training. Bright,
  // friendly, playful palette.
  { test: /\b(pet|dog|cat|puppy|kitten|groom(?:er|ing)?|kennel|boarding|doggy\s*day\s*care|dog\s*walk|pet\s*sit|animal\s*hospital|veterinary)\b/i,
    cta: "Book Grooming",
    skipBanner: true,
    palette: { primary: "#0ea5e9", secondary: "#0369a1", accent: "#f97316", background: "#f0f9ff", text: "#0c4a6e" },
    fonts: { heading: "Quicksand", body: "Nunito" },
    vibe: "playful and friendly",
    heroImage: PO_HERO("professional photograph of a happy golden retriever being groomed in a bright pet salon, soft natural lighting"),
    aboutImage: PO_ABOUT("professional photograph of a smiling pet groomer brushing a happy dog on a grooming table, bright friendly studio"),
    servicesHeroImage: PO_WIDE("professional photograph of multiple happy dogs playing together in a clean indoor doggy daycare, bright lighting"),
    contactImage: PO_WIDE("professional photograph of a clean modern pet boarding facility with comfortable individual kennels"),
    serviceImages: [
      PO_CARD("professional photograph of a happy dog getting a bath with bubbles, pet groomer's hands soaping the dog"),
      PO_CARD("professional photograph of a fluffy poodle being trimmed with grooming scissors, bright salon"),
      PO_CARD("professional photograph of a dog walker leading three leashed dogs on a sunny suburban street"),
      PO_CARD("professional photograph of happy dogs playing in a fenced outdoor doggy daycare, sunny day"),
      PO_CARD("professional photograph of a sleeping puppy curled up on a soft pet bed in a clean boarding room"),
      PO_CARD("professional photograph of a cat being gently brushed by a groomer, soft studio lighting"),
    ] },
  // Events / photography / wedding / DJ / catering. Editorial elegant vibe
  // — serif headings, warm cream background, gold accent.
  { test: /\b(wedding|photograph(?:y|er)|videograph|event\s*plan|dj\s*service|catering|caterer|florist|flowers|banquet|venue|reception\s*hall|party\s*plan)\b/i,
    cta: "Check Availability",
    skipBanner: true,
    template: "hospitality",
    highlights: ["Custom Packages", "Full-Service Team", "Beautiful Venues", "Unforgettable Days"],
    palette: { primary: "#1c1917", secondary: "#44403c", accent: "#d4af37", background: "#faf7f2", text: "#1c1917" },
    fonts: { heading: "Playfair Display", body: "Inter" },
    vibe: "elegant and refined",
    heroImage: PO_HERO("professional photograph of an elegant outdoor wedding ceremony with a flower arch and rows of white chairs, golden hour"),
    aboutImage: PO_ABOUT("professional photograph of a wedding photographer holding a camera at a beautiful outdoor venue, soft sunset light"),
    servicesHeroImage: PO_WIDE("professional photograph of an elegantly set wedding reception table with floral centerpieces, candles, and gold accents"),
    contactImage: PO_WIDE("professional photograph of a bride and groom holding hands at sunset, romantic outdoor setting"),
    serviceImages: [
      PO_CARD("professional photograph of a bride holding a bouquet of white roses in soft natural light"),
      PO_CARD("professional photograph of an elegantly set wedding reception table with candles and flowers"),
      PO_CARD("professional photograph of a DJ at a wedding reception with colorful lights and a dance floor crowd"),
      PO_CARD("professional photograph of a beautifully arranged floral centerpiece with white and blush flowers"),
      PO_CARD("professional photograph of an outdoor catering buffet with elegant platters and warming dishes"),
      PO_CARD("professional photograph of a multi-tier wedding cake with floral decoration on a wooden table"),
    ] },
  // Trades / outdoor / construction / home services — covers a LOT of
  // related trade keywords so plumbers, painters, graders, junk haulers,
  // pressure washers, handymen, etc. all land here instead of falling
  // through to the generic Picsum fallback.
  { test: /\b(landscap|lawn|garden|tree|arborist|construction|contractor|builder|remodel|renovation|roof(?:er|ing)?|plumb(?:er|ing)?|electric(?:ian|al)?|hvac|heating|cooling|air\s*condition|paving|asphalt|fenc(?:e|ing)|paint(?:er|ing)|drywall|siding|gutter|window\s*install|door\s*install|deck\s*build|carpenter|carpentry|welder|welding|mason(?:ry)?|concrete|tile|flooring|hardwood|cabinet|countertop|excavat|grading|grader|septic|sewer|well\s*drill|junk\s*removal|hauling|mover|moving\s*company|pressure\s*wash|power\s*wash|soft\s*wash|pest\s*control|exterminator|handyman|home\s*repair|home\s*service|chimney|insulation|garage\s*door|pool\s*service|spa\s*service|locksmith)\b/i,
    palette: { primary: "#166534", secondary: "#15803d", accent: "#f59e0b" },
    fonts: { heading: "Oswald", body: "Inter" },
    vibe: "reliable and hardworking",
    heroImage: PO_HERO("professional photograph of a contractor in work boots and tool belt on a residential construction site, golden hour"),
    aboutImage: PO_ABOUT("professional photograph of a professional landscaper mowing a manicured lawn in front of a suburban home, sunny day"),
    servicesHeroImage: PO_WIDE("professional photograph of a beautifully landscaped garden with neat hedges and flower beds, suburban home"),
    contactImage: PO_WIDE("professional photograph of new asphalt shingle roofing being installed on a residential home, blue sky"),
    serviceImages: [
      PO_CARD("professional photograph of a freshly mowed green lawn in front of a suburban home, sunny day"),
      PO_CARD("professional photograph of a residential construction site with framing visible, workers in hard hats"),
      PO_CARD("professional photograph of a roofer installing asphalt shingles on a sloped roof, blue sky"),
      PO_CARD("professional photograph of a plumber's hands fixing a copper pipe under a sink with a wrench"),
      PO_CARD("professional photograph of an electrician's hands wiring an outlet, tools visible"),
      PO_CARD("professional photograph of an organised workshop with hand tools hanging on a pegboard wall"),
    ] },
  // Real estate
  { test: /\b(real\s*estate|realtor|realty|broker|properties|homes\s*for\s*sale)\b/i,
    cta: "Schedule a Tour",
    skipBanner: true,
    palette: { primary: "#0f766e", secondary: "#134e4a", accent: "#d4af37" },
    fonts: { heading: "Montserrat", body: "Inter" },
    vibe: "polished and approachable",
    heroImage: PO_HERO("professional photograph of a beautiful modern two-story suburban home exterior at golden hour, manicured lawn"),
    aboutImage: PO_ABOUT("professional photograph of a bright open-concept living room interior with large windows and modern furniture"),
    servicesHeroImage: PO_WIDE("professional photograph of a SOLD real estate sign in front of a suburban home, sunny day"),
    contactImage: PO_WIDE("professional photograph of a modern luxury kitchen with marble island and pendant lights"),
    serviceImages: [
      PO_CARD("professional photograph of a beautiful modern suburban home exterior, twilight, lights on"),
      PO_CARD("professional photograph of a luxury home interior living room with high ceilings and natural light"),
      PO_CARD("professional photograph of a sleek modern kitchen with white marble island and pendant lighting"),
      PO_CARD("professional photograph of a FOR SALE real estate sign on a suburban front lawn, blue sky"),
      PO_CARD("professional photograph of a luxury apartment balcony overlooking a city skyline at sunset"),
    ] },
  // Auto / mechanic / dealership
  { test: /\b(auto(?:motive)?|mechanic|garage|tire|car\s*(?:wash|dealer)|dealership|body\s*shop)\b/i,
    cta: "Schedule Service",
    skipBanner: true,
    palette: { primary: "#dc2626", secondary: "#1c1917", accent: "#facc15" },
    fonts: { heading: "Oswald", body: "Inter" },
    vibe: "bold and dependable",
    heroImage: PO_HERO("professional photograph of a modern auto repair garage interior with cars on lifts, mechanics working, dramatic lighting"),
    aboutImage: PO_ABOUT("professional photograph of a mechanic in coveralls working on a car engine, focused expression, garage background"),
    servicesHeroImage: PO_WIDE("professional photograph of mechanic's hands using a wrench on a car engine, tools visible, garage"),
    contactImage: PO_WIDE("professional photograph of a car tire being changed by a mechanic in a service bay, professional setting"),
    serviceImages: [
      PO_CARD("professional photograph of a mechanic's hands working on a car engine with a wrench, garage lighting"),
      PO_CARD("professional photograph of a car tire being lifted onto a wheel hub in a service bay"),
      PO_CARD("professional photograph of fresh motor oil being poured into a car engine, close-up"),
      PO_CARD("professional photograph of a car being soaped at a professional car wash, foam and shine"),
      PO_CARD("professional photograph of a car body shop painter spraying glossy red paint on a panel"),
    ] },
];

type VerticalImagePack = {
  palette?: PalettePartial;
  fonts?: FontsPartial;
  vibe?: string;
  cta?: string;
  skipBanner?: boolean;
  template?: "service" | "hospitality";
  highlights?: string[];
  heroImage?: string;
  aboutImage?: string;
  servicesHeroImage?: string;
  contactImage?: string;
  serviceImages?: string[];
};

function pickVerticalDefaults(businessType: string): VerticalImagePack {
  if (!businessType) return {};
  for (const v of VERTICAL_DEFAULTS) {
    if (v.test.test(businessType)) return {
      palette: v.palette,
      fonts: v.fonts,
      vibe: v.vibe,
      cta: v.cta,
      skipBanner: v.skipBanner,
      template: v.template,
      highlights: v.highlights,
      heroImage: v.heroImage,
      aboutImage: v.aboutImage,
      servicesHeroImage: v.servicesHeroImage,
      contactImage: v.contactImage,
      serviceImages: v.serviceImages,
    };
  }
  return {};
}

// ── Retry variation packs ──────────────────────────────────────────────────
//
// When a user clicks "Retry build (new design)" on a proposal bubble, the
// backend ships the SAME content (businessName / services / phone / etc.)
// but with a fresh full-stack visual identity — different palette, fonts,
// and vibe. Variation 0 = no override (use whatever palette/fonts/vibe the
// spec specified, falling back to vertical defaults). Variation 1..N picks
// the (variation-1) entry from this list, wrapping at the end. Each pack
// is intentionally distinct so two clicks in a row never feel similar.
// Order matters — variation 1 is the FIRST retry the user sees, so put
// the most universally flattering ones first.
type VariationPack = {
  name: string;
  palette: { primary: string; secondary: string; background: string; accent: string; text: string };
  fonts: { heading: string; body: string };
  vibe: string;
};
const VARIATION_PACKS: VariationPack[] = [
  {
    // 1: dark + neon — premium tech / agency feel.
    name: "dark-neon",
    palette: { primary: "#0ea5e9", secondary: "#1e293b", background: "#0b0f1a", accent: "#22d3ee", text: "#f1f5f9" },
    fonts: { heading: "Inter", body: "Inter" },
    vibe: "modern and clean",
  },
  {
    // 2: warm editorial — cream bg, serif heading, gold accent.
    name: "warm-editorial",
    palette: { primary: "#7c2d12", secondary: "#44403c", background: "#fef7ed", accent: "#d4af37", text: "#1c1917" },
    fonts: { heading: "Playfair Display", body: "Inter" },
    vibe: "warm and elegant",
  },
  {
    // 3: bold contrast — high-energy poster style.
    name: "bold-contrast",
    palette: { primary: "#dc2626", secondary: "#0a0a0a", background: "#fafafa", accent: "#facc15", text: "#0a0a0a" },
    fonts: { heading: "Oswald", body: "Inter" },
    vibe: "adventurous and bold",
  },
  {
    // 4: minimalist mono — near-white bg, near-black text, one accent.
    name: "minimalist-mono",
    palette: { primary: "#171717", secondary: "#525252", background: "#ffffff", accent: "#0d9488", text: "#171717" },
    fonts: { heading: "Montserrat", body: "Inter" },
    vibe: "professional and trustworthy",
  },
  {
    // 5: soft pastel — playful, friendly, approachable.
    name: "soft-pastel",
    palette: { primary: "#7c3aed", secondary: "#a78bfa", background: "#faf5ff", accent: "#f472b6", text: "#1e1b4b" },
    fonts: { heading: "Inter", body: "Inter" },
    vibe: "playful and friendly",
  },
];

export function pickVariationPack(variation: number): VariationPack | null {
  if (!Number.isInteger(variation) || variation <= 0) return null;
  return VARIATION_PACKS[(variation - 1) % VARIATION_PACKS.length] ?? null;
}

// Build a single Google Fonts <link> URL covering all requested font
// families with sensible weight ranges. Inter is always loaded so the
// fallback CSS works even when the body font fails to download.
function buildGoogleFontsLink(families: string[]): string {
  const seen = new Set<string>();
  const ordered: string[] = [];
  // Always include Inter as a safety net for body text.
  ordered.push("Inter");
  seen.add("inter");
  for (const raw of families) {
    const name = (raw || "").trim();
    if (!name) continue;
    const key = name.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    ordered.push(name);
  }
  // Conservative weight set that covers everything from body to extrabold
  // headings without ballooning the request size.
  const weights = "wght@400;500;600;700;800;900";
  const fams = ordered
    .map((n) => `family=${encodeURIComponent(n).replace(/%20/g, "+")}:${weights}`)
    .join("&");
  return `https://fonts.googleapis.com/css2?${fams}&display=swap`;
}

function fontFamilyCss(name: string, fallback: "sans" | "serif"): string {
  const n = (name || "").trim() || "Inter";
  const fb = fallback === "serif" ? "Georgia, serif" : "system-ui, -apple-system, sans-serif";
  return `'${n}', ${fb}`;
}

function isLikelySerifFont(name: string): boolean {
  return /\b(playfair|merriweather|lora|cormorant|libre|baskerville|garamond|fraunces|dm\s*serif|crimson|bitter|spectral|source\s*serif|eb\s*garamond|serif)\b/i.test(name || "");
}

// Curated Picsum image IDs that look reasonable as generic placeholder
// photography (interiors, workspaces, neutral scenes — nothing wildly
// off-tone). Used as deterministic fallbacks when the spec doesn't supply
// custom image URLs. The user can swap any of them by editing the
// `<!-- REPLACE IMAGE -->` block in the generated HTML.
const DEFAULT_IMAGES = {
  hero: "https://picsum.photos/id/1015/2000/1200",
  about: "https://picsum.photos/id/823/1200/900",
  servicesHero: "https://picsum.photos/id/849/1600/900",
  contact: "https://picsum.photos/id/1067/1600/900",
};
const DEFAULT_SERVICE_IMAGES = [
  "https://picsum.photos/id/1080/800/600",
  "https://picsum.photos/id/1071/800/600",
  "https://picsum.photos/id/1059/800/600",
  "https://picsum.photos/id/1043/800/600",
  "https://picsum.photos/id/164/800/600",
  "https://picsum.photos/id/106/800/600",
  "https://picsum.photos/id/225/800/600",
  "https://picsum.photos/id/119/800/600",
  "https://picsum.photos/id/249/800/600",
  "https://picsum.photos/id/376/800/600",
  "https://picsum.photos/id/421/800/600",
  "https://picsum.photos/id/513/800/600",
];

// Services accept BOTH the new shape `{name, description, details}` and
// the legacy `{title, description}`. The transform normalises to a single
// canonical `{title, description, details, image}` shape so the renderers
// don't need to know which form came in.
const ServiceSchema = z
  .object({
    title: z.string().trim().min(1).max(80).optional(),
    name: z.string().trim().min(1).max(80).optional(),
    description: z.string().trim().min(1).max(500),
    details: z.string().trim().max(800).nullable().optional(),
    // Accept null — the model frequently emits `image: null` as a "no image
    // yet" sentinel. Treat null the same as omitted (falls back to defaults).
    image: z.string().trim().url().max(500).nullable().optional(),
  })
  .transform((s) => ({
    title: (s.title ?? s.name ?? "").trim(),
    description: s.description,
    details: s.details ?? null,
    image: s.image ?? undefined,
  }))
  .refine((s) => s.title.length > 0, { message: "service must have a 'name' or 'title'" });

const TestimonialSchema = z.object({
  quote: z.string().trim().min(1).max(400),
  author: z.string().trim().min(1).max(80),
});

const ImagesSchema = z
  .object({
    // All four image slots accept null — the model frequently emits
    // `{hero:null, about:null, ...}` as a "no image yet" sentinel. The
    // outer transform normalises null → undefined so renderer falsy-checks
    // (`if (images.hero)`) and vertical-default fallbacks behave as if
    // the field were omitted.
    hero: z.string().trim().url().max(500).nullable().optional(),
    about: z.string().trim().url().max(500).nullable().optional(),
    servicesHero: z.string().trim().url().max(500).nullable().optional(),
    contact: z.string().trim().url().max(500).nullable().optional(),
  })
  .optional()
  .default({})
  .transform((imgs) => ({
    hero: imgs.hero ?? undefined,
    about: imgs.about ?? undefined,
    servicesHero: imgs.servicesHero ?? undefined,
    contact: imgs.contact ?? undefined,
  }));

// Sections that may appear on the page. Used by the spec's `sections` field
// to drive what actually renders (and, in multi-page mode, which extra pages
// get emitted). Order in the array is irrelevant — render order is fixed
// inside the renderers themselves.
const SECTION_IDS = ["hero", "about", "services", "testimonials", "area", "contact"] as const;
type SectionId = (typeof SECTION_IDS)[number];

const RawWebsiteSpecSchema = z.object({
  businessName: z.string().trim().min(1).max(100),
  // Free-form vertical descriptor used by the renderer to nudge tone (e.g.
  // "Cleaning Service", "Firearms Retail", "ATV Sales & Service"). Optional.
  businessType: z.string().trim().max(100).optional().default(""),
  tagline: z.string().trim().min(1).max(200),
  description: z.string().trim().max(500).optional().default(""),
  // Free-form, single-line location. Preferred over the legacy
  // address/city/state/zip fields when set; the legacy fields are still
  // supported for backwards compat and used as the structured contact block.
  location: z.string().trim().max(200).optional().default(""),
  phone: z.string().trim().max(50).optional().default(""),
  email: z.string().trim().max(120).optional().default(""),
  address: z.string().trim().max(200).optional().default(""),
  city: z.string().trim().max(100).optional().default(""),
  state: z.string().trim().max(50).optional().default(""),
  zipCode: z.string().trim().max(20).optional().default(""),
  hours: z.string().trim().max(200).optional().default(""),
  // Free-form descriptor — "fresh and trustworthy", "tactical and rugged",
  // "adventurous and bold", etc. The renderer matches keywords in this
  // string against VIBE_PROFILES to pick a heading style and (sometimes)
  // a different display font.
  vibe: z.string().trim().max(200).optional().default(""),
  // Per-business colour palette. Each field is a 6-digit hex (#rrggbb).
  // The whole field is optional — when omitted the neutral DEFAULT_PALETTE
  // (dark navy / slate gray / white / near-black + #111827 text) is used.
  // Individual sub-fields are also optional and fall back to the matching
  // DEFAULT_PALETTE entry, so the model can specify only the colour(s) it
  // cares about (e.g. just `primary`) without supplying a full palette.
  palette: z
    .object({
      primary: z.string().trim().regex(HEX6, "must be #rrggbb hex").optional(),
      secondary: z.string().trim().regex(HEX6, "must be #rrggbb hex").optional(),
      background: z.string().trim().regex(HEX6, "must be #rrggbb hex").optional(),
      accent: z.string().trim().regex(HEX6, "must be #rrggbb hex").optional(),
      text: z.string().trim().regex(HEX6, "must be #rrggbb hex").optional(),
    })
    .optional()
    .default({})
    .transform((p) => ({
      primary: p.primary ?? DEFAULT_PALETTE.primary,
      secondary: p.secondary ?? DEFAULT_PALETTE.secondary,
      background: p.background ?? DEFAULT_PALETTE.background,
      accent: p.accent ?? DEFAULT_PALETTE.accent,
      text: p.text ?? DEFAULT_PALETTE.text,
    })),
  // Optional explicit list of sections to render. When omitted the renderer
  // includes every section that has data. Unknown values are ignored.
  sections: z.array(z.enum(SECTION_IDS)).max(SECTION_IDS.length).optional(),
  services: z.array(ServiceSchema).max(12).default([]),
  about: z
    .object({
      heading: z.string().trim().max(80).default("About Us"),
      body: z.string().trim().min(1).max(2000),
    })
    .optional(),
  // Convenience alias — `aboutText: "..."` is sugar for
  // `about: { heading: "About Us", body: "..." }`. Only consulted when
  // `about` is not already set.
  aboutText: z.string().trim().max(2000).optional(),
  serviceArea: z.array(z.string().trim().min(1).max(80)).max(20).optional().default([]),
  testimonials: z.array(TestimonialSchema).max(6).optional().default([]),
  cta: z.string().trim().max(60).optional(),
  // Newer alias preferred by the expanded schema — "Get Free Estimate",
  // "Shop Now", etc. Wins over `cta` when both are set.
  ctaText: z.string().trim().max(60).optional(),
  // Free-form extra styling instructions from the user. Surfaced as an
  // HTML comment near the top of the document so the user / a downstream
  // edit pass can act on it without it changing the deterministic output.
  styleNotes: z.string().trim().max(500).optional().default(""),
  // Multi-page output: when true, the zip contains index.html / about.html /
  // services.html / contact.html with a sticky top nav linking between
  // them. Defaults to TRUE — the user-facing rule is "default to multi-page
  // unless single-page is explicitly requested".
  multiPage: z.boolean().optional().default(true),
  // Newer alias preferred by the expanded schema. When set, wins over the
  // legacy `multiPage` boolean. Both values map to the same renderer.
  layout: z.enum(["multi-page", "single-page"]).optional(),
  // Google Fonts to load. Both fields are optional. When omitted the
  // template falls back to vertical-aware defaults (Oswald headings for
  // tactical/auto/trades, Playfair Display for elegant/restaurant/spa,
  // Inter everywhere else). Both heading + body always pull from
  // fonts.googleapis.com so the picks are deterministic.
  fonts: z
    .object({
      heading: z.string().trim().min(1).max(60).optional(),
      body: z.string().trim().min(1).max(60).optional(),
    })
    .optional()
    .default({}),
  // Social links rendered in the footer. All entries optional; null is
  // accepted as a "not set" sentinel since the model is told the schema
  // shape uses `"url or null"`.
  socialLinks: z
    .object({
      facebook: z.string().trim().url().max(300).nullable().optional(),
      instagram: z.string().trim().url().max(300).nullable().optional(),
      twitter: z.string().trim().url().max(300).nullable().optional(),
      linkedin: z.string().trim().url().max(300).nullable().optional(),
      youtube: z.string().trim().url().max(300).nullable().optional(),
      tiktok: z.string().trim().url().max(300).nullable().optional(),
    })
    .optional()
    .default({}),
  // Formspree (or compatible) endpoint URL for the contact form. Optional —
  // when omitted, the form falls back to the placeholder
  // `https://formspree.io/f/YOUR_FORM_ID` with a clear comment telling the
  // user how to wire it up.
  formspreeUrl: z.string().trim().url().max(300).optional(),
  // Header design — driven by the niche research Vance does in Phase 0.
  // Each top vertical has a recognisable header pattern (cleaning sites
  // often use a centered serif wordmark; gun/tactical use uppercase left-
  // anchored caps; restaurants use centered elegant serifs; trades use
  // chunky left-anchored sans). The model sets these enums based on what
  // the top 3-5 reference sites in the vertical actually do, and the
  // template renders the matching variant. All fields optional —
  // omitted → "logo-left" + "dot" (the legacy default).
  header: z
    .object({
      layout: z.enum(["logo-left", "centered", "stacked"]).nullable().optional(),
      brandTreatment: z
        .enum(["plain", "dot", "badge", "uppercase", "underline"])
        .nullable()
        .optional(),
      tagline: z.string().trim().max(80).nullable().optional(),
    })
    .nullable()
    .optional()
    .default({})
    .transform((h) => ({
      layout: (h?.layout ?? "logo-left") as "logo-left" | "centered" | "stacked",
      brandTreatment: (h?.brandTreatment ?? "dot") as
        | "plain"
        | "dot"
        | "badge"
        | "uppercase"
        | "underline",
      tagline: h?.tagline ?? null,
    })),
  images: ImagesSchema,
  zipName: z
    .string()
    .trim()
    .max(60)
    .optional()
    .default("site")
    .transform((s: string) => {
      const cleaned = (s || "site").toLowerCase().replace(/[^a-z0-9-]+/g, "-").replace(/^-+|-+$/g, "");
      return cleaned || "site";
    }),
  // Retry variation index. 0 = use the spec's palette/fonts/vibe (or vertical
  // defaults). 1..N = swap palette + fonts + vibe wholesale for VARIATION_PACKS[
  // (variation-1) % len]. The backend's retry handler increments this each
  // time the user clicks "Retry build (new design)" on the proposal bubble.
  variation: z.number().int().min(0).max(99).optional().default(0),
});

// Outer transform: resolves aliases (ctaText/aboutText) and computes the
// effective `sections` list (either from the explicit field or by inferring
// from which data the spec actually provides). The inner schema above stays
// "raw" so error messages point at the original field names.
export const WebsiteSpecSchema = RawWebsiteSpecSchema.transform((s) => {
  // If the model passed something phone-shaped OR call-shaped as the CTA
  // ("Call Now", "Call Now (803) 792-5749", "(803) 792-5749", "Call Us",
  // etc.) we silently swap to a non-call CTA — otherwise the header CTA
  // pill becomes a duplicate of the phone button AND the hero + estimate
  // banner end up shouting "Call Now" three more times on the home page.
  // The phone pill in the header and the call buttons in the contact
  // section already cover the call CTA — the hero/banner CTAs should
  // funnel users TO the contact section, not duplicate it.
  const rawCta = ((s.ctaText && s.ctaText.trim()) || (s.cta && s.cta.trim()) || "").trim();
  const phoneDigits = (s.phone || "").replace(/\D+/g, "");
  const ctaLooksLikePhone =
    rawCta.length > 0 &&
    phoneDigits.length >= 7 &&
    rawCta.replace(/\D+/g, "").includes(phoneDigits);
  const ctaLooksLikeCall = /\bcall\b/i.test(rawCta);
  // Vertical-aware CTA fallback. Service businesses → "Get a Free Estimate";
  // hospitality/destination verticals → "Visit Us" / "Reserve a Table" / etc.
  // We need verticalDefaults before this line, so compute it here (it's
  // computed again below for palette/fonts/etc. — cheap, idempotent).
  const verticalCtaDefault = pickVerticalDefaults(s.businessType).cta || "Get a Free Estimate";
  const ctaResolved = !rawCta || ctaLooksLikePhone || ctaLooksLikeCall ? verticalCtaDefault : rawCta;
  const about =
    s.about ??
    (s.aboutText && s.aboutText.trim()
      ? { heading: "About Us", body: s.aboutText.trim() }
      : undefined);

  // Apply vertical-aware smart defaults: any palette/font/vibe field the
  // spec didn't specify gets filled in from the businessType match. We
  // detect "user supplied" by comparing against DEFAULT_PALETTE for the
  // palette (since the inner schema already filled holes with defaults)
  // — only fields that DIDN'T match the default get treated as explicit.
  const verticalDefaults = pickVerticalDefaults(s.businessType);
  const palette = { ...s.palette };
  if (verticalDefaults.palette) {
    if (s.palette.primary === DEFAULT_PALETTE.primary && verticalDefaults.palette.primary) palette.primary = verticalDefaults.palette.primary;
    if (s.palette.secondary === DEFAULT_PALETTE.secondary && verticalDefaults.palette.secondary) palette.secondary = verticalDefaults.palette.secondary;
    if (s.palette.accent === DEFAULT_PALETTE.accent && verticalDefaults.palette.accent) palette.accent = verticalDefaults.palette.accent;
    if (s.palette.background === DEFAULT_PALETTE.background && verticalDefaults.palette.background) palette.background = verticalDefaults.palette.background;
    if (s.palette.text === DEFAULT_PALETTE.text && verticalDefaults.palette.text) palette.text = verticalDefaults.palette.text;
  }
  const fonts = {
    heading: s.fonts.heading || verticalDefaults.fonts?.heading || "Inter",
    body: s.fonts.body || verticalDefaults.fonts?.body || "Inter",
  };
  let vibe = s.vibe || verticalDefaults.vibe || "";
  // Vertical-aware hero photo fallback. User-supplied `images.hero` always
  // wins; otherwise a vertical-specific Unsplash photo (kitchen for cleaning,
  // dining room for restaurant, etc.) beats the generic Picsum mountain.
  // Only the hero is overridden — about/services/contact still fall back to
  // the generic DEFAULT_IMAGES so the page doesn't feel monothematic.
  // Fill ALL four image slots from vertical defaults when the spec didn't
  // supply them (user-supplied URLs always win). Without this, about/
  // servicesHero/contact would fall back to the generic picsum mountain,
  // which on a cleaning site reads as "stock photo unrelated to cleaning".
  const images = { ...(s.images ?? {}) };
  if (!images.hero && verticalDefaults.heroImage) images.hero = verticalDefaults.heroImage;
  if (!images.about && verticalDefaults.aboutImage) images.about = verticalDefaults.aboutImage;
  if (!images.servicesHero && verticalDefaults.servicesHeroImage) images.servicesHero = verticalDefaults.servicesHeroImage;
  if (!images.contact && verticalDefaults.contactImage) images.contact = verticalDefaults.contactImage;

  // Fill per-service image fallbacks from the vertical's service image bank
  // (cycled by index). User-supplied `image` URLs win. Without this, a
  // cleaning site's Deep Clean card could end up showing a random picsum
  // car (real bug the user just reported).
  const serviceBank = verticalDefaults.serviceImages ?? [];
  const services = serviceBank.length > 0
    ? s.services.map((svc, idx) => svc.image
        ? svc
        : { ...svc, image: serviceBank[idx % serviceBank.length] })
    : s.services;

  // Retry variation override: when variation > 0, swap palette + fonts + vibe
  // wholesale (intentionally overriding even user-supplied values — the whole
  // point of Retry is to show the user a visually different take on the same
  // content). Content fields (businessName, services, phone, etc.) are
  // untouched. Variation 0 leaves everything as-is.
  const pack = pickVariationPack(s.variation ?? 0);
  if (pack) {
    palette.primary = pack.palette.primary;
    palette.secondary = pack.palette.secondary;
    palette.background = pack.palette.background;
    palette.accent = pack.palette.accent;
    palette.text = pack.palette.text;
    fonts.heading = pack.fonts.heading;
    fonts.body = pack.fonts.body;
    vibe = pack.vibe;
  }

  // Layout: explicit `layout` enum wins over the legacy `multiPage` boolean.
  const isMulti = s.layout ? s.layout === "multi-page" : s.multiPage;

  // Sections: testimonials removed entirely per user preference — we never
  // render fabricated/placeholder reviews. Area still gates on having data —
  // pills with no items would just render an empty grid.
  const inferred: SectionId[] = ["hero"];
  if (about) inferred.push("about");
  if (s.services.length > 0) inferred.push("services");
  if (s.serviceArea.length > 0) inferred.push("area");
  inferred.push("contact");
  const sectionsResolved =
    s.sections && s.sections.length > 0 ? Array.from(new Set(s.sections)) : inferred;

  return {
    ...s,
    palette,
    fonts,
    vibe,
    images,
    services,
    cta: ctaResolved,
    about,
    multiPage: isMulti,
    layout: (isMulti ? "multi-page" : "single-page") as "multi-page" | "single-page",
    sections: sectionsResolved,
  };
});

export type WebsiteSpec = z.infer<typeof WebsiteSpecSchema>;

export function parseWebsiteSpec(raw: string): WebsiteSpec | null {
  const trimmed = raw.trim();
  if (!trimmed) return null;
  const fenceStripped = trimmed
    .replace(/^```(?:json|JSON|jsonc)?\s*\n/, "")
    .replace(/\n```\s*$/, "")
    .trim();
  const firstBrace = fenceStripped.indexOf("{");
  const lastBrace = fenceStripped.lastIndexOf("}");
  if (firstBrace === -1 || lastBrace <= firstBrace) return null;
  const jsonSpan = fenceStripped.slice(firstBrace, lastBrace + 1);
  let parsed: unknown;
  try {
    parsed = JSON.parse(jsonSpan);
  } catch {
    return null;
  }
  // Scrub placeholder values from URL-typed fields BEFORE validation. The
  // model frequently emits `formspreeUrl: "YOUR_FORM_ID"` or social URLs
  // like `"your-handle"` — they're meant as "fill this in later" hints,
  // but z.string().url() rejects them, which made the whole spec fail to
  // parse and dropped the short-circuit into the flaky LLM tool path. The
  // renderer ALREADY handles missing formspreeUrl with a placeholder URL
  // + comment, so dropping these invalid values is the correct behaviour.
  if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
    const obj = parsed as Record<string, unknown>;
    const looksLikeUrl = (v: unknown): boolean =>
      typeof v === "string" && /^https?:\/\//i.test(v.trim());
    if ("formspreeUrl" in obj && !looksLikeUrl(obj.formspreeUrl) && obj.formspreeUrl !== null) {
      delete obj.formspreeUrl;
    }
    if (obj.socialLinks && typeof obj.socialLinks === "object" && !Array.isArray(obj.socialLinks)) {
      const social = obj.socialLinks as Record<string, unknown>;
      for (const k of Object.keys(social)) {
        if (social[k] !== null && !looksLikeUrl(social[k])) {
          delete social[k];
        }
      }
    }
  }
  const result = WebsiteSpecSchema.safeParse(parsed);
  if (!result.success) return null;
  return result.data;
}

// ── HTML rendering ──────────────────────────────────────────────────────────

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function escapeAttr(s: string): string {
  return escapeHtml(s);
}

function renderParagraphs(body: string, className: string): string {
  return body
    .split(/\n\s*\n/)
    .map((p) => p.trim())
    .filter(Boolean)
    .map((p) => `<p class="${className}">${escapeHtml(p).replace(/\n/g, "<br>")}</p>`)
    .join("\n          ");
}

function telHref(phone: string): string {
  const trimmed = phone.trim();
  if (!trimmed) return "";
  const plus = trimmed.startsWith("+") ? "+" : "";
  const digits = trimmed.replace(/\D/g, "");
  return digits ? `${plus}${digits}` : "";
}

/**
 * Wrap an <img> tag in a clear "REPLACE IMAGE" HTML comment so the user
 * can find and swap every placeholder photo with one Find-and-Replace pass.
 * Indentation is intentional — the surrounding template literals are
 * already indented two levels.
 */
function renderImageBlock(url: string, alt: string, imgClass: string): string {
  return `        <!-- REPLACE IMAGE: change the src URL below with your own photo -->
        <img src="${escapeAttr(url)}" alt="${escapeAttr(alt)}" loading="lazy" class="${imgClass}">`;
}

type NavMode = "single" | "multi";
type PageId = "home" | "about" | "services" | "contact";

interface NavConfig {
  mode: NavMode;
  /** For multi-page mode, which page is currently being rendered. */
  currentPage?: PageId;
  /** For single-page mode, the in-page sections that exist (drives anchor links). */
  sections?: string[];
}

function renderHeader(spec: WebsiteSpec, palette: PaletteSpec, nav: NavConfig): string {
  const tel = telHref(spec.phone);
  let navLinks = "";
  let homeHref = "#";
  let contactHref = "#contact";

  if (nav.mode === "multi") {
    homeHref = "index.html";
    contactHref = "contact.html";
    // Services link only appears when there's actually a services list — some
    // verticals (bars, simple venues) have no menu/offerings to surface.
    const items: Array<{ id: PageId; label: string; href: string }> = [
      { id: "home", label: "Home", href: "index.html" },
      { id: "about", label: "About", href: "about.html" },
      ...(spec.services.length > 0
        ? [{ id: "services" as PageId, label: "Services", href: "services.html" }]
        : []),
      { id: "contact", label: "Contact", href: "contact.html" },
    ];
    navLinks = items
      .map((item) => {
        const isActive = item.id === nav.currentPage;
        const cls = isActive
          ? `font-semibold`
          : `hover:text-[${palette.brand}] transition`;
        const styleAttr = isActive ? ` style="color:${palette.brand}"` : "";
        return `<a href="${item.href}" class="${cls}"${styleAttr}>${item.label}</a>`;
      })
      .join("\n          ");
  } else {
    const sections = nav.sections ?? [];
    navLinks = sections
      .filter((s) => s !== "header" && s !== "hero" && s !== "footer")
      .map((s) => {
        const labels: Record<string, string> = {
          services: "Services",
          about: "About",
          area: "Service Area",
          contact: "Contact",
        };
        return `<a href="#${s}" class="hover:text-[${palette.brand}] transition">${labels[s] ?? s}</a>`;
      })
      .join("\n          ");
  }

  // Click-to-call button is shown EVERYWHERE — icon-only on tiny screens,
  // icon + number on >= sm. The CTA stays right of it.
  const phoneIcon = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" class="w-4 h-4 shrink-0"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.97.37 1.92.7 2.83a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.33 1.86.57 2.83.7A2 2 0 0 1 22 16.92Z"/></svg>`;
  const phoneBtn = tel
    ? `<a href="tel:${escapeAttr(tel)}" class="inline-flex items-center gap-2 px-3 py-2 rounded-full text-sm font-semibold text-white shadow-sm hover:shadow-md transition" style="background:${palette.brandDark}" aria-label="Call ${escapeAttr(spec.phone)}">${phoneIcon}<span class="hidden sm:inline">${escapeHtml(spec.phone)}</span></a>`
    : "";
  // Brand name uses the configured heading font (Google Font already in
  // <head>) for visual continuity with the hero.
  const brandFont = spec.fonts?.heading || "Inter";
  const isSerif = isLikelySerifFont(brandFont);
  const headerCfg = spec.header ?? { layout: "logo-left", brandTreatment: "dot", tagline: null };
  const treatment = headerCfg.brandTreatment;

  // Compose the brand mark per `brandTreatment`. Each variant matches a
  // recognisable pattern from the top sites in different verticals:
  // - plain: clean wordmark only (modern minimal)
  // - dot: wordmark + small brand-coloured dot (friendly local services)
  // - badge: 2-letter initials in a brand pill before the name (trades / gun shops)
  // - uppercase: wide-tracked all-caps wordmark (tactical / auto / law)
  // - underline: wordmark with a thick brand-coloured underline (editorial / spa)
  const initials = spec.businessName
    .split(/\s+/)
    .filter((w) => /[a-z0-9]/i.test(w))
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase() ?? "")
    .join("");
  const brandBase = `font-family: '${escapeAttr(brandFont)}', ${isSerif ? "serif" : "system-ui, sans-serif"}; color:${palette.brandDark}`;
  let brandSize = "text-lg md:text-2xl font-extrabold tracking-tight";
  let brandMark = "";
  let brandExtraStyle = "";
  let nameContent = escapeHtml(spec.businessName);
  if (treatment === "dot") {
    brandMark = `<span class="inline-block w-2.5 h-2.5 rounded-full" style="background:${palette.brand}"></span>`;
  } else if (treatment === "badge" && initials.length > 0) {
    brandMark = `<span class="inline-flex items-center justify-center w-8 h-8 rounded-lg text-white text-xs font-bold tracking-wide" style="background:${palette.brand}">${escapeHtml(initials)}</span>`;
  } else if (treatment === "uppercase") {
    brandSize = "text-base md:text-xl font-extrabold uppercase tracking-[0.18em]";
  } else if (treatment === "underline") {
    brandSize = "text-lg md:text-2xl font-extrabold tracking-tight";
    brandExtraStyle = `; border-bottom: 3px solid ${palette.brand}; padding-bottom: 2px`;
    nameContent = escapeHtml(spec.businessName);
  }
  // "plain" intentionally adds nothing.

  const brandTagline = headerCfg.tagline
    ? `<span class="hidden md:block text-xs text-slate-500 font-medium tracking-wide mt-0.5">${escapeHtml(headerCfg.tagline)}</span>`
    : "";

  const brandBlock = `<a href="${homeHref}" class="flex items-center gap-2.5 leading-none no-underline" aria-label="${escapeAttr(spec.businessName)} home">
        ${brandMark}
        <span class="flex flex-col">
          <span class="${brandSize}" style="${brandBase}${brandExtraStyle}">${nameContent}</span>
          ${brandTagline}
        </span>
      </a>`;

  // Mobile nav: same links as desktop, but rendered as a second row beneath
  // the brand on screens narrower than md. Keeps the multi-page structure
  // visible/navigable on phones without needing a JS hamburger.
  const mobileNav = navLinks
    ? `<nav class="md:hidden flex items-center justify-center flex-wrap gap-x-5 gap-y-1 px-6 pb-3 text-sm font-medium text-slate-600 border-t border-slate-100">
          ${navLinks}
      </nav>`
    : "";

  const desktopNav = navLinks
    ? `<nav class="hidden md:flex items-center gap-8 text-sm font-medium text-slate-600">
          ${navLinks}
      </nav>`
    : "";

  // Skip the header CTA pill when the phone button already covers the same
  // job — i.e. there's a phone AND the CTA text reads like "Call ...". This
  // avoids the visual stutter of three call-to-action chips crammed into the
  // header (phone pill + "Call Now" + nav). When the CTA is something genuinely
  // different ("Book Online", "Get a Quote"), it still renders alongside.
  const ctaIsCallShaped = /\bcall\b/i.test(spec.cta);
  const ctaBtn = (tel && ctaIsCallShaped)
    ? ""
    : `<a href="${contactHref}" class="hidden sm:inline-block px-4 py-2 rounded-full text-sm font-semibold text-white shadow-sm hover:shadow-md transition" style="background:${palette.brand}">${escapeHtml(spec.cta)}</a>`;

  // Branch on layout. "centered" puts brand in the middle with nav split L/R
  // (or below on mobile); "stacked" keeps brand+tagline as a tall left block;
  // "logo-left" is the conventional flex-between we've always shipped.
  let innerRow: string;
  if (headerCfg.layout === "centered") {
    innerRow = `<div class="max-w-6xl mx-auto px-6 py-3 md:py-4 grid grid-cols-3 items-center gap-4">
      <div class="hidden md:flex justify-start">${desktopNav}</div>
      <div class="col-span-2 md:col-span-1 flex justify-start md:justify-center">${brandBlock}</div>
      <div class="flex items-center gap-2 justify-end">
        ${phoneBtn}
        ${ctaBtn}
      </div>
    </div>`;
  } else {
    // logo-left and stacked share the same row structure — "stacked" already
    // got its second line via brandTagline above.
    innerRow = `<div class="max-w-6xl mx-auto px-6 py-3 md:py-4 flex items-center justify-between gap-4">
      ${brandBlock}
      ${desktopNav}
      <div class="flex items-center gap-2">
        ${phoneBtn}
        ${ctaBtn}
      </div>
    </div>`;
  }

  return `  <header class="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-slate-200 shadow-sm">
    ${innerRow}
    ${mobileNav}
  </header>`;
}

function renderHero(spec: WebsiteSpec, palette: PaletteSpec, opts: { includeImage: boolean; ctaHref: string }): string {
  const tel = telHref(spec.phone);
  const locationLine = spec.location || [spec.city, spec.state].filter(Boolean).join(", ");
  const eyebrow = [spec.businessType, locationLine].filter(Boolean).join(" · ");
  const heading = vibeProfile(spec.vibe).headingClass;
  const heroImage = opts.includeImage ? (spec.images?.hero ?? DEFAULT_IMAGES.hero) : null;
  const imageBlock = heroImage
    ? `\n    <div class="absolute inset-0">
${renderImageBlock(heroImage, `${spec.businessName} hero photo`, "w-full h-full object-cover opacity-30")}
    </div>`
    : "";
  return `  <section class="relative overflow-hidden text-white" style="background: linear-gradient(135deg, ${palette.heroFrom} 0%, ${palette.heroTo} 100%);">${imageBlock}
    <div class="absolute inset-0 opacity-20" style="background-image: radial-gradient(circle at 20% 20%, rgba(255,255,255,0.4) 0%, transparent 50%), radial-gradient(circle at 80% 80%, rgba(255,255,255,0.2) 0%, transparent 50%);"></div>
    <div class="relative max-w-6xl mx-auto px-6 py-24 md:py-32">
      ${eyebrow ? `<p class="text-white/80 font-semibold uppercase tracking-widest text-xs mb-5">${escapeHtml(eyebrow)}</p>` : ""}
      <h1 class="text-4xl md:text-6xl lg:text-7xl font-extrabold leading-[1.05] mb-6 max-w-4xl ${heading}">${escapeHtml(spec.tagline)}</h1>
      ${spec.description ? `<p class="text-lg md:text-xl text-white/90 max-w-2xl mb-10 leading-relaxed">${escapeHtml(spec.description)}</p>` : ""}
      <div class="flex flex-wrap gap-4">
        <a href="${opts.ctaHref}" class="inline-block px-8 py-4 rounded-full bg-white font-semibold shadow-xl hover:shadow-2xl hover:-translate-y-0.5 transition" style="color:${palette.brandDark}">${escapeHtml(spec.cta)}</a>
      </div>
    </div>
  </section>`;
}

function renderServices(spec: WebsiteSpec, palette: PaletteSpec, opts: { withImages: boolean; heading: string; subheading?: string }): string {
  if (spec.services.length === 0) {
    // Multi-page mode always emits services.html; surface a friendly placeholder
    // so the page is never blank even when the spec has no service data yet.
    return `  <section id="services" class="py-20 md:py-24 bg-slate-50">
    <div class="max-w-3xl mx-auto px-6 text-center">
      <p class="text-sm font-semibold uppercase tracking-widest mb-3" style="color:${palette.brand}">${escapeHtml(opts.heading)}</p>
      <h2 class="text-3xl md:text-4xl font-extrabold text-slate-900 mb-4">${escapeHtml(opts.subheading ?? "Tell us what you need")}</h2>
      <p class="text-lg text-slate-600 mb-8">We&rsquo;ll customise a quote based on your space and timing. Reach out and we&rsquo;ll get right back to you.</p>
      <a href="contact.html" class="inline-block px-8 py-4 rounded-full font-semibold text-white shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition" style="background:${palette.brand}">${escapeHtml(spec.cta)}</a>
      <!-- REPLACE: Add services to your spec to render the full grid here. -->
    </div>
  </section>`;
  }
  const headingClass = vibeProfile(spec.vibe).headingClass;
  const cards = spec.services
    .map((s, idx) => {
      const detailsBlock = s.details
        ? `\n            <p class="text-sm text-slate-500 leading-relaxed mt-3 italic">${escapeHtml(s.details)}</p>`
        : "";
      if (opts.withImages) {
        const img = s.image ?? DEFAULT_SERVICE_IMAGES[idx % DEFAULT_SERVICE_IMAGES.length];
        return `        <div class="group rounded-2xl bg-white border border-slate-200 hover:border-[${palette.brand}] hover:shadow-xl transition overflow-hidden flex flex-col">
${renderImageBlock(img, `${s.title} photo`, "w-full h-48 object-cover")}
          <div class="p-6 flex-1 flex flex-col">
            <h3 class="text-lg font-bold text-slate-900 mb-2 ${headingClass}">${escapeHtml(s.title)}</h3>
            <p class="text-slate-600 leading-relaxed">${escapeHtml(s.description)}</p>${detailsBlock}
          </div>
        </div>`;
      }
      return `        <div class="group p-7 rounded-2xl bg-white border border-slate-200 hover:border-[${palette.brand}] hover:shadow-xl transition">
          <div class="w-12 h-12 rounded-xl flex items-center justify-center mb-5 text-white font-bold text-xl" style="background:${palette.brand}">✓</div>
          <h3 class="text-lg font-bold text-slate-900 mb-2 ${headingClass}">${escapeHtml(s.title)}</h3>
          <p class="text-slate-600 leading-relaxed">${escapeHtml(s.description)}</p>${detailsBlock}
        </div>`;
    })
    .join("\n");
  const gridCols = spec.services.length >= 4 ? "md:grid-cols-2 lg:grid-cols-3" : spec.services.length === 3 ? "md:grid-cols-3" : "md:grid-cols-2";
  return `  <section id="services" class="py-20 md:py-24 bg-slate-50">
    <div class="max-w-6xl mx-auto px-6">
      <div class="max-w-2xl mb-14">
        <p class="text-sm font-semibold uppercase tracking-widest mb-3" style="color:${palette.brand}">${escapeHtml(opts.subheading ?? "What we do")}</p>
        <h2 class="text-3xl md:text-5xl font-extrabold text-slate-900 leading-tight">${escapeHtml(opts.heading)}</h2>
      </div>
      <div class="grid grid-cols-1 ${gridCols} gap-5">
${cards}
      </div>
    </div>
  </section>`;
}

function renderAbout(spec: WebsiteSpec, palette: PaletteSpec, opts: { withImage: boolean }): string {
  if (!spec.about) return "";
  const paragraphs = renderParagraphs(spec.about.body, "text-lg text-slate-600 leading-relaxed");
  const aboutImg = opts.withImage ? (spec.images?.about ?? DEFAULT_IMAGES.about) : null;
  if (aboutImg) {
    return `  <section id="about" class="py-20 md:py-24 bg-white">
    <div class="max-w-6xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-center">
      <div class="rounded-2xl overflow-hidden shadow-lg">
${renderImageBlock(aboutImg, `About ${spec.businessName}`, "w-full h-full object-cover")}
      </div>
      <div>
        <p class="text-sm font-semibold uppercase tracking-widest mb-3" style="color:${palette.brand}">${escapeHtml(spec.about.heading)}</p>
        <h2 class="text-3xl md:text-5xl font-extrabold text-slate-900 leading-tight mb-8">Why ${escapeHtml(spec.businessName)}</h2>
        <div class="space-y-5">
          ${paragraphs}
        </div>
      </div>
    </div>
  </section>`;
  }
  return `  <section id="about" class="py-20 md:py-24 bg-white">
    <div class="max-w-4xl mx-auto px-6">
      <p class="text-sm font-semibold uppercase tracking-widest mb-3" style="color:${palette.brand}">${escapeHtml(spec.about.heading)}</p>
      <h2 class="text-3xl md:text-5xl font-extrabold text-slate-900 leading-tight mb-8">Why ${escapeHtml(spec.businessName)}</h2>
      <div class="space-y-5">
          ${paragraphs}
      </div>
    </div>
  </section>`;
}

function renderArea(spec: WebsiteSpec, palette: PaletteSpec): string {
  if (!spec.serviceArea || spec.serviceArea.length === 0) return "";
  const pills = spec.serviceArea
    .map(
      (a: string) => `<span class="inline-flex items-center px-4 py-2 rounded-full text-sm font-medium bg-white border border-slate-200 text-slate-700 hover:border-[${palette.brand}] hover:text-[${palette.brand}] transition">${escapeHtml(a)}</span>`,
    )
    .join("\n          ");
  return `  <section id="area" class="py-20 md:py-24 bg-slate-50">
    <div class="max-w-5xl mx-auto px-6 text-center">
      <p class="text-sm font-semibold uppercase tracking-widest mb-3" style="color:${palette.brand}">Coverage</p>
      <h2 class="text-3xl md:text-5xl font-extrabold text-slate-900 leading-tight mb-10">Service Area</h2>
      <div class="flex flex-wrap justify-center gap-3">
          ${pills}
      </div>
    </div>
  </section>`;
}

// Testimonials/reviews intentionally removed per user preference — no
// placeholder/fabricated reviews ever, and the user does not want a reviews
// section at all. The `testimonials` spec field is retained in the schema
// for back-compat with older specs but is no longer rendered. Future option:
// real Facebook reviews embed via Elfsight or the FB Page Plugin.

// "Free Estimates" / strong-CTA banner — a thin attention-grabbing strip
// between hero and services on the home page. Always rendered so the user
// can edit the copy if they don't want it; copy reflects spec.cta verbatim.
function renderEstimateBanner(spec: WebsiteSpec, palette: PaletteSpec, ctaHref: string): string {
  const tel = telHref(spec.phone);
  return `  <section class="py-10 md:py-12" style="background:${palette.brand}; color:${palette.textOnBrand};">
    <div class="max-w-6xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-5 text-center md:text-left">
      <div>
        <p class="text-xs font-semibold uppercase tracking-widest opacity-80 mb-1">Free, no-obligation quotes</p>
        <h2 class="text-2xl md:text-3xl font-extrabold leading-tight">${escapeHtml(spec.cta)} — quick response, no pressure.</h2>
      </div>
      <div class="flex flex-wrap justify-center gap-3">
        <a href="${ctaHref}" class="inline-block px-6 py-3 rounded-full bg-white font-semibold shadow-md hover:shadow-lg transition" style="color:${palette.brandDark}">${escapeHtml(spec.cta)}</a>
      </div>
    </div>
  </section>`;
}

// Google Maps embed (no API key required). Uses the public unauthenticated
// /maps/embed URL with the location string as the search query, which Google
// resolves on the user's browser. Returns "" when no location is set.
function renderMap(spec: WebsiteSpec, palette: PaletteSpec): string {
  const location = (spec.location || [spec.address, spec.city, spec.state, spec.zipCode].filter(Boolean).join(", ")).trim();
  if (!location) return "";
  const q = encodeURIComponent(location);
  return `  <section id="map" class="py-20 md:py-24 bg-slate-50">
    <div class="max-w-6xl mx-auto px-6">
      <div class="max-w-2xl mb-10">
        <p class="text-sm font-semibold uppercase tracking-widest mb-3" style="color:${palette.brand}">Find us</p>
        <h2 class="text-3xl md:text-5xl font-extrabold text-slate-900 leading-tight">${escapeHtml(location)}</h2>
      </div>
      <div class="rounded-2xl overflow-hidden shadow-lg border border-slate-200" style="aspect-ratio: 16/9;">
        <iframe
          src="https://maps.google.com/maps?q=${q}&t=&z=13&ie=UTF8&iwloc=&output=embed"
          width="100%" height="100%" frameborder="0" style="border:0" loading="lazy"
          referrerpolicy="no-referrer-when-downgrade" allowfullscreen
          title="Map showing the location of ${escapeAttr(spec.businessName)}"></iframe>
      </div>
    </div>
  </section>`;
}

function renderContact(spec: WebsiteSpec, palette: PaletteSpec): string {
  const tel = telHref(spec.phone);
  const fullAddress = spec.location || [spec.address, [spec.city, spec.state].filter(Boolean).join(", "), spec.zipCode].filter(Boolean).join(", ");
  // Contact form removed by user preference — the section now centres the
  // call-button + contact details. `formspreeUrl` is kept in the schema for
  // back-compat but no longer wired into the page.
  const mailHref = spec.email ? `mailto:${spec.email}` : "";
  return `  <section id="contact" class="py-20 md:py-24" style="background:${palette.brandDark}; color:${palette.textOnBrand};">
    <div class="max-w-3xl mx-auto px-6 text-center">
      <p class="text-sm font-semibold uppercase tracking-widest mb-3 text-white/70">Reach out</p>
      <h2 class="text-3xl md:text-5xl font-extrabold leading-tight mb-6">Get in Touch</h2>
      <p class="text-white/80 text-lg leading-relaxed mb-10">${spec.email ? "Give us a call or send a quick email — we&rsquo;ll get back to you with a no-obligation quote." : (tel ? "Give us a call — we&rsquo;ll get back to you with a no-obligation quote." : "We&rsquo;ll get back to you with a no-obligation quote.")}</p>
      <div class="flex flex-col sm:flex-row gap-4 justify-center mb-12">
        ${tel ? `<a href="tel:${escapeAttr(tel)}" class="inline-flex items-center justify-center gap-3 px-7 py-4 rounded-full bg-white font-bold text-lg shadow-lg hover:shadow-2xl hover:-translate-y-0.5 transition" style="color:${palette.brandDark};"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" class="w-5 h-5"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.97.37 1.92.7 2.83a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.33 1.86.57 2.83.7A2 2 0 0 1 22 16.92Z"/></svg>Call ${escapeHtml(spec.phone)}</a>` : ""}
        ${mailHref ? `<a href="${escapeAttr(mailHref)}" class="inline-flex items-center justify-center gap-3 px-7 py-4 rounded-full border-2 border-white/60 font-bold text-lg text-white hover:bg-white/10 transition"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" class="w-5 h-5"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>Email Us</a>` : ""}
      </div>
      <dl class="inline-grid gap-3 text-left text-white/90">
        ${spec.email ? `<div class="flex items-start gap-3"><dt class="font-semibold text-white/70 w-20 shrink-0">Email</dt><dd><a href="mailto:${escapeAttr(spec.email)}" class="hover:underline">${escapeHtml(spec.email)}</a></dd></div>` : ""}
        ${fullAddress ? `<div class="flex items-start gap-3"><dt class="font-semibold text-white/70 w-20 shrink-0">Visit</dt><dd>${escapeHtml(fullAddress)}</dd></div>` : ""}
        ${spec.hours ? `<div class="flex items-start gap-3"><dt class="font-semibold text-white/70 w-20 shrink-0">Hours</dt><dd>${escapeHtml(spec.hours)}</dd></div>` : ""}
      </dl>
    </div>
  </section>`;
}

// SVG icons inlined so the footer has zero external icon-font dependency.
const SOCIAL_ICONS: Record<string, string> = {
  facebook: `<svg viewBox="0 0 24 24" fill="currentColor" class="w-5 h-5"><path d="M22 12a10 10 0 1 0-11.56 9.88v-6.99H7.9V12h2.54V9.8c0-2.5 1.49-3.89 3.77-3.89 1.09 0 2.24.2 2.24.2v2.46h-1.26c-1.24 0-1.63.77-1.63 1.56V12h2.78l-.44 2.89h-2.34v6.99A10 10 0 0 0 22 12z"/></svg>`,
  instagram: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-5 h-5"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37a4 4 0 1 1-7.91 1.18A4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>`,
  twitter: `<svg viewBox="0 0 24 24" fill="currentColor" class="w-5 h-5"><path d="M18.244 2H21l-6.52 7.45L22 22h-6.18l-4.84-6.34L5.4 22H2.64l6.97-7.97L2 2h6.34l4.37 5.78L18.244 2zm-1.08 18h1.71L7.99 4H6.18l10.984 16z"/></svg>`,
  linkedin: `<svg viewBox="0 0 24 24" fill="currentColor" class="w-5 h-5"><path d="M20.45 20.45h-3.56v-5.57c0-1.33-.02-3.04-1.85-3.04-1.86 0-2.14 1.45-2.14 2.95v5.66H9.34V9h3.42v1.56h.05a3.75 3.75 0 0 1 3.38-1.86c3.62 0 4.29 2.38 4.29 5.48v6.27zM5.34 7.43a2.06 2.06 0 1 1 0-4.13 2.06 2.06 0 0 1 0 4.13zm1.78 13.02H3.56V9h3.56v11.45zM22.22 0H1.77C.79 0 0 .77 0 1.72v20.56C0 23.23.79 24 1.77 24h20.45c.98 0 1.78-.77 1.78-1.72V1.72C24 .77 23.2 0 22.22 0z"/></svg>`,
  youtube: `<svg viewBox="0 0 24 24" fill="currentColor" class="w-5 h-5"><path d="M23.5 6.2a3 3 0 0 0-2.1-2.1C19.5 3.5 12 3.5 12 3.5s-7.5 0-9.4.6A3 3 0 0 0 .5 6.2C0 8.1 0 12 0 12s0 3.9.5 5.8a3 3 0 0 0 2.1 2.1c1.9.6 9.4.6 9.4.6s7.5 0 9.4-.6a3 3 0 0 0 2.1-2.1c.5-1.9.5-5.8.5-5.8s0-3.9-.5-5.8zM9.6 15.6V8.4l6.3 3.6-6.3 3.6z"/></svg>`,
  tiktok: `<svg viewBox="0 0 24 24" fill="currentColor" class="w-5 h-5"><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5.83 20.1a6.34 6.34 0 0 0 10.86-4.43V8.42a8.13 8.13 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1.87-.85z"/></svg>`,
};

function renderSocialLinks(spec: WebsiteSpec, opts: { compact?: boolean } = {}): string {
  const links: Array<{ key: keyof typeof SOCIAL_ICONS; url: string; label: string }> = [];
  const sl = spec.socialLinks ?? {};
  const order: Array<{ key: keyof typeof SOCIAL_ICONS; label: string }> = [
    { key: "facebook", label: "Facebook" },
    { key: "instagram", label: "Instagram" },
    { key: "twitter", label: "Twitter / X" },
    { key: "linkedin", label: "LinkedIn" },
    { key: "youtube", label: "YouTube" },
    { key: "tiktok", label: "TikTok" },
  ];
  for (const { key, label } of order) {
    const url = (sl as Record<string, string | null | undefined>)[key];
    if (typeof url === "string" && url.trim()) links.push({ key, url: url.trim(), label });
  }
  if (links.length === 0) return "";
  const sizeCls = opts.compact ? "w-9 h-9" : "w-10 h-10";
  return links
    .map(
      ({ key, url, label }) =>
        `<a href="${escapeAttr(url)}" target="_blank" rel="noopener noreferrer" aria-label="${escapeAttr(label)}" class="inline-flex items-center justify-center ${sizeCls} rounded-full bg-white/10 hover:bg-white/20 text-white transition">${SOCIAL_ICONS[key]}</a>`,
    )
    .join("\n          ");
}

function renderFooter(spec: WebsiteSpec): string {
  const year = new Date().getFullYear();
  const tel = telHref(spec.phone);
  const social = renderSocialLinks(spec, { compact: true });
  return `  <footer class="bg-slate-950 text-slate-400 py-12">
    <div class="max-w-6xl mx-auto px-6 grid gap-8 md:grid-cols-3 items-start">
      <div>
        <p class="text-white font-bold text-lg mb-2">${escapeHtml(spec.businessName)}</p>
        ${spec.tagline ? `<p class="text-sm text-slate-400 leading-relaxed">${escapeHtml(spec.tagline)}</p>` : ""}
      </div>
      <div class="text-sm space-y-2">
        ${tel ? `<p><a href="tel:${escapeAttr(tel)}" class="hover:text-white">${escapeHtml(spec.phone)}</a></p>` : ""}
        ${spec.email ? `<p><a href="mailto:${escapeAttr(spec.email)}" class="hover:text-white">${escapeHtml(spec.email)}</a></p>` : ""}
        ${spec.location ? `<p>${escapeHtml(spec.location)}</p>` : ""}
        ${spec.hours ? `<p class="text-slate-500">${escapeHtml(spec.hours)}</p>` : ""}
      </div>
      <div class="md:text-right">
        ${social ? `<div class="flex md:justify-end gap-2 mb-4">\n          ${social}\n        </div>` : ""}
        <p class="text-xs text-slate-500">&copy; ${year} ${escapeHtml(spec.businessName)}. All rights reserved.</p>
      </div>
    </div>
  </footer>`;
}

/**
 * Wrap an array of section HTML strings in the standard <html>…</html>
 * shell with title, meta tags, Tailwind CDN, Inter font, and shared styles.
 */
function wrapDocument(spec: WebsiteSpec, pageTitleSuffix: string, metaDescription: string, bodySections: string[]): string {
  const sections = bodySections.filter(Boolean).join("\n\n");
  const palette = derivePaletteSpec(spec.palette);

  const fontsLink = buildGoogleFontsLink([spec.fonts.heading, spec.fonts.body]);
  const headingFamily = fontFamilyCss(spec.fonts.heading, isLikelySerifFont(spec.fonts.heading) ? "serif" : "sans");
  const bodyFamily = fontFamilyCss(spec.fonts.body, isLikelySerifFont(spec.fonts.body) ? "serif" : "sans");

  const styleNotesComment = spec.styleNotes
    ? `\n  <!-- Style notes from spec: ${escapeHtml(spec.styleNotes).slice(0, 480)} -->`
    : "";
  const businessTypeComment = spec.businessType
    ? `\n  <!-- Business type: ${escapeHtml(spec.businessType)} -->`
    : "";
  const vibeComment = spec.vibe ? `\n  <!-- Vibe: ${escapeHtml(spec.vibe)} -->` : "";
  const fontsComment = `\n  <!-- Fonts: heading=${escapeHtml(spec.fonts.heading)}, body=${escapeHtml(spec.fonts.body)} -->`;

  // Site URL is unknown at build time; og:url is intentionally left as a
  // placeholder the user can swap. Twitter card uses summary_large_image
  // since we always emit a hero photo.
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${escapeHtml(spec.businessName)}${pageTitleSuffix ? ` — ${escapeHtml(pageTitleSuffix)}` : ""}</title>
  <meta name="description" content="${escapeAttr(metaDescription)}">
  <meta name="theme-color" content="${palette.brand}">
  <meta property="og:title" content="${escapeAttr(spec.businessName)}">
  <meta property="og:description" content="${escapeAttr(metaDescription)}">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="${escapeAttr(spec.businessName)}">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="${escapeAttr(spec.businessName)}">
  <meta name="twitter:description" content="${escapeAttr(metaDescription)}">${businessTypeComment}${vibeComment}${fontsComment}${styleNotesComment}
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="${fontsLink}" rel="stylesheet">
  <style>
    html { scroll-behavior: smooth; }
    :root { --brand: ${palette.brand}; --brand-dark: ${palette.brandDark}; --brand-light: ${palette.brandLight}; --accent: ${palette.accent}; }
    body { font-family: ${bodyFamily}; }
    h1, h2, h3, h4 { font-family: ${headingFamily}; }
    section { scroll-margin-top: 80px; }
  </style>
</head>
<body class="antialiased" style="background:${palette.background}; color:${palette.text};">
${sections}
</body>
</html>
`;
}

/**
 * Render the full single-page Tailwind CDN site as one HTML string. Section
 * order is fixed (header → hero → services → about → area → testimonials →
 * contact → footer); sections with no data are skipped silently.
 */
// ── Hospitality template ───────────────────────────────────────────────────
// A whole alternative page layout for destination businesses (bars,
// restaurants, salons, event venues, shops). The service template is built
// around "we'll come do work for you" — hero card → services grid → free
// estimate. Hospitality is the inverse: "come to us" — full-bleed atmosphere
// shot → quick "what's on" highlights → our story → photo gallery → big map
// with hours and directions. No services grid, no estimate form, no
// "What we do" eyebrow text. Dispatched from renderWebsiteHtml /
// renderHomePage / renderContactPage when pickVerticalDefaults(...).template
// === "hospitality".

function renderHospitalityHero(spec: WebsiteSpec, palette: PaletteSpec, opts: { ctaHref: string }): string {
  const heroImage = spec.images?.hero ?? DEFAULT_IMAGES.hero;
  const heading = vibeProfile(spec.vibe).headingClass;
  const locationLine = spec.location || [spec.city, spec.state].filter(Boolean).join(", ");
  const eyebrow = [spec.businessType, locationLine].filter(Boolean).join(" · ");
  return `  <section class="relative min-h-[88vh] flex items-end overflow-hidden text-white">
    <div class="absolute inset-0">
${renderImageBlock(heroImage, `${spec.businessName} atmosphere`, "w-full h-full object-cover")}
    </div>
    <div class="absolute inset-0" style="background: linear-gradient(180deg, rgba(0,0,0,0.35) 0%, rgba(0,0,0,0.15) 40%, rgba(0,0,0,0.85) 100%);"></div>
    <div class="absolute inset-x-0 top-0 h-32" style="background: linear-gradient(180deg, rgba(0,0,0,0.6), transparent);"></div>
    <div class="relative max-w-6xl mx-auto px-6 pt-32 pb-16 md:pb-24 w-full">
      ${eyebrow ? `<p class="text-white/80 font-semibold uppercase tracking-[0.3em] text-xs mb-6">${escapeHtml(eyebrow)}</p>` : ""}
      <h1 class="text-5xl md:text-7xl lg:text-8xl font-extrabold leading-[0.95] mb-6 ${heading}" style="text-shadow: 0 0 40px ${palette.brand}66, 0 4px 30px rgba(0,0,0,0.7);">${escapeHtml(spec.businessName)}</h1>
      ${spec.tagline ? `<p class="text-xl md:text-2xl text-white/90 max-w-2xl mb-10 font-light italic">${escapeHtml(spec.tagline)}</p>` : ""}
      <div class="flex flex-wrap gap-4 items-center">
        <a href="${opts.ctaHref}" class="inline-flex items-center gap-2 px-8 py-4 rounded-full font-bold text-base uppercase tracking-wider shadow-2xl hover:-translate-y-0.5 transition" style="background:${palette.accent}; color:${palette.brandDark};">${escapeHtml(spec.cta)} <span aria-hidden="true">→</span></a>
        ${spec.hours ? `<div class="flex items-center gap-2 text-white/80 text-sm pl-2"><span class="inline-block w-2 h-2 rounded-full animate-pulse" style="background:${palette.accent};"></span>${escapeHtml(spec.hours)}</div>` : ""}
      </div>
    </div>
  </section>`;
}

function renderHospitalityHighlights(spec: WebsiteSpec, palette: PaletteSpec): string {
  // Prefer spec.services titles; fall back to vertical highlights; skip if
  // neither — never render a placeholder "tell us what you need" prompt.
  const items: string[] = spec.services.length > 0
    ? spec.services.slice(0, 4).map((s) => s.title)
    : pickVerticalDefaults(spec.businessType).highlights ?? [];
  if (items.length === 0) return "";
  const headingClass = vibeProfile(spec.vibe).headingClass;
  const colCls = items.length >= 4 ? "md:grid-cols-4" : items.length === 3 ? "md:grid-cols-3" : "md:grid-cols-2";
  const cards = items
    .map(
      (label, i) =>
        `        <div class="text-center border-t-2 pt-6" style="border-color:${palette.accent};">
          <p class="text-xs font-semibold uppercase tracking-[0.3em] mb-3" style="color:${palette.accent};">${String(i + 1).padStart(2, "0")}</p>
          <p class="text-xl md:text-2xl font-bold leading-tight ${headingClass}">${escapeHtml(label)}</p>
        </div>`,
    )
    .join("\n");
  return `  <section class="py-16 md:py-20" style="background:${palette.brandDark}; color:${palette.textOnBrand};">
    <div class="max-w-6xl mx-auto px-6">
      <div class="grid grid-cols-2 ${colCls} gap-8 md:gap-12">
${cards}
      </div>
    </div>
  </section>`;
}

function renderHospitalityStory(spec: WebsiteSpec, palette: PaletteSpec): string {
  const heading = spec.about?.heading || "Our Story";
  const body = spec.about?.body || spec.aboutText || spec.description || "";
  if (!body.trim()) return "";
  const headingClass = vibeProfile(spec.vibe).headingClass;
  const paragraphs = renderParagraphs(body, "text-lg md:text-xl leading-relaxed text-white/80");
  return `  <section class="py-20 md:py-28" style="background:${palette.brandDark}; color:${palette.textOnBrand};">
    <div class="max-w-3xl mx-auto px-6 text-center">
      <p class="text-xs font-semibold uppercase tracking-[0.3em] mb-4" style="color:${palette.accent};">${escapeHtml(heading)}</p>
      <h2 class="text-4xl md:text-5xl font-extrabold mb-8 ${headingClass}">${escapeHtml(spec.businessName)}</h2>
      <div class="space-y-5">
        ${paragraphs}
      </div>
    </div>
  </section>`;
}

function renderHospitalityGallery(spec: WebsiteSpec, palette: PaletteSpec): string {
  // Build an atmosphere photo pool from spec images + the vertical's bank.
  // Dedupe by URL so a hero shot never appears twice.
  const v = pickVerticalDefaults(spec.businessType);
  const pool: string[] = [];
  const push = (src?: string | null) => {
    if (src && !pool.includes(src)) pool.push(src);
  };
  push(spec.images?.hero);
  push(spec.images?.about);
  push(spec.images?.contact);
  push(spec.images?.servicesHero);
  push(v.heroImage);
  push(v.aboutImage);
  push(v.contactImage);
  push(v.servicesHeroImage);
  if (v.serviceImages) for (const img of v.serviceImages) push(img);
  const images = pool.slice(0, 6);
  if (images.length < 3) return "";
  const headingClass = vibeProfile(spec.vibe).headingClass;
  const tiles = images
    .map((src, i) => {
      // Tiles at index 1 and 4 span 2 rows on desktop for visual rhythm.
      const tall = i === 1 || i === 4;
      const rowSpan = tall ? "md:row-span-2" : "";
      const h = tall ? "h-64 md:h-full" : "h-64 md:h-72";
      return `        <div class="rounded-xl overflow-hidden ${rowSpan} group">
${renderImageBlock(src, `${spec.businessName} gallery photo ${i + 1}`, `w-full ${h} object-cover group-hover:scale-105 transition duration-700`)}
        </div>`;
    })
    .join("\n");
  return `  <section class="py-20 md:py-24" style="background:${palette.background}; color:${palette.text};">
    <div class="max-w-6xl mx-auto px-6">
      <div class="max-w-2xl mb-10">
        <p class="text-xs font-semibold uppercase tracking-[0.3em] mb-3" style="color:${palette.brand};">The Vibe</p>
        <h2 class="text-3xl md:text-5xl font-extrabold leading-tight ${headingClass}">Inside ${escapeHtml(spec.businessName)}</h2>
      </div>
      <div class="grid grid-cols-2 md:grid-cols-3 gap-3 md:gap-4 md:auto-rows-[16rem]">
${tiles}
      </div>
    </div>
  </section>`;
}

function renderHospitalityFindUs(spec: WebsiteSpec, palette: PaletteSpec): string {
  const tel = telHref(spec.phone);
  const fullAddress = spec.location || [spec.address, [spec.city, spec.state].filter(Boolean).join(", "), spec.zipCode].filter(Boolean).join(", ");
  const mapQuery = fullAddress || spec.businessName;
  const mapSrc = `https://maps.google.com/maps?q=${encodeURIComponent(mapQuery)}&output=embed`;
  const directionsHref = fullAddress
    ? `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(fullAddress)}`
    : "";
  const headingClass = vibeProfile(spec.vibe).headingClass;
  return `  <section id="contact" class="py-0" style="background:${palette.brandDark}; color:${palette.textOnBrand};">
    <div class="grid md:grid-cols-2">
      <div class="relative min-h-[420px] md:min-h-[560px]">
        <iframe src="${escapeAttr(mapSrc)}" class="absolute inset-0 w-full h-full" style="border:0;" loading="lazy" referrerpolicy="no-referrer-when-downgrade" title="Map to ${escapeAttr(spec.businessName)}"></iframe>
      </div>
      <div class="p-10 md:p-16 flex flex-col justify-center">
        <p class="text-xs font-semibold uppercase tracking-[0.3em] mb-4" style="color:${palette.accent};">Drop In</p>
        <h2 class="text-4xl md:text-5xl font-extrabold leading-tight mb-8 ${headingClass}">Come See Us</h2>
        <dl class="space-y-5 text-base md:text-lg mb-10">
          ${fullAddress ? `<div><dt class="text-xs uppercase tracking-widest text-white/50 mb-1">Find Us</dt><dd class="font-medium">${escapeHtml(fullAddress)}</dd></div>` : ""}
          ${spec.hours ? `<div><dt class="text-xs uppercase tracking-widest text-white/50 mb-1">Hours</dt><dd class="font-medium whitespace-pre-line">${escapeHtml(spec.hours)}</dd></div>` : ""}
          ${spec.phone ? `<div><dt class="text-xs uppercase tracking-widest text-white/50 mb-1">Phone</dt><dd class="font-medium">${escapeHtml(spec.phone)}</dd></div>` : ""}
          ${spec.email ? `<div><dt class="text-xs uppercase tracking-widest text-white/50 mb-1">Email</dt><dd class="font-medium"><a href="mailto:${escapeAttr(spec.email)}" class="hover:underline">${escapeHtml(spec.email)}</a></dd></div>` : ""}
        </dl>
        <div class="flex flex-wrap gap-3">
          ${tel ? `<a href="tel:${escapeAttr(tel)}" class="inline-flex items-center gap-2 px-6 py-3 rounded-full font-bold text-sm uppercase tracking-wider transition hover:-translate-y-0.5 shadow-lg" style="background:${palette.accent}; color:${palette.brandDark};"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" class="w-4 h-4"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.97.37 1.92.7 2.83a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.33 1.86.57 2.83.7A2 2 0 0 1 22 16.92Z"/></svg>Call ${escapeHtml(spec.phone)}</a>` : ""}
          ${directionsHref ? `<a href="${escapeAttr(directionsHref)}" target="_blank" rel="noopener noreferrer" class="inline-flex items-center gap-2 px-6 py-3 rounded-full border-2 border-white/40 font-bold text-sm uppercase tracking-wider text-white hover:bg-white/10 transition"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" class="w-4 h-4"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>Get Directions</a>` : ""}
        </div>
      </div>
    </div>
  </section>`;
}

function renderHospitalityHomePage(spec: WebsiteSpec, palette: PaletteSpec, opts: { mode: "single" | "multi" }): string {
  const ctaHref = opts.mode === "multi" ? "contact.html" : "#contact";
  const nav: NavConfig =
    opts.mode === "multi"
      ? { mode: "multi", currentPage: "home" }
      : { mode: "single", sections: ["contact"] };
  const sections = [
    renderHeader(spec, palette, nav),
    renderHospitalityHero(spec, palette, { ctaHref }),
    renderHospitalityHighlights(spec, palette),
    renderHospitalityStory(spec, palette),
    renderHospitalityGallery(spec, palette),
    renderHospitalityFindUs(spec, palette),
    renderFooter(spec),
  ];
  return wrapDocument(spec, spec.tagline, spec.description || spec.tagline, sections);
}

function renderHospitalityContactPage(spec: WebsiteSpec, palette: PaletteSpec): string {
  const sections = [
    renderHeader(spec, palette, { mode: "multi", currentPage: "contact" }),
    renderHospitalityFindUs(spec, palette),
    renderFooter(spec),
  ];
  return wrapDocument(spec, "Visit", `Visit ${spec.businessName}. ${spec.tagline}`, sections);
}

// ── Page renderers (service template — dispatches to hospitality above) ────

export function renderWebsiteHtml(spec: WebsiteSpec): string {
  const palette = derivePaletteSpec(spec.palette);
  if (pickVerticalDefaults(spec.businessType).template === "hospitality") {
    return renderHospitalityHomePage(spec, palette, { mode: "single" });
  }
  const has = (id: SectionId) => spec.sections.includes(id);
  const sectionOrder: string[] = ["header"];
  if (has("hero")) sectionOrder.push("hero");
  if (has("services") && spec.services.length > 0) sectionOrder.push("services");
  if (has("about") && spec.about) sectionOrder.push("about");
  if (has("area") && spec.serviceArea.length > 0) sectionOrder.push("area");
  if (has("contact")) sectionOrder.push("contact");
  sectionOrder.push("footer");

  const metaDescription = spec.description || spec.tagline;
  const sections = [
    renderHeader(spec, palette, { mode: "single", sections: sectionOrder }),
    has("hero") ? renderHero(spec, palette, { includeImage: true, ctaHref: "#contact" }) : "",
    has("services") && spec.services.length > 0 && !pickVerticalDefaults(spec.businessType).skipBanner ? renderEstimateBanner(spec, palette, "#contact") : "",
    has("services") ? renderServices(spec, palette, { withImages: true, heading: "Services" }) : "",
    has("about") ? renderAbout(spec, palette, { withImage: true }) : "",
    has("area") ? renderArea(spec, palette) : "",
    has("contact") ? renderContact(spec, palette) : "",
    renderMap(spec, palette),
    renderFooter(spec),
  ];
  return wrapDocument(spec, spec.tagline, metaDescription, sections);
}

// ── Multi-page renderers ────────────────────────────────────────────────────

function renderHomePage(spec: WebsiteSpec, palette: PaletteSpec): string {
  if (pickVerticalDefaults(spec.businessType).template === "hospitality") {
    return renderHospitalityHomePage(spec, palette, { mode: "multi" });
  }
  const has = (id: SectionId) => spec.sections.includes(id);
  const sections = [
    renderHeader(spec, palette, { mode: "multi", currentPage: "home" }),
    has("hero") ? renderHero(spec, palette, { includeImage: true, ctaHref: "contact.html" }) : "",
    has("services") && spec.services.length > 0 && !pickVerticalDefaults(spec.businessType).skipBanner ? renderEstimateBanner(spec, palette, "contact.html") : "",
    has("services") ? renderServices(spec, palette, { withImages: true, heading: "Services", subheading: "How we can help" }) : "",
    has("contact") ? renderContact(spec, palette) : "",
    renderFooter(spec),
  ];
  return wrapDocument(spec, spec.tagline, spec.description || spec.tagline, sections);
}

function renderAboutPage(spec: WebsiteSpec, palette: PaletteSpec): string {
  const heroImage = spec.images?.about ?? DEFAULT_IMAGES.about;
  const aboutBody = spec.about?.body ?? "";
  const heading = spec.about?.heading ?? "About Us";
  const paragraphs = aboutBody
    ? renderParagraphs(aboutBody, "text-lg text-slate-600 leading-relaxed")
    : `<p class="text-lg text-slate-600 leading-relaxed">${escapeHtml(spec.tagline)}</p>`;

  const aboutSection = `  <section class="py-20 md:py-24 bg-white">
    <div class="max-w-6xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-center">
      <div class="rounded-2xl overflow-hidden shadow-lg">
${renderImageBlock(heroImage, `About ${spec.businessName}`, "w-full h-full object-cover")}
      </div>
      <div>
        <p class="text-sm font-semibold uppercase tracking-widest mb-3" style="color:${palette.brand}">${escapeHtml(heading)}</p>
        <h1 class="text-3xl md:text-5xl font-extrabold text-slate-900 leading-tight mb-8">Why ${escapeHtml(spec.businessName)}</h1>
        <div class="space-y-5">
          ${paragraphs}
        </div>
      </div>
    </div>
  </section>`;

  const sections = [
    renderHeader(spec, palette, { mode: "multi", currentPage: "about" }),
    aboutSection,
    renderArea(spec, palette),
    renderContact(spec, palette),
    renderFooter(spec),
  ];
  return wrapDocument(spec, "About", `About ${spec.businessName}. ${spec.tagline}`, sections);
}

function renderServicesPage(spec: WebsiteSpec, palette: PaletteSpec): string {
  const heroImage = spec.images?.servicesHero ?? DEFAULT_IMAGES.servicesHero;
  const heroSection = `  <section class="relative overflow-hidden text-white" style="background: linear-gradient(135deg, ${palette.heroFrom} 0%, ${palette.heroTo} 100%);">
    <div class="absolute inset-0">
${renderImageBlock(heroImage, `${spec.businessName} services`, "w-full h-full object-cover opacity-30")}
    </div>
    <div class="relative max-w-6xl mx-auto px-6 py-20 md:py-24">
      <p class="text-white/80 font-semibold uppercase tracking-widest text-xs mb-4">What we offer</p>
      <h1 class="text-4xl md:text-6xl font-extrabold leading-tight mb-4">Our Services</h1>
      <p class="text-lg md:text-xl text-white/90 max-w-2xl">Pick the cleaning that fits your home or project. Every job comes with a free estimate.</p>
    </div>
  </section>`;

  const sections = [
    renderHeader(spec, palette, { mode: "multi", currentPage: "services" }),
    heroSection,
    renderServices(spec, palette, { withImages: true, heading: "All Services", subheading: "Choose what you need" }),
    renderContact(spec, palette),
    renderFooter(spec),
  ];
  return wrapDocument(spec, "Services", `${spec.businessName} services. ${spec.tagline}`, sections);
}

function renderContactPage(spec: WebsiteSpec, palette: PaletteSpec): string {
  if (pickVerticalDefaults(spec.businessType).template === "hospitality") {
    return renderHospitalityContactPage(spec, palette);
  }
  const heroImage = spec.images?.contact ?? DEFAULT_IMAGES.contact;
  const heroSection = `  <section class="relative overflow-hidden text-white" style="background: linear-gradient(135deg, ${palette.heroFrom} 0%, ${palette.heroTo} 100%);">
    <div class="absolute inset-0">
${renderImageBlock(heroImage, `Contact ${spec.businessName}`, "w-full h-full object-cover opacity-25")}
    </div>
    <div class="relative max-w-6xl mx-auto px-6 py-20 md:py-24">
      <p class="text-white/80 font-semibold uppercase tracking-widest text-xs mb-4">Free estimates</p>
      <h1 class="text-4xl md:text-6xl font-extrabold leading-tight mb-4">Get in Touch</h1>
      <p class="text-lg md:text-xl text-white/90 max-w-2xl">Tell us a little about your space and we&rsquo;ll get back to you with a no-obligation quote.</p>
    </div>
  </section>`;

  const sections = [
    renderHeader(spec, palette, { mode: "multi", currentPage: "contact" }),
    heroSection,
    renderContact(spec, palette),
    renderMap(spec, palette),
    renderFooter(spec),
  ];
  return wrapDocument(spec, "Contact", `Contact ${spec.businessName} for a free estimate.`, sections);
}

// ── README ─────────────────────────────────────────────────────────────────

function renderReadme(spec: WebsiteSpec, isMultiPage: boolean): string {
  const tel = telHref(spec.phone);
  const hasServices = spec.services.length > 0;
  const fileList = isMultiPage
    ? [
        "- `index.html` — Home page (hero + services overview + contact)",
        "- `about.html` — About page",
        ...(hasServices ? ["- `services.html` — Full services page"] : []),
        "- `contact.html` — Contact page",
      ].join("\n")
    : "- `index.html` — the full single-page site, styled with Tailwind CDN. Open it in any browser to preview.";

  const lines = [
    `# ${spec.businessName}`,
    "",
    spec.tagline,
    "",
    "## What's in this zip",
    "",
    fileList,
    "",
    "## Replacing the placeholder photos",
    "",
    "Every image in this site is a Picsum/Unsplash placeholder. Find them by searching the HTML files for the comment:",
    "",
    "```html",
    "<!-- REPLACE IMAGE: change the src URL below with your own photo -->",
    "```",
    "",
    "Replace the `src` URL on the next line with a link to your own photo (or a relative path like `images/my-photo.jpg` if you put files in an `images/` folder next to the HTML).",
    "",
    "## Deploying",
    "",
    "Drag and drop the HTML files (and any `images/` folder you create) onto Netlify, Vercel, GitHub Pages, or any static host. No build step required.",
    "",
    "## Wiring up the contact form",
    "",
    "The contact section uses tap-to-call and tap-to-email buttons — no contact form. Visitors phone or email you directly, so no third-party form service or wiring is needed.",
    "",
    "## Replacing the placeholder reviews",
    "",
    "The site intentionally has no reviews/testimonials section. If you want to add one later, the cleanest path is a Facebook reviews embed via Elfsight or the FB Page Plugin — just paste the embed snippet wherever you want it.",
    "",
    "## Contact (used on the page)",
    "",
    tel ? `- Phone: ${spec.phone}` : "",
    spec.email ? `- Email: ${spec.email}` : "",
    spec.address || spec.city
      ? `- Address: ${[spec.address, [spec.city, spec.state].filter(Boolean).join(", "), spec.zipCode].filter(Boolean).join(", ")}`
      : "",
    spec.hours ? `- Hours: ${spec.hours}` : "",
  ]
    .filter((l) => l !== "")
    .join("\n");
  return lines + "\n";
}

/**
 * Build the in-memory zip buffer. When `multiPage` is set on the spec, the
 * zip contains 4 HTML files (index/about/services/contact) sharing a sticky
 * top nav. Otherwise it contains a single index.html with anchor-link nav.
 */
export function buildWebsiteZip(spec: WebsiteSpec): { zipName: string; buffer: Buffer; fileCount: number } {
  const palette = derivePaletteSpec(spec.palette);
  const zip = new AdmZip();
  let fileCount = 0;
  const has = (id: SectionId) => spec.sections.includes(id);

  if (spec.multiPage) {
    // Multi-page mode emits index/about/contact unconditionally + services.html
    // only when the spec actually has a services list. The nav above is in
    // sync, so links are never broken. Renderers fall back to placeholder
    // copy for empty about/contact data.
    void has;
    zip.addFile("index.html", Buffer.from(renderHomePage(spec, palette), "utf8"));
    zip.addFile("about.html", Buffer.from(renderAboutPage(spec, palette), "utf8"));
    if (spec.services.length > 0) {
      zip.addFile("services.html", Buffer.from(renderServicesPage(spec, palette), "utf8"));
    }
    zip.addFile("contact.html", Buffer.from(renderContactPage(spec, palette), "utf8"));
    fileCount = spec.services.length > 0 ? 4 : 3;
  } else {
    zip.addFile("index.html", Buffer.from(renderWebsiteHtml(spec), "utf8"));
    fileCount = 1;
  }
  zip.addFile("README.md", Buffer.from(renderReadme(spec, !!spec.multiPage), "utf8"));
  fileCount += 1;

  const baseName = spec.zipName.endsWith(".zip") ? spec.zipName : `${spec.zipName}.zip`;
  return { zipName: baseName, buffer: zip.toBuffer(), fileCount };
}

/**
 * Public-facing schema doc the system prompt embeds verbatim so Vance
 * knows exactly what JSON shape to emit. Keep this in sync with
 * WebsiteSpecSchema above — if the schema changes, regenerate the prompt.
 */
export const WEBSITE_SPEC_SCHEMA_DOC = `{
  "businessName": "string (REQUIRED, 1-100 chars)",
  "businessType": "string (optional) — the vertical, e.g. 'Cleaning Service', 'Firearms Retail', 'ATV Sales & Service', 'Italian Restaurant'. Shown as eyebrow text above the tagline. Use it to inform colour + vibe + service-name choices.",
  "tagline": "string (REQUIRED, 1-200 chars) — the big headline sentence in the hero.",
  "description": "string (optional, ≤500 chars) — sub-headline paragraph under the tagline.",
  "location": "string (optional) — single-line, e.g. 'Bozeman, MT' or 'Serving the Bay Area'. Preferred over the legacy address/city/state/zip fields when set.",
  "phone": "string (optional)",
  "email": "string (optional)",
  "address": "string (optional, street address)  -- legacy / contact block",
  "city": "string (optional)                    -- legacy / contact block",
  "state": "string (optional)                   -- legacy / contact block",
  "zipCode": "string (optional)                 -- legacy / contact block",
  "hours": "string (optional, free-form, e.g. 'Mon-Fri 8am-6pm, Sat 9am-2pm')",
  "vibe": "string (optional) — short tone descriptor, e.g. 'fresh and trustworthy', 'tactical and rugged', 'adventurous and bold', 'elegant and refined', 'playful and friendly'. The renderer matches keywords to pick heading style. When omitted, a vibe is inferred from businessType (smart vertical defaults). Set explicitly when you want to override the vertical default.",
  "palette": "OPTIONAL object {primary, secondary, accent, background, text} — each a 6-digit hex like '#1e3a8a'. When omitted (or any sub-field omitted), the template auto-fills from a vertical-aware default table (gun-shop → gunmetal+red+amber on near-black; ATV → orange+black+yellow; restaurant → warm browns+gold on cream; bar/pub/tavern/brewery → dark wood brown+amber on near-black; law/finance → navy+slate+amber; salon/spa → rose+plum+gold on pink-tinted; tech → blue+cyan; cleaning → teal+yellow; trades → forest-green+amber; real-estate → teal+gold; auto → red+black+yellow). If the user mentions colours, use those literally — they win.",
  "fonts": "OPTIONAL object {heading?, body?} — each a Google Fonts family name like 'Oswald', 'Playfair Display', 'Montserrat', 'Inter', 'Roboto', 'Merriweather'. When omitted, vertical defaults apply: tactical/auto/trades/ATV → Oswald headings, restaurant/salon → Playfair Display headings, law/realestate → Montserrat, everywhere else → Inter. Body defaults to Inter (or Roboto for tactical). Always loaded via fonts.googleapis.com.",
  "socialLinks": "OPTIONAL object {facebook, instagram, twitter, linkedin, youtube, tiktok} — each a full URL or null. Rendered as icon links in the footer. Omit/null entries are simply not displayed. Never fabricate — only include URLs the user actually gave you.",
  "formspreeUrl": "DEPRECATED — accepted for back-compat with older specs but no longer rendered. The contact section no longer has a form; it uses tap-to-call + tap-to-email buttons instead. Just omit this field.",
  "header": "OPTIONAL object {layout?, brandTreatment?, tagline?} — drives the sticky top header design. Pick these from your niche research, NOT defaults. (a) layout: 'logo-left' (conventional, brand on left, nav middle, CTA right — trades, cleaning, auto), 'centered' (brand centered, nav split L/R — restaurants, salons, spas, editorial), or 'stacked' (brand + tagline stacked left — law, finance, real-estate). (b) brandTreatment: 'plain' (clean wordmark — modern minimal), 'dot' (wordmark + small brand-coloured dot — friendly local services), 'badge' (2-letter initials in a brand-coloured pill before the name — trades, gun shops, ATV), 'uppercase' (wide-tracked all-caps wordmark — tactical, auto, law firms), 'underline' (wordmark with a thick brand-coloured underline — editorial, spa, salon). (c) tagline: optional short phrase (≤80 chars) shown beneath the brand name on desktop, e.g. 'Family-owned · Hamptonville, NC' or 'Est. 2014'. When the whole object is omitted, defaults to {layout:'logo-left', brandTreatment:'dot'}.",
  "sections": "OPTIONAL string array — explicitly choose which sections to render. Allowed values: 'hero', 'about', 'services', 'area', 'contact'. ('testimonials' is accepted for back-compat but renders nothing — the user does not want a reviews section.) Order is irrelevant. When omitted, every section that has data is rendered automatically. In multi-page mode this also drives which extra pages get emitted.",
  "services": "array (≤12) of {name, description, details?, image?}. 'name' is the service title (legacy 'title' is also accepted). 'description' is a short blurb (≤500 chars). 'details' (optional, ≤800 chars) is an italic supplementary line under the description for prices, durations, what's included, etc. 'image' OPTIONAL URL — this is a paste-in image slot for the user. ALWAYS include the key 'image' on EVERY service even if you don't have a URL (set it to null) so the proposal card surfaces an obvious paste-here slot. The user fills in real image URLs after they see the proposal; until then a Picsum placeholder wrapped in a REPLACE IMAGE comment ships.",
  "about": "OPTIONAL {heading (default 'About Us'), body (1-2000 chars, multi-paragraph allowed via blank-line separation)}.",
  "aboutText": "string (optional, ≤2000 chars) — convenience alias for about.body when you don't need a custom heading. Ignored if 'about' is set.",
  "serviceArea": "array of strings (≤20), each a city/region name. Optional.",
  "testimonials": "array (≤6) of {quote, author}. Accepted for back-compat but NOT RENDERED — the user has opted out of having a reviews/testimonials section. Just omit this field.",
  "ctaText": "string (≤60 chars, optional) — primary call-to-action button label. e.g. 'Get Free Estimate', 'Shop Now', 'Book a Test Ride', 'Reserve a Table'. Wins over legacy 'cta'. Default 'Get a Free Estimate'. Also used as the headline of the always-on Free Estimates banner between hero and services on the home page.",
  "cta": "string (≤60 chars, optional) — legacy alias for ctaText. Either works.",
  "styleNotes": "string (optional, ≤500 chars) — extra instructions you want preserved with the site. Surfaced as an HTML comment in <head>; not a substitute for setting palette/vibe/etc.",
  "layout": "OPTIONAL enum 'multi-page' | 'single-page'. Preferred over the legacy multiPage boolean. Default 'multi-page'. Set 'single-page' only when the user explicitly asks for a single page.",
  "multiPage": "boolean (legacy alias for layout — default TRUE). 'layout' wins when both are set.",
  "images": "REQUIRED object {hero, about, servicesHero, contact} — each a URL OR null. ALWAYS include all four keys (set unknown ones to null). When a slot is null, the template AUTOMATICALLY fills it with a niche-appropriate Unsplash photo from a vertical-aware bank (cleaning → kitchen/bathroom; gun → firearms/range; restaurant → plated food/interior; etc.) — so the site never ships with a random irrelevant stock photo. The user can swap any of them after the build via the REPLACE IMAGE comment above each img tag. Only set an explicit URL when you genuinely have a better photo than the vertical default would pick. Same rule for per-service 'image': leave it null and the template will rotate through the vertical's service-photo bank by service index (e.g. a cleaning service's Basic/Deep/Move-Out cards each get a different cleaning-themed photo automatically).",
  "zipName": "string (default 'site') — lowercase, alphanum + dashes only, e.g. 'rangefinders-site'."
}

GENERATOR RULES (always apply):
- **Read businessType FIRST** — vertical-aware smart defaults will auto-fill palette + fonts + vibe for the 15 built-in verticals (cleaning, gun, ATV, restaurant, bar/pub/tavern/brewery, fitness/gym/crossfit, medical/dental/clinic/vet, pet services/grooming/daycare, events/wedding/photography, law/finance, salon/spa, tech, trades — covers plumber/painter/grader/excavator/roofer/electrician/HVAC/handyman/junk-removal/pressure-wash/concrete/welding/etc., real-estate, auto). Only override them when the user mentioned specific colours/fonts/feel.
- **For ANY non-cleaning vertical (gun shop, ATV dealer, restaurant, bar/pub/brewery, gym, dental/medical, pet groomer, wedding photographer, salon, law firm, auto shop, trades, tech, real estate, anything else):** you MUST have run \`web_search\` for "best <vertical> websites 2026" / "<vertical> landing page design" BEFORE producing this JSON. Use what you learned to inform the palette, vibe, tagline tone, and service-name choices — don't just default. If you haven't searched, stop and search now.
- If the user mentions colours, use those literally — they win over everything else.
- **Otherwise, derive the palette + CTA colour from your web_search findings.** When you searched 3-5 top sites in the vertical, look at what colours THEY use for hero backgrounds, CTA buttons, and accents — if you see a consistent pattern (e.g. 4 of 5 top gun-shop sites use blood-red CTAs on gunmetal, or 3 of 4 top restaurant sites use warm-amber CTAs on cream), USE that pattern: set \`palette.primary\` and \`palette.accent\` to hex values matching what you saw. Mention briefly in your proposal text which sites informed the choice (e.g. *"CTA red pulled from Vortex Optics + Sig Sauer's site"*). Only fall back to the built-in vertical defaults when research was inconclusive or the vertical doesn't show a clear pattern. NEVER default to green CTAs unless the research actually showed green CTAs in the wild — match what real, good-looking sites in the vertical are doing.
- Always include Tailwind CDN — handled by the template, do not add anything to the spec for it.
- **\`images\` is REQUIRED and must always include all four keys (hero, about, servicesHero, contact) with either a URL or null.** Same for every entry in \`services\` — always include the \`image\` key (URL or null). This is so the user sees obvious paste-here slots in the proposal card and knows exactly where to drop their own photos. Never invent stock-photo URLs.
- Do not set 'testimonials' — the reviews section is disabled site-wide. Omit the field.
- For socialLinks, only set values the user actually gave you — never invent URLs.
- A click-to-call phone button, footer social links, an always-on "Free Estimates" CTA banner, a Google Maps embed (when location is set), and updated SEO/OG meta are ALL rendered automatically — do not add anything to the spec to opt in.
- The contact section uses tap-to-call and tap-to-email buttons (NO form). Do not set 'formspreeUrl' — it's deprecated and ignored.
- Default to multi-page unless single-page is explicitly requested.`;
