import pino from "pino";
import { pushLog } from "./log-buffer";

const isProduction = process.env.NODE_ENV === "production";

export const logger = pino({
  level: process.env.LOG_LEVEL ?? "info",
  redact: [
    "req.headers.authorization",
    "req.headers.cookie",
    "res.headers['set-cookie']",
  ],
  hooks: {
    logMethod(this: pino.Logger, args: Parameters<pino.LogFn>, method: pino.LogFn, level: number) {
      try {
        const labels = (this as unknown as { levels: { labels: Record<number, string> } }).levels?.labels ?? {};
        pushLog(labels[level] ?? "info", args as unknown as unknown[]);
      } catch { /* never let log capture break logging */ }
      return method.apply(this, args);
    },
  },
  ...(isProduction
    ? {}
    : {
        transport: {
          target: "pino-pretty",
          options: { colorize: true },
        },
      }),
});
