import { Storage } from "@google-cloud/storage";

const REPLIT_SIDECAR_ENDPOINT = "http://127.0.0.1:1106";

const storageClient = new Storage({
  credentials: {
    audience: "replit",
    subject_token_type: "access_token",
    token_url: `${REPLIT_SIDECAR_ENDPOINT}/token`,
    type: "external_account",
    credential_source: {
      url: `${REPLIT_SIDECAR_ENDPOINT}/credential`,
      format: { type: "json", subject_token_field_name: "access_token" },
    },
    universe_domain: "googleapis.com",
  },
  projectId: "",
});

const BUCKET_ID = process.env.DEFAULT_OBJECT_STORAGE_BUCKET_ID;
const PRIVATE_DIR = process.env.PRIVATE_OBJECT_DIR;

function bucket() {
  if (!BUCKET_ID) throw new Error("DEFAULT_OBJECT_STORAGE_BUCKET_ID not set");
  return storageClient.bucket(BUCKET_ID);
}

function keyFor(subdir: string, filename: string): string {
  if (!PRIVATE_DIR) throw new Error("PRIVATE_OBJECT_DIR not set");
  // PRIVATE_DIR is like `/<bucket-id>/.private` — strip leading slash and bucket prefix
  const trimmed = PRIVATE_DIR.replace(/^\/+/, "");
  const parts = trimmed.split("/");
  // Drop the bucket id (first segment) since we apply it via .bucket()
  const base = parts.slice(1).join("/") || ".private";
  return `${base}/${subdir}/${filename}`;
}

export async function uploadBodyModel(filename: string, buf: Buffer): Promise<void> {
  const file = bucket().file(keyFor("body-models", filename));
  await file.save(buf, {
    contentType: "model/gltf-binary",
    resumable: false,
    metadata: { cacheControl: "public, max-age=86400, immutable" },
  });
}

export async function bodyModelExists(filename: string): Promise<boolean> {
  const [exists] = await bucket().file(keyFor("body-models", filename)).exists();
  return exists;
}

export function streamBodyModel(filename: string): NodeJS.ReadableStream {
  return bucket().file(keyFor("body-models", filename)).createReadStream();
}

// --- Emote files (Mixamo .glb / .fbx, one per named slot) -------------------
// Same durability story as body models: local disk gets wiped on Autoscale
// restarts/instance switches, so we mirror writes to GCS and fall back to
// GCS on reads when the local copy isn't there.

export async function uploadEmote(name: string, ext: "glb" | "fbx", buf: Buffer): Promise<void> {
  const file = bucket().file(keyFor("emotes", `${name}.${ext}`));
  await file.save(buf, {
    contentType: ext === "glb" ? "model/gltf-binary" : "application/octet-stream",
    resumable: false,
    metadata: { cacheControl: "private, no-cache" },
  });
}

export async function deleteEmote(name: string, ext: "glb" | "fbx"): Promise<void> {
  try {
    await bucket().file(keyFor("emotes", `${name}.${ext}`)).delete({ ignoreNotFound: true });
  } catch { /* noop */ }
}

export async function findEmoteInStorage(name: string): Promise<{ ext: "glb" | "fbx"; sizeBytes: number } | null> {
  for (const ext of ["glb", "fbx"] as const) {
    const file = bucket().file(keyFor("emotes", `${name}.${ext}`));
    const [exists] = await file.exists();
    if (exists) {
      const [meta] = await file.getMetadata();
      const size = typeof meta.size === "string" ? Number(meta.size) : (meta.size ?? 0);
      return { ext, sizeBytes: size };
    }
  }
  return null;
}

export function streamEmote(name: string, ext: "glb" | "fbx"): NodeJS.ReadableStream {
  return bucket().file(keyFor("emotes", `${name}.${ext}`)).createReadStream();
}
