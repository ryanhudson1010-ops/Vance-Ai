import { logger } from "./logger";

export interface SearchSource { title: string; url: string; snippet: string; pageText?: string }

function decodeDDGUrl(ddgHref: string): string | null {
  try {
    const uddg = ddgHref.match(/[?&]uddg=([^&)]+)/)?.[1];
    if (!uddg) return null;
    const decoded = decodeURIComponent(uddg);
    return decoded.startsWith("http") ? decoded : null;
  } catch {
    return null;
  }
}

async function searchWithJinaDDG(query: string): Promise<SearchSource[]> {
  const ddgPageUrl = `https://duckduckgo.com/html/?q=${encodeURIComponent(query)}`;
  const jinaUrl = `https://r.jina.ai/${ddgPageUrl}`;
  const res = await fetch(jinaUrl, {
    signal: AbortSignal.timeout(12000),
    headers: { "User-Agent": "Mozilla/5.0 (compatible; VanceBot/1.0)" },
  });
  if (!res.ok) return [];
  const markdown = await res.text();
  const sources: SearchSource[] = [];
  const blocks = markdown.split(/\n## /);
  for (const block of blocks.slice(1)) {
    if (sources.length >= 7) break;
    const headingMatch = /^\[([^\]]+)\]\((https?:\/\/duckduckgo\.com\/l\/\?[^)]+)\)/.exec(block);
    if (!headingMatch) continue;
    const title = headingMatch[1].trim();
    const url = decodeDDGUrl(headingMatch[2]);
    if (!url) continue;
    const linkMatches = [...block.matchAll(/\[([^\]]{30,})\]\(https?:\/\/duckduckgo\.com[^)]+\)/g)];
    const snippet = linkMatches.length > 0
      ? linkMatches[linkMatches.length - 1][1].replace(/\*\*/g, "").trim()
      : "";
    if (!title || title.length < 4) continue;
    sources.push({ title, url, snippet });
  }
  return sources;
}

export async function fetchPageViaJina(url: string, maxChars = 3000): Promise<string> {
  try {
    const res = await fetch(`https://r.jina.ai/${url}`, {
      signal: AbortSignal.timeout(8000),
      headers: { "User-Agent": "Mozilla/5.0 (compatible; VanceBot/1.0)" },
    });
    if (!res.ok) return "";
    const text = await res.text();
    const bodyStart = text.indexOf("Markdown Content:");
    const body = bodyStart >= 0 ? text.slice(bodyStart + 17) : text;
    return body.slice(0, maxChars);
  } catch {
    return "";
  }
}

async function searchWithSerper(query: string): Promise<SearchSource[]> {
  const key = process.env.SERPER_API_KEY;
  if (!key) return [];
  try {
    const r = await fetch("https://google.serper.dev/search", {
      method: "POST",
      headers: { "X-API-KEY": key, "Content-Type": "application/json" },
      body: JSON.stringify({ q: query, num: 8 }),
      signal: AbortSignal.timeout(8000),
    });
    if (!r.ok) {
      logger.warn({ status: r.status }, "Serper search non-ok response");
      return [];
    }
    const data = await r.json() as {
      organic?: Array<{ title?: string; link?: string; snippet?: string; date?: string }>;
    };
    return (data.organic ?? [])
      .slice(0, 6)
      .filter((o): o is { title: string; link: string; snippet?: string; date?: string } =>
        typeof o.title === "string" && typeof o.link === "string"
      )
      .map((o) => ({
        title: o.title,
        url: o.link,
        snippet: o.date ? `${o.date} — ${o.snippet ?? ""}` : (o.snippet ?? ""),
      }));
  } catch (err) {
    logger.warn({ err }, "Serper search failed");
    return [];
  }
}

export async function runWebSearch(query: string): Promise<{ sources: SearchSource[]; error?: string }> {
  try {
    let sources = await searchWithSerper(query);
    if (sources.length === 0) sources = await searchWithJinaDDG(query);
    if (sources.length === 0) {
      return { sources: [], error: "No results found for that query" };
    }
    const fetchTasks = sources.slice(0, 2).map(async (s) => {
      s.pageText = await fetchPageViaJina(s.url, 3000);
    });
    await Promise.allSettled(fetchTasks);
    return { sources };
  } catch (err) {
    logger.warn({ err }, "Web search failed");
    return { sources: [], error: "Search request failed" };
  }
}

export function buildWebSearchContext(query: string, sources: SearchSource[]): string {
  const parts = sources.map((s, i) => {
    const body = s.pageText?.trim() || s.snippet;
    return `[Source ${i + 1}: ${s.title}]
URL: ${s.url}
${body}`;
  });
  return `
══════════════════════════════════════════════
STARTER WEB SEARCH RESULTS (auto-fetched right now — ${new Date().toUTCString()})
Query: "${query}"
══════════════════════════════════════════════

${parts.join("\n\n---\n\n")}

══════════════════════════════════════════════
IMPORTANT — these are a STARTER batch only, NOT your final answer:
- You HAVE searched the web. Do not say you cannot.
- Attribute facts to the sources above when they come from them.
- Mention that you just looked this up online.
- If these starter results don't clearly answer the question (thin snippets, wrong subject, no direct fact), you MUST call the \`web_search\` tool with a refined query (add city, employer, model number, "site:linkedin.com", etc.) and/or \`fetch_url\` on a promising link BEFORE giving up. Do not write "I couldn't verify" until you've genuinely tried 2-3 refined searches in this same turn.
- If sources are incomplete or conflicting, say so honestly only after iterating.
══════════════════════════════════════════════
`;
}
