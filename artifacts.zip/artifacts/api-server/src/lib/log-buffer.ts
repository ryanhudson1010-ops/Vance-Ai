export interface LogEntry { ts: number; level: string; msg: string; obj?: string }

const RING_MAX = 500;
const ring: LogEntry[] = [];

// Mirror of pino's redact paths in lib/logger.ts — applied here because pino's
// `hooks.logMethod` fires BEFORE the serializer/redactor runs, so raw req/res
// objects with cookies/auth headers would otherwise hit the ring buffer and be
// returned by get_server_logs (which is gated only by app passcode auth, not
// secret-grade ACL). Keep this list in sync with logger.ts redact array.
const REDACT_KEYS = new Set([
  "authorization", "cookie", "set-cookie",
  "password", "passwd", "passcode", "secret", "token",
  "api_key", "apikey", "x-api-key", "session_secret",
]);
const REDACTED = "[REDACTED]";

function safeStringify(v: unknown): string {
  try {
    const seen = new WeakSet<object>();
    const s = JSON.stringify(v, (key, val) => {
      if (val instanceof Error) return { name: val.name, message: val.message, stack: val.stack };
      if (typeof val === "string" && REDACT_KEYS.has(key.toLowerCase())) return REDACTED;
      if (val && typeof val === "object") {
        if (seen.has(val as object)) return "[Circular]";
        seen.add(val as object);
        // Redact common nested shapes: req.headers.authorization, res.headers['set-cookie']
        if (key === "headers" && !Array.isArray(val)) {
          const cleaned: Record<string, unknown> = {};
          for (const [k, vv] of Object.entries(val as Record<string, unknown>)) {
            cleaned[k] = REDACT_KEYS.has(k.toLowerCase()) ? REDACTED : vv;
          }
          return cleaned;
        }
      }
      return val;
    });
    return s.length > 2000 ? s.slice(0, 2000) + "…" : s;
  } catch {
    return "(unserializable)";
  }
}

export function pushLog(level: string, args: unknown[]): void {
  let obj: unknown = undefined;
  let msg = "";
  if (args.length === 0) {
    msg = "";
  } else if (typeof args[0] === "string") {
    msg = args[0];
  } else {
    obj = args[0];
    msg = typeof args[1] === "string" ? args[1] : "";
  }
  ring.push({
    ts: Date.now(),
    level,
    msg: msg.slice(0, 1500),
    ...(obj !== undefined ? { obj: safeStringify(obj) } : {}),
  });
  if (ring.length > RING_MAX) ring.shift();
}

export function getRecentLogs(opts?: { limit?: number; level?: string; search?: string }): LogEntry[] {
  const limit = Math.min(Math.max(opts?.limit ?? 50, 1), RING_MAX);
  const levelFilter = opts?.level?.toLowerCase();
  const searchFilter = opts?.search?.toLowerCase();
  let out = ring;
  if (levelFilter) {
    const order = ["trace", "debug", "info", "warn", "error", "fatal"];
    const minIdx = order.indexOf(levelFilter);
    if (minIdx >= 0) out = out.filter((e) => order.indexOf(e.level) >= minIdx);
  }
  if (searchFilter) {
    out = out.filter((e) => e.msg.toLowerCase().includes(searchFilter) || (e.obj?.toLowerCase().includes(searchFilter) ?? false));
  }
  return out.slice(-limit);
}
