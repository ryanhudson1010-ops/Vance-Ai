import type { Request, Response, NextFunction } from "express";

const COOKIE_NAME = "vance_auth";

export function isAuthed(req: Request): boolean {
  const signed = (req as Request & { signedCookies?: Record<string, string> }).signedCookies;
  return signed?.[COOKIE_NAME] === "ok";
}

export function passcodeAuth(_req: Request, _res: Response, next: NextFunction): void {
  // Passcode lock disabled — open access. Re-enable by restoring the
  // `if (isAuthed(req)) next(); else res.status(401)` check below.
  next();
}

export const AUTH_COOKIE_NAME = COOKIE_NAME;
