// Per-conversation SSE event mirror for website-build chat turns.
//
// The chat route in routes/openai/index.ts already keeps running after the
// client disconnects (clientGone flag swallows write errors, the OpenAI loop
// has no AbortSignal tied to req, the DB insert at the end happens
// regardless). What's missing is a way for the *client* to reattach to an
// in-flight turn it lost the SSE for — typically because the deployment
// platform's edge proxy aborts the request at 5 min, or the iPhone PWA was
// backgrounded long enough to kill the fetch.
//
// This file mirrors every emit() from a website-mode turn into a ring buffer
// keyed by sessionId, with monotonic absolute event ids. A reattach route
// replays from the highest seen id and then live-tails. Same shape as
// BuildRunner.emit / attachSseToRunner in routes/vance/index.ts, just
// scoped to a single chat turn and indexed by conversationId so the client
// can ask "is there a turn in progress for conv N?" after a refresh.

import type { Request, Response } from "express";
import { randomUUID } from "node:crypto";

export interface WebsiteSessionEvent { type?: string; [k: string]: unknown }

export class WebsiteSession {
  readonly id: string = randomUUID();
  readonly conversationId: number;
  readonly startedAt: number = Date.now();
  endedAt: number | null = null;
  events: WebsiteSessionEvent[] = [];
  // Monotonic absolute event id. Stable across ring-buffer truncation
  // (clients persist highest-seen id, reconnect with ?after=<id>; server
  // uses (id - baseEventId) to index events[]).
  nextEventId = 0;
  baseEventId = 0;
  subscribers: Set<(e: WebsiteSessionEvent, id: number) => void> = new Set();

  constructor(conversationId: number) {
    this.conversationId = conversationId;
  }

  // Returns the absolute id assigned to the event so callers (the chat
  // route's live `emit()` wrapper) can write the same id over the live
  // socket. Without this the client only saw `id:` lines on REPLAY frames,
  // never on live frames, so `lastIdx` stayed at -1 during the initial
  // stream and a reattach would request `?after=0` and replay every event
  // already rendered (duplicate content / TTS / UI events).
  emit(event: WebsiteSessionEvent): number {
    // Hard-stop superseded sessions. Once `end()` has been called (either
    // because the chat handler finished naturally OR because a newer turn
    // for this conversation force-ended us via createWebsiteSession), no
    // further events should be mirrored. Without this guard, the ORIGINAL
    // chat handler keeps calling websiteSession.emit() after supersede
    // (it still holds the old reference), buffering up to 5000 events
    // into a dead session — wasting memory and, worse, polluting any
    // client that reattaches to the dead session id with events that
    // happened AFTER the terminal "Superseded" error event.
    if (this.endedAt !== null) return -1;
    const id = this.nextEventId++;
    this.events.push(event);
    if (this.events.length > 5000) {
      const drop = this.events.length - 5000;
      this.events.splice(0, drop);
      this.baseEventId += drop;
    }
    for (const sub of this.subscribers) {
      try { sub(event, id); } catch { /* one bad subscriber must not kill the session */ }
    }
    return id;
  }

  end(finalEvent?: WebsiteSessionEvent): void {
    if (this.endedAt !== null) return;
    if (finalEvent) this.emit(finalEvent);
    this.endedAt = Date.now();
    this.subscribers.clear();
  }
}

const sessionsById: Map<string, WebsiteSession> = new Map();
// One ACTIVE (not-yet-ended) session per conversation. The latest session
// for a conv supersedes any prior live one (defensive — same conv firing
// two website turns in parallel shouldn't happen, but if it does the
// later one wins and the earlier one is force-ended).
const activeSessionByConv: Map<number, string> = new Map();

const EVICT_AFTER_END_MS = 10 * 60 * 1000;

function scheduleEviction(s: WebsiteSession): void {
  const t = setTimeout(() => {
    sessionsById.delete(s.id);
    if (activeSessionByConv.get(s.conversationId) === s.id) {
      activeSessionByConv.delete(s.conversationId);
    }
  }, EVICT_AFTER_END_MS);
  t.unref?.();
}

export function createWebsiteSession(conversationId: number): WebsiteSession {
  // Supersede any prior live session for this conversation. Force-ends it
  // so any still-attached SSE writers see a terminal event and unsubscribe.
  const priorId = activeSessionByConv.get(conversationId);
  if (priorId) {
    const prior = sessionsById.get(priorId);
    if (prior && prior.endedAt === null) {
      prior.end({ type: "error", message: "Superseded by a newer turn in this conversation." });
      scheduleEviction(prior);
    }
  }
  const session = new WebsiteSession(conversationId);
  sessionsById.set(session.id, session);
  activeSessionByConv.set(conversationId, session.id);
  return session;
}

export function endWebsiteSession(session: WebsiteSession, finalEvent?: WebsiteSessionEvent): void {
  if (session.endedAt !== null) return;
  session.end(finalEvent);
  if (activeSessionByConv.get(session.conversationId) === session.id) {
    activeSessionByConv.delete(session.conversationId);
  }
  scheduleEviction(session);
}

export function getWebsiteSession(id: string): WebsiteSession | undefined {
  return sessionsById.get(id);
}

export function getActiveWebsiteSessionForConversation(conversationId: number): WebsiteSession | null {
  const id = activeSessionByConv.get(conversationId);
  if (!id) return null;
  const s = sessionsById.get(id);
  if (!s || s.endedAt !== null) return null;
  return s;
}

// SSE attach + replay + live tail. Mirrors attachSseToRunner in
// routes/vance/index.ts so the wire shape matches what the build-mode
// reconnect logic on the client already understands.
export function attachSseToWebsiteSession(req: Request, res: Response, session: WebsiteSession, after: number): void {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
  try { res.flushHeaders?.(); } catch { /* socket may already be dead */ }

  // ── Race-free replay+subscribe + dead-socket safety ──────────────────────
  // Previous order (replay → subscribe) had a window where any emit() landing
  // between the last replayed event and `subscribers.add(sub)` would be lost
  // forever (no subscriber yet, never replayed because they post-dated the
  // snapshot the next reconnect would request). Fix: subscribe FIRST with a
  // queue that buffers live events, then snapshot `nextEventId` (the
  // exclusive upper bound for replay), replay, then flush the queue keeping
  // only events with id >= the replay upper bound (everything else was just
  // delivered via replay and would dupe).
  //
  // Also: ALL writes (including the very first ': connected' / init frame)
  // go through safeWrite, and req.on('close')/res.on('error') are registered
  // BEFORE any write attempt. Previously the connected+init writes were
  // unguarded above this block — if the socket was already dead at attach
  // time (slow client retry on a freshly-reset connection) those writes
  // would throw and surface as an uncaught route error, exactly the class
  // safeWrite was added to eliminate.
  let closed = false;
  let replayDone = false;
  const queued: Array<[WebsiteSessionEvent, number]> = [];
  let cleanupCalled = false;
  let heartbeat: ReturnType<typeof setInterval> | null = null;
  // `sub` is declared further down (after replay setup) but `cleanup` MUST be
  // defined here because req.on("close")/res.on("error") get registered next,
  // BEFORE any write attempt — and a dead-on-arrival socket can fire those
  // handlers (or fail safeWrite during the init frame) before `sub` exists.
  // Using `let sub` + null-guard keeps cleanup TDZ-safe in that race.
  let sub: ((e: WebsiteSessionEvent, id: number) => void) | null = null;
  const cleanup = () => {
    if (cleanupCalled) return;
    cleanupCalled = true;
    closed = true;
    if (heartbeat) clearInterval(heartbeat);
    if (sub) session.subscribers.delete(sub);
    try { res.end(); } catch { /* already ended */ }
  };
  // Register socket-close cleanup BEFORE any write so a disconnect at any
  // point — including mid-handshake or before the first byte — deterministically
  // unsubscribes us instead of stranding the subscriber until end+eviction.
  req.on("close", cleanup);
  res.on("error", cleanup);

  const safeWrite = (chunk: string): boolean => {
    if (closed) return false;
    try { res.write(chunk); return true; }
    catch { cleanup(); return false; }
  };
  const safeFlush = () => {
    if (closed) return;
    try { (res as unknown as { flush?: () => void }).flush?.(); } catch {}
  };
  const writeIndexed = (event: WebsiteSessionEvent, id: number): boolean => {
    if (!safeWrite(`id: ${id}\n`)) return false;
    if (!safeWrite(`data: ${JSON.stringify(event)}\n\n`)) return false;
    safeFlush();
    return true;
  };

  // Initial handshake — also through safeWrite so a dead-on-arrival socket
  // takes the same cleanup path as any other failure.
  if (!safeWrite(": connected\n\n")) return;
  if (!safeWrite(`data: ${JSON.stringify({ type: "init", sessionId: session.id, conversationId: session.conversationId, status: session.endedAt === null ? "running" : "done", nextEventId: session.nextEventId, baseEventId: session.baseEventId })}\n\n`)) return;
  safeFlush();

  heartbeat = setInterval(() => {
    if (closed) return;
    if (!safeWrite(": ping\n\n")) return;
    safeFlush();
  }, 5000);

  sub = (event: WebsiteSessionEvent, id: number) => {
    if (closed) return;
    if (!replayDone) { queued.push([event, id]); return; }
    if (!writeIndexed(event, id)) return;
    if (event.type === "done" || event.type === "error" || (event as { done?: boolean }).done === true) {
      cleanup();
    }
  };
  session.subscribers.add(sub);

  // Snapshot AFTER subscribe so any event emitted between the snapshot and
  // the first replay write is captured by `sub` into `queued` rather than
  // missed. Since JS is single-threaded, no emit() can interleave between
  // these two synchronous lines.
  const replayUpto = session.nextEventId;
  const desiredStart = Math.max(0, Math.floor(after));
  const startId = Math.max(desiredStart, session.baseEventId);
  for (let i = startId - session.baseEventId; i < session.events.length; i++) {
    if (closed) return;
    const absId = i + session.baseEventId;
    if (absId >= replayUpto) break;
    if (!writeIndexed(session.events[i]!, absId)) return;
  }

  // Flush anything that arrived during replay, deduped against the replay
  // window. If a terminal event landed in the queue we honour it.
  replayDone = true;
  for (const [ev, id] of queued) {
    if (id < replayUpto) continue; // already delivered via replay
    if (closed) return;
    if (!writeIndexed(ev, id)) return;
    if (ev.type === "done" || ev.type === "error" || (ev as { done?: boolean }).done === true) {
      cleanup();
      return;
    }
  }
  queued.length = 0;

  // If the session was already ended at attach time (and the terminal event
  // was inside the replayed window, not the queue), wrap up now.
  if (session.endedAt !== null) {
    cleanup();
  }
}
