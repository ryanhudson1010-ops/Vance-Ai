import app from "./app";
import { logger } from "./lib/logger";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

// ── Process-level resilience ───────────────────────────────────────────────
// Without these, ANY unhandled exception or rejected promise anywhere in the
// codebase (including inside the build runner, OpenAI streams, playwright,
// etc.) crashes the entire api-server.  When the user is not actively
// editing, a crashed server means Vance is just down — no chat, no memory,
// no avatar.  We log loudly and stay alive.  Real fatal errors (EADDRINUSE
// at boot, missing env) still exit because they happen synchronously before
// these handlers are wired up, which is what we want for fail-fast startup.
process.on("uncaughtException", (err) => {
  logger.error({ err }, "uncaughtException — keeping server alive");
});
process.on("unhandledRejection", (reason) => {
  logger.error({ err: reason }, "unhandledRejection — keeping server alive");
});

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
});
