import express, { type Express, type Request, type Response, type NextFunction } from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";

const SESSION_SECRET = process.env["SESSION_SECRET"];
if (!SESSION_SECRET) {
  throw new Error("SESSION_SECRET environment variable is required for signed auth cookies.");
}

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors({ credentials: true }));
app.use(cookieParser(SESSION_SECRET));
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

app.use("/api", router);

// ── Last-resort error handler ──────────────────────────────────────────────
// Catches anything a route handler threw or `next(err)`'d.  Without this,
// Express returns its default HTML error page (or hangs the response if the
// throw happened mid-stream), which on the frontend looks like the server
// went down.  We always respond with structured JSON so the frontend can
// recover gracefully instead of white-screening or showing parse errors.
// The four-arg signature is required for Express to recognise this as an
// error middleware.
app.use((err: unknown, req: Request, res: Response, _next: NextFunction) => {
  req.log?.error({ err }, "Unhandled route error");
  if (res.headersSent) {
    // Response was already streaming (SSE etc.) — just abort the socket.
    try { res.end(); } catch { /* noop */ }
    return;
  }
  const message = err instanceof Error ? err.message : String(err);
  res.status(500).json({ error: "Internal server error", message });
});

export default app;
