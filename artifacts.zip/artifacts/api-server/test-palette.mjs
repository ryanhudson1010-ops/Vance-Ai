import { build } from "esbuild";
import AdmZip from "adm-zip";
import { writeFileSync } from "fs";
import { pathToFileURL } from "url";
import path from "path";
const result = await build({
  entryPoints: ["./src/lib/website-template.ts"],
  bundle: true, format: "esm", platform: "node", target: "node22",
  write: false, external: ["adm-zip"],
});
const outPath = path.resolve("./test-bundle.mjs");
writeFileSync(outPath, result.outputFiles[0].text);
const mod = await import(pathToFileURL(outPath).href);

// CASE 1: no palette → defaults to neutral navy
const spec1 = mod.parseWebsiteSpec(JSON.stringify({
  businessName: "Acme Co", tagline: "We do stuff", multiPage: true,
  services: [{title:"S1", description:"d1"}],
}));
console.log("CASE 1 (no palette):", spec1?.palette);

// CASE 2: full palette
const spec2 = mod.parseWebsiteSpec(JSON.stringify({
  businessName: "Gun Shop", tagline: "Tactical gear", multiPage: true,
  palette: { primary: "#7f1d1d", secondary: "#1f2937", background: "#0a0a0a", accent: "#f59e0b" },
  services: [{title:"S1", description:"d1"}],
}));
console.log("CASE 2 (gun shop):", spec2?.palette);

// CASE 3: partial palette
const spec3 = mod.parseWebsiteSpec(JSON.stringify({
  businessName: "ATV Co", tagline: "Ride", multiPage: true,
  palette: { primary: "#ea580c" },
  services: [{title:"S1", description:"d1"}],
}));
console.log("CASE 3 (partial):", spec3?.palette);

// CASE 4: invalid hex → reject
const spec4 = mod.parseWebsiteSpec(JSON.stringify({
  businessName: "X", tagline: "y",
  palette: { primary: "red" },
}));
console.log("CASE 4 (invalid hex 'red'):", spec4 === null ? "REJECTED ✓" : `accepted: ${JSON.stringify(spec4.palette)}`);

// Build zip for case 2 and verify gunshop colors appear in HTML, navy default doesn't
const { buffer } = mod.buildWebsiteZip(spec2);
const zip = new AdmZip(buffer);
const idx = zip.getEntry("index.html").getData().toString("utf8");
console.log("\nCase 2 HTML checks:");
console.log("  primary #7f1d1d present:", idx.includes("#7f1d1d"));
console.log("  secondary #1f2937 present:", idx.includes("#1f2937"));
console.log("  background #0a0a0a present:", idx.includes("#0a0a0a"));
console.log("  default navy #1e3a8a NOT present:", !idx.includes("#1e3a8a"));
console.log("  body uses background style:", idx.includes('style="background:#0a0a0a'));

// Build zip for case 1 and verify default navy appears
const { buffer: buf1 } = mod.buildWebsiteZip(spec1);
const idx1 = new AdmZip(buf1).getEntry("index.html").getData().toString("utf8");
console.log("\nCase 1 HTML checks (default neutral):");
console.log("  default navy #1e3a8a present:", idx1.includes("#1e3a8a"));
console.log("  default gray #64748b present:", idx1.includes("#64748b"));
console.log("  white bg present:", idx1.includes("background:#ffffff"));
console.log("  REPLACE IMAGE comments:", (idx1.match(/REPLACE IMAGE/g) || []).length);
console.log("  sticky nav:", idx1.includes('class="sticky top-0'));
