import { build } from "esbuild";
import AdmZip from "adm-zip";
import { writeFileSync } from "fs";
import { pathToFileURL } from "url";
import path from "path";
const result = await build({
  entryPoints: ["./src/lib/website-template.ts"],
  bundle: true, format: "esm", platform: "node", target: "node22",
  write: false, external: ["adm-zip"],
});
const outPath = path.resolve("./test-bundle.mjs");
writeFileSync(outPath, result.outputFiles[0].text);
const mod = await import(pathToFileURL(outPath).href);

function check(name, cond) { console.log((cond?"  ✓ ":"  ✗ ")+name); if (!cond) process.exitCode = 1; }

// --- CASE A: Full new-shape spec (gun shop, tactical vibe) ---
const gunSpec = mod.parseWebsiteSpec(JSON.stringify({
  businessName: "Iron Sights Tactical",
  businessType: "Firearms Retail",
  tagline: "Precision gear for serious shooters",
  location: "Bozeman, MT",
  phone: "555-0101",
  email: "info@ironsights.example",
  vibe: "tactical and rugged",
  palette: { primary: "#2a2a2a", secondary: "#7f1d1d", accent: "#f59e0b", background: "#0a0a0a", text: "#f5f5f5" },
  sections: ["hero","services","about","contact"],
  services: [
    { name: "Rifles & Carbines", description: "AR platforms, bolt-actions, and modern sporting rifles", details: "From $499. Free background check on premises." },
    { name: "Optics & Mounts", description: "Red dots, LPVOs, and precision scopes", details: null },
    { name: "Ammunition", description: "Bulk and match-grade in common calibers" },
  ],
  aboutText: "Veteran-owned shop founded in 2014. We stock what we'd carry ourselves and we test every optic before it ships.",
  ctaText: "Shop Now",
  styleNotes: "Lean dark and serious — no playful elements.",
  multiPage: true,
}));
console.log("\nCASE A: gun shop spec parsed");
check("spec parsed", !!gunSpec);
check("businessType set", gunSpec?.businessType === "Firearms Retail");
check("vibe set", gunSpec?.vibe === "tactical and rugged");
check("palette.text honored", gunSpec?.palette.text === "#f5f5f5");
check("sections passes through", JSON.stringify(gunSpec?.sections) === JSON.stringify(["hero","services","about","contact"]));
check("ctaText -> cta", gunSpec?.cta === "Shop Now");
check("aboutText -> about.body", gunSpec?.about?.body?.startsWith("Veteran-owned"));
check("services[0].name -> title", gunSpec?.services[0].title === "Rifles & Carbines");
check("services[0].details preserved", gunSpec?.services[0].details?.startsWith("From $499"));
check("services[1].details null", gunSpec?.services[1].details === null);
check("services[2].details null when missing", gunSpec?.services[2].details === null);

const gunZip = mod.buildWebsiteZip(gunSpec);
console.log(`zip files: ${gunZip.fileCount}`);
const gunArc = new AdmZip(gunZip.buffer);
const idx = gunArc.getEntry("index.html").getData().toString("utf8");
check("body uses palette.text", idx.includes('color:#f5f5f5'));
check("body uses background", idx.includes('background:#0a0a0a'));
check("primary color present", idx.includes('#2a2a2a'));
check("Tailwind CDN present", idx.includes('cdn.tailwindcss.com'));
check("REPLACE IMAGE comment present", idx.includes('<!-- REPLACE IMAGE'));
check("businessType eyebrow rendered", idx.includes('Firearms Retail'));
check("location eyebrow rendered", idx.includes('Bozeman, MT'));
check("vibe → uppercase tracking on h1", idx.match(/<h1[^>]*uppercase tracking-wider/));
check("Vibe HTML comment", idx.includes('<!-- Vibe:'));
check("Style notes comment", idx.includes('Style notes from spec'));
check("ctaText reflected (Shop Now)", idx.includes('Shop Now'));
check("service details rendered", idx.includes('From $499'));
check("about.html present (sections includes about)", !!gunArc.getEntry("about.html"));
check("services.html present", !!gunArc.getEntry("services.html"));
check("contact.html present", !!gunArc.getEntry("contact.html"));

// --- CASE B: explicit `sections` excludes about/services pages ---
const minimalSpec = mod.parseWebsiteSpec(JSON.stringify({
  businessName: "Bare Bones Co",
  tagline: "Just contact us",
  sections: ["hero","contact"],
}));
console.log("\nCASE B: sections=[hero,contact] only");
check("multiPage default true", minimalSpec?.multiPage === true);
const minZip = mod.buildWebsiteZip(minimalSpec);
const minArc = new AdmZip(minZip.buffer);
check("index.html present", !!minArc.getEntry("index.html"));
check("contact.html present", !!minArc.getEntry("contact.html"));
check("about.html SKIPPED", !minArc.getEntry("about.html"));
check("services.html SKIPPED", !minArc.getEntry("services.html"));

// --- CASE C: legacy {title,description} services still work ---
const legacy = mod.parseWebsiteSpec(JSON.stringify({
  businessName: "Legacy Co",
  tagline: "Old shape",
  services: [{ title: "Old Service", description: "still parses" }],
  cta: "Contact Us",
  multiPage: false,
}));
console.log("\nCASE C: legacy backwards-compat");
check("legacy parses", !!legacy);
check("legacy title preserved", legacy?.services[0].title === "Old Service");
check("legacy cta preserved", legacy?.cta === "Contact Us");
check("legacy multiPage:false honored", legacy?.multiPage === false);
const legZip = mod.buildWebsiteZip(legacy);
console.log("  legacy zip files:", legZip.fileCount);
check("single-page output", legZip.fileCount === 2);

// --- CASE D: elegant vibe -> Playfair Display injection ---
const elegant = mod.parseWebsiteSpec(JSON.stringify({
  businessName: "Maison Lumière",
  tagline: "Refined dining since 1987",
  vibe: "elegant and refined",
  palette: { primary: "#7c2d12", secondary: "#451a03" },
}));
const elZip = mod.buildWebsiteZip(elegant);
const elIdx = new AdmZip(elZip.buffer).getEntry("index.html").getData().toString("utf8");
console.log("\nCASE D: elegant vibe → Playfair Display");
check("Playfair Display font link", elIdx.includes('Playfair+Display'));
check("h1/h2/h3 font-family override", elIdx.includes("h1, h2, h3 { font-family: 'Playfair Display'"));

// --- CASE E: missing palette → defaults ---
const def = mod.parseWebsiteSpec(JSON.stringify({
  businessName: "Defaulty",
  tagline: "no palette",
}));
console.log("\nCASE E: defaults");
check("default text", def?.palette.text === "#111827");
check("default bg", def?.palette.background === "#ffffff");
