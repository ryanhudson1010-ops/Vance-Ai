import { useState } from "react";
import { 
  Menu, Settings, Search, Mic, Paperclip, Send, 
  Plus, Trash2, Globe, FileImage, Sparkles, X,
  CheckCircle2, ChevronRight, MessageSquare
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";

export function Holographic() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [ttsOn, setTtsOn] = useState(true);
  const [webSearchOn, setWebSearchOn] = useState(true);
  const [height, setHeight] = useState([42]);
  const [isSpeaking, setIsSpeaking] = useState(false);
  
  return (
    <div className="w-[1280px] h-[900px] flex flex-col font-['Space_Grotesk'] text-slate-300 relative overflow-hidden bg-[#05060B]">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;700&family=Space+Grotesk:wght@400;500;600;700&display=swap');
        
        .holo-grid {
          background-size: 40px 40px;
          background-image: 
            linear-gradient(to right, rgba(34, 211, 238, 0.05) 1px, transparent 1px),
            linear-gradient(to bottom, rgba(34, 211, 238, 0.05) 1px, transparent 1px);
        }
        
        .scanlines {
          background: linear-gradient(
            to bottom,
            rgba(255,255,255,0),
            rgba(255,255,255,0) 50%,
            rgba(34, 211, 238, 0.05) 50%,
            rgba(34, 211, 238, 0.05)
          );
          background-size: 100% 4px;
          animation: scanlines 10s linear infinite;
        }
        
        @keyframes scanlines {
          0% { background-position: 0 0; }
          100% { background-position: 0 100vh; }
        }

        @keyframes rotate-slow {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        
        @keyframes rotate-slow-reverse {
          0% { transform: rotate(360deg); }
          100% { transform: rotate(0deg); }
        }

        @keyframes waveform {
          0%, 100% { transform: scale(1); opacity: 0.8; }
          50% { transform: scale(1.15); opacity: 0; }
        }

        .neon-border {
          border: 1px solid rgba(34, 211, 238, 0.3);
          box-shadow: 0 0 10px rgba(34, 211, 238, 0.1), inset 0 0 10px rgba(34, 211, 238, 0.05);
        }
        
        .neon-border-magenta {
          border: 1px solid rgba(232, 121, 249, 0.3);
          box-shadow: 0 0 10px rgba(232, 121, 249, 0.1), inset 0 0 10px rgba(232, 121, 249, 0.05);
        }

        .neon-text-cyan {
          color: #22d3ee;
          text-shadow: 0 0 8px rgba(34, 211, 238, 0.6);
        }
        
        .neon-text-magenta {
          color: #e879f9;
          text-shadow: 0 0 8px rgba(232, 121, 249, 0.6);
        }

        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
      `}</style>
      
      {/* Background Ambience */}
      <div className="absolute inset-0 holo-grid pointer-events-none z-0" />
      <div className="absolute inset-0 scanlines pointer-events-none z-0 opacity-50" />
      
      {/* Top Bar */}
      <header className="h-[56px] shrink-0 border-b border-cyan-500/20 bg-[#05060B]/80 backdrop-blur-md flex items-center justify-between px-4 z-10 relative">
        <div className="flex items-center gap-3">
          <Button 
            variant="ghost" 
            size="icon" 
            className="text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/10"
            onClick={() => setSidebarOpen(!sidebarOpen)}
          >
            <Menu className="w-5 h-5" />
          </Button>
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-magenta-400" />
            <span className="font-['JetBrains_Mono'] font-bold text-lg tracking-widest neon-text-cyan">VANCE</span>
            <div className="flex items-center gap-1.5 ml-2 bg-slate-900/80 px-2 py-1 rounded neon-border">
              <div className="w-2 h-2 rounded-full bg-green-400 shadow-[0_0_8px_rgba(74,222,128,0.8)] animate-pulse" />
              <span className="text-[10px] font-['JetBrains_Mono'] tracking-widest text-green-400">ONLINE</span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 bg-slate-900/60 p-1 rounded border border-cyan-500/20">
            <button 
              onClick={() => setTtsOn(!ttsOn)}
              className={`px-3 py-1.5 rounded text-xs font-['JetBrains_Mono'] tracking-widest transition-all ${ttsOn ? 'bg-cyan-500/20 text-cyan-400 neon-border' : 'text-slate-500 hover:text-slate-300'}`}
            >
              TTS • {ttsOn ? 'ON' : 'OFF'}
            </button>
            <div className="h-4 w-px bg-cyan-500/20" />
            <select defaultValue="coral" className="bg-transparent text-xs font-['JetBrains_Mono'] tracking-widest text-magenta-400 outline-none cursor-pointer appearance-none px-2">
              <option value="alloy">VOICE • ALLOY</option>
              <option value="ash">VOICE • ASH</option>
              <option value="sage">VOICE • SAGE</option>
              <option value="coral">VOICE • CORAL</option>
              <option value="verse">VOICE • VERSE</option>
            </select>
          </div>
          
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setWebSearchOn(!webSearchOn)}
            className={`transition-all ${webSearchOn ? 'text-cyan-400 bg-cyan-500/10 neon-border' : 'text-slate-500'}`}
          >
            <Globe className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="icon" className="text-cyan-500 hover:bg-cyan-500/10">
            <Settings className="w-4 h-4" />
          </Button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden relative z-10">
        {/* Sidebar */}
        {sidebarOpen && (
          <aside className="w-[300px] shrink-0 border-r border-cyan-500/20 bg-[#05060B]/90 backdrop-blur flex flex-col">
            <div className="p-4">
              <Button className="w-full bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 font-['JetBrains_Mono'] tracking-widest text-xs flex items-center justify-start gap-2 shadow-[0_0_15px_rgba(34,211,238,0.1)]">
                <Plus className="w-4 h-4" />
                NEW TERMINAL
              </Button>
            </div>
            
            <div className="flex-1 overflow-y-auto scrollbar-hide px-3 pb-4 flex flex-col gap-1">
              <div className="text-[10px] font-['JetBrains_Mono'] text-cyan-500/50 mb-2 px-2 uppercase tracking-widest">Memory Banks</div>
              {[
                { title: "React context bug hunt", date: "2H AGO" },
                { title: "Puppy name ideas", date: "YESTERDAY" },
                { title: "Spacing review feedback", date: "TUESDAY" },
                { title: "Comebacks for 'must be nice'", date: "LAST WEEK" },
              ].map((chat, i) => (
                <div key={i} className="group flex items-center justify-between p-2 rounded cursor-pointer hover:bg-cyan-500/10 border border-transparent hover:border-cyan-500/20 transition-all">
                  <div className="flex items-center gap-2 overflow-hidden">
                    <MessageSquare className="w-3.5 h-3.5 text-cyan-600 shrink-0" />
                    <div className="truncate">
                      <div className="text-sm text-slate-300 truncate">{chat.title}</div>
                      <div className="text-[10px] font-['JetBrains_Mono'] text-cyan-600 mt-0.5">{chat.date}</div>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" className="h-6 w-6 opacity-0 group-hover:opacity-100 text-magenta-500 hover:bg-magenta-500/20">
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              ))}
            </div>
          </aside>
        )}

        {/* Main Content */}
        <main className="flex-1 flex flex-col relative overflow-hidden">
          
          {/* Mobile Slider Panel */}
          <div className="absolute top-4 right-4 bg-slate-900/80 backdrop-blur-md p-3 rounded-lg neon-border flex flex-col gap-2 z-20 w-48">
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-['JetBrains_Mono'] text-cyan-400 tracking-widest">CONV HEIGHT</span>
              <span className="text-[10px] font-['JetBrains_Mono'] bg-cyan-500/20 text-cyan-300 px-1.5 py-0.5 rounded">{height}%</span>
            </div>
            <Slider 
              defaultValue={[42]} 
              max={100} 
              step={1} 
              onValueChange={setHeight}
              className="[&_[role=slider]]:bg-cyan-400 [&_[role=slider]]:border-cyan-400 [&_.bg-primary]:bg-cyan-500"
            />
          </div>

          {/* Avatar Stage */}
          <div className="relative shrink-0 flex items-center justify-center border-b border-cyan-500/10 bg-transparent" style={{ height: `${height}%` }}>
            {/* Emote Picker */}
            <div className="absolute top-4 left-4 flex items-center gap-1.5">
              {['👋', '🙅', '👍', '😎', '🤔', '😅', '💪', '🎉'].map((emoji, i) => (
                <button key={i} className="w-8 h-8 flex items-center justify-center hover:bg-cyan-500/20 rounded text-lg transition-colors border border-transparent hover:border-cyan-500/30">
                  {emoji}
                </button>
              ))}
            </div>
            
            {/* Holographic Avatar */}
            <div className="relative w-40 h-40 flex items-center justify-center cursor-pointer" onClick={() => setIsSpeaking(!isSpeaking)}>
              {/* Speaking Ring */}
              {isSpeaking && (
                <div className="absolute inset-[-10%] rounded-full border-2 border-cyan-400 shadow-[0_0_15px_rgba(34,211,238,0.8)]" style={{ animation: 'waveform 2s ease-out infinite' }} />
              )}
              
              {/* Core Avatar Sphere */}
              <div className="absolute inset-4 rounded-full bg-slate-900 overflow-hidden flex items-center justify-center border border-cyan-500/50 shadow-[0_0_10px_rgba(34,211,238,0.2)]">
                <Sparkles className="w-10 h-10 text-cyan-300 drop-shadow-[0_0_10px_rgba(34,211,238,0.8)] animate-pulse" />
              </div>
            </div>
            
            <div className="absolute bottom-4 font-['JetBrains_Mono'] text-[10px] tracking-[0.2em] text-cyan-500/50 uppercase">
              System Active • {isSpeaking ? 'Speaking' : 'Processing'}
            </div>
          </div>

          {/* Transcript */}
          <div className="flex-1 overflow-y-auto p-6 flex flex-col gap-6 scrollbar-hide">
            
            <div className="flex justify-end">
              <div className="max-w-[70%] neon-border bg-cyan-950/30 text-cyan-50 px-4 py-3 rounded-2xl rounded-tr-sm shadow-[0_4px_20px_rgba(34,211,238,0.05)]">
                What's a good comeback when someone says 'must be nice'?
              </div>
            </div>

            <div className="flex justify-start">
              <div className="max-w-[70%] neon-border-magenta bg-magenta-950/20 text-slate-200 px-4 py-3 rounded-2xl rounded-tl-sm shadow-[0_4px_20px_rgba(232,121,249,0.05)]">
                Ooh, the classic passive-aggressive 'must be nice'. Depends on the vibe you want to set. Here are a few angles:<br/><br/>
                <ul className="list-disc pl-5 mt-2 space-y-1 text-magenta-100/90">
                  <li><span className="font-bold text-magenta-300">The Agreement:</span> "It really is! I'm super grateful." (Kills their negativity with pure sunshine)</li>
                  <li><span className="font-bold text-magenta-300">The Hard Truth:</span> "It's not bad, but the 60-hour work weeks to get here were less fun."</li>
                  <li><span className="font-bold text-magenta-300">The Deflection:</span> "Right? Anyway, how have you been?"</li>
                </ul>
              </div>
            </div>

            <div className="flex justify-end">
              <div className="flex flex-col items-end gap-2 max-w-[70%]">
                <div className="relative group rounded-lg overflow-hidden neon-border w-48 h-32 bg-slate-800">
                  <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/20 to-magenta-500/20" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <FileImage className="w-8 h-8 text-cyan-500/50" />
                  </div>
                </div>
                <div className="neon-border bg-cyan-950/30 text-cyan-50 px-4 py-3 rounded-2xl rounded-tr-sm shadow-[0_4px_20px_rgba(34,211,238,0.05)]">
                  Look at this screenshot — does the spacing feel off?
                </div>
              </div>
            </div>

            <div className="flex justify-start">
              <div className="max-w-[70%] flex flex-col gap-3">
                <div className="neon-border-magenta bg-magenta-950/20 text-slate-200 px-4 py-3 rounded-2xl rounded-tl-sm">
                  Yeah, I see it. The padding between the header and the main card is way too tight compared to the generous margins on the sides. Let me spin up a fix for that component.
                </div>
                
                <div className="neon-border bg-slate-900/80 rounded-xl p-4 flex flex-col gap-3">
                  <div className="flex items-center gap-2 text-cyan-400 font-['JetBrains_Mono'] text-xs">
                    <Sparkles className="w-4 h-4" />
                    <span>BUILD PROGRESS</span>
                  </div>
                  <div className="font-['JetBrains_Mono'] text-[10px] text-slate-400 flex flex-col gap-1">
                    <div className="flex items-center gap-2"><CheckCircle2 className="w-3 h-3 text-green-400" /> Analyzing Layout.tsx</div>
                    <div className="flex items-center gap-2"><CheckCircle2 className="w-3 h-3 text-green-400" /> Adjusting top padding to pt-12</div>
                    <div className="flex items-center gap-2"><CheckCircle2 className="w-3 h-3 text-green-400" /> Normalizing side margins</div>
                    <div className="flex items-center gap-2 text-cyan-300 animate-pulse"><ChevronRight className="w-3 h-3" /> Rendering preview...</div>
                  </div>
                  <button className="text-xs text-magenta-400 hover:text-magenta-300 font-medium self-start mt-1 flex items-center gap-1">
                    View screenshots <ChevronRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>

            <div className="flex justify-start pb-4">
              <div className="max-w-[70%] flex flex-col gap-3">
                <div className="neon-border-magenta bg-magenta-950/20 text-slate-200 px-4 py-3 rounded-2xl rounded-tl-sm">
                  Alright, I've adjusted the spacing. The layout breathes much better now. Want me to apply this edit?
                </div>
                
                <div className="neon-border bg-slate-900/80 rounded-xl p-4 flex flex-col gap-4">
                  <div className="flex items-center justify-between">
                    <div className="text-sm font-medium text-slate-200">Propose edit</div>
                    <div className="text-xs font-['JetBrains_Mono'] text-slate-500">Layout.tsx</div>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Button size="sm" className="bg-cyan-500 text-slate-950 hover:bg-cyan-400 font-bold">Accept</Button>
                    <Button size="sm" variant="outline" className="border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10">Edit</Button>
                    <Button size="sm" variant="ghost" className="text-slate-400 hover:text-red-400">Cancel</Button>
                  </div>
                </div>
              </div>
            </div>

          </div>

          {/* Composer */}
          <div className="h-[110px] shrink-0 p-4 border-t border-cyan-500/20 bg-[#05060B]/90 backdrop-blur z-20 flex flex-col gap-2 relative">
            <div className="absolute -top-10 left-4">
              <div className="inline-flex items-center gap-1.5 bg-slate-800 border border-cyan-500/30 px-3 py-1.5 rounded-full shadow-lg">
                <FileImage className="w-3.5 h-3.5 text-cyan-400" />
                <span className="text-xs font-['JetBrains_Mono'] text-cyan-100">hero.png</span>
                <button className="hover:bg-slate-700 rounded-full p-0.5 ml-1"><X className="w-3 h-3 text-slate-400" /></button>
              </div>
            </div>
            
            <div className="flex-1 flex items-end gap-2 bg-slate-900/50 neon-border rounded-xl p-2 focus-within:border-cyan-400/50 focus-within:shadow-[0_0_15px_rgba(34,211,238,0.2)] transition-all">
              <div className="flex items-center gap-1 pb-1">
                <Button variant="ghost" size="icon" className="w-8 h-8 text-cyan-500/70 hover:text-cyan-400 hover:bg-cyan-500/10">
                  <Paperclip className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" className={`w-8 h-8 ${webSearchOn ? 'text-cyan-400 bg-cyan-500/10' : 'text-cyan-500/70 hover:text-cyan-400 hover:bg-cyan-500/10'}`}>
                  <Globe className="w-4 h-4" />
                </Button>
              </div>
              
              <textarea 
                className="flex-1 max-h-20 min-h-[40px] bg-transparent resize-none outline-none text-slate-200 placeholder:text-slate-600 py-2 px-2 scrollbar-hide text-sm"
                placeholder="Message Vance..."
                defaultValue=""
              />
              
              <div className="flex items-center gap-2 pb-1 pr-1">
                <Button variant="ghost" size="icon" className="w-8 h-8 text-magenta-400 hover:text-magenta-300 hover:bg-magenta-500/10">
                  <Mic className="w-4 h-4" />
                </Button>
                <Button size="icon" className="w-8 h-8 bg-cyan-500 text-slate-950 hover:bg-cyan-400 shadow-[0_0_10px_rgba(34,211,238,0.4)]">
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
