import { useState } from "react";
import { 
  Menu, Settings, Search, Mic, Paperclip, Send, X, Trash2, Globe, Volume2, Plus, SlidersHorizontal, Check, PenSquare
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";

export function Editorial() {
  const [sidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div className="w-[1280px] h-[900px] flex flex-col font-['Inter',sans-serif] bg-[#F5F2EC] text-[#1A1816] overflow-hidden selection:bg-[#C2845A] selection:text-white relative">
      <style dangerouslySetInnerHTML={{
        __html: `
          @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,400&family=Inter:wght@300;400;500;600&display=swap');
          
          .scrollbar-hide::-webkit-scrollbar {
              display: none;
          }
          .scrollbar-hide {
              -ms-overflow-style: none;
              scrollbar-width: none;
          }
        `
      }} />

      {/* Top Bar */}
      <header className="flex-none h-[56px] px-6 border-b border-[#1A1816]/10 flex items-center justify-between shrink-0 bg-transparent">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="text-[#1A1816]/60 hover:text-[#1A1816] transition-colors"
          >
            <Menu className="w-5 h-5 stroke-[1.5]" />
          </button>
          <div className="text-xl font-['Cormorant_Garamond'] font-semibold italic tracking-wide">
            Vance
          </div>
        </div>
        
        <div className="flex items-center gap-5 text-sm">
          <button className="flex items-center gap-2 text-[#1A1816]/60 hover:text-[#1A1816] transition-colors">
            <Volume2 className="w-4 h-4 stroke-[1.5]" />
            <span className="font-light">TTS On</span>
          </button>
          
          <select className="bg-transparent border-none outline-none font-light text-[#1A1816]/60 hover:text-[#1A1816] cursor-pointer appearance-none text-center">
            <option>alloy</option>
            <option>ash</option>
            <option>sage</option>
            <option>coral</option>
            <option>verse</option>
          </select>
          
          <button className="flex items-center gap-2 text-[#C2845A] transition-colors group">
            <Globe className="w-4 h-4 stroke-[1.5] group-hover:opacity-80" />
            <span className="font-light">Search On</span>
          </button>

          <button className="text-[#1A1816]/60 hover:text-[#1A1816] transition-colors ml-2">
            <Settings className="w-4 h-4 stroke-[1.5]" />
          </button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Left Sidebar */}
        {sidebarOpen && (
          <aside className="w-[300px] border-r border-[#1A1816]/10 flex flex-col shrink-0">
            <div className="p-6 pb-2">
              <button className="w-full flex items-center gap-3 text-left group">
                <div className="w-8 h-8 rounded-full border border-[#1A1816]/20 flex items-center justify-center group-hover:border-[#C2845A] group-hover:text-[#C2845A] transition-colors">
                  <Plus className="w-4 h-4 stroke-[1.5]" />
                </div>
                <span className="font-light text-[15px] group-hover:text-[#C2845A] transition-colors">New interaction</span>
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto scrollbar-hide p-6 space-y-8">
              <div>
                <div className="text-xs font-['Cormorant_Garamond'] uppercase tracking-widest text-[#1A1816]/40 mb-4">Today</div>
                <ul className="space-y-1">
                  <li className="group flex items-center justify-between py-2 text-[14px] font-light text-[#1A1816]/80 cursor-pointer hover:text-[#C2845A] transition-colors">
                    <div className="flex items-center gap-3 truncate">
                      <span className="w-1 h-1 rounded-full bg-[#C2845A]"></span>
                      <span className="truncate">Design feedback on hero section</span>
                    </div>
                    <Trash2 className="w-3.5 h-3.5 stroke-[1.5] opacity-0 group-hover:opacity-100 text-red-900/40 hover:text-red-900 transition-all shrink-0" />
                  </li>
                  <li className="group flex items-center justify-between py-2 text-[14px] font-light text-[#1A1816]/60 cursor-pointer hover:text-[#C2845A] transition-colors">
                    <div className="flex items-center gap-3 truncate">
                      <span className="w-1 h-1 rounded-full bg-transparent"></span>
                      <span className="truncate">Brainstorming comeback lines</span>
                    </div>
                    <Trash2 className="w-3.5 h-3.5 stroke-[1.5] opacity-0 group-hover:opacity-100 text-red-900/40 hover:text-red-900 transition-all shrink-0" />
                  </li>
                </ul>
              </div>
              
              <div>
                <div className="text-xs font-['Cormorant_Garamond'] uppercase tracking-widest text-[#1A1816]/40 mb-4">Yesterday</div>
                <ul className="space-y-1">
                  <li className="group flex items-center justify-between py-2 text-[14px] font-light text-[#1A1816]/60 cursor-pointer hover:text-[#C2845A] transition-colors">
                    <div className="flex items-center gap-3 truncate">
                      <span className="w-1 h-1 rounded-full bg-transparent"></span>
                      <span className="truncate">Puppy name ideas</span>
                    </div>
                    <Trash2 className="w-3.5 h-3.5 stroke-[1.5] opacity-0 group-hover:opacity-100 text-red-900/40 hover:text-red-900 transition-all shrink-0" />
                  </li>
                  <li className="group flex items-center justify-between py-2 text-[14px] font-light text-[#1A1816]/60 cursor-pointer hover:text-[#C2845A] transition-colors">
                    <div className="flex items-center gap-3 truncate">
                      <span className="w-1 h-1 rounded-full bg-transparent"></span>
                      <span className="truncate">Refactoring the auth flow</span>
                    </div>
                    <Trash2 className="w-3.5 h-3.5 stroke-[1.5] opacity-0 group-hover:opacity-100 text-red-900/40 hover:text-red-900 transition-all shrink-0" />
                  </li>
                </ul>
              </div>
            </div>
          </aside>
        )}

        {/* Main Area */}
        <main className="flex-1 flex flex-col relative min-w-0">
          
          {/* Mobile slider panel (Floating top right) */}
          <div className="absolute top-6 right-6 flex items-center gap-3 px-4 py-2 border border-[#1A1816]/10 rounded-full bg-[#F5F2EC] z-20">
            <span className="text-xs font-light text-[#1A1816]/60 uppercase tracking-wide">Conv. Height</span>
            <div className="w-24">
              <Slider defaultValue={[42]} max={100} step={1} className="[&_[role=slider]]:h-3 [&_[role=slider]]:w-3 [&_[role=slider]]:border-[#C2845A] [&_[role=slider]]:bg-[#F5F2EC] [&_.bg-primary]:bg-[#1A1816]/10 [&_.bg-primary/20]:bg-[#1A1816]/5" />
            </div>
            <span className="text-xs font-medium text-[#1A1816]/80">42%</span>
          </div>

          <div className="flex-1 flex flex-col h-full max-w-3xl mx-auto w-full">
            
            {/* Avatar Stage */}
            <div className="h-[38%] flex flex-col items-center justify-center relative shrink-0">
              <div className="absolute top-8 left-0 flex gap-2">
                {['👋', '🙅', '👍', '😎', '🤔', '😅', '💪', '🎉'].map((emoji, i) => (
                  <button key={i} className="w-8 h-8 rounded-full flex items-center justify-center text-sm border border-[#1A1816]/10 hover:border-[#C2845A] hover:bg-[#C2845A]/5 transition-colors grayscale hover:grayscale-0 opacity-60 hover:opacity-100">
                    {emoji}
                  </button>
                ))}
              </div>
              
              <div className="relative">
                {/* Portrait */}
                <div className="relative w-32 h-32 rounded-full bg-[#1A1816]/5 flex items-center justify-center overflow-hidden border border-[#1A1816]/10">
                  <div className="absolute inset-0 opacity-20 mix-blend-overlay" style={{ backgroundImage: 'radial-gradient(#1A1816 1px, transparent 1px)', backgroundSize: '4px 4px' }} />
                  <div className="w-20 h-20 bg-[#1A1816]/10 rounded-full relative z-10" />
                </div>
                
                {/* Speaking waveform ring - Hairline amber for Editorial */}
                <div className="absolute -inset-[2px] border border-[#C2845A] rounded-full animate-pulse pointer-events-none" style={{ animationDuration: '2s' }} />
              </div>
              
              <div className="mt-6 text-sm font-['Cormorant_Garamond'] italic text-[#1A1816]/60">
                Listening...
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto scrollbar-hide px-4 pb-8 space-y-12">
              
              {/* User message */}
              <div className="flex flex-col items-end gap-2">
                <span className="text-xs font-['Cormorant_Garamond'] italic text-[#1A1816]/40 mr-1">You</span>
                <div className="max-w-[80%] text-[15px] leading-relaxed font-light text-[#1A1816] px-6 py-4 border border-[#1A1816]/10 rounded-2xl rounded-tr-sm bg-white/40">
                  What's a good comeback when someone says 'must be nice'?
                </div>
              </div>

              {/* Vance message */}
              <div className="flex flex-col items-start gap-2">
                <span className="text-xs font-['Cormorant_Garamond'] italic text-[#C2845A] ml-1">Vance</span>
                <div className="max-w-[80%] text-[15px] leading-relaxed font-light text-[#1A1816] pr-6">
                  Ah, the classic passive-aggressive 'must be nice'. Here are a few ways to handle it, depending on the vibe you want to set:
                  <ul className="mt-4 space-y-2 list-none">
                    <li className="flex gap-3"><span className="text-[#C2845A]">·</span> <strong>The Earnest Deflection:</strong> "It is! I'm really grateful it worked out." (Kills the passive-aggression with genuine positivity).</li>
                    <li className="flex gap-3"><span className="text-[#C2845A]">·</span> <strong>The Hard-Work Reminder:</strong> "It definitely took a lot of effort to get here." (A gentle reminder that luck wasn't the only factor).</li>
                    <li className="flex gap-3"><span className="text-[#C2845A]">·</span> <strong>The Pivot:</strong> "Thanks! How are things going with your [project/life event]?" (Moves the spotlight off you entirely).</li>
                  </ul>
                </div>
              </div>

              {/* User message with image */}
              <div className="flex flex-col items-end gap-2">
                <span className="text-xs font-['Cormorant_Garamond'] italic text-[#1A1816]/40 mr-1">You</span>
                <div className="max-w-[80%] flex flex-col items-end gap-3">
                  <div className="w-48 h-32 bg-[#1A1816]/5 border border-[#1A1816]/10 rounded-xl overflow-hidden relative">
                    <div className="absolute inset-0 bg-gradient-to-br from-[#1A1816]/5 to-[#1A1816]/10" />
                    <div className="absolute inset-0 flex items-center justify-center text-[#1A1816]/20">
                      <span className="text-xs uppercase tracking-widest font-['Cormorant_Garamond']">hero_v2.png</span>
                    </div>
                  </div>
                  <div className="text-[15px] leading-relaxed font-light text-[#1A1816] px-6 py-4 border border-[#1A1816]/10 rounded-2xl rounded-tr-sm bg-white/40">
                    Look at this screenshot — does the spacing feel off?
                  </div>
                </div>
              </div>

              {/* Vance message with Build Progress */}
              <div className="flex flex-col items-start gap-2">
                <span className="text-xs font-['Cormorant_Garamond'] italic text-[#C2845A] ml-1">Vance</span>
                <div className="max-w-[80%] text-[15px] leading-relaxed font-light text-[#1A1816] pr-6">
                  Good eye. The hero headline is crowded against the top navigation, and the CTA button needs more breathing room below the subheadline. I'll adjust the padding.
                  
                  <div className="mt-6 border border-[#1A1816]/10 rounded-xl p-5 bg-white/40">
                    <div className="flex items-center gap-3 mb-4 text-[#1A1816]/60">
                      <div className="w-4 h-4 rounded-full border border-t-[#C2845A] animate-spin" />
                      <span className="text-sm font-medium tracking-wide">Building changes...</span>
                    </div>
                    <div className="space-y-2 text-sm font-light text-[#1A1816]/70 mb-4">
                      <div className="flex items-center gap-2"><Check className="w-3.5 h-3.5 text-[#C2845A]" /> Increasing top padding on hero container to pt-24</div>
                      <div className="flex items-center gap-2"><Check className="w-3.5 h-3.5 text-[#C2845A]" /> Adding mb-8 to subheadline</div>
                      <div className="flex items-center gap-2"><Check className="w-3.5 h-3.5 text-[#C2845A]" /> Adjusting line-height on primary heading</div>
                      <div className="flex items-center gap-2 opacity-50"><div className="w-3.5 h-3.5" /> Recompiling assets...</div>
                    </div>
                    <button className="text-sm text-[#C2845A] hover:text-[#1A1816] transition-colors underline underline-offset-4 decoration-[#C2845A]/30">
                      View screenshots
                    </button>
                  </div>
                </div>
              </div>

              {/* Vance message with Proposal */}
              <div className="flex flex-col items-start gap-2">
                <span className="text-xs font-['Cormorant_Garamond'] italic text-[#C2845A] ml-1">Vance</span>
                <div className="w-full max-w-[80%] text-[15px] leading-relaxed font-light text-[#1A1816] pr-6">
                  Alright, I've got a proposal ready. The breathing room makes a huge difference—it feels much more intentional now. Shall we apply this?
                  
                  <div className="mt-6 border border-[#C2845A]/20 rounded-xl p-5 bg-white/60">
                    <div className="flex items-center gap-2 mb-2 text-[#C2845A]">
                      <PenSquare className="w-4 h-4" />
                      <span className="text-sm font-medium">Hero Layout Adjustments</span>
                    </div>
                    <p className="text-sm font-light text-[#1A1816]/70 mb-6">
                      Modified padding and margin utilities in Landing.tsx to improve spatial harmony in the hero section.
                    </p>
                    
                    <div className="flex items-center gap-3">
                      <button className="px-5 py-2 bg-[#C2845A] text-white text-sm font-medium rounded-lg hover:bg-[#1A1816] transition-colors shadow-sm shadow-[#C2845A]/20">
                        Accept
                      </button>
                      <button className="px-5 py-2 border border-[#1A1816]/10 text-[#1A1816] text-sm font-medium rounded-lg hover:border-[#1A1816]/30 transition-colors">
                        Edit
                      </button>
                      <button className="px-5 py-2 text-[#1A1816]/50 text-sm font-medium hover:text-[#1A1816] transition-colors">
                        Cancel
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="h-4" />
            </div>

            {/* Composer */}
            <div className="h-[110px] px-4 pb-6 shrink-0 relative">
              <div className="absolute -top-10 left-6">
                <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-white border border-[#1A1816]/10 rounded-full text-xs font-light shadow-sm">
                  <span className="truncate max-w-[100px] text-[#1A1816]/70">hero.png</span>
                  <button className="text-[#1A1816]/40 hover:text-[#1A1816]">
                    <X className="w-3 h-3" />
                  </button>
                </div>
              </div>
              
              <div className="h-full bg-white border border-[#1A1816]/10 shadow-[0_4px_24px_-8px_rgba(26,24,22,0.05)] rounded-2xl flex flex-col overflow-hidden focus-within:border-[#C2845A]/40 transition-colors">
                <Textarea 
                  placeholder="Message Vance..." 
                  className="flex-1 resize-none border-none bg-transparent shadow-none focus-visible:ring-0 p-4 text-[15px] font-light placeholder:text-[#1A1816]/30 rounded-none h-[60px]"
                />
                
                <div className="flex items-center justify-between px-3 pb-3">
                  <div className="flex items-center gap-1">
                    <button className="p-2 text-[#1A1816]/40 hover:text-[#1A1816] transition-colors rounded-lg hover:bg-[#1A1816]/5">
                      <Paperclip className="w-4 h-4 stroke-[1.5]" />
                    </button>
                    <button className="p-2 text-[#1A1816]/40 hover:text-[#1A1816] transition-colors rounded-lg hover:bg-[#1A1816]/5">
                      <Mic className="w-4 h-4 stroke-[1.5]" />
                    </button>
                    <div className="w-px h-4 bg-[#1A1816]/10 mx-1" />
                    <button className="p-2 text-[#C2845A] hover:bg-[#C2845A]/10 transition-colors rounded-lg relative">
                      <Globe className="w-4 h-4 stroke-[1.5]" />
                      <span className="absolute top-2 right-2 w-1.5 h-1.5 bg-[#C2845A] rounded-full border border-white" />
                    </button>
                  </div>
                  
                  <button className="w-8 h-8 bg-[#C2845A] text-white rounded-full flex items-center justify-center hover:bg-[#1A1816] transition-colors shadow-sm shadow-[#C2845A]/20 group">
                    <Send className="w-4 h-4 stroke-[1.5] group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                  </button>
                </div>
              </div>
            </div>

          </div>
        </main>
      </div>
    </div>
  );
}
