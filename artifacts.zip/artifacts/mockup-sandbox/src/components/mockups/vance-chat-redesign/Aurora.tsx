import { 
  Menu, Settings, Globe, Volume2, Plus, Trash2, 
  Paperclip, Mic, ArrowUp, X, Check, FileCode2,
  ChevronDown
} from "lucide-react";
import { useState } from "react";

export function Aurora() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [webSearchEnabled, setWebSearchEnabled] = useState(false);
  const [ttsEnabled, setTtsEnabled] = useState(true);
  
  return (
    <div className="w-full h-[100dvh] md:w-[1280px] md:h-[900px] flex flex-col font-sans overflow-hidden text-white relative bg-[#0a0a16] mx-auto">
      {/* Aurora Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-[20%] -left-[10%] w-[60%] h-[60%] rounded-full bg-violet-600/30 blur-[120px] mix-blend-screen" />
        <div className="absolute top-[20%] -right-[10%] w-[50%] h-[70%] rounded-full bg-teal-500/20 blur-[150px] mix-blend-screen" />
        <div className="absolute -bottom-[20%] left-[20%] w-[40%] h-[50%] rounded-full bg-indigo-500/30 blur-[120px] mix-blend-screen" />
      </div>

      <div className="flex h-full relative z-10">
        {/* Mobile Sidebar Overlay */}
        {sidebarOpen && (
          <div 
            className="fixed inset-0 bg-black/50 z-40 md:hidden backdrop-blur-sm"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Left Sidebar */}
        <div 
          className={`fixed md:relative z-50 h-full flex flex-col transition-all duration-300 ease-in-out border-r border-white/10 bg-[#0a0a16]/90 md:bg-white/[0.02] backdrop-blur-2xl ${
            sidebarOpen ? "w-[300px] translate-x-0 opacity-100" : "-translate-x-full md:translate-x-0 w-0 opacity-0 overflow-hidden border-none"
          } md:translate-x-0`}
        >
          <div className="p-4 flex items-center justify-between md:block">
            <button className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-sm font-medium transition-all shadow-[inset_0_1px_0_rgba(255,255,255,0.1)]">
              <Plus className="w-4 h-4" />
              New chat
            </button>
            <button className="p-2 md:hidden ml-2" onClick={() => setSidebarOpen(false)}>
              <X className="w-5 h-5 text-white/50" />
            </button>
          </div>
          
          <div className="flex-1 overflow-y-auto px-2 pb-4 space-y-1 scrollbar-hide">
            <div className="px-3 py-2 text-xs font-medium text-white/40 uppercase tracking-wider">Today</div>
            
            <SidebarItem title="What's a good comeback..." active />
            <SidebarItem title="Help me name my puppy" />
            
            <div className="px-3 py-2 mt-4 text-xs font-medium text-white/40 uppercase tracking-wider">Yesterday</div>
            
            <SidebarItem title="Fixing the navigation bug" />
            <SidebarItem title="Recipe for sourdough" />
            <SidebarItem title="Explain quantum computing" />
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col min-w-0 relative">
          {/* Top Bar */}
          <header className="h-[56px] flex items-center justify-between px-3 md:px-4 border-b border-white/5 bg-white/[0.01] backdrop-blur-xl relative z-20">
            <div className="flex items-center gap-2 md:gap-3">
              <button 
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="p-2 rounded-full hover:bg-white/10 text-white/70 hover:text-white transition-colors"
              >
                <Menu className="w-5 h-5 md:w-5 md:h-5" />
              </button>
              <div className="font-semibold text-base md:text-lg tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-white/60">
                Vance
              </div>
            </div>
            
            <div className="flex items-center gap-1.5 md:gap-2">
              <div className="hidden md:flex items-center gap-2">
                <button 
                  onClick={() => setTtsEnabled(!ttsEnabled)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-full border transition-all ${
                    ttsEnabled 
                      ? "bg-white/10 border-white/20 text-white shadow-[0_0_15px_rgba(255,255,255,0.1)]" 
                      : "bg-transparent border-transparent text-white/50 hover:bg-white/5 hover:text-white"
                  }`}
                >
                  <Volume2 className="w-4 h-4" />
                  <span className="text-xs font-medium">TTS</span>
                </button>
                
                <div className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 cursor-pointer transition-colors text-white/80">
                  <span className="text-xs font-medium">alloy</span>
                  <ChevronDown className="w-3 h-3 opacity-50" />
                </div>
                
                <button 
                  onClick={() => setWebSearchEnabled(!webSearchEnabled)}
                  className={`p-2 rounded-full transition-all border ${
                    webSearchEnabled 
                      ? "bg-teal-500/20 border-teal-500/30 text-teal-300 shadow-[0_0_15px_rgba(20,184,166,0.2)]" 
                      : "bg-transparent border-transparent text-white/50 hover:bg-white/5 hover:text-white"
                  }`}
                >
                  <Globe className="w-4.5 h-4.5" />
                </button>
              </div>
              
              <button className="p-2 rounded-full text-white/50 hover:bg-white/5 hover:text-white transition-colors">
                <Settings className="w-5 h-5 md:w-4.5 md:h-4.5" />
              </button>
            </div>
          </header>

          {/* Floating Slider */}
          <div className="hidden md:flex absolute top-20 right-6 z-30 items-center gap-3 p-2.5 pr-4 rounded-full bg-white/5 backdrop-blur-2xl border border-white/10 shadow-lg">
            <span className="text-xs text-white/50 font-medium pl-2">Conversation height</span>
            <div className="w-24 h-1.5 bg-white/10 rounded-full overflow-hidden relative">
              <div className="absolute left-0 top-0 bottom-0 w-[42%] bg-gradient-to-r from-violet-400 to-teal-400 rounded-full" />
              <div className="absolute left-[42%] top-1/2 -translate-y-1/2 -translate-x-1/2 w-3 h-3 bg-white rounded-full shadow-[0_0_10px_rgba(255,255,255,0.5)]" />
            </div>
            <span className="text-xs font-mono text-white/80">42%</span>
          </div>

          <div className="flex-1 flex flex-col overflow-hidden relative z-10">
            {/* Avatar Stage */}
            <div className="h-[38%] md:h-[38%] shrink-0 flex flex-col items-center justify-center relative border-b border-white/5 bg-transparent">
              {/* Emote Picker */}
              <div className="relative md:absolute mt-auto mb-2 md:mt-0 md:mb-0 md:top-4 md:left-6 flex gap-3 md:gap-1.5 p-1.5 max-w-full overflow-x-auto no-scrollbar order-last md:order-none">
                {["👋", "🙅", "👍", "😎", "🤔", "😅", "💪", "🎉"].map((emoji, i) => (
                  <button key={i} className="w-10 h-10 md:w-8 md:h-8 shrink-0 flex items-center justify-center rounded-full hover:bg-white/10 transition-colors text-xl md:text-lg opacity-80 hover:opacity-100 hover:scale-110 transform">
                    {emoji}
                  </button>
                ))}
              </div>

              {/* Avatar Ring */}
              <div className="relative flex items-center justify-center">
                {/* Speaking Ring */}
                <div className="absolute w-[100px] h-[100px] md:w-[124px] md:h-[124px] rounded-full border border-teal-400/60 animate-pulse" />
                
                {/* Core Avatar */}
                <div className="w-24 h-24 md:w-28 md:h-28 rounded-full bg-slate-900 relative z-10 overflow-hidden flex items-center justify-center">
                  <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-white/10" />
                </div>
              </div>
              <div className="mt-4 md:mt-6 px-4 py-1.5 text-xs font-medium text-white/60 tracking-wide text-center">
                Vance is speaking...
              </div>
            </div>

            {/* Transcript */}
            <div className="flex-1 overflow-y-auto px-3 md:px-6 py-4 md:py-8 space-y-4 md:space-y-6">
              <div className="max-w-3xl mx-auto space-y-4 md:space-y-6">
                
                <UserMessage content="What's a good comeback when someone says 'must be nice'?" />
                
                <VanceMessage>
                  <p>That one's a classic passive-aggressive trap! Here are a few ways to play it, depending on the vibe you want:</p>
                  <ul className="list-disc pl-5 mt-3 space-y-2 text-white/80">
                    <li><strong className="text-white">The Kill-Them-With-Kindness:</strong> "It really is! I feel very fortunate."</li>
                    <li><strong className="text-white">The Hard-Work Angle:</strong> "Thanks! A lot of long nights went into making it happen."</li>
                    <li><strong className="text-white">The Witty Deflection:</strong> "I highly recommend it."</li>
                  </ul>
                </VanceMessage>

                <UserMessage 
                  content="Look at this screenshot — does the spacing feel off?" 
                  attachment={
                    <div className="relative mt-2 rounded-xl overflow-hidden border border-white/10 w-40 md:w-48 h-28 md:h-32 bg-slate-800 flex items-center justify-center group">
                      <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/20 to-purple-500/20" />
                      <div className="w-16 h-4 bg-white/20 rounded mx-auto mb-2" />
                      <div className="flex gap-2 justify-center">
                        <div className="w-8 md:w-10 h-8 md:h-10 bg-white/10 rounded-lg" />
                        <div className="w-8 md:w-10 h-8 md:h-10 bg-white/10 rounded-lg" />
                      </div>
                    </div>
                  }
                />

                <VanceMessage>
                  <div className="p-3 md:p-4 rounded-2xl bg-white/[0.03] border border-white/10 shadow-sm mt-1">
                    <div className="flex items-center gap-2 mb-2 md:mb-3">
                      <FileCode2 className="w-4 h-4 text-violet-400" />
                      <span className="text-xs md:text-sm font-medium text-white/90">Build progress</span>
                    </div>
                    <div className="space-y-1.5 md:space-y-2 text-[11px] md:text-sm text-white/60">
                      <div className="flex items-center gap-2"><Check className="w-3.5 h-3.5 text-teal-400 shrink-0" /> Analyzing layout constraints</div>
                      <div className="flex items-center gap-2"><Check className="w-3.5 h-3.5 text-teal-400 shrink-0" /> Adjusting flex gap from 2 to 4</div>
                      <div className="flex items-center gap-2"><Check className="w-3.5 h-3.5 text-teal-400 shrink-0" /> Normalizing padding on the parent container</div>
                      <div className="flex items-center gap-2">
                        <div className="w-3.5 h-3.5 rounded-full border-2 border-white/20 border-t-white animate-spin shrink-0" /> 
                        <span className="text-white/80">Regenerating preview...</span>
                      </div>
                    </div>
                    <a href="#" className="inline-block mt-3 md:mt-4 text-[11px] md:text-sm text-teal-300 hover:text-teal-200 transition-colors">View screenshots →</a>
                  </div>
                </VanceMessage>

                <VanceMessage>
                  <p>I agree, the horizontal spacing between those buttons feels a bit tight for touch targets. I've drafted an edit to increase the gap and add some breathing room around the container.</p>
                  
                  <div className="mt-4 p-3 md:p-4 rounded-2xl bg-gradient-to-br from-violet-500/10 to-teal-500/5 border border-white/10 shadow-lg backdrop-blur-sm">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 md:gap-4">
                      <div>
                        <h4 className="text-[13px] md:text-sm font-semibold text-white">Propose edit</h4>
                        <p className="text-[11px] md:text-xs text-white/60 mt-0.5">App.tsx: Updated layout spacing</p>
                      </div>
                      <div className="flex items-center gap-1.5 md:gap-2">
                        <button className="px-3 md:px-4 py-1.5 md:py-2 rounded-full text-[11px] md:text-xs font-medium text-white/70 hover:text-white hover:bg-white/5 transition-colors">
                          Cancel
                        </button>
                        <button className="px-3 md:px-4 py-1.5 md:py-2 rounded-full text-[11px] md:text-xs font-medium bg-white/10 hover:bg-white/20 border border-white/10 transition-colors">
                          Edit
                        </button>
                        <button className="px-3 md:px-4 py-1.5 md:py-2 rounded-full text-[11px] md:text-xs font-medium bg-white text-black hover:bg-white/90 shadow-[0_0_15px_rgba(255,255,255,0.3)] transition-all">
                          Accept
                        </button>
                      </div>
                    </div>
                  </div>
                </VanceMessage>
              </div>
            </div>
          </div>

          {/* Composer */}
          <div className="shrink-0 px-3 md:px-6 py-3 md:py-4 bg-gradient-to-t from-[#0a0a16] via-[#0a0a16] to-transparent relative z-20 flex flex-col justify-end">
            <div className="max-w-3xl mx-auto w-full relative">
              {/* Attachment Chip */}
              <div className="absolute -top-10 left-4">
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/10 shadow-lg text-xs font-medium text-white/80">
                  <div className="w-4 h-4 rounded bg-gradient-to-br from-indigo-400 to-purple-400" />
                  hero.png
                  <button className="p-0.5 hover:bg-white/20 rounded-full transition-colors ml-1">
                    <X className="w-3 h-3" />
                  </button>
                </div>
              </div>

              <div className="flex items-end gap-1.5 md:gap-2 bg-white/5 backdrop-blur-2xl border border-white/10 rounded-[28px] md:rounded-3xl p-1.5 md:p-2 shadow-[0_8px_30px_rgba(0,0,0,0.5),inset_0_1px_0_rgba(255,255,255,0.1)] transition-all focus-within:bg-white/[0.07] focus-within:border-white/20">
                <button className="p-2.5 md:p-3 text-white/40 hover:text-white hover:bg-white/10 rounded-full transition-colors shrink-0">
                  <Paperclip className="w-4.5 h-4.5 md:w-5 md:h-5" />
                </button>
                
                <textarea 
                  className="flex-1 bg-transparent border-0 resize-none outline-none py-2.5 md:py-3 px-1 md:px-2 text-white placeholder:text-white/30 max-h-[120px] md:max-h-[150px] min-h-[40px] md:min-h-[44px] text-[14px] md:text-[15px]"
                  placeholder="Message Vance..."
                  rows={1}
                />
                
                <div className="flex items-center gap-0.5 md:gap-1 shrink-0 pb-0.5 pr-0.5 md:pb-1 md:pr-1">
                  <button className="p-2 md:p-2.5 text-white/40 hover:text-white hover:bg-white/10 rounded-full transition-colors">
                    <Mic className="w-4.5 h-4.5 md:w-5 md:h-5" />
                  </button>
                  <button className="p-2 md:p-2.5 text-white text-black bg-white hover:bg-white/90 rounded-full transition-all shadow-[0_0_20px_rgba(255,255,255,0.2)] ml-0.5 md:ml-1">
                    <ArrowUp className="w-4.5 h-4.5 md:w-5 md:h-5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function SidebarItem({ title, active = false }: { title: string, active?: boolean }) {
  return (
    <div className={`group flex items-center justify-between px-3 py-2 rounded-xl cursor-pointer transition-colors ${
      active ? "bg-white/10 text-white" : "text-white/60 hover:bg-white/5 hover:text-white/90"
    }`}>
      <span className="text-sm truncate pr-2">{title}</span>
      <button className="opacity-0 group-hover:opacity-100 p-1.5 hover:bg-white/10 rounded-md transition-all text-white/40 hover:text-red-400">
        <Trash2 className="w-3.5 h-3.5" />
      </button>
    </div>
  );
}

function UserMessage({ content, attachment }: { content: string, attachment?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-end w-full pl-6 md:pl-12">
      <div className="bg-white/10 backdrop-blur-md border border-white/5 text-white px-4 md:px-5 py-3 md:py-3.5 rounded-3xl rounded-tr-sm max-w-[92%] md:max-w-[85%] shadow-sm">
        <p className="text-[14px] md:text-[15px] leading-relaxed">{content}</p>
        {attachment}
      </div>
    </div>
  );
}

function VanceMessage({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-start gap-3 md:gap-4 w-full pr-4 md:pr-12">
      <div className="w-7 h-7 md:w-8 md:h-8 rounded-full bg-gradient-to-br from-violet-500 to-cyan-500 shrink-0 flex items-center justify-center shadow-lg border border-white/20 mt-1">
        <div className="w-1.5 h-1.5 md:w-2 md:h-2 rounded-full bg-white shadow-[0_0_10px_rgba(255,255,255,0.8)]" />
      </div>
      <div className="flex-1 text-[14px] md:text-[15px] leading-relaxed text-white/90 pt-1">
        {children}
      </div>
    </div>
  );
}
