# Vance Skills

Specialized procedural knowledge Vance can load on-demand during build mode.

Each skill is a markdown file with:

- A short YAML-ish front-matter (`name`, `when_to_use`)
- Step-by-step procedure for a specific recurring build task

Vance lists skills with `list_skills`, loads one with `load_skill(name)`, and
can author new skills with `create_skill(name, when_to_use, content)` whenever
he discovers a workflow worth remembering.

Skills are the canonical place to teach Vance "how we do X around here"
without bloating the always-on system prompt.
