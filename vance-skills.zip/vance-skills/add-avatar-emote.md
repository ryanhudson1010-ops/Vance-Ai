---
name: add-avatar-emote
when_to_use: Adding a new facial expression, color theme, or animated emote to the holographic 3D avatar.
---

# Add a new avatar emote

The 3D avatar lives at `artifacts/vance/src/components/VanceAvatar3D.tsx`. It's a CSS/SVG-driven holographic rendering with prop-driven emote system. The photo-mode wrapper is `VanceFaceAvatar.tsx` — it falls back to VanceAvatar3D when no avatar URL is set.

## Steps

1. **Read VanceAvatar3D.tsx** with offset/limit, find the existing `emote` prop's union type and the switch/lookup that maps emote name → visual params.
2. **Add the new emote name** to the union type and the lookup table. Pick colors that fit the holographic aesthetic (cyan/magenta/teal range).
3. **If the emote needs custom motion**, add a Framer Motion variant. Keep the duration short (300-600ms) so it feels responsive.
4. **Wire the trigger**: most emotes are triggered from chat-side logic (e.g. "become X" persona, voice command parsing). Find the trigger site and add the new emote name to the matcher.
5. **Verify**: `run_typecheck vance`, hot-reload picks it up. Confirm visually in the preview pane.

## Common pitfalls

- The avatar has TWO modes (3D fallback vs photo). For non-color emotes that should work in both modes, edit `VanceFaceAvatar.tsx` too.
- Color values are hex strings, not Tailwind class names — these are inline-styled SVG fills.
