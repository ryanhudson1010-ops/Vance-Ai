---
name: add-db-column
when_to_use: Adding a new column or table to the Postgres schema that the app will read/write.
---

# Add a database column or table

Drizzle is the ORM and the source of truth lives in `lib/db/src/schema/`.

## Steps

1. **Schema edit**: Find the right schema file (e.g. `lib/db/src/schema/vance-profile.ts` for profile fields). Add the column with a Drizzle column type and any defaults.
2. **Push**: Call `run_db_push`. This runs `pnpm --filter @workspace/db run push` which uses `drizzle-kit push` to sync the live database. The user's `DATABASE_URL` is configured.
3. **If the new column is exposed via API**: update `lib/api-spec/openapi.yaml` to reflect the new field, then `run_codegen`.
4. **Backend reads/writes**: import the table from `@workspace/db` (re-exported from the schema). Use Drizzle's typed query builder — never raw SQL strings.
5. **Verify**: `run_typecheck db`, `run_typecheck api-server`, and any frontend package that consumes the field.

## Common pitfalls

- Forgetting `run_db_push` — the new column exists in code but not in the DB; queries fail at runtime.
- Adding a `notNull()` column without a default to a table that already has rows — push will fail. Either add a default, or do nullable first then backfill.
- The `vance_profile` table is a single-row pattern — `getOrCreateProfile()` uses `ORDER BY id ASC LIMIT 1`. Don't break that contract.
