---
name: redesign-ui-component
when_to_use: Reskinning, restyling, or visually overhauling an existing React component without changing its behaviour or props.
---

# Redesign a UI component

The frontend is React 19 + Tailwind v4 + Framer Motion. There is NO tailwind config file — colors come from CSS variables in `artifacts/vance/src/index.css`.

## Steps

1. **Read the current component** (offset/limit if it's large).
2. **Read `index.css`** to confirm which design tokens (CSS vars) exist before inventing new color names. Tailwind classes like `bg-primary` resolve via these vars.
3. **Edit** the component with `edit_file`. Don't add `import React from "react"` at the top — the JSX transformer handles it (user preference, see replit.md).
4. **For animations**, prefer Framer Motion (already a dep) over hand-rolled CSS transitions for anything beyond simple hover.
5. **For new tokens**, edit `index.css` to add the CSS var, then use the Tailwind class.
6. **Verify**: `run_typecheck vance`. Vite HMR will hot-reload — no restart needed for frontend.

## Common pitfalls

- Inventing tailwind color names that don't exist (`bg-vance-blue`) — they need to be defined as CSS vars first.
- Adding a `React` default import — user preference is no React imports at top of `.tsx` files.
- Heavy re-rendering in animated lists — wrap items in `motion.div` with a stable `key` and use `AnimatePresence` for enter/exit.
