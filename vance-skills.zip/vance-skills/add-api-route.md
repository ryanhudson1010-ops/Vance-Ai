---
name: add-api-route
when_to_use: Adding a new HTTP endpoint to the api-server that the frontend will call (forms, data fetching, mutations).
---

# Add an API route end-to-end

This is a contract-first repo. The OpenAPI spec is the source of truth — Zod schemas and React Query hooks are generated from it.

## Steps

1. **Spec first**: Edit `lib/api-spec/openapi.yaml`. Add the new path under `paths:` with full request/response schemas (use `$ref` to existing components where you can).
2. **Codegen**: Call `run_codegen`. This regenerates `lib/api-zod/` (Zod schemas) and the React Query hooks. Wait for it to finish before importing the new hook.
3. **Backend handler**: Add the route in the appropriate file under `artifacts/api-server/src/routes/`. Validate the request body with the generated Zod schema. Use `req.log` for logging — never `console.log`. Return JSON matching the response schema.
4. **Frontend usage**: Import the generated hook from `@workspace/api-hooks` (or wherever the orval config writes — check `lib/api-spec/orval.config.ts`). Use it in the component with React Query semantics.
5. **Verify**: `run_typecheck vance` and `run_typecheck api-server`. If you edited the api-server, finish with `restart_api_server`.

## Common pitfalls

- Forgetting to call `run_codegen` after the spec change — the hook won't exist and typecheck will fail.
- Missing the Zod validation in the handler — runtime crashes on bad input.
- Using `fetch()` directly in the component instead of the generated hook — defeats the contract.
